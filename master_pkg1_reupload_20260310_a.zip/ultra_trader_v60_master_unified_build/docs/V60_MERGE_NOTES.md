# v60 Merge Notes

This project is the unified production-oriented tree based on v51 plus the strongest later modules.

Practical guidance:
- treat this folder as the canonical codebase
- do not create new parallel version trees
- add new work directly here behind tests and docs
