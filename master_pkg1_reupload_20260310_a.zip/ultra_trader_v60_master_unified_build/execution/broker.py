from __future__ import annotations

from abc import ABC, abstractmethod

from common.models import Fill, Order, OrderStatus, OrderType
from ops.metrics import MetricsRegistry


class Broker(ABC):
    @abstractmethod
    async def submit(self, order: Order, market_price: float) -> Fill:
        raise NotImplementedError

    @abstractmethod
    async def list_open_orders(self) -> list[str]:
        raise NotImplementedError


class PaperBroker(Broker):
    def __init__(self, metrics: MetricsRegistry, fee_bps: float = 2.0) -> None:
        self.metrics = metrics
        self.fee_bps = fee_bps
        self._open_orders: set[str] = set()

    async def submit(self, order: Order, market_price: float) -> Fill:
        self._open_orders.add(order.client_order_id)
        crossed = order.order_type == OrderType.MARKET or (order.side.value == 'BUY' and (order.limit_price or 0) >= market_price) or (order.side.value == 'SELL' and (order.limit_price or 0) <= market_price)
        if not crossed:
            return Fill(client_order_id=order.client_order_id, venue=order.venue, symbol=order.symbol, side=order.side, qty=0.0, price=order.limit_price or market_price, strategy=order.strategy)
        fee = market_price * order.qty * (self.fee_bps / 10000)
        fill = Fill(
            client_order_id=order.client_order_id,
            venue=order.venue,
            symbol=order.symbol,
            side=order.side,
            qty=order.qty,
            price=market_price,
            fee=fee,
            strategy=order.strategy,
        )
        self._open_orders.discard(order.client_order_id)
        self.metrics.increment("fills_total")
        return fill

    async def list_open_orders(self) -> list[str]:
        return sorted(self._open_orders)
