import os
import pytest

from execution.live.adapters import BinanceRestBroker, BybitRestBroker, MexcRestBroker, BitgetRestBroker
from market.live.base import ExchangeCredentials
from ops.metrics import MetricsRegistry


def _has_env(prefix: str) -> bool:
    return bool(os.getenv(f'{prefix}_API_KEY') and os.getenv(f'{prefix}_API_SECRET'))


@pytest.mark.skipif(not (_has_env('BINANCE') and os.getenv('RUN_SANDBOX_TESTS') == '1'), reason='Binance sandbox credentials not configured')
@pytest.mark.asyncio
async def test_binance_testnet_exchange_info_smoke():
    broker = BinanceRestBroker(ExchangeCredentials(api_key=os.getenv('BINANCE_API_KEY', ''), api_secret=os.getenv('BINANCE_API_SECRET', '')), MetricsRegistry())
    vf = await broker.fetch_symbol_filter('BTCUSDT')
    assert vf.symbol == 'BTCUSDT'
    await broker.aclose()


@pytest.mark.skipif(not (_has_env('BYBIT') and os.getenv('RUN_SANDBOX_TESTS') == '1'), reason='Bybit sandbox credentials not configured')
@pytest.mark.asyncio
async def test_bybit_testnet_exchange_info_smoke():
    broker = BybitRestBroker(ExchangeCredentials(api_key=os.getenv('BYBIT_API_KEY', ''), api_secret=os.getenv('BYBIT_API_SECRET', '')), MetricsRegistry())
    vf = await broker.fetch_symbol_filter('BTCUSDT')
    assert vf.symbol == 'BTCUSDT'
    await broker.aclose()


@pytest.mark.skipif(not (_has_env('MEXC') and os.getenv('RUN_SANDBOX_TESTS') == '1'), reason='MEXC sandbox credentials not configured')
@pytest.mark.asyncio
async def test_mexc_exchange_info_smoke():
    broker = MexcRestBroker(ExchangeCredentials(api_key=os.getenv('MEXC_API_KEY', ''), api_secret=os.getenv('MEXC_API_SECRET', '')), MetricsRegistry())
    vf = await broker.fetch_symbol_filter('BTCUSDT')
    assert vf.symbol == 'BTCUSDT'
    await broker.aclose()


@pytest.mark.skipif(not (_has_env('BITGET') and os.getenv('RUN_SANDBOX_TESTS') == '1'), reason='Bitget sandbox credentials not configured')
@pytest.mark.asyncio
async def test_bitget_exchange_info_smoke():
    broker = BitgetRestBroker(ExchangeCredentials(api_key=os.getenv('BITGET_API_KEY', ''), api_secret=os.getenv('BITGET_API_SECRET', ''), passphrase=os.getenv('BITGET_API_PASSPHRASE', '')), MetricsRegistry())
    vf = await broker.fetch_symbol_filter('BTCUSDT')
    assert vf.symbol == 'BTCUSDT'
    await broker.aclose()
