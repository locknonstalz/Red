# Strategy Suite

## 1. Market Making Engine
Quotes passive two-sided liquidity around a rolling fair value. The quote width adapts to spread and realized micro-volatility; inventory skew biases quotes away from the current inventory.

## 2. Cross-Exchange Arbitrage
Maintains the latest quote snapshot across venues and fires paired buy/sell legs when the bid on one venue crosses the ask on another by more than the configured edge.

## 3. Statistical Arbitrage
Tracks the spread between a lead and lag venue, converts the spread into a z-score, and opens/closes a hedged pair when the spread deviates from and then mean reverts back toward equilibrium.

## 4. Liquidity Taking Engine
Aggressively crosses the spread on micro-breakouts when the spread is tight enough that urgency dominates passive waiting.

## Practical Notes
These strategies are intentionally conservative compared with a full production prop stack. They are integrated with the same risk, journal, reconciliation, and live orchestration layers already present in the engine.
