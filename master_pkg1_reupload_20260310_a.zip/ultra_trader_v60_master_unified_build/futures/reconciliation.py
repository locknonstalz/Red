from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from common.models import Fill, Position, Side
from futures.models import FundingSnapshot
from storage.base import Journal


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class FuturesMarketTruth:
    venue: str
    symbol: str
    mark_price: float = 0.0
    index_price: float = 0.0
    liquidation_price: float = 0.0
    funding_rate: float = 0.0
    open_interest: float = 0.0
    basis_bps: float = 0.0
    ts: datetime = field(default_factory=utc_now)

    def to_payload(self) -> dict[str, Any]:
        return {
            'mark_price': self.mark_price,
            'index_price': self.index_price,
            'liquidation_price': self.liquidation_price,
            'funding_rate': self.funding_rate,
            'open_interest': self.open_interest,
            'basis_bps': self.basis_bps,
            'ts': self.ts.isoformat(),
        }


@dataclass(slots=True)
class HedgeLegState:
    symbol: str
    venue: str
    side: Side
    qty: float
    filled_qty: float = 0.0
    avg_fill_price: float = 0.0
    client_order_id: str = ''


@dataclass(slots=True)
class HedgeLifecycle:
    hedge_id: str
    futures_leg: HedgeLegState
    spot_leg: HedgeLegState
    status: str = 'PENDING'

    def apply_fill(self, fill: Fill) -> None:
        for leg in (self.futures_leg, self.spot_leg):
            if fill.client_order_id and fill.client_order_id == leg.client_order_id:
                total_notional = leg.avg_fill_price * leg.filled_qty + fill.price * fill.qty
                leg.filled_qty += fill.qty
                leg.avg_fill_price = total_notional / leg.filled_qty if leg.filled_qty else 0.0
        if self.futures_leg.filled_qty >= self.futures_leg.qty and self.spot_leg.filled_qty >= self.spot_leg.qty:
            self.status = 'HEDGED'
        elif self.futures_leg.filled_qty or self.spot_leg.filled_qty:
            self.status = 'PARTIAL'


class FuturesTruthReconciliationService:
    def __init__(self, journal: Journal) -> None:
        self.journal = journal
        self._truth: dict[tuple[str, str], FuturesMarketTruth] = {}
        self._hedges: dict[str, HedgeLifecycle] = {}

    def apply_funding(self, snapshot: FundingSnapshot) -> FuturesMarketTruth:
        key = (snapshot.venue, snapshot.symbol)
        truth = self._truth.get(key, FuturesMarketTruth(venue=snapshot.venue, symbol=snapshot.symbol))
        truth.funding_rate = snapshot.funding_rate
        truth.open_interest = snapshot.open_interest
        truth.basis_bps = snapshot.basis_bps
        truth.ts = snapshot.ts
        self._truth[key] = truth
        self.journal.record_protection_event('futures_truth', f'{snapshot.venue}:{snapshot.symbol}', 'funding_update', truth.to_payload())
        return truth

    def apply_mark_price(self, venue: str, symbol: str, *, mark_price: float, index_price: float = 0.0, liquidation_price: float = 0.0, basis_bps: float = 0.0, open_interest: float = 0.0) -> FuturesMarketTruth:
        key = (venue, symbol)
        truth = self._truth.get(key, FuturesMarketTruth(venue=venue, symbol=symbol))
        truth.mark_price = mark_price
        truth.index_price = index_price
        truth.liquidation_price = liquidation_price
        truth.basis_bps = basis_bps
        truth.open_interest = open_interest or truth.open_interest
        truth.ts = utc_now()
        self._truth[key] = truth
        self.journal.record_protection_event('futures_truth', f'{venue}:{symbol}', 'mark_price_update', truth.to_payload())
        return truth

    def apply_position_truth(self, position: Position) -> None:
        self.journal.save_position_snapshot(position)
        self.journal.record_protection_event('futures_truth', f'{position.venue}:{position.symbol}', 'position_truth', {'qty': position.qty, 'avg_price': position.avg_price, 'mark_price': position.mark_price, 'realized_pnl': position.realized_pnl})

    def register_hedge(self, hedge: HedgeLifecycle) -> None:
        self._hedges[hedge.hedge_id] = hedge
        self.journal.record_protection_event('hedge_lifecycle', hedge.hedge_id, 'registered', {'futures_qty': hedge.futures_leg.qty, 'spot_qty': hedge.spot_leg.qty})

    def apply_hedge_fill(self, hedge_id: str, fill: Fill) -> HedgeLifecycle | None:
        hedge = self._hedges.get(hedge_id)
        if hedge is None:
            return None
        before = hedge.status
        hedge.apply_fill(fill)
        self.journal.record_protection_event('hedge_lifecycle', hedge_id, f'fill_{hedge.status.lower()}', {'client_order_id': fill.client_order_id, 'qty': fill.qty, 'price': fill.price, 'before': before, 'after': hedge.status})
        return hedge

    def truth(self, venue: str, symbol: str) -> FuturesMarketTruth | None:
        return self._truth.get((venue, symbol))

    def hedge(self, hedge_id: str) -> HedgeLifecycle | None:
        return self._hedges.get(hedge_id)
