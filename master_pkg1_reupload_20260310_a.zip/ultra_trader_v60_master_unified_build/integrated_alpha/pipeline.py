
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Sequence

from alpha_factory.factory import CandidateTemplate, StrategyGenerator, StrategyFactoryService
from research.regime_ensemble import RegimeAwareSpecialistEnsemble, SpecialistSleeve
from ops.micro_live_controller import MicroLiveController, StrategyRunInput

@dataclass
class IntegratedAlphaPipeline:
    templates: Sequence[CandidateTemplate]
    factory: StrategyFactoryService = field(init=False)
    controller: MicroLiveController = field(default_factory=MicroLiveController)
    ensemble: RegimeAwareSpecialistEnsemble = field(default_factory=RegimeAwareSpecialistEnsemble)

    def __post_init__(self):
        self.factory = StrategyFactoryService(generator=StrategyGenerator(list(self.templates)))

    def discover_test_route(self, regime: str, allowed_venues: Sequence[str], market_snapshot: Dict[str, float]) -> Dict[str, object]:
        candidates = self.factory.discover(regime=regime, allowed_venues=allowed_venues, market_snapshot=market_snapshot)
        routed = self.factory.router.select(candidates, regime=regime, top_n=5)
        return {'candidates': candidates, 'routed': routed}

    def evaluate_micro_live(self, runs: Sequence[StrategyRunInput]) -> Dict[str, object]:
        results = {run.strategy: self.controller.evaluate(run) for run in runs}
        sleeves: List[SpecialistSleeve] = []
        for run in runs:
            result = results[run.strategy]
            scorecard = result['scorecard']
            family = run.strategy
            if 'funding' in run.strategy:
                family = 'funding_carry'
            elif 'cross' in run.strategy:
                family = 'cross_exchange_arb'
            elif 'market' in run.strategy:
                family = 'market_making'
            sleeves.append(SpecialistSleeve(
                name=run.strategy,
                family=family,
                expected_edge=max(scorecard['net_pnl'], 0.0) / max(run.capacity_score * 100.0, 1.0),
                realized_net_pnl=scorecard['net_pnl'],
                drawdown_pct=2.0 if scorecard['net_pnl'] > 0 else 6.0,
                cost_drag_pct=(scorecard['fees'] + scorecard['slippage_cost'] + scorecard['hedge_cost']) / max(abs(scorecard['gross_pnl']), 1.0),
            ))
        allocation = self.ensemble.allocate(sleeves, regime='carry')
        if not allocation or sum(allocation.values()) == 0:
            n = max(len(sleeves), 1)
            allocation = {s.name: round(1.0 / n, 4) for s in sleeves}
        return {'results': results, 'allocation': allocation}
