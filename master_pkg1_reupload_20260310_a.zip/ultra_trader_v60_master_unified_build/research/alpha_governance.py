from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any

from ops.go_live import GoLiveScoringService
from ops.incidents import LivePromotionGateService
from research.alpha_lab import AlphaLabService


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class HypothesisApproval:
    hypothesis_id: str
    status: str = 'proposed'
    requested_by: str | None = None
    approved_by: str | None = None
    notes: str = ''
    updated_at: datetime = field(default_factory=utc_now)

    def snapshot(self) -> dict[str, Any]:
        row = asdict(self)
        row['updated_at'] = self.updated_at.isoformat()
        return row


@dataclass(slots=True)
class StrategyHealth:
    strategy: str
    score: float
    stage: str
    healthy: bool
    reasons: list[str] = field(default_factory=list)
    recommendation: str = 'hold'


@dataclass(slots=True)
class DemotionDecision:
    strategy: str
    from_stage: str
    to_stage: str
    reason: str
    triggered: bool


class AlphaGovernanceService:
    def __init__(self, *, alpha_lab: AlphaLabService, promotions: LivePromotionGateService, go_live: GoLiveScoringService) -> None:
        self.alpha_lab = alpha_lab
        self.promotions = promotions
        self.go_live = go_live
        self._approvals: dict[str, HypothesisApproval] = {}
        self._history: list[dict[str, Any]] = []

    def propose_hypothesis(self, hypothesis_id: str, actor: str, notes: str = '') -> dict[str, Any]:
        row = self._approvals.setdefault(hypothesis_id, HypothesisApproval(hypothesis_id=hypothesis_id))
        row.status = 'proposed'
        row.requested_by = actor
        row.notes = notes
        row.updated_at = utc_now()
        snap = row.snapshot()
        self._history.append({'ts': row.updated_at.isoformat(), 'event': 'hypothesis_proposed', 'hypothesis_id': hypothesis_id, 'actor': actor, 'notes': notes})
        return {'ok': True, 'approval': snap}

    def approve_hypothesis(self, hypothesis_id: str, actor: str, notes: str = '') -> dict[str, Any]:
        row = self._approvals.setdefault(hypothesis_id, HypothesisApproval(hypothesis_id=hypothesis_id))
        row.status = 'approved'
        row.approved_by = actor
        row.notes = notes or row.notes
        row.updated_at = utc_now()
        self.alpha_lab.hypotheses.set_status(hypothesis_id, 'approved')
        snap = row.snapshot()
        self._history.append({'ts': row.updated_at.isoformat(), 'event': 'hypothesis_approved', 'hypothesis_id': hypothesis_id, 'actor': actor, 'notes': row.notes})
        return {'ok': True, 'approval': snap}

    def strategy_health(self, strategy: str, venue: str, symbol: str) -> StrategyHealth:
        alpha = self.alpha_lab.snapshot([strategy], venue, symbol)
        decay = alpha.decay_reports[0] if alpha.decay_reports else None
        score_row = self.go_live.strategy_score(strategy)
        stage = str(score_row.get('components', {}).get('current_stage', 'research'))
        score = float(score_row.get('score', 0.0))
        if score <= 1.0:
            score *= 100.0
        healthy = True
        reasons: list[str] = []
        recommendation = 'promote_if_cap_ok' if score >= 75 else 'hold'
        if decay is not None and decay.is_decaying:
            healthy = False
            reasons.append(f'decay:{decay.decay_score:.1f}')
            recommendation = 'demote_or_shadow'
        if score < 55:
            healthy = False
            reasons.append(f'low_readiness:{score:.1f}')
            recommendation = 'paper_or_shadow'
        return StrategyHealth(strategy=strategy, score=score, stage=stage, healthy=healthy, reasons=reasons, recommendation=recommendation)

    def maybe_demote(self, strategy: str, venue: str, symbol: str, actor: str = 'governance') -> DemotionDecision:
        health = self.strategy_health(strategy, venue, symbol)
        current = next((row for row in self.promotions.list_promotions() if row['strategy'] == strategy), None)
        from_stage = str(current['current_stage']) if current else 'research'
        order = list(self.promotions.stages)
        to_stage = from_stage
        triggered = False
        reason = 'healthy'
        if not health.healthy and from_stage in order:
            idx = order.index(from_stage)
            to_stage = order[max(0, idx - 1)]
            triggered = to_stage != from_stage
            reason = ','.join(health.reasons) or health.recommendation
            if triggered:
                record = self.promotions._record(strategy)
                record.current_stage = to_stage
                record.pending_stage = None
                record.history.append({'ts': utc_now().isoformat(), 'actor': actor, 'event': 'automatic_demotion', 'from_stage': from_stage, 'to_stage': to_stage, 'reason': reason})
                self._history.append({'ts': utc_now().isoformat(), 'event': 'automatic_demotion', 'strategy': strategy, 'from_stage': from_stage, 'to_stage': to_stage, 'reason': reason})
        return DemotionDecision(strategy=strategy, from_stage=from_stage, to_stage=to_stage, reason=reason, triggered=triggered)

    def sleeve_rotation(self, strategies: list[str], venue: str, symbol: str) -> list[dict[str, Any]]:
        snap = self.alpha_lab.snapshot(strategies, venue, symbol)
        out: list[dict[str, Any]] = []
        for row in snap.sleeve_allocations:
            health = self.strategy_health(row.strategy, venue, symbol)
            multiplier = 1.0 if health.healthy else 0.5
            out.append({
                'strategy': row.strategy,
                'target_notional_pct': round(row.target_notional_pct * multiplier, 4),
                'base_weight': row.weight,
                'health_score': health.score,
                'healthy': health.healthy,
                'recommendation': health.recommendation,
            })
        return sorted(out, key=lambda x: x['target_notional_pct'], reverse=True)

    def snapshot(self, strategies: list[str], venue: str, symbol: str) -> dict[str, Any]:
        return {
            'approvals': [row.snapshot() for row in self._approvals.values()],
            'health': [asdict(self.strategy_health(strategy, venue, symbol)) for strategy in strategies],
            'sleeve_rotation': self.sleeve_rotation(strategies, venue, symbol),
            'history': self._history[-50:],
        }
