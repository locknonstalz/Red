# Live Certification Matrix

## Purpose
This matrix defines the minimum sign-off gates before a venue/account pair can be marked PROD_READY.

| Venue | Auth/login | Private WS | Balance sync | Position sync | Order new | Amend | Cancel | Fill truth | Gap recovery | Reconnect | Sandbox E2E | Prod sign-off |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Binance | Required | Required | Required | Required | Required | Required | Required | Required | Required | Required | Required | Pending |
| Bybit | Required | Required | Required | Required | Required | Required | Required | Required | Required | Required | Required | Pending |
| MEXC | Required | Required | Required | Required | Required | Required | Required | Required | Required | Required | Required | Pending |
| Bitget | Required | Required | Required | Required | Required | Required | Required | Required | Required | Required | Required | Pending |

## Required evidence per venue
- successful login and re-auth after forced credential/session expiry
- forced websocket disconnect recovery without event loss
- duplicate event ingestion test proves idempotency
- balance/order/fill truth matches exchange REST reconciliation snapshot
- cancel/amend edge cases validated
- sequence or checkpoint continuity validated where venue supports it
- alert firing and routing verified
- rollback drill documented

## Promotion states
- `NOT_STARTED`
- `IN_PROGRESS`
- `BLOCKED`
- `SANDBOX_CERTIFIED`
- `STAGING_CERTIFIED`
- `PROD_READY`

## Sign-off template
- trading engineering
- SRE
- risk owner
- on-call owner
- security owner
