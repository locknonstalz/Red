from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from statistics import fmean, pstdev

from common.models import Side, Tick


@dataclass(slots=True)
class FeatureSnapshot:
    features: dict[str, float]
    price: float
    tick_index: int


class OnlineFeatureStore:
    def __init__(self, lookback: int = 64) -> None:
        self.lookback = lookback
        self._prices: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=lookback))
        self._spreads: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=lookback))
        self._tick_index: dict[tuple[str, str], int] = defaultdict(int)

    def observe_tick(self, tick: Tick) -> FeatureSnapshot:
        key = (tick.venue, tick.symbol)
        self._prices[key].append(float(tick.mid))
        self._spreads[key].append(float(tick.spread))
        self._tick_index[key] += 1
        return FeatureSnapshot(features=self.features_for_tick(tick), price=tick.mid, tick_index=self._tick_index[key])

    def current_tick_index(self, venue: str, symbol: str) -> int:
        return self._tick_index[(venue, symbol)]

    def features_for_signal(self, tick: Tick, side: Side, strength: float) -> dict[str, float]:
        features = self.features_for_tick(tick)
        features['side_sign'] = 1.0 if side == Side.BUY else -1.0
        features['base_strength'] = float(strength)
        features['signed_momentum_1'] = features['momentum_1'] * features['side_sign']
        features['signed_momentum_3'] = features['momentum_3'] * features['side_sign']
        features['signed_orderbook_pressure'] = features['orderbook_pressure'] * features['side_sign']
        return features

    def features_for_tick(self, tick: Tick) -> dict[str, float]:
        key = (tick.venue, tick.symbol)
        prices = list(self._prices[key])
        spreads = list(self._spreads[key])
        if not prices:
            prices = [tick.mid]
        last = prices[-1]
        prev = prices[-2] if len(prices) >= 2 else last
        mean_fast = fmean(prices[-5:]) if len(prices) >= 5 else fmean(prices)
        mean_slow = fmean(prices[-20:]) if len(prices) >= 20 else fmean(prices)
        sigma = pstdev(prices[-20:]) if len(prices) >= 3 else 0.0
        spread_mean = fmean(spreads[-10:]) if spreads else tick.spread
        microprice = (tick.bid + tick.ask + tick.mid) / 3.0
        return {
            'bias': 1.0,
            'momentum_1': (last - prev) / last if last else 0.0,
            'momentum_3': (last - prices[-4]) / last if len(prices) >= 4 and last else 0.0,
            'mean_reversion_gap': (last - mean_slow) / mean_slow if mean_slow else 0.0,
            'fast_slow_gap': (mean_fast - mean_slow) / mean_slow if mean_slow else 0.0,
            'volatility_20': sigma / mean_slow if mean_slow else 0.0,
            'spread_bps': (tick.spread / tick.mid) * 10000.0 if tick.mid else 0.0,
            'spread_regime': (tick.spread / spread_mean) if spread_mean else 1.0,
            'orderbook_pressure': (microprice - tick.mid) / tick.mid if tick.mid else 0.0,
        }
