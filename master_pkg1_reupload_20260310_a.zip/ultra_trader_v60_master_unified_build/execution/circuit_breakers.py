from __future__ import annotations

import time
from dataclasses import dataclass


@dataclass(slots=True)
class CircuitState:
    failures: int = 0
    opened_at: float = 0.0


class CircuitBreaker:
    def __init__(self, max_failures: int, cooldown_sec: float) -> None:
        self.max_failures = max_failures
        self.cooldown_sec = cooldown_sec
        self.state = CircuitState()

    def allow(self) -> bool:
        if self.state.failures < self.max_failures:
            return True
        return (time.time() - self.state.opened_at) >= self.cooldown_sec

    def on_success(self) -> None:
        self.state = CircuitState()

    def on_failure(self) -> None:
        self.state.failures += 1
        if self.state.failures >= self.max_failures and self.state.opened_at == 0:
            self.state.opened_at = time.time()
