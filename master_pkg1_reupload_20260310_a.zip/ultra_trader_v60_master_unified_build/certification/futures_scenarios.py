from __future__ import annotations

from certification.models import VenueCertificationConfig


def default_futures_certification_configs() -> dict[str, VenueCertificationConfig]:
    return {
        'binance': VenueCertificationConfig(venue='binance', environment='futures-testnet', symbol='BTCUSDT', notes='USDⓈ-M futures testnet create/cancel plus mark/funding truth checks.'),
        'bybit': VenueCertificationConfig(venue='bybit', environment='futures-testnet', symbol='BTCUSDT', notes='Bybit linear futures testnet order/private-topic validation.'),
        'mexc': VenueCertificationConfig(venue='mexc', environment='futures-live-guarded', symbol='BTC_USDT', allow_live_micro_orders=False, notes='MEXC contract endpoints require explicit live opt-in for micro-order certification.'),
        'bitget': VenueCertificationConfig(venue='bitget', environment='futures-demo', symbol='BTCUSDT', require_passphrase=True, notes='Bitget futures demo with private order/account/position verification.'),
    }
