from common.models import Fill, Order, Side, Tick
from config.settings import Settings
from execution.sor import SmartOrderRouter
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from research.venue_health import VenueHealthScoringService
from risk.advanced_limits import AdvancedRiskSettings, CorrelationConcentrationRiskGuard
from storage.journal import SqliteJournal
from strategy.shadow import ShadowDeploymentService
from runtime.bootstrap import build_runtime_bundle


def test_smart_router_prefers_healthier_venue():
    vh = VenueHealthScoringService(window=16)
    for _ in range(12):
        vh.observe_tick(Tick('binance', 'BTC/USDT', 100.0, 99.95, 100.05))
        vh.observe_tick(Tick('bybit', 'BTC/USDT', 100.0, 99.98, 100.02))
    for _ in range(4):
        vh.record_execution_result('binance', success=False)
    vh.record_execution_result('bybit', success=True)
    router = SmartOrderRouter(vh, health_weight=0.8)
    decision = router.route('BTC/USDT', Side.BUY, {
        'binance': Tick('binance', 'BTC/USDT', 99.99, 99.94, 100.00),
        'bybit': Tick('bybit', 'BTC/USDT', 100.02, 100.01, 100.03),
    })
    assert decision is not None
    assert decision.selected_venue == 'bybit'


def test_advanced_risk_blocks_correlation_and_concentration(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'risk.db'))
    portfolio = PortfolioService('USDT', journal, MetricsRegistry())
    guard = CorrelationConcentrationRiskGuard(portfolio, AdvancedRiskSettings(max_symbol_concentration_pct=0.40, max_correlated_exposure_pct=0.50, correlation_window=8, correlation_threshold=0.8))
    for px in [100, 101, 102, 103, 104, 105, 106, 107]:
        guard.observe_tick(Tick('binance', 'BTC/USDT', px, px - 0.1, px + 0.1))
        guard.observe_tick(Tick('binance', 'ETH/USDT', px * 0.5, px * 0.5 - 0.05, px * 0.5 + 0.05))
    portfolio.apply_fill(Fill('o1', 'binance', 'ETH/USDT', Side.BUY, qty=5, price=50.0, strategy='momentum'))
    order = Order('momentum', 'binance', 'BTC/USDT', Side.BUY, qty=20)
    decision = guard.check_order(order, Tick('binance', 'BTC/USDT', 107, 106.9, 107.1))
    assert decision.allowed is False
    assert decision.reason in {'symbol_concentration_exceeded', 'correlated_exposure_exceeded'}


def test_shadow_deployment_captures_orders(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'shadow.db'))
    shadow = ShadowDeploymentService(journal, {'momentum'})
    order = Order('momentum', 'binance', 'BTC/USDT', Side.BUY, qty=0.01)
    shadow.capture(order)
    snap = shadow.snapshot()
    assert snap['signals'] == 1
    assert snap['by_strategy']['momentum'] == 1
    assert journal.recent_protection_events(1)[0]['event_type'] == 'shadow_order'


def test_runtime_bundle_exposes_v25_layers(tmp_path, monkeypatch):
    monkeypatch.setenv('SQLITE_PATH', str(tmp_path / 'bundle.db'))
    monkeypatch.setenv('SHADOW_ENABLED', '1')
    monkeypatch.setenv('SHADOW_STRATEGIES', 'momentum')
    monkeypatch.setenv('SMART_ROUTING_ENABLED', '1')
    settings = Settings()
    # ensure env-based parsing is exercised through loader
    from config.settings import get_settings
    bundle = build_runtime_bundle(get_settings())
    snap = bundle.snapshot()
    assert 'venue_health' in snap
    assert 'shadow' in snap
    assert bundle.shadow.enabled_for('momentum') is True
