# Rollback and Recovery

## Rollback triggers
- two failed sandbox certifications in a row
- unrecoverable sequence gap in staging/prod
- duplicate leaders writing the same venue stream
- alert storm caused by bad release

## Recovery path
1. Freeze outbound order flow.
2. Keep journal writable.
3. Restart only standby node first.
4. Rehydrate from latest checkpoint.
5. Compare exchange truth with journal truth.
6. Resume private stream subscriptions.
7. Unfreeze trading only after reconciliation is green.
