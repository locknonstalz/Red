from __future__ import annotations

import pytest

from common.models import Fill, Side
from config.settings import VenueCredentials
from execution.live.ws_sessions import ReplayPrivateWsSession
from futures.live_adapters import build_futures_spec
from futures.live_integration import FuturesLiveOrchestrationService
from futures.private_streams import BinanceFuturesPrivateAdapter, BitgetFuturesPrivateAdapter, BybitFuturesPrivateAdapter, MexcFuturesPrivateAdapter
from futures.reconciliation import FuturesTruthReconciliationService, HedgeLegState, HedgeLifecycle
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.journal import SqliteJournal
from certification.futures_scenarios import default_futures_certification_configs


def test_build_futures_spec_binance():
    spec = build_futures_spec('binance')
    assert spec.rest_base.startswith('https://')
    assert 'binance' == spec.venue


def test_binance_futures_private_adapter_parses_fill_and_positions():
    adapter = BinanceFuturesPrivateAdapter()
    fill = adapter.parse_execution({'e': 'ORDER_TRADE_UPDATE', 'E': 1710000000000, 'o': {'x': 'TRADE', 'c': 'c1', 'i': 11, 's': 'BTCUSDT', 'S': 'BUY', 'l': '0.010', 'L': '64000', 'n': '0.2', 't': 't1'}})
    assert fill and fill.symbol == 'BTCUSDT' and fill.qty == pytest.approx(0.01)
    positions = adapter.parse_position({'e': 'ACCOUNT_UPDATE', 'E': 1710000000000, 'a': {'P': [{'s': 'BTCUSDT', 'pa': '0.010', 'ep': '64000', 'cr': '1.5', 'mp': '64100'}], 'B': [{'a': 'USDT', 'wb': '1000'}]}})
    assert positions and positions[0].mark_price == pytest.approx(64100)


def test_bybit_mexc_bitget_adapters_smoke():
    bybit = BybitFuturesPrivateAdapter()
    fills = bybit.parse_execution({'topic': 'execution', 'creationTime': 1710000000000, 'data': [{'orderLinkId': 'c2', 'orderId': 'o2', 'symbol': 'BTCUSDT', 'side': 'Buy', 'execQty': '0.1', 'execPrice': '62000', 'execFee': '0.5', 'execId': 'e1'}]})
    assert fills and fills[0].price == pytest.approx(62000)
    mexc = MexcFuturesPrivateAdapter()
    upd = mexc.parse_order({'channel': 'push.personal.order', 'ts': 1710000000000, 'data': {'externalOid': 'c3', 'orderId': 'o3', 'symbol': 'BTC_USDT', 'state': 'PARTIALLY_FILLED', 'dealVol': '1', 'dealAvgPrice': '61000'}})
    assert upd and upd.status == 'PARTIALLY_FILLED'
    bitget = BitgetFuturesPrivateAdapter()
    ous = bitget.parse_order({'arg': {'channel': 'orders'}, 'data': [{'clientOid': 'c4', 'ordId': 'o4', 'instId': 'BTCUSDT', 'status': 'filled', 'accFillSz': '0.2', 'fillPx': '60000', 'uTime': '1710000000000'}]})
    assert ous and ous[0].avg_price == pytest.approx(60000)


def test_futures_truth_reconciliation_and_hedge_lifecycle(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'v32.db'))
    recon = FuturesTruthReconciliationService(journal)
    truth = recon.apply_mark_price('binance', 'BTCUSDT', mark_price=65000, index_price=64980, liquidation_price=59000, basis_bps=4.5)
    assert truth.mark_price == pytest.approx(65000)
    hedge = HedgeLifecycle(
        hedge_id='h1',
        futures_leg=HedgeLegState(symbol='BTCUSDT', venue='binance', side=Side.SELL, qty=1.0, client_order_id='fut-1'),
        spot_leg=HedgeLegState(symbol='BTCUSDT', venue='binance', side=Side.BUY, qty=1.0, client_order_id='spot-1'),
    )
    recon.register_hedge(hedge)
    recon.apply_hedge_fill('h1', Fill(client_order_id='fut-1', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1.0, price=65000))
    state = recon.apply_hedge_fill('h1', Fill(client_order_id='spot-1', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0, price=64950))
    assert state and state.status == 'HEDGED'


@pytest.mark.asyncio
async def test_futures_live_orchestration_service_applies_truth(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'orchestrator.db'))
    metrics = MetricsRegistry()
    portfolio = PortfolioService('USDT', journal, metrics)
    frames = [
        {'e': 'ORDER_TRADE_UPDATE', 'E': 1710000000000, 'o': {'x': 'TRADE', 'c': 'c1', 'i': 1, 's': 'BTCUSDT', 'S': 'BUY', 'l': '0.010', 'L': '64000', 'n': '0.1', 't': 't1'}},
        {'e': 'ACCOUNT_UPDATE', 'E': 1710000000100, 'a': {'P': [{'s': 'BTCUSDT', 'pa': '0.010', 'ep': '64000', 'cr': '0', 'mp': '64100'}], 'B': [{'a': 'USDT', 'wb': '1000'}]}},
        {'markPrice': '64150', 'indexPrice': '64140', 'liquidationPrice': '59000', 'symbol': 'BTCUSDT', 'basisBps': '3.1'},
    ]
    session = ReplayPrivateWsSession('binance', frames)
    svc = FuturesLiveOrchestrationService(sessions={'binance': session}, journal=journal, portfolio=portfolio, metrics=metrics)
    await svc.run()
    assert svc.stats.fills_applied == 1
    assert svc.stats.positions_synced == 1
    truth = svc.truth.truth('binance', 'BTCUSDT')
    assert truth and truth.mark_price == pytest.approx(64150)


def test_futures_certification_configs_present():
    cfg = default_futures_certification_configs()
    assert set(cfg) == {'binance', 'bybit', 'mexc', 'bitget'}
    assert cfg['bitget'].require_passphrase is True
