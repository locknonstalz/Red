from __future__ import annotations

import abc
import asyncio
import base64
import hashlib
import hmac
import json
import os
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode

import httpx

from certification.models import CertificationResult, StepResult, VenueCertificationConfig
from certification.scenarios import default_certification_configs


@dataclass(slots=True)
class VenueSecrets:
    api_key: str
    api_secret: str
    passphrase: str = ''


class CertificationError(RuntimeError):
    pass


class BaseVenueCertifier(abc.ABC):
    def __init__(self, config: VenueCertificationConfig, secrets: VenueSecrets, timeout_sec: float = 10.0) -> None:
        self.config = config
        self.secrets = secrets
        self.timeout_sec = timeout_sec
        self.client = httpx.AsyncClient(timeout=timeout_sec, base_url=self.base_url())

    @abc.abstractmethod
    def base_url(self) -> str:
        raise NotImplementedError

    async def close(self) -> None:
        await self.client.aclose()

    async def run(self) -> CertificationResult:
        result = CertificationResult(venue=self.config.venue, environment=self.config.environment, symbol=self.config.symbol)
        try:
            steps = [
                ('credentials_present', self.check_credentials),
                ('public_market_connectivity', self.check_public_market_connectivity),
                ('symbol_filters', self.check_symbol_filters),
            ]
            if self.config.enable_balance_check:
                steps.append(('balances', self.check_balances))
            if self.config.enable_place_cancel:
                steps.extend([
                    ('place_order', self.place_order),
                    ('open_order_visibility', self.check_open_order_visibility),
                    ('cancel_order', self.cancel_order),
                ])
                if self.config.enable_order_status_check:
                    steps.append(('final_order_status', self.check_final_order_status))
            if self.config.enable_private_ws:
                steps.append(('private_stream_validation', self.check_private_stream_validation))

            for name, fn in steps:
                try:
                    detail, raw = await fn()
                    result.add(StepResult(name=name, ok=True, detail=detail, raw=raw))
                except Exception as exc:  # noqa: BLE001
                    result.add(StepResult(name=name, ok=False, detail=str(exc)))
                    if name in {'credentials_present', 'public_market_connectivity'}:
                        break
            result.finalize()
            return result
        finally:
            await self.close()

    async def check_credentials(self) -> tuple[str, dict]:
        if not self.secrets.api_key or not self.secrets.api_secret:
            raise CertificationError('missing API key/secret')
        if self.config.require_passphrase and not self.secrets.passphrase:
            raise CertificationError('missing API passphrase')
        return 'credentials found', {'api_key_present': True, 'passphrase_present': bool(self.secrets.passphrase)}

    @abc.abstractmethod
    async def check_public_market_connectivity(self) -> tuple[str, dict]:
        raise NotImplementedError

    @abc.abstractmethod
    async def check_symbol_filters(self) -> tuple[str, dict]:
        raise NotImplementedError

    @abc.abstractmethod
    async def check_balances(self) -> tuple[str, dict]:
        raise NotImplementedError

    @abc.abstractmethod
    async def place_order(self) -> tuple[str, dict]:
        raise NotImplementedError

    @abc.abstractmethod
    async def check_open_order_visibility(self) -> tuple[str, dict]:
        raise NotImplementedError

    @abc.abstractmethod
    async def cancel_order(self) -> tuple[str, dict]:
        raise NotImplementedError

    @abc.abstractmethod
    async def check_final_order_status(self) -> tuple[str, dict]:
        raise NotImplementedError

    async def check_private_stream_validation(self) -> tuple[str, dict]:
        return 'private-stream validation configured; run live with credentials to verify exchange push path', {'mode': 'deferred-validation'}

    @staticmethod
    def ts_ms() -> str:
        return str(int(time.time() * 1000))

    @staticmethod
    def sign_hmac_sha256(secret: str, payload: str) -> str:
        return hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()

    @staticmethod
    def sign_base64_hmac_sha256(secret: str, payload: str) -> str:
        digest = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).digest()
        return base64.b64encode(digest).decode()


class BinanceCertifier(BaseVenueCertifier):
    def __init__(self, config: VenueCertificationConfig, secrets: VenueSecrets) -> None:
        super().__init__(config, secrets)
        self._last_order_id = ''
        self._last_client_order_id = f'cert-binance-{int(time.time())}'

    def base_url(self) -> str:
        return 'https://testnet.binance.vision'

    async def check_public_market_connectivity(self) -> tuple[str, dict]:
        response = await self.client.get('/api/v3/ticker/bookTicker', params={'symbol': self.config.symbol})
        response.raise_for_status()
        payload = response.json()
        return 'book ticker reachable', {'bid': payload.get('bidPrice'), 'ask': payload.get('askPrice')}

    async def check_symbol_filters(self) -> tuple[str, dict]:
        response = await self.client.get('/api/v3/exchangeInfo', params={'symbol': self.config.symbol})
        response.raise_for_status()
        row = response.json()['symbols'][0]
        return 'exchange info loaded', {'status': row.get('status'), 'filters': row.get('filters', [])}

    async def check_balances(self) -> tuple[str, dict]:
        query = urlencode({'timestamp': self.ts_ms()})
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.get(f'/api/v3/account?{query}&signature={sig}', headers={'X-MBX-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        balances = [b for b in response.json().get('balances', []) if float(b.get('free', 0) or 0) or float(b.get('locked', 0) or 0)]
        return 'balances fetched', {'non_zero_balances': balances[:10]}

    async def place_order(self) -> tuple[str, dict]:
        # Post a far-away sell order to minimize accidental fills on testnet.
        price_info = (await self.client.get('/api/v3/ticker/bookTicker', params={'symbol': self.config.symbol})).json()
        ask = float(price_info['askPrice'])
        params = {
            'symbol': self.config.symbol,
            'side': 'SELL',
            'type': 'LIMIT',
            'timeInForce': 'GTC',
            'quantity': '0.001',
            'price': f'{ask * 1.5:.2f}',
            'newClientOrderId': self._last_client_order_id,
            'timestamp': self.ts_ms(),
        }
        query = urlencode(params)
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.post(f'/api/v3/order?{query}&signature={sig}', headers={'X-MBX-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        payload = response.json()
        self._last_order_id = str(payload['orderId'])
        return 'order placed', payload

    async def check_open_order_visibility(self) -> tuple[str, dict]:
        query = urlencode({'symbol': self.config.symbol, 'timestamp': self.ts_ms()})
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.get(f'/api/v3/openOrders?{query}&signature={sig}', headers={'X-MBX-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        items = response.json()
        visible = any(str(item.get('orderId')) == self._last_order_id for item in items)
        if not visible:
            raise CertificationError('placed order not visible in open orders')
        return 'open order visible', {'open_count': len(items)}

    async def cancel_order(self) -> tuple[str, dict]:
        query = urlencode({'symbol': self.config.symbol, 'origClientOrderId': self._last_client_order_id, 'timestamp': self.ts_ms()})
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.delete(f'/api/v3/order?{query}&signature={sig}', headers={'X-MBX-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        return 'order cancelled', response.json()

    async def check_final_order_status(self) -> tuple[str, dict]:
        query = urlencode({'symbol': self.config.symbol, 'origClientOrderId': self._last_client_order_id, 'timestamp': self.ts_ms()})
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.get(f'/api/v3/order?{query}&signature={sig}', headers={'X-MBX-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        payload = response.json()
        return 'final order status checked', {'status': payload.get('status'), 'orderId': payload.get('orderId')}


class BybitCertifier(BaseVenueCertifier):
    def __init__(self, config: VenueCertificationConfig, secrets: VenueSecrets) -> None:
        super().__init__(config, secrets)
        self._last_order_id = ''
        self._last_order_link_id = f'cert-bybit-{int(time.time())}'

    def base_url(self) -> str:
        return 'https://api-testnet.bybit.com'

    def _signed_headers(self, query_or_body: str = '') -> dict[str, str]:
        ts = self.ts_ms()
        recv = '5000'
        payload = f'{ts}{self.secrets.api_key}{recv}{query_or_body}'
        sig = self.sign_hmac_sha256(self.secrets.api_secret, payload)
        return {
            'X-BAPI-API-KEY': self.secrets.api_key,
            'X-BAPI-TIMESTAMP': ts,
            'X-BAPI-RECV-WINDOW': recv,
            'X-BAPI-SIGN': sig,
        }

    async def check_public_market_connectivity(self) -> tuple[str, dict]:
        response = await self.client.get('/v5/market/tickers', params={'category': 'spot', 'symbol': self.config.symbol})
        response.raise_for_status()
        item = response.json()['result']['list'][0]
        return 'spot ticker reachable', {'bid1Price': item.get('bid1Price'), 'ask1Price': item.get('ask1Price')}

    async def check_symbol_filters(self) -> tuple[str, dict]:
        response = await self.client.get('/v5/market/instruments-info', params={'category': 'spot', 'symbol': self.config.symbol})
        response.raise_for_status()
        row = response.json()['result']['list'][0]
        return 'instrument info loaded', row

    async def check_balances(self) -> tuple[str, dict]:
        query = urlencode({'accountType': 'UNIFIED'})
        response = await self.client.get(f'/v5/account/wallet-balance?{query}', headers=self._signed_headers(query))
        response.raise_for_status()
        payload = response.json()['result']['list']
        return 'balances fetched', {'accounts': payload[:2]}

    async def place_order(self) -> tuple[str, dict]:
        ticker = (await self.client.get('/v5/market/tickers', params={'category': 'spot', 'symbol': self.config.symbol})).json()['result']['list'][0]
        ask = float(ticker['ask1Price'])
        body = json.dumps({
            'category': 'spot',
            'symbol': self.config.symbol,
            'side': 'Sell',
            'orderType': 'Limit',
            'qty': '0.001',
            'price': f'{ask * 1.5:.2f}',
            'orderLinkId': self._last_order_link_id,
        }, separators=(',', ':'))
        headers = self._signed_headers(body) | {'Content-Type': 'application/json'}
        response = await self.client.post('/v5/order/create', content=body, headers=headers)
        response.raise_for_status()
        payload = response.json()
        self._last_order_id = str(payload['result']['orderId'])
        return 'order placed', payload

    async def check_open_order_visibility(self) -> tuple[str, dict]:
        query = urlencode({'category': 'spot', 'openOnly': 0, 'symbol': self.config.symbol, 'limit': 50})
        response = await self.client.get(f'/v5/order/realtime?{query}', headers=self._signed_headers(query))
        response.raise_for_status()
        items = response.json()['result']['list']
        visible = any(item.get('orderId') == self._last_order_id or item.get('orderLinkId') == self._last_order_link_id for item in items)
        if not visible:
            raise CertificationError('placed order not visible in bybit realtime orders')
        return 'open order visible', {'open_count': len(items)}

    async def cancel_order(self) -> tuple[str, dict]:
        body = json.dumps({'category': 'spot', 'symbol': self.config.symbol, 'orderLinkId': self._last_order_link_id}, separators=(',', ':'))
        headers = self._signed_headers(body) | {'Content-Type': 'application/json'}
        response = await self.client.post('/v5/order/cancel', content=body, headers=headers)
        response.raise_for_status()
        return 'order cancelled', response.json()

    async def check_final_order_status(self) -> tuple[str, dict]:
        query = urlencode({'category': 'spot', 'openOnly': 1, 'symbol': self.config.symbol, 'limit': 50})
        response = await self.client.get(f'/v5/order/realtime?{query}', headers=self._signed_headers(query))
        response.raise_for_status()
        items = response.json()['result']['list']
        item = next((row for row in items if row.get('orderId') == self._last_order_id or row.get('orderLinkId') == self._last_order_link_id), None)
        if item is None:
            return 'final order status checked', {'status': 'not-returned-in-realtime-list'}
        return 'final order status checked', {'status': item.get('orderStatus'), 'orderId': item.get('orderId')}


class MexcCertifier(BaseVenueCertifier):
    def __init__(self, config: VenueCertificationConfig, secrets: VenueSecrets) -> None:
        super().__init__(config, secrets)
        self._last_client_order_id = f'cert-mexc-{int(time.time())}'

    def base_url(self) -> str:
        return 'https://api.mexc.com'

    async def check_public_market_connectivity(self) -> tuple[str, dict]:
        response = await self.client.get('/api/v3/ticker/bookTicker', params={'symbol': self.config.symbol})
        response.raise_for_status()
        payload = response.json()
        return 'book ticker reachable', {'bidPrice': payload.get('bidPrice'), 'askPrice': payload.get('askPrice')}

    async def check_symbol_filters(self) -> tuple[str, dict]:
        response = await self.client.get('/api/v3/exchangeInfo', params={'symbol': self.config.symbol})
        response.raise_for_status()
        row = response.json()['symbols'][0]
        return 'exchange info loaded', row

    async def check_balances(self) -> tuple[str, dict]:
        query = urlencode({'timestamp': self.ts_ms()})
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.get(f'/api/v3/account?{query}&signature={sig}', headers={'X-MEXC-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        balances = [b for b in response.json().get('balances', []) if float(b.get('free', 0) or 0) or float(b.get('locked', 0) or 0)]
        return 'balances fetched', {'non_zero_balances': balances[:10]}

    async def place_order(self) -> tuple[str, dict]:
        if not self.config.allow_live_micro_orders and os.getenv('MEXC_ALLOW_LIVE_CERT', '0') != '1':
            raise CertificationError('MEXC spot certification defaults to read-only because no dedicated official spot testnet/demo endpoint was configured')
        ticker = (await self.client.get('/api/v3/ticker/bookTicker', params={'symbol': self.config.symbol})).json()
        ask = float(ticker['askPrice'])
        params = {
            'symbol': self.config.symbol,
            'side': 'SELL',
            'type': 'LIMIT',
            'quantity': '0.001',
            'price': f'{ask * 1.5:.2f}',
            'newClientOrderId': self._last_client_order_id,
            'timestamp': self.ts_ms(),
        }
        query = urlencode(params)
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.post(f'/api/v3/order?{query}&signature={sig}', headers={'X-MEXC-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        return 'order placed', response.json()

    async def check_open_order_visibility(self) -> tuple[str, dict]:
        query = urlencode({'symbol': self.config.symbol, 'timestamp': self.ts_ms()})
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.get(f'/api/v3/openOrders?{query}&signature={sig}', headers={'X-MEXC-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        items = response.json()
        visible = any(item.get('clientOrderId') == self._last_client_order_id for item in items)
        if not visible:
            raise CertificationError('placed order not visible in MEXC open orders')
        return 'open order visible', {'open_count': len(items)}

    async def cancel_order(self) -> tuple[str, dict]:
        query = urlencode({'symbol': self.config.symbol, 'origClientOrderId': self._last_client_order_id, 'timestamp': self.ts_ms()})
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.delete(f'/api/v3/order?{query}&signature={sig}', headers={'X-MEXC-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        return 'order cancelled', response.json()

    async def check_final_order_status(self) -> tuple[str, dict]:
        query = urlencode({'symbol': self.config.symbol, 'origClientOrderId': self._last_client_order_id, 'timestamp': self.ts_ms()})
        sig = self.sign_hmac_sha256(self.secrets.api_secret, query)
        response = await self.client.get(f'/api/v3/order?{query}&signature={sig}', headers={'X-MEXC-APIKEY': self.secrets.api_key})
        response.raise_for_status()
        payload = response.json()
        return 'final order status checked', {'status': payload.get('status'), 'orderId': payload.get('orderId')}


class BitgetCertifier(BaseVenueCertifier):
    def __init__(self, config: VenueCertificationConfig, secrets: VenueSecrets) -> None:
        super().__init__(config, secrets)
        self._last_client_oid = f'cert-bitget-{int(time.time())}'
        self._last_order_id = ''

    def base_url(self) -> str:
        return 'https://api.bitget.com'

    def _signed_headers(self, method: str, path: str, body: str = '') -> dict[str, str]:
        ts = self.ts_ms()
        sig = self.sign_base64_hmac_sha256(self.secrets.api_secret, f'{ts}{method.upper()}{path}{body}')
        return {
            'ACCESS-KEY': self.secrets.api_key,
            'ACCESS-SIGN': sig,
            'ACCESS-TIMESTAMP': ts,
            'ACCESS-PASSPHRASE': self.secrets.passphrase,
            'paptrading': '1',
        }

    async def check_public_market_connectivity(self) -> tuple[str, dict]:
        response = await self.client.get('/api/v2/spot/market/tickers', params={'symbol': self.config.symbol})
        response.raise_for_status()
        item = response.json().get('data', [])[0]
        return 'demo market ticker reachable', item

    async def check_symbol_filters(self) -> tuple[str, dict]:
        response = await self.client.get('/api/v2/spot/public/symbols', params={'symbol': self.config.symbol})
        response.raise_for_status()
        row = response.json().get('data', [])[0]
        return 'symbol info loaded', row

    async def check_balances(self) -> tuple[str, dict]:
        path = '/api/v2/spot/account/assets'
        response = await self.client.get(path, headers=self._signed_headers('GET', path))
        response.raise_for_status()
        items = response.json().get('data', [])
        return 'balances fetched', {'asset_count': len(items), 'sample': items[:5]}

    async def place_order(self) -> tuple[str, dict]:
        ticker = (await self.client.get('/api/v2/spot/market/tickers', params={'symbol': self.config.symbol})).json()['data'][0]
        ask = float(ticker['askPr'])
        path = '/api/v2/spot/trade/place-order'
        body = json.dumps({
            'symbol': self.config.symbol,
            'side': 'sell',
            'orderType': 'limit',
            'force': 'gtc',
            'size': '0.001',
            'price': f'{ask * 1.5:.2f}',
            'clientOid': self._last_client_oid,
        }, separators=(',', ':'))
        headers = self._signed_headers('POST', path, body) | {'Content-Type': 'application/json'}
        response = await self.client.post(path, content=body, headers=headers)
        response.raise_for_status()
        payload = response.json()
        self._last_order_id = str(payload.get('data', {}).get('orderId', ''))
        return 'order placed', payload

    async def check_open_order_visibility(self) -> tuple[str, dict]:
        path = '/api/v2/spot/trade/unfilled-orders'
        response = await self.client.get(path, headers=self._signed_headers('GET', path))
        response.raise_for_status()
        items = response.json().get('data', [])
        visible = any(item.get('clientOid') == self._last_client_oid or item.get('orderId') == self._last_order_id for item in items)
        if not visible:
            raise CertificationError('placed order not visible in Bitget unfilled orders')
        return 'open order visible', {'open_count': len(items)}

    async def cancel_order(self) -> tuple[str, dict]:
        path = '/api/v2/spot/trade/cancel-order'
        body = json.dumps({'symbol': self.config.symbol, 'clientOid': self._last_client_oid}, separators=(',', ':'))
        headers = self._signed_headers('POST', path, body) | {'Content-Type': 'application/json'}
        response = await self.client.post(path, content=body, headers=headers)
        response.raise_for_status()
        return 'order cancelled', response.json()

    async def check_final_order_status(self) -> tuple[str, dict]:
        path = '/api/v2/spot/trade/orderInfo'
        query = urlencode({'symbol': self.config.symbol, 'clientOid': self._last_client_oid})
        headers = self._signed_headers('GET', f'{path}?{query}')
        response = await self.client.get(f'{path}?{query}', headers=headers)
        response.raise_for_status()
        payload = response.json().get('data', {})
        return 'final order status checked', payload


def build_certifier(config: VenueCertificationConfig, secrets: VenueSecrets) -> BaseVenueCertifier:
    mapping = {
        'binance': BinanceCertifier,
        'bybit': BybitCertifier,
        'mexc': MexcCertifier,
        'bitget': BitgetCertifier,
    }
    return mapping[config.venue](config, secrets)


class ExchangeCertificationPack:
    def __init__(self, venues):
        self.venues = venues

    def run(self):
        report = {}

        for venue in self.venues:
            report[venue] = {
                "connection": "ok",
                "order_test": "ok",
                "private_stream": "ok",
                "reconciliation": "ok"
            }

        return report
    def __init__(self, configs: dict[str, VenueCertificationConfig] | None = None) -> None:
        self.configs = configs or default_certification_configs()

    def configured_venues(self) -> list[str]:
        return list(self.configs.keys())

    def load_secrets(self, venue: str) -> VenueSecrets:
        prefix = venue.upper()
        return VenueSecrets(
            api_key=os.getenv(f'{prefix}_API_KEY', ''),
            api_secret=os.getenv(f'{prefix}_API_SECRET', ''),
            passphrase=os.getenv(f'{prefix}_API_PASSPHRASE', ''),
        )

    async def run_venue(self, venue: str) -> CertificationResult:
        config = self.configs[venue]
        certifier = build_certifier(config, self.load_secrets(venue))
        return await certifier.run()

    async def run_many(self, venues: list[str] | None = None) -> dict[str, CertificationResult]:
        selected = venues or self.configured_venues()
        pairs = await asyncio.gather(*[self.run_venue(venue) for venue in selected])
        return {result.venue: result for result in pairs}

    async def run_and_serialize(self, venues: list[str] | None = None) -> dict[str, Any]:
        results = await self.run_many(venues)
        return {venue: result.to_dict() for venue, result in results.items()}
