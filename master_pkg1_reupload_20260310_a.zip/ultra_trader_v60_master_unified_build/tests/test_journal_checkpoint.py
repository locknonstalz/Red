from common.models import SessionState, StreamCheckpoint
from storage.journal import SqliteJournal


def test_journal_persists_checkpoint_and_session_state(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'j.db'))
    journal.save_stream_checkpoint(StreamCheckpoint(venue='binance', channel='private', sequence=7, checkpoint='cursor-7', payload_hash='abc'))
    journal.save_session_state(SessionState(venue='binance', state='live', auth_ok=True, subscriptions_ok=True))

    ckpt = journal.load_stream_checkpoint('binance', 'private')
    state = journal.load_session_state('binance')
    assert ckpt is not None and ckpt.sequence == 7 and ckpt.checkpoint == 'cursor-7'
    assert state is not None and state.state == 'live' and state.auth_ok is True
