from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass


@dataclass(slots=True)
class LiquidationEvent:
    venue: str
    symbol: str
    side: str
    notional: float


@dataclass(slots=True)
class LiquidationPressure:
    venue: str
    symbol: str
    long_liq_notional: float
    short_liq_notional: float
    skew: float
    cascade_risk: float


class LiquidationAnalyticsService:
    def __init__(self, window: int = 64) -> None:
        self.window = max(window, 8)
        self._events: dict[tuple[str, str], deque[LiquidationEvent]] = defaultdict(lambda: deque(maxlen=self.window))

    def ingest(self, event: LiquidationEvent) -> None:
        self._events[(event.venue, event.symbol)].append(event)

    def snapshot(self, venue: str, symbol: str) -> LiquidationPressure:
        bucket = list(self._events.get((venue, symbol), ()))
        long_liq = sum(item.notional for item in bucket if item.side.upper() == 'LONG')
        short_liq = sum(item.notional for item in bucket if item.side.upper() == 'SHORT')
        total = max(long_liq + short_liq, 1.0)
        skew = (short_liq - long_liq) / total
        cascade_risk = min(1.0, total / 1_000_000.0 + abs(skew) * 0.5)
        return LiquidationPressure(venue=venue, symbol=symbol, long_liq_notional=long_liq, short_liq_notional=short_liq, skew=skew, cascade_risk=cascade_risk)
