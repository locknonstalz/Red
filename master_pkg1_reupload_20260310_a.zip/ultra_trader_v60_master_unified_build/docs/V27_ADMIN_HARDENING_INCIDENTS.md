# V27 Admin UI Hardening, Incident Workflow, Promotion Gates

This release adds:
- hardened control-plane HTTP headers
- alert inbox with acknowledgements
- incident workflow from alert to ack to resolve
- staged live-promotion gates (`research -> shadow -> paper -> micro_live -> live`)

New endpoints:
- `GET /alerts`
- `POST /alerts/ack`
- `GET /incidents`
- `POST /incidents/open`
- `POST /incidents/ack`
- `POST /incidents/resolve`
- `GET /promotions`
- `POST /promotions/request`
- `POST /promotions/approve`

Dashboard additions:
- alert table
- incident table
- promotion table

Security headers:
- `Cache-Control: no-store`
- `X-Frame-Options: DENY`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: no-referrer`
- `Permissions-Policy`
- `Content-Security-Policy`
