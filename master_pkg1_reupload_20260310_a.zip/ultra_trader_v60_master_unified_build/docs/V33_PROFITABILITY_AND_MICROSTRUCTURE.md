# v33 Profitability, Microstructure, and Simulation Layer

## Что добавлено
- L2/L3 order book intelligence
- полноценный event-driven backtesting engine
- advanced ML lifecycle: drift detection, champion/challenger, rollback-health
- on-chain analytics integration layer
- liquidation analytics
- exchange simulation engine
- profitability advisor

## Что реально нужно для прибыльности
Архитектура сама по себе не создаёт edge. Для прибыльности нужны:
1. **Edge discovery** — рабочие гипотезы, проверенные на out-of-sample данных.
2. **Market selection** — выбор правильных монет, площадок и режимов.
3. **Execution discipline** — низкий slippage, контроль fees и adverse selection.
4. **Risk discipline** — маленькие убытки, быстрый cut-off плохих режимов.
5. **Capacity discipline** — не перегружать стратегию размером.
6. **Model governance** — не допускать деградации ML и signal drift.

## Что теперь делает движок лучше
- Оценивает microstructure quality через orderbook features.
- Может прогонять стратегии через backtester до live rollout.
- Умеет следить за drift моделей и решать, когда challenger сильнее champion.
- Принимает on-chain и liquidation сигналы как часть alpha context.
- Может симулировать частичные fills и cost-to-trade.
- Даёт profitability assessment по стратегии.

## Что всё ещё остаётся вне кода
- Реальные paid data connectors и их валидация.
- Исторические L2/L3 датасеты большого объёма.
- Боевая latency-инфраструктура и co-location.
- Строгая research-методология: walk-forward, survivor-bias control, data QA.
