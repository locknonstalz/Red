from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional
from uuid import uuid4


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"


class OrderStatus(str, Enum):
    NEW = "NEW"
    ACCEPTED = "ACCEPTED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"


class ExecutionPolicy(str, Enum):
    AUTO = "AUTO"
    PASSIVE = "PASSIVE"
    AGGRESSIVE = "AGGRESSIVE"
    TWAP = "TWAP"
    VWAP = "VWAP"


@dataclass(slots=True)
class Tick:
    venue: str
    symbol: str
    price: float
    bid: float
    ask: float
    ts: datetime = field(default_factory=utc_now)
    funding_rate: float = 0.0
    microprice_bias_bps: float = 0.0
    toxicity_score: float = 0.0
    liquidation_long_pressure: float = 0.0
    liquidation_short_pressure: float = 0.0
    cascade_risk: float = 0.0

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2.0

    @property
    def spread(self) -> float:
        return max(self.ask - self.bid, 0.0)


@dataclass(slots=True)
class Signal:
    strategy: str
    venue: str
    symbol: str
    side: Side
    strength: float
    reason: str
    ts: datetime = field(default_factory=utc_now)
    qty: float | None = None
    order_type: OrderType = OrderType.MARKET
    limit_price: float | None = None
    tags: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Order:
    strategy: str
    venue: str
    symbol: str
    side: Side
    qty: float
    order_type: OrderType = OrderType.MARKET
    limit_price: Optional[float] = None
    client_order_id: str = field(default_factory=lambda: str(uuid4()))
    status: OrderStatus = OrderStatus.NEW
    filled_qty: float = 0.0
    avg_fill_price: float = 0.0
    ts: datetime = field(default_factory=utc_now)
    execution_policy: ExecutionPolicy = ExecutionPolicy.AUTO
    parent_order_id: str = ""
    slice_index: int = 0
    slice_count: int = 1

    @property
    def remaining_qty(self) -> float:
        return max(self.qty - self.filled_qty, 0.0)


@dataclass(slots=True)
class Fill:
    client_order_id: str
    venue: str
    symbol: str
    side: Side
    qty: float
    price: float
    fee: float = 0.0
    ts: datetime = field(default_factory=utc_now)
    trade_id: str = ""
    exchange_order_id: str = ""
    strategy: str = ""


@dataclass(slots=True)
class Position:
    symbol: str
    qty: float = 0.0
    avg_price: float = 0.0
    realized_pnl: float = 0.0
    mark_price: float = 0.0
    venue: str = ""

    @property
    def unrealized_pnl(self) -> float:
        if self.qty == 0:
            return 0.0
        return (self.mark_price - self.avg_price) * self.qty


@dataclass(slots=True)
class Balance:
    venue: str
    asset: str
    free: float
    locked: float = 0.0
    ts: datetime = field(default_factory=utc_now)


@dataclass(slots=True)
class VenueFilter:
    venue: str
    symbol: str
    tick_size: float
    step_size: float
    min_qty: float
    min_notional: float


@dataclass(slots=True)
class OrderUpdate:
    venue: str
    client_order_id: str
    exchange_order_id: str
    symbol: str
    status: str
    filled_qty: float
    avg_price: float
    raw: dict[str, Any]
    ts: datetime = field(default_factory=utc_now)


@dataclass(slots=True)
class RiskDecision:
    allowed: bool
    reason: str = "OK"


@dataclass(slots=True)
class StreamCheckpoint:
    venue: str
    channel: str
    sequence: int | None = None
    checkpoint: str = ""
    payload_hash: str = ""
    updated_at: datetime = field(default_factory=utc_now)


@dataclass(slots=True)
class SessionState:
    venue: str
    state: str
    auth_ok: bool
    subscriptions_ok: bool
    last_error: str = ""
    updated_at: datetime = field(default_factory=utc_now)
