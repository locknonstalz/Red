# V34 Alpha Lab

Добавлено:
- hypothesis registry
- experiment tracking
- factor importance ranking
- regime-by-regime performance decomposition
- strategy decay detection
- alpha sleeve portfolio optimizer

Новые поверхности:
- runtime snapshot section `alpha_lab`
- control plane endpoint `GET /alpha-lab`
- dashboard block for factor importance and decay reports

Назначение:
- отделить исследование alpha-гипотез от execution core
- хранить evidence по экспериментам
- понимать, какие факторы реально помогают
- вовремя замечать деградацию стратегии
- перераспределять капитал между alpha sleeves по фактическому качеству
