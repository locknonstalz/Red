from common.models import StreamCheckpoint
from execution.live.recovery_engines import get_recovery_engine


def test_recovery_engines_build_requests():
    checkpoint = StreamCheckpoint(venue='binance', channel='private', sequence=100, checkpoint='cursor-1')
    for venue in ['binance', 'bybit', 'mexc', 'bitget']:
        engine = get_recovery_engine(venue)
        requests = engine.build_requests(checkpoint, 'BTC/USDT')
        assert len(requests) >= 3
        assert all(req.path.startswith('/') for req in requests)
