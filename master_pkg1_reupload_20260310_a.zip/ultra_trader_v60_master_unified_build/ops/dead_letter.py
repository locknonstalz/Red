from __future__ import annotations

from storage.base import Journal


class DeadLetterQueue:
    def __init__(self, journal: Journal) -> None:
        self.journal = journal

    def push(self, topic: str, payload: str, reason: str) -> None:
        self.journal.enqueue_dead_letter(topic, payload, reason)
