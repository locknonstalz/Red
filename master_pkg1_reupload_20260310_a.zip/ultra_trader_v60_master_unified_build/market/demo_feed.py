from __future__ import annotations

import asyncio
import math

from common.bus import EventBus
from common.models import Tick


class DemoFeed:
    def __init__(self, bus: EventBus, venue: str, symbol: str, tick_interval_sec: float = 0.2) -> None:
        self.bus = bus
        self.venue = venue
        self.symbol = symbol
        self.tick_interval_sec = tick_interval_sec
        self._running = True

    async def run(self) -> None:
        i = 0
        while self._running:
            price = 50000.0 + math.sin(i / 5) * 300 + i * 2.5
            tick = Tick(venue=self.venue, symbol=self.symbol, price=price, bid=price - 2, ask=price + 2)
            await self.bus.publish("ticks", tick)
            i += 1
            await asyncio.sleep(self.tick_interval_sec)

    async def close(self) -> None:
        self._running = False


class MultiVenueDemoFeed:
    def __init__(self, bus: EventBus, symbol: str, venues: list[str], tick_interval_sec: float = 0.2) -> None:
        self.bus = bus
        self.symbol = symbol
        self.venues = venues
        self.tick_interval_sec = tick_interval_sec
        self._running = True

    async def run(self) -> None:
        i = 0
        offsets = {venue: idx * 5.0 for idx, venue in enumerate(self.venues)}
        while self._running:
            base = 50000.0 + math.sin(i / 5) * 200 + i * 1.8
            for idx, venue in enumerate(self.venues):
                skew = offsets[venue] + math.sin((i + idx * 3) / 7) * (8 + idx * 2)
                spread = 1.2 + idx * 0.3
                price = base + skew
                tick = Tick(venue=venue, symbol=self.symbol, price=price, bid=price - spread, ask=price + spread)
                await self.bus.publish('ticks', tick)
            i += 1
            await asyncio.sleep(self.tick_interval_sec)

    async def close(self) -> None:
        self._running = False
