# Capital Protection Layer

В проект встроен полноценный защитный слой капитала:

- DailyLossGuard
- DrawdownGovernor
- StrategyKillSwitch
- CircuitBreakerService на уровне защиты капитала
- PositionProtectionEngine
- CapitalAllocator
- Only-Close emergency mode
- Global kill switch
- audit trail всех блокировок и остановок через `protection_events`

Основная интеграция:

```text
strategy signal -> AI filter -> capital protection -> risk -> execution
```

Защитные выходы по позиции создаются внутри `CapitalProtectionService.protective_orders()`.
