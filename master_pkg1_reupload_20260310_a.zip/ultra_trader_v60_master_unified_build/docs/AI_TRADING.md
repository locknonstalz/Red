# AI trading layer

В эту версию встроен online AI-слой, который работает **поверх стратегий**, а не вместо них.

## Что он делает

- извлекает online-features из потока тиков
- оценивает вероятность того, что вход даст положительное движение в нужную сторону
- отбрасывает слабые сигналы
- усиливает размер позиции на сильных сигналах
- самообучается по факту будущего движения цены на горизонте `entry_horizon_ticks`
- дополнительно хранит EWMA reward по стратегиям

## Как это устроено

1. стратегия генерирует базовый `Signal`
2. AI layer считает признаки:
   - momentum
   - fast/slow gap
   - volatility regime
   - spread regime
   - orderbook pressure proxy
3. online logistic model считает probability of favorable move
4. если вероятность ниже порога — сигнал отклоняется
5. если вероятность высокая — размер заявки увеличивается
6. спустя несколько тиков модель получает label и обновляет веса

## Что это даёт

- точнее фильтруются входы
- уменьшается шум от ложных пробоев
- одна и та же стратегия адаптируется к режиму рынка
- появляется online self-learning без отдельного offline training job

## Ограничения

Это **не magic alpha** и не полноценный deep learning stack.

Сейчас AI-слой:
- online
- lightweight
- интерпретируемый
- безопасный для встраивания в execution core

Для следующего шага можно добавить:
- offline feature store
- walk-forward training
- meta-labeling
- fill probability model
- queue position model
- regime classifier
