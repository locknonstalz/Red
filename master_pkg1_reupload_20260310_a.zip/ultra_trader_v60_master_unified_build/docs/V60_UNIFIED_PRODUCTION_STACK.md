# v60 Unified Production Stack Blueprint

v60 is the canonical production tree that consolidates the strongest capabilities of the previous versions into one codebase.

## Canonical base

The codebase is anchored on `v51` because it already contains the integrated alpha lifecycle:

`discover -> test -> shadow -> micro_live -> score -> rotate capital`

## Mandatory included capabilities

### Runtime and infra
- unified runtime bootstrap
- multi-venue live runtime
- exchange certification scripts
- futures private stream and truth loop foundation

### Control plane and operator surface
- auth + RBAC + audit signing
- confirmations for dangerous controls
- incident and drill workflow
- production UI wiring blueprint

### Execution and risk
- execution quality attribution
- execution tactics and slicing
- inventory, hedge and exposure management
- capital protection and advanced risk controls
- micro-live hardening guards

### Alpha lifecycle
- alpha lab
- alpha factory
- integrated alpha pipeline
- live alpha scoreboard
- deployment profiles and daily operator workflow

### Capital and portfolio
- capital scaling
- autonomous portfolio allocation
- regime-aware specialist ensemble

## Canonical strategies
- funding_carry
- cross_exchange_arbitrage
- market_making_toxicity_aware
- liquidation_cascade
- statistical_arbitrage
- momentum benchmark only

## What was intentionally not kept as parallel systems
- duplicate dashboards
- duplicate allocators without hierarchy
- duplicate rollout controllers
- older non-canonical strategy variants

## Recommended next action after assembling v60
1. Run paper mode.
2. Run exchange certification for selected venues.
3. Start first-wave micro-live with very small capital.
4. Review scorecards daily.
5. Scale only after positive net alpha after costs.
