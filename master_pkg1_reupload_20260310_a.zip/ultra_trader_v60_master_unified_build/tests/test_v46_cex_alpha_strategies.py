from common.models import OrderType, Side, Tick
from strategy.cross_exchange_arbitrage import CrossExchangeArbitrageStrategy
from strategy.funding_carry import FundingCarryStrategy
from strategy.liquidation_cascade import LiquidationCascadeStrategy
from strategy.market_making import MarketMakingStrategy
from strategy.statistical_arbitrage import StatisticalArbitrageStrategy

def test_market_making_blocks_toxic_quotes_and_then_quotes():
    strat = MarketMakingStrategy('mm', 'binance', 'BTC/USDT', quote_size=0.01, requote_cooldown_ticks=1, min_spread_bps=0.5, max_toxicity=0.5)
    for i in range(35):
        out = list(strat.on_tick(Tick('binance', 'BTC/USDT', 50000 + i * 0.1, 49998 + i * 0.1, 50002 + i * 0.1, toxicity_score=0.8, microprice_bias_bps=1.0)))
    assert out == []
    quoted = []
    for i in range(10):
        quoted = list(strat.on_tick(Tick('binance', 'BTC/USDT', 50010 + i * 0.1, 50008 + i * 0.1, 50012 + i * 0.1, toxicity_score=0.1, microprice_bias_bps=1.0)))
        if quoted:
            break
    assert len(quoted) == 2
    assert all(s.order_type == OrderType.LIMIT for s in quoted)


def test_funding_carry_emits_paired_legs():
    strat = FundingCarryStrategy('carry', 'binance', 'bybit', 'BTC/USDT', trade_size=0.01, min_funding_rate=0.0005, min_basis_bps=2.0)
    assert list(strat.on_tick(Tick('binance', 'BTC/USDT', 100.0, 99.95, 100.05, funding_rate=0.001))) == []
    out = list(strat.on_tick(Tick('bybit', 'BTC/USDT', 100.2, 100.15, 100.25, funding_rate=0.001)))
    assert len(out) == 2
    assert {s.venue for s in out} == {'binance', 'bybit'}
    assert {s.side for s in out} == {Side.BUY, Side.SELL}


def test_cross_exchange_arbitrage_emits_paired_legs():
    strat = CrossExchangeArbitrageStrategy('arb', 'BTC/USDT', trade_size=0.01, min_edge_bps=5.0)
    assert list(strat.on_tick(Tick('binance', 'BTC/USDT', 100.0, 99.9, 100.1))) == []
    out = list(strat.on_tick(Tick('bybit', 'BTC/USDT', 100.8, 100.7, 100.9)))
    assert len(out) == 2


def test_liquidation_cascade_detects_breakout():
    strat = LiquidationCascadeStrategy('liq', 'binance', 'BTC/USDT', trade_size=0.01, lookback=5, breakout_bps=3.0, min_liquidation_pressure=0.5, min_cascade_risk=0.2)
    out = []
    ticks = [100.0, 100.01, 100.02, 100.03, 100.25]
    for px in ticks:
        out = list(strat.on_tick(Tick('binance', 'BTC/USDT', px, px - 0.01, px + 0.01, liquidation_short_pressure=0.7, cascade_risk=0.4, toxicity_score=0.1)))
    assert len(out) == 1
    assert out[0].side == Side.BUY


def test_stat_arb_opens_pair():
    strat = StatisticalArbitrageStrategy('stat', 'binance', 'bybit', 'BTC/USDT', trade_size=0.01, window=5, entry_z=1.0, exit_z=0.2)
    for i in range(5):
        strat.on_tick(Tick('binance', 'BTC/USDT', 100 + i * 0.1, 99.9 + i * 0.1, 100.1 + i * 0.1))
        strat.on_tick(Tick('bybit', 'BTC/USDT', 100 + i * 0.1, 99.9 + i * 0.1, 100.1 + i * 0.1))
    opened = strat.on_tick(Tick('binance', 'BTC/USDT', 101.5, 101.4, 101.6))
    opened = strat.on_tick(Tick('bybit', 'BTC/USDT', 100.0, 99.9, 100.1)) or opened
    assert len(opened) == 2



def test_funding_carry_debug_state_exposes_blockers():
    strat = FundingCarryStrategy('carry', 'binance', 'bybit', 'BTC/USDT', trade_size=0.01, min_funding_rate=0.0005, min_basis_bps=2.0)
    list(strat.on_tick(Tick('binance', 'BTC/USDT', 100.0, 99.95, 100.05, funding_rate=0.0)))
    state = strat.debug_state()
    assert state['status'] == 'waiting_for_both_venues'
    list(strat.on_tick(Tick('bybit', 'BTC/USDT', 100.01, 100.0, 100.02, funding_rate=0.0)))
    state = strat.debug_state()
    assert state['status'] in {'blocked_funding_below_threshold', 'blocked_basis_too_small', 'blocked_basis_too_wide'}
