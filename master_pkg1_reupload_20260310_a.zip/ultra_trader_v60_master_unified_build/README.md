# Ultra Trader v60 Unified Production Stack

Ultra Trader v60 is the unified production-oriented codebase that consolidates the strongest parts of the previous versions into one canonical project.

## What is unified in v60

- runtime bootstrap and multi-venue live orchestration
- control plane with auth, RBAC, confirmations and audit
- GUI/operator surface wiring blueprint
- capital protection and advanced risk controls
- execution quality, tactics, capacity and rollout guardrails
- inventory, exposure and hedge management
- canonical CEX alpha strategy pack
- alpha lab, alpha factory and integrated alpha lifecycle
- micro-live deployment profiles, hardening guards and operator workflow
- autonomous portfolio allocation and capital scaling
- futures/funding/basis/liquidation analytics foundation

## Canonical strategies

- funding_carry
- cross_exchange_arbitrage
- market_making_toxicity_aware
- liquidation_cascade
- statistical_arbitrage
- momentum (benchmark only)

## Recommended runtime flow

```text
market data
-> research features
-> alpha factory / strategy pack
-> signal scoring
-> execution planning
-> risk + capital protection
-> execution
-> reconciliation
-> alpha scoreboard
-> micro-live hardening
-> rollout decision
-> capital rotation
-> operator review
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python scripts/preflight.py
TRADING_MODE=paper python app.py
```

## Suggested first live path

1. Run paper mode and check `/risk/dashboard`, `/alpha-lab`, `/governance`.
2. Run exchange certification on chosen venues.
3. Start first-wave micro-live with:
   - funding_carry
   - cross_exchange_arbitrage
   - market_making_toxicity_aware
4. Review daily scorecards before any scaling.

## First $100 micro-live profile

Use `.env.micro_live_100.example` as the starting template for the first real-money launch.
The template keeps only `funding_carry` enabled, caps total deployable notional at `$100`,
limits per-order notional to `$8`, and keeps daily loss hard-stops at `$2` globally and `$1` per strategy.

Recommended flow:

```bash
cp .env.micro_live_100.example .env
python scripts/preflight.py
python app.py
```

## Important docs

- `docs/V60_UNIFIED_PRODUCTION_STACK.md`
- `docs/UNIFIED_RUNBOOK.md`
- `docs/V51_INTEGRATED_ALPHA_PIPELINE.md`
- `docs/V48_MICRO_LIVE_HARDENING.md`
- `docs/V47_MICRO_LIVE_DEPLOYMENT_PACK.md`


## Desktop GUI

В проект добавлен локальный интерфейс `gui_launcher.py` и Windows launcher `start_gui.bat`. Подробности: `docs/GUI_CONTROL_CENTER.md`.


## Desktop GUI v2
Запуск локального графического интерфейса: `python gui_launcher.py` или двойным кликом по `start_gui.bat`.


## GUI v3
Запуск Windows-интерфейса: `start_gui.bat` или `python gui_launcher.py`.
