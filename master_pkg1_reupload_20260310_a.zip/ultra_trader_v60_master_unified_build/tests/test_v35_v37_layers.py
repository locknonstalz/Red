from fastapi.testclient import TestClient

from capital.protection import CapitalProtectionService
from common.models import Fill, Side, Tick
from config.settings import CapitalProtectionSettings, Settings
from control_plane.api import create_control_plane_app
from control_plane.auth import AuthConfig, ControlPlanePrincipal, TokenAuthManager
from control_plane.service import ControlPlaneService
from data.production_data import ProductionDataLayer
from execution.quality import ExecutionQualityAttributionService
from futures.liquidations import LiquidationAnalyticsService
from live_validation.validation import LiveValidationService
from ops.alerts import AlertRouter
from ops.go_live import GoLiveScoringService
from ops.incidents import AlertInboxSink, IncidentWorkflowService, LivePromotionGateService
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from research.alpha_governance import AlphaGovernanceService
from research.alpha_lab import AlphaLabService
from research.asset_analysis import AssetAnalysisService
from research.attribution import StrategyAttributionService
from research.onchain import OnChainAnalyticsService
from research.profitability import ProfitabilityAdvisorService
from research.venue_health import VenueHealthScoringService
from runtime.bootstrap import build_runtime_bundle
from storage.journal import SqliteJournal


def _service() -> ControlPlaneService:
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    protection = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    attribution = StrategyAttributionService()
    profitability = ProfitabilityAdvisorService(
        attribution=attribution,
        execution_quality=ExecutionQualityAttributionService(),
        venue_health=VenueHealthScoringService(),
        onchain=OnChainAnalyticsService(),
        liquidations=LiquidationAnalyticsService(),
    )
    alpha_lab = AlphaLabService(profitability=profitability, attribution=attribution)
    alpha_lab.hypotheses.register('h1', 'Test edge', 'Desc', strategies=['momentum'], factors=['spread_bps'], expected_edge='more selective entries')
    asset = AssetAnalysisService()
    asset.observe_tick(Tick(venue='binance', symbol='BTCUSDT', price=100.0, bid=99.9, ask=100.1))
    promotions = LivePromotionGateService()
    promotions.request_promotion(strategy='momentum', target_stage='shadow', checks={'basic': True}, actor='op', reason='bootstrap')
    promotions.approve('momentum', actor='admin')
    go_live = GoLiveScoringService(promotions=promotions, incidents=IncidentWorkflowService(), alerts=AlertInboxSink(), shadow=None, drills=None, evidence=None)
    governance = AlphaGovernanceService(alpha_lab=alpha_lab, promotions=promotions, go_live=go_live)
    prod = ProductionDataLayer()
    prod.ingest('binance', 'trade', {'venue': 'binance', 'symbol': 'BTCUSDT', 'price': 100.0, 'qty': 0.01})
    prod.ingest('binance', 'l2_book', {'venue': 'binance', 'symbol': 'BTCUSDT', 'bids': 5, 'asks': 5})
    service = ControlPlaneService(
        capital_protection=protection,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        alert_router=AlertRouter([]),
        asset_analysis=asset,
        alpha_lab=alpha_lab,
        alpha_governance=governance,
        production_data=prod,
    )
    service.live_validation = LiveValidationService(portfolio=portfolio, execution_quality=ExecutionQualityAttributionService(), alerts=service.alert_inbox, incidents=service.incidents)
    return service


def test_alpha_governance_can_auto_demote_on_decay() -> None:
    service = _service()
    gov = service.alpha_governance
    assert gov is not None
    gov.approve_hypothesis('h1', actor='chief')
    attribution = service.alpha_lab.attribution
    attribution.observe_fill(Fill(client_order_id='1', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1, price=100, strategy='momentum'))
    attribution.observe_fill(Fill(client_order_id='2', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1, price=110, strategy='momentum'))
    for idx in range(6):
        service.alpha_lab.observe_fill(Fill(client_order_id=f'n{idx}', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1, price=99-idx, strategy='momentum'), realized_pnl_hint=-2.0)
    decision = gov.maybe_demote('momentum', 'binance', 'BTCUSDT')
    assert decision.triggered is True
    assert decision.to_stage == 'research'


def test_data_quality_and_live_validation_endpoints_exposed() -> None:
    service = _service()
    service.live_validation.plan_micro_live('momentum', 'binance', 'BTCUSDT', notional=100.0)
    auth = TokenAuthManager(AuthConfig(enabled=True, static_tokens={
        'viewer-token': ControlPlanePrincipal(subject='viewer1', role='viewer'),
    }))
    client = TestClient(create_control_plane_app(service, auth))
    dq = client.get('/data/quality', headers={'Authorization': 'Bearer viewer-token'})
    lv = client.get('/live-validation', headers={'Authorization': 'Bearer viewer-token'})
    assert dq.status_code == 200
    assert dq.json()['production_data']['event_count'] >= 2
    assert lv.status_code == 200
    assert lv.json()['live_validation']['micro_live_runs'][0]['strategy'] == 'momentum'


def test_runtime_bundle_contains_v35_v37_sections() -> None:
    settings = Settings()
    settings.runtime_seconds = 0.1
    bundle = build_runtime_bundle(settings)
    snap = bundle.snapshot()
    assert 'alpha_governance' in snap
    assert 'production_data' in snap
    assert 'live_validation' in snap
    bundle.journal.close()
