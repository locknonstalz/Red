from __future__ import annotations

from dataclasses import dataclass, field

from common.models import Signal, Tick
from research.attribution import StrategyAttributionService
from research.external_research import ExternalResearchIngestionLayer
from research.regime import MarketRegimeClassifier


@dataclass(slots=True)
class StrategyAllocationDecision:
    accepted: bool
    reason: str
    signal: Signal | None
    weight: float


@dataclass(slots=True)
class StrategyAllocatorSnapshot:
    regime: str
    weights: dict[str, float] = field(default_factory=dict)


class StrategyAllocatorService:
    def __init__(
        self,
        attribution: StrategyAttributionService,
        regime_classifier: MarketRegimeClassifier,
        external_research: ExternalResearchIngestionLayer,
        *,
        default_weight: float = 1.0,
        min_weight: float = 0.25,
        max_weight: float = 1.75,
    ) -> None:
        self.attribution = attribution
        self.regime_classifier = regime_classifier
        self.external_research = external_research
        self.default_weight = default_weight
        self.min_weight = min_weight
        self.max_weight = max_weight
        self._weights: dict[str, float] = {}
        self._last_regime = 'unknown'

    def _expected_pnl_score(self, strategy: str) -> float:
        stats = self.attribution.snapshot().get(strategy)
        if stats is None or stats.trades == 0:
            return 0.0
        avg = stats.net_pnl / max(stats.trades, 1)
        hit = stats.wins / max(stats.trades, 1)
        return avg * 0.02 + (hit - 0.5) * 0.8

    def _regime_multiplier(self, regime: str, strategy: str) -> float:
        if regime == 'trend':
            if strategy in {'momentum', 'liquidity_taking'}:
                return 1.2
            if strategy in {'statistical_arbitrage'}:
                return 0.85
        if regime == 'mean_reversion':
            if strategy in {'statistical_arbitrage', 'market_making'}:
                return 1.2
            if strategy in {'liquidity_taking'}:
                return 0.85
        return 1.0

    def current_weight(self, strategy: str) -> float:
        return self._weights.get(strategy, self.default_weight)

    def evaluate(self, signal: Signal, tick: Tick) -> StrategyAllocationDecision:
        regime = self.regime_classifier.snapshot(signal.venue, signal.symbol)
        regime_name = regime.regime if regime is not None else 'unknown'
        self._last_regime = regime_name
        research_bias = self.external_research.aggregate_score(signal.symbol)
        attr_score = self._expected_pnl_score(signal.strategy)
        raw = self.default_weight + attr_score + research_bias * 0.25
        raw *= self._regime_multiplier(regime_name, signal.strategy)
        weight = max(self.min_weight, min(self.max_weight, raw))
        self._weights[signal.strategy] = weight
        if weight < 0.3:
            return StrategyAllocationDecision(False, 'strategy_allocator_blocked', None, weight)
        adjusted = Signal(
            strategy=signal.strategy,
            venue=signal.venue,
            symbol=signal.symbol,
            side=signal.side,
            strength=signal.strength,
            reason=signal.reason,
            ts=signal.ts,
            qty=(signal.qty or 0.0) * weight if signal.qty is not None else None,
            order_type=signal.order_type,
            limit_price=signal.limit_price,
            tags={**signal.tags, 'allocator_weight': round(weight, 4), 'allocator_regime': regime_name},
        )
        return StrategyAllocationDecision(True, 'ok', adjusted, weight)

    def snapshot(self) -> StrategyAllocatorSnapshot:
        return StrategyAllocatorSnapshot(regime=self._last_regime, weights=dict(sorted(self._weights.items())))
