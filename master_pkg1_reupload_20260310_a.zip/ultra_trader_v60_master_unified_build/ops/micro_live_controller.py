
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict

from scoreboard.alpha_scoreboard import StrategyCosts, make_scorecard
from ops.micro_live_hardening import DriftSnapshot, StrategyRunStats, CostMetrics, MicroLiveHardeningService
from ops.operator_review import DailyOperatorReview
from ops.rollout_manager import RolloutManager, RolloutDecision

@dataclass
class StrategyRunInput:
    strategy: str
    venue: str
    gross_pnl: float
    fees: float
    slippage_cost: float
    funding_drag: float
    hedge_cost: float
    adverse_fill_rate: float
    capacity_score: float
    drift: DriftSnapshot
    stats: StrategyRunStats
    current_stage: str = 'micro_live'

@dataclass
class MicroLiveController:
    hardening: MicroLiveHardeningService = field(default_factory=MicroLiveHardeningService)
    rollout: RolloutManager = field(default_factory=RolloutManager)

    def evaluate(self, run: StrategyRunInput) -> Dict[str, object]:
        costs = StrategyCosts(
            gross_pnl=run.gross_pnl,
            fees=run.fees,
            slippage_cost=run.slippage_cost,
            funding_drag=run.funding_drag,
            hedge_cost=run.hedge_cost,
        )
        scorecard = make_scorecard(run.strategy, run.venue, costs, run.adverse_fill_rate, run.capacity_score)
        hardening = self.hardening.snapshot(
            run.drift,
            CostMetrics(
                gross_pnl=run.gross_pnl,
                net_pnl=costs.net_pnl,
                fees=run.fees,
                slippage_cost=run.slippage_cost,
                funding_drag=run.funding_drag,
                hedge_cost=run.hedge_cost,
            ),
            run.stats,
        )
        decision = self.rollout.decide(run.current_stage, scorecard['recommendation'], hardening['final_action'])
        review = DailyOperatorReview(
            strategy=run.strategy,
            metrics=scorecard,
            guard_snapshot=hardening,
            recommendation=decision.action,
        )
        return {
            'scorecard': scorecard,
            'hardening': hardening,
            'rollout_decision': decision,
            'review': review,
        }
