
from fastapi.testclient import TestClient

from ai.decision_engine import AIDecisionEngine
from capital.protection import CapitalProtectionService
from common.models import Order, Side, Tick
from config.settings import CapitalProtectionSettings
from control_plane.api import create_control_plane_app
from control_plane.service import ControlPlaneService
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.journal import SqliteJournal
from strategy.shadow import ShadowDeploymentService


def _build():
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    capital = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    ai = AIDecisionEngine(metrics=metrics, enabled=True, model_path='/tmp/nonexistent-v26.json')
    shadow = ShadowDeploymentService(journal=journal, shadow_strategies={'alpha'})
    control = ControlPlaneService(
        capital_protection=capital,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        ai_engine=ai,
        shadow=shadow,
    )
    return journal, shadow, create_control_plane_app(control)


def test_confirmation_flow_executes_requested_action() -> None:
    _, _, app = _build()
    client = TestClient(app)
    req = client.post('/controls/request/global-kill', json={'enabled': True, 'reason': 'ops_drill'})
    assert req.status_code == 200
    payload = req.json()
    assert payload['confirmation_required'] is True
    confirmation_id = payload['confirmation_id']

    res = client.post('/controls/confirm/execute', json={'confirmation_id': confirmation_id})
    assert res.status_code == 200
    assert res.json()['ok'] is True
    state = client.get('/state').json()
    assert state['protection']['global_kill_switch'] is True


def test_shadow_tracks_proxy_pnl() -> None:
    _, shadow, _ = _build()
    order = Order(strategy='alpha', venue='binance', symbol='BTC/USDT', side=Side.BUY, qty=2.0)
    shadow.capture(order, mark_price=100.0)
    shadow.observe_tick(Tick(venue='binance', symbol='BTC/USDT', price=101.0, bid=100.9, ask=101.1))
    snap = shadow.snapshot()
    assert snap['unrealized_pnl_by_strategy']['alpha'] > 0
    realized = shadow.close_strategy('alpha')
    assert realized > 0
    assert shadow.snapshot()['realized_proxy_pnl_by_strategy']['alpha'] > 0
