v20 Research & Analytics Layer

Includes AssetAnalysisService, UniverseSelectionEngine, IndicatorEngine, CandlePatternEngine, StrategyAttributionService, MarketRegimeClassifier, ExternalResearchIngestionLayer, and SignalScoringLayer.
