from __future__ import annotations

from collections import deque
from statistics import fmean, pstdev
from typing import Sequence

from common.models import Side, Signal, Tick
from strategy.base import Strategy


class StatisticalArbitrageStrategy(Strategy):
    def __init__(self, name: str, lead_venue: str, lag_venue: str, symbol: str, trade_size: float, window: int = 40, entry_z: float = 1.8, exit_z: float = 0.4) -> None:
        self.name = name
        self.lead_venue = lead_venue
        self.lag_venue = lag_venue
        self.symbol = symbol
        self.trade_size = trade_size
        self.window = deque(maxlen=window)
        self.entry_z = entry_z
        self.exit_z = exit_z
        self._latest: dict[str, Tick] = {}
        self._state = 0

    def on_tick(self, tick: Tick) -> Sequence[Signal]:
        if tick.symbol != self.symbol:
            return []
        self._latest[tick.venue] = tick
        if self.lead_venue not in self._latest or self.lag_venue not in self._latest:
            return []
        lead = self._latest[self.lead_venue]
        lag = self._latest[self.lag_venue]
        spread = lead.mid - lag.mid
        self.window.append(spread)
        if len(self.window) < self.window.maxlen:
            return []
        mu = fmean(self.window)
        sigma = pstdev(self.window) or 1e-9
        z = (spread - mu) / sigma
        if self._state == 0 and z >= self.entry_z:
            self._state = -1
            return [
                Signal(self.name, self.lead_venue, self.symbol, Side.SELL, abs(z), f"zscore_open_short_lead={z:.2f}", qty=self.trade_size, tags={"zscore": round(z, 3)}),
                Signal(self.name, self.lag_venue, self.symbol, Side.BUY, abs(z), f"zscore_open_long_lag={z:.2f}", qty=self.trade_size, tags={"zscore": round(z, 3)}),
            ]
        if self._state == 0 and z <= -self.entry_z:
            self._state = 1
            return [
                Signal(self.name, self.lead_venue, self.symbol, Side.BUY, abs(z), f"zscore_open_long_lead={z:.2f}", qty=self.trade_size, tags={"zscore": round(z, 3)}),
                Signal(self.name, self.lag_venue, self.symbol, Side.SELL, abs(z), f"zscore_open_short_lag={z:.2f}", qty=self.trade_size, tags={"zscore": round(z, 3)}),
            ]
        if self._state != 0 and abs(z) <= self.exit_z:
            side_lead = Side.BUY if self._state == -1 else Side.SELL
            side_lag = Side.SELL if self._state == -1 else Side.BUY
            self._state = 0
            return [
                Signal(self.name, self.lead_venue, self.symbol, side_lead, 0.5, f"zscore_close_lead={z:.2f}", qty=self.trade_size, tags={"zscore": round(z, 3)}),
                Signal(self.name, self.lag_venue, self.symbol, side_lag, 0.5, f"zscore_close_lag={z:.2f}", qty=self.trade_size, tags={"zscore": round(z, 3)}),
            ]
        return []
