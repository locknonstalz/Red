from __future__ import annotations

from dataclasses import dataclass, field

from common.models import Order, Side, Tick
from config.settings import CapitalProtectionSettings
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.base import Journal


@dataclass(slots=True)
class ProtectionDecision:
    allowed: bool
    reason: str = "OK"
    adjusted_qty: float | None = None


@dataclass(slots=True)
class PositionGuardState:
    high: float
    low: float
    holding_ticks: int = 0
    stop_sent: bool = False


class CapitalProtectionService:
    def __init__(self, settings: CapitalProtectionSettings, portfolio: PortfolioService, journal: Journal, metrics: MetricsRegistry) -> None:
        self.settings = settings
        self.portfolio = portfolio
        self.journal = journal
        self.metrics = metrics
        self._equity_peak = 0.0
        self._global_kill = settings.global_kill_switch
        self._only_close = settings.only_close_mode
        self._strategy_disabled: set[str] = set()
        self._strategy_realized: dict[str, float] = {}
        self._strategy_losses: dict[str, int] = {}
        self._strategy_traded_notional: dict[str, float] = {}
        self._rejection_count = 0
        self._circuit_cooldown = 0
        self._last_mid: dict[tuple[str, str], float] = {}
        self._position_guards: dict[tuple[str, str], PositionGuardState] = {}

    @property
    def global_kill_switch(self) -> bool:
        return self._global_kill

    @property
    def only_close_mode(self) -> bool:
        return self._only_close

    def disable_strategy(self, strategy: str, reason: str) -> None:
        self._strategy_disabled.add(strategy)
        self.journal.record_protection_event('strategy_kill', strategy, reason, {'strategy': strategy})
        self.metrics.increment('capital_strategy_kills_total')

    def enable_only_close_mode(self, reason: str) -> None:
        self._only_close = True
        self.journal.record_protection_event('only_close', 'global', reason, {})
        self.metrics.increment('capital_only_close_total')

    def disable_only_close_mode(self, reason: str) -> None:
        self._only_close = False
        self.journal.record_protection_event('only_close_clear', 'global', reason, {})

    def trigger_global_kill(self, reason: str) -> None:
        self._global_kill = True
        self.journal.record_protection_event('global_kill', 'global', reason, {})
        self.metrics.increment('capital_global_kill_total')

    def clear_global_kill(self, reason: str) -> None:
        self._global_kill = False
        self.journal.record_protection_event('global_kill_clear', 'global', reason, {})

    def enable_strategy(self, strategy: str, reason: str) -> None:
        self._strategy_disabled.discard(strategy)
        self.journal.record_protection_event('strategy_enable', strategy, reason, {'strategy': strategy})


    def state_snapshot(self) -> dict:
        portfolio = self.portfolio.snapshot()
        equity = portfolio.realized_pnl + portfolio.unrealized_pnl
        daily_loss = max(-portfolio.realized_pnl, 0.0)
        drawdown = max(self._equity_peak - equity, 0.0)
        return {
            'global_kill_switch': self._global_kill,
            'only_close_mode': self._only_close,
            'disabled_strategies': sorted(self._strategy_disabled),
            'equity_peak': self._equity_peak,
            'equity': equity,
            'daily_loss': daily_loss,
            'drawdown': drawdown,
            'strategy_realized': dict(self._strategy_realized),
            'strategy_losses': dict(self._strategy_losses),
            'rejection_count': self._rejection_count,
            'circuit_cooldown': self._circuit_cooldown,
        }

    def note_execution_rejection(self, reason: str) -> None:
        self._rejection_count += 1
        if self._rejection_count >= self.settings.circuit_breaker.max_rejections:
            self._circuit_cooldown = self.settings.circuit_breaker.cooldown_ticks
            self.enable_only_close_mode(f'rejection_spike:{reason}')

    def on_tick(self, tick: Tick) -> None:
        key = (tick.venue, tick.symbol)
        prev_mid = self._last_mid.get(key)
        if prev_mid:
            vol_bps = abs(tick.mid - prev_mid) / prev_mid * 10000.0
            if vol_bps >= self.settings.circuit_breaker.max_volatility_bps:
                self._circuit_cooldown = self.settings.circuit_breaker.cooldown_ticks
                self.enable_only_close_mode('volatility_circuit_breaker')
        self._last_mid[key] = tick.mid
        spread_bps = (tick.spread / tick.mid * 10000.0) if tick.mid > 0 else 0.0
        if spread_bps >= self.settings.circuit_breaker.max_spread_bps:
            self._circuit_cooldown = self.settings.circuit_breaker.cooldown_ticks
            self.enable_only_close_mode('spread_circuit_breaker')
        if self._circuit_cooldown > 0:
            self._circuit_cooldown -= 1
            if self._circuit_cooldown == 0 and not self._global_kill:
                self._only_close = False
                self.journal.record_protection_event('only_close_clear', 'global', 'cooldown_expired', {})

    def evaluate_order(self, order: Order, tick: Tick | None) -> ProtectionDecision:
        if not self.settings.enabled:
            return ProtectionDecision(True)
        if self._global_kill:
            return ProtectionDecision(False, 'global_kill_switch')
        if order.strategy in self._strategy_disabled:
            return ProtectionDecision(False, 'strategy_kill_switch')
        portfolio = self.portfolio.snapshot()
        equity = portfolio.realized_pnl + portfolio.unrealized_pnl
        self._equity_peak = max(self._equity_peak, equity)
        daily_loss = max(-portfolio.realized_pnl, 0.0)
        if daily_loss >= self.settings.daily_loss.max_daily_loss:
            if self.settings.daily_loss.lockout_on_breach:
                self.enable_only_close_mode('daily_loss_guard')
            return ProtectionDecision(False, 'daily_loss_guard')
        drawdown = self._equity_peak - equity
        if drawdown >= self.settings.drawdown.kill_at:
            self.trigger_global_kill('drawdown_governor_kill')
            return ProtectionDecision(False, 'drawdown_kill')
        if drawdown >= self.settings.drawdown.pause_at:
            self.enable_only_close_mode('drawdown_governor_pause')
            return ProtectionDecision(False, 'drawdown_pause')
        adjusted_qty = order.qty
        if drawdown >= self.settings.drawdown.reduce_at:
            adjusted_qty = max(order.qty * self.settings.drawdown.reduced_size_factor, 0.0)
        if tick is not None and tick.mid > 0:
            notional = tick.mid * adjusted_qty
            if portfolio.gross_notional + notional > self.settings.allocator.max_total_notional:
                return ProtectionDecision(False, 'capital_allocator_total_limit')
            weight = self.settings.allocator.strategy_weights.get(order.strategy, self.settings.allocator.default_strategy_weight)
            traded = self._strategy_traded_notional.get(order.strategy, 0.0)
            if traded + notional > self.settings.allocator.max_total_notional * weight:
                return ProtectionDecision(False, 'capital_allocator_strategy_budget')
        if self._only_close:
            pos = self.portfolio.get_position(order.symbol, venue=order.venue)
            current = pos.qty
            signed = adjusted_qty if order.side == Side.BUY else -adjusted_qty
            if current == 0 or abs(current + signed) > abs(current):
                return ProtectionDecision(False, 'only_close_mode')
        return ProtectionDecision(True, 'OK', adjusted_qty=adjusted_qty)

    def on_fill(self, fill) -> None:
        strategy = getattr(fill, 'strategy', '') or 'unknown'
        traded_notional = fill.qty * fill.price
        self._strategy_traded_notional[strategy] = self._strategy_traded_notional.get(strategy, 0.0) + traded_notional
        signed_pnl = -fill.fee
        if signed_pnl < 0:
            self._strategy_losses[strategy] = self._strategy_losses.get(strategy, 0) + 1
        else:
            self._strategy_losses[strategy] = 0
        self._strategy_realized[strategy] = self._strategy_realized.get(strategy, 0.0) + signed_pnl
        if -self._strategy_realized[strategy] >= self.settings.strategy_kill.max_strategy_daily_loss:
            self.disable_strategy(strategy, 'strategy_daily_loss_guard')
        if self._strategy_losses[strategy] >= self.settings.strategy_kill.max_consecutive_losses:
            self.disable_strategy(strategy, 'strategy_consecutive_losses_guard')

    def protective_orders(self, tick: Tick) -> list[Order]:
        pos = self.portfolio.get_position(tick.symbol, venue=tick.venue)
        if pos.qty == 0:
            self._position_guards.pop((tick.venue, tick.symbol), None)
            return []
        key = (tick.venue, tick.symbol)
        state = self._position_guards.setdefault(key, PositionGuardState(high=tick.price, low=tick.price))
        state.holding_ticks += 1
        state.high = max(state.high, tick.price)
        state.low = min(state.low, tick.price)
        if state.stop_sent:
            return []
        side = Side.SELL if pos.qty > 0 else Side.BUY
        reason = None
        entry = pos.avg_price or tick.price
        if pos.qty > 0:
            if tick.price <= entry * (1 - self.settings.position_protection.stop_loss_bps / 10000.0):
                reason = 'stop_loss'
            elif tick.price <= state.high * (1 - self.settings.position_protection.trailing_stop_bps / 10000.0):
                reason = 'trailing_stop'
            elif tick.price >= entry * (1 + self.settings.position_protection.take_profit_bps / 10000.0):
                reason = 'take_profit'
        else:
            if tick.price >= entry * (1 + self.settings.position_protection.stop_loss_bps / 10000.0):
                reason = 'stop_loss'
            elif tick.price >= state.low * (1 + self.settings.position_protection.trailing_stop_bps / 10000.0):
                reason = 'trailing_stop'
            elif tick.price <= entry * (1 - self.settings.position_protection.take_profit_bps / 10000.0):
                reason = 'take_profit'
        if state.holding_ticks >= self.settings.position_protection.max_holding_ticks:
            reason = reason or 'time_stop'
        if reason is None:
            return []
        state.stop_sent = True
        self.journal.record_protection_event('position_protection', f'{tick.venue}:{tick.symbol}', reason, {'qty': abs(pos.qty)})
        self.metrics.increment('capital_position_protection_total')
        return [Order(strategy='position_protection', venue=tick.venue, symbol=tick.symbol, side=side, qty=abs(pos.qty))]
