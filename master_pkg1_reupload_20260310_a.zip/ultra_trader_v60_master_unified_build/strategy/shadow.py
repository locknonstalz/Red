
from __future__ import annotations

from dataclasses import dataclass, field

from common.models import Order, Side, Tick
from storage.base import Journal


@dataclass(slots=True)
class ShadowOrder:
    strategy: str
    venue: str
    symbol: str
    side: Side
    qty: float
    entry_price: float


@dataclass(slots=True)
class ShadowStats:
    signals: int = 0
    accepted: int = 0
    blocked: int = 0
    by_strategy: dict[str, int] = field(default_factory=dict)
    unrealized_pnl_by_strategy: dict[str, float] = field(default_factory=dict)
    realized_proxy_pnl_by_strategy: dict[str, float] = field(default_factory=dict)
    last_mark_by_symbol: dict[str, float] = field(default_factory=dict)


class ShadowDeploymentService:
    def __init__(self, journal: Journal, shadow_strategies: set[str] | None = None) -> None:
        self.journal = journal
        self.shadow_strategies = shadow_strategies or set()
        self._stats = ShadowStats()
        self._open_orders: list[ShadowOrder] = []

    def enabled_for(self, strategy: str) -> bool:
        return strategy in self.shadow_strategies

    def capture(self, order: Order, *, reason: str = 'shadow_mode', mark_price: float | None = None) -> None:
        self._stats.signals += 1
        self._stats.accepted += 1
        self._stats.by_strategy[order.strategy] = self._stats.by_strategy.get(order.strategy, 0) + 1
        entry_price = float(mark_price if mark_price is not None else order.limit_price or 0.0)
        if entry_price > 0:
            self._open_orders.append(ShadowOrder(
                strategy=order.strategy,
                venue=order.venue,
                symbol=order.symbol,
                side=order.side,
                qty=order.qty,
                entry_price=entry_price,
            ))
        self.journal.record_protection_event('shadow_order', order.strategy, reason, {
            'venue': order.venue,
            'symbol': order.symbol,
            'side': order.side.value,
            'qty': order.qty,
            'order_type': order.order_type.value,
            'entry_price': entry_price,
        })

    def observe_tick(self, tick: Tick) -> None:
        key = f"{tick.venue}:{tick.symbol}"
        self._stats.last_mark_by_symbol[key] = tick.mid
        totals: dict[str, float] = {}
        for shadow in self._open_orders:
            if shadow.venue != tick.venue or shadow.symbol != tick.symbol:
                continue
            direction = 1.0 if shadow.side == Side.BUY else -1.0
            pnl = (tick.mid - shadow.entry_price) * shadow.qty * direction
            totals[shadow.strategy] = totals.get(shadow.strategy, 0.0) + pnl
        for strategy, pnl in totals.items():
            self._stats.unrealized_pnl_by_strategy[strategy] = round(pnl, 10)

    def close_strategy(self, strategy: str, mark_price: float | None = None) -> float:
        realized = 0.0
        remaining: list[ShadowOrder] = []
        for shadow in self._open_orders:
            if shadow.strategy != strategy:
                remaining.append(shadow)
                continue
            current = float(mark_price if mark_price is not None else self._stats.last_mark_by_symbol.get(f"{shadow.venue}:{shadow.symbol}", shadow.entry_price))
            direction = 1.0 if shadow.side == Side.BUY else -1.0
            realized += (current - shadow.entry_price) * shadow.qty * direction
        self._open_orders = remaining
        if realized:
            self._stats.realized_proxy_pnl_by_strategy[strategy] = round(self._stats.realized_proxy_pnl_by_strategy.get(strategy, 0.0) + realized, 10)
        self._stats.unrealized_pnl_by_strategy[strategy] = 0.0
        return realized

    def snapshot(self) -> dict:
        return {
            'shadow_strategies': sorted(self.shadow_strategies),
            'signals': self._stats.signals,
            'accepted': self._stats.accepted,
            'blocked': self._stats.blocked,
            'open_shadow_orders': len(self._open_orders),
            'by_strategy': dict(sorted(self._stats.by_strategy.items())),
            'unrealized_pnl_by_strategy': dict(sorted(self._stats.unrealized_pnl_by_strategy.items())),
            'realized_proxy_pnl_by_strategy': dict(sorted(self._stats.realized_proxy_pnl_by_strategy.items())),
        }
