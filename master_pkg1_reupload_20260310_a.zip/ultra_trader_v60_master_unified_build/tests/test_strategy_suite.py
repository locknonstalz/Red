from common.models import OrderType, Side, Tick
from strategy.cross_exchange_arbitrage import CrossExchangeArbitrageStrategy
from strategy.liquidity_taking import LiquidityTakingStrategy
from strategy.market_making import MarketMakingStrategy
from strategy.statistical_arbitrage import StatisticalArbitrageStrategy


def test_market_making_emits_two_sided_limit_quotes():
    strat = MarketMakingStrategy('mm', 'binance', 'BTC/USDT', quote_size=0.01, requote_cooldown_ticks=1, min_spread_bps=0.5)
    found = []
    for i in range(50):
        out = list(strat.on_tick(Tick('binance', 'BTC/USDT', 50000 + i * 0.1, 49998 + i * 0.1, 50002 + i * 0.1)))
        if out:
            found = out
            break
    assert len(found) == 2
    assert {s.side for s in found} == {Side.BUY, Side.SELL}
    assert all(s.order_type == OrderType.LIMIT for s in found)


def test_cross_exchange_arbitrage_emits_paired_legs():
    strat = CrossExchangeArbitrageStrategy('arb', 'BTC/USDT', trade_size=0.01, min_edge_bps=5.0)
    assert list(strat.on_tick(Tick('binance', 'BTC/USDT', 100.0, 99.9, 100.1))) == []
    out = list(strat.on_tick(Tick('bybit', 'BTC/USDT', 100.8, 100.7, 100.9)))
    assert len(out) == 2
    assert {s.venue for s in out} == {'binance', 'bybit'}
    assert {s.side for s in out} == {Side.BUY, Side.SELL}


def test_stat_arb_opens_and_closes_pair():
    strat = StatisticalArbitrageStrategy('stat', 'binance', 'bybit', 'BTC/USDT', trade_size=0.01, window=5, entry_z=1.0, exit_z=0.2)
    for i in range(5):
        strat.on_tick(Tick('binance', 'BTC/USDT', 100 + i * 0.1, 99.9 + i * 0.1, 100.1 + i * 0.1))
        strat.on_tick(Tick('bybit', 'BTC/USDT', 100 + i * 0.1, 99.9 + i * 0.1, 100.1 + i * 0.1))
    opened = strat.on_tick(Tick('binance', 'BTC/USDT', 101.5, 101.4, 101.6))
    opened = strat.on_tick(Tick('bybit', 'BTC/USDT', 100.0, 99.9, 100.1)) or opened
    assert len(opened) == 2
    closed = []
    for _ in range(10):
        closed = strat.on_tick(Tick('binance', 'BTC/USDT', 100.0, 99.9, 100.1))
        closed = strat.on_tick(Tick('bybit', 'BTC/USDT', 100.0, 99.9, 100.1)) or closed
        if closed:
            break
    assert len(closed) == 2


def test_liquidity_taking_detects_breakout():
    strat = LiquidityTakingStrategy('lt', 'binance', 'BTC/USDT', trade_size=0.01, lookback=5, breakout_bps=3.0, min_spread_bps=5.0)
    out = []
    for px in [100.0, 100.01, 100.02, 100.03, 100.25]:
        out = list(strat.on_tick(Tick('binance', 'BTC/USDT', px, px - 0.01, px + 0.01)))
    assert len(out) == 1
    assert out[0].side == Side.BUY
