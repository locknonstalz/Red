from __future__ import annotations

from dataclasses import dataclass

from common.models import ExecutionPolicy, Order, OrderType, Side
from futures.models import FuturesOrderIntent


@dataclass(slots=True)
class FuturesExecutionContext:
    mark_price: float
    index_price: float | None = None
    funding_rate: float = 0.0
    basis_bps: float = 0.0
    liquidation_distance_bps: float = 9_999.0
    venue_health_score: float = 75.0
    position_qty: float = 0.0


@dataclass(slots=True)
class FuturesExecutionPlan:
    order: Order
    leverage: float
    reduce_only: bool
    close_only: bool
    execution_policy: ExecutionPolicy
    liquidation_distance_bps: float
    funding_bias: str
    route_score: float


@dataclass(slots=True)
class FuturesVenueRoute:
    venue: str
    score: float
    policy: ExecutionPolicy
    reason: str


@dataclass(slots=True)
class PerpBasisPairPlan:
    futures_intent: FuturesOrderIntent
    spot_side: Side
    spot_qty: float
    carry_direction: str


class FuturesExecutionService:
    def __init__(
        self,
        *,
        min_liquidation_distance_bps: float = 250.0,
        funding_passive_threshold: float = 0.0005,
        basis_aggressive_threshold_bps: float = 8.0,
    ) -> None:
        self.min_liquidation_distance_bps = min_liquidation_distance_bps
        self.funding_passive_threshold = funding_passive_threshold
        self.basis_aggressive_threshold_bps = basis_aggressive_threshold_bps

    def build_plan(
        self,
        intent: FuturesOrderIntent,
        context: FuturesExecutionContext | None = None,
    ) -> FuturesExecutionPlan:
        context = context or FuturesExecutionContext(mark_price=0.0)
        order = intent.to_order()
        order.execution_policy = self.choose_policy(intent, context)
        order.order_type = self._order_type(order.execution_policy)
        order.qty = self._normalized_qty(intent, context.position_qty)
        funding_bias = self._funding_bias(intent, context)
        route_score = self.route_score(context)
        return FuturesExecutionPlan(
            order=order,
            leverage=max(1.0, intent.leverage),
            reduce_only=bool(intent.reduce_only),
            close_only=bool(intent.close_only),
            execution_policy=order.execution_policy,
            liquidation_distance_bps=context.liquidation_distance_bps,
            funding_bias=funding_bias,
            route_score=route_score,
        )

    def choose_policy(self, intent: FuturesOrderIntent, context: FuturesExecutionContext) -> ExecutionPolicy:
        if intent.close_only or intent.reduce_only:
            return ExecutionPolicy.AGGRESSIVE
        if context.liquidation_distance_bps <= self.min_liquidation_distance_bps:
            return ExecutionPolicy.AGGRESSIVE
        if abs(context.basis_bps) >= self.basis_aggressive_threshold_bps and 'basis' in intent.strategy.lower():
            return ExecutionPolicy.VWAP
        if self._funding_bias(intent, context) == 'costly_to_hold':
            return ExecutionPolicy.PASSIVE
        if context.venue_health_score >= 80.0:
            return ExecutionPolicy.AGGRESSIVE
        return ExecutionPolicy.TWAP

    def route_score(self, context: FuturesExecutionContext) -> float:
        liq_score = min(max(context.liquidation_distance_bps / max(self.min_liquidation_distance_bps, 1.0), 0.1), 4.0)
        health_score = max(0.0, min(context.venue_health_score / 100.0, 1.0))
        funding_penalty = min(abs(context.funding_rate) * 10000.0 / 50.0, 1.0)
        return round(0.5 * liq_score + 0.45 * health_score - 0.15 * funding_penalty, 6)

    def rank_routes(self, venues: dict[str, FuturesExecutionContext], intent: FuturesOrderIntent) -> list[FuturesVenueRoute]:
        rows: list[FuturesVenueRoute] = []
        for venue, context in venues.items():
            policy = self.choose_policy(intent, context)
            rows.append(
                FuturesVenueRoute(
                    venue=venue,
                    score=self.route_score(context),
                    policy=policy,
                    reason=self._route_reason(context),
                )
            )
        return sorted(rows, key=lambda row: row.score, reverse=True)

    def build_basis_pair(self, *, venue: str, symbol: str, qty: float, basis_bps: float, leverage: float = 1.0) -> PerpBasisPairPlan:
        if basis_bps >= 0:
            futures_side = Side.SELL
            spot_side = Side.BUY
            carry_direction = 'short_perp_long_spot'
        else:
            futures_side = Side.BUY
            spot_side = Side.SELL
            carry_direction = 'long_perp_short_spot'
        intent = FuturesOrderIntent(
            strategy='basis_carry',
            venue=venue,
            symbol=symbol,
            side=futures_side,
            qty=qty,
            leverage=leverage,
            reduce_only=False,
            close_only=False,
        )
        return PerpBasisPairPlan(
            futures_intent=intent,
            spot_side=spot_side,
            spot_qty=qty,
            carry_direction=carry_direction,
        )

    def _normalized_qty(self, intent: FuturesOrderIntent, position_qty: float) -> float:
        if intent.close_only or intent.reduce_only:
            if position_qty == 0:
                return 0.0
            return min(abs(intent.qty), abs(position_qty))
        return abs(intent.qty)

    def _funding_bias(self, intent: FuturesOrderIntent, context: FuturesExecutionContext) -> str:
        if context.funding_rate >= self.funding_passive_threshold and intent.side == Side.BUY:
            return 'costly_to_hold'
        if context.funding_rate <= -self.funding_passive_threshold and intent.side == Side.SELL:
            return 'costly_to_hold'
        return 'neutral_or_favorable'

    def _route_reason(self, context: FuturesExecutionContext) -> str:
        if context.liquidation_distance_bps <= self.min_liquidation_distance_bps:
            return 'liquidation_distance_risk'
        if abs(context.funding_rate) >= self.funding_passive_threshold:
            return 'funding_sensitive'
        return 'healthy_route'

    def _order_type(self, policy: ExecutionPolicy) -> OrderType:
        if policy in {ExecutionPolicy.AGGRESSIVE, ExecutionPolicy.VWAP}:
            return OrderType.MARKET
        return OrderType.LIMIT
