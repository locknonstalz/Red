# V28 Live Operator Drills, Certification Evidence, and Go-Live Scoring

This release adds three operator-facing layers:

- operator drill execution and history
- automated certification evidence ingestion
- strategy go-live readiness scoring

## New APIs

- `GET /go-live/scores`
- `POST /drills/run`
- `GET /drills`
- `POST /certification/ingest`
- `POST /go-live/evidence`

## Operator drills

Supported drill examples:

- `only_close`
- `global_kill`
- `alert_ack`
- `incident_flow`
- `promotion_gate`
- `reconnect_recovery`

## Certification evidence

The control plane can ingest exchange certification results and store them as machine-readable readiness evidence.

## Go-live scoring

Go-live scoring combines:

- current promotion stage
- shadow PnL proxy
- recent drill success ratio
- latest strategy evidence
- active incidents
- unacknowledged alerts

The output verdict is one of:

- `go`
- `hold`
- `block`
