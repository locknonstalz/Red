# Secrets and KMS Blueprint

## Secret classes
- exchange API key / secret
- websocket auth tokens or listen-key bootstrap credentials
- database credentials
- Alertmanager Slack webhook
- PagerDuty routing key
- Grafana admin secret

## Storage policy
- no long-lived secrets committed to repository
- production secrets must come from Vault or a managed KMS-backed secret store
- secrets exposed to processes only through short-lived leased material or injected files

## Recommended models
### Vault
- KV v2 for static bootstrap metadata
- Transit engine for signing helpers if needed
- AppRole or Kubernetes auth for workloads
- response wrapping for break-glass operations

### Cloud KMS + secret manager
- store encrypted payloads in secret manager
- use workload identity / instance profiles
- rotate quarterly or on incident

## Rotation policy
- routine rotation every 90 days
- immediate rotation on role change, suspected leak, or failed offboarding
- dual-control for production venue credentials
