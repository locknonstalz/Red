from __future__ import annotations

from dataclasses import dataclass, asdict
from math import sqrt

from mlops.feature_store import FeatureRecord, FeatureStore
from mlops.model_registry import ModelRegistry
from mlops.trainer import OfflineTrainer, TrainingExample
from mlops.validation import WalkForwardValidator


@dataclass(slots=True)
class DriftReport:
    feature: str
    baseline_mean: float
    live_mean: float
    drift_score: float
    is_alert: bool


@dataclass(slots=True)
class ModelHealth:
    name: str
    version: str
    accuracy: float
    precision: float
    drift_alerts: int
    should_rollback: bool


@dataclass(slots=True)
class ChallengerDecision:
    promote: bool
    champion_version: str
    challenger_version: str
    reason: str


class FeatureDriftDetector:
    def compare(self, baseline: list[FeatureRecord], live: list[FeatureRecord]) -> list[DriftReport]:
        if not baseline or not live:
            return []
        keys = sorted({k for rec in baseline + live for k in rec.features})
        reports: list[DriftReport] = []
        for key in keys:
            base_vals = [rec.features.get(key, 0.0) for rec in baseline]
            live_vals = [rec.features.get(key, 0.0) for rec in live]
            bmean = sum(base_vals) / len(base_vals)
            lmean = sum(live_vals) / len(live_vals)
            bvar = sum((x - bmean) ** 2 for x in base_vals) / len(base_vals)
            score = abs(lmean - bmean) / max(sqrt(bvar), 1e-9)
            reports.append(DriftReport(feature=key, baseline_mean=bmean, live_mean=lmean, drift_score=score, is_alert=score >= 2.0))
        return reports


class ModelMonitor:
    def assess(self, name: str, version: str, validation_report, drift_reports: list[DriftReport]) -> ModelHealth:
        drift_alerts = sum(1 for item in drift_reports if item.is_alert)
        should_rollback = drift_alerts >= 2 or validation_report.accuracy < 0.5
        return ModelHealth(name=name, version=version, accuracy=validation_report.accuracy, precision=validation_report.precision, drift_alerts=drift_alerts, should_rollback=should_rollback)


class ChampionChallengerManager:
    def decide(self, champion: dict | None, challenger: dict | None) -> ChallengerDecision:
        champ_v = '' if champion is None else str(champion.get('version', ''))
        chall_v = '' if challenger is None else str(challenger.get('version', ''))
        if challenger is None:
            return ChallengerDecision(promote=False, champion_version=champ_v, challenger_version=chall_v, reason='no_challenger')
        if champion is None:
            return ChallengerDecision(promote=True, champion_version=champ_v, challenger_version=chall_v, reason='no_champion')
        champ_acc = float(champion.get('metrics', {}).get('accuracy', 0.0))
        chall_acc = float(challenger.get('metrics', {}).get('accuracy', 0.0))
        champ_prec = float(champion.get('metrics', {}).get('precision', 0.0))
        chall_prec = float(challenger.get('metrics', {}).get('precision', 0.0))
        if chall_acc > champ_acc + 0.03 and chall_prec >= champ_prec - 0.02:
            return ChallengerDecision(promote=True, champion_version=champ_v, challenger_version=chall_v, reason='better_validation')
        return ChallengerDecision(promote=False, champion_version=champ_v, challenger_version=chall_v, reason='champion_stable')


class AdvancedMLLifecycle:
    def __init__(self, feature_store: FeatureStore, model_registry: ModelRegistry | None = None) -> None:
        self.feature_store = feature_store
        self.model_registry = model_registry or ModelRegistry()
        self.trainer = OfflineTrainer()
        self.validator = WalkForwardValidator(self.trainer)
        self.drift = FeatureDriftDetector()
        self.monitor = ModelMonitor()
        self.cc = ChampionChallengerManager()

    def train_and_register(self, model_name: str, version: str, examples: list[TrainingExample], artifact_path: str) -> dict:
        weights = self.trainer.train(examples)
        self.trainer.persist(weights, artifact_path)
        validation = self.validator.validate(examples)
        self.model_registry.register(model_name, version, {'accuracy': validation.accuracy, 'precision': validation.precision}, artifact_path)
        return {'weights': weights, 'validation': asdict(validation)}

    def evaluate_live_health(self, model_name: str, version: str, baseline: list[FeatureRecord], live: list[FeatureRecord], validation_report) -> ModelHealth:
        drift_reports = self.drift.compare(baseline, live)
        return self.monitor.assess(model_name, version, validation_report, drift_reports)
