from __future__ import annotations

from dotenv import load_dotenv
load_dotenv()

import argparse
import asyncio
import json
from pathlib import Path

from certification.runner import ExchangeCertificationPack


async def _main() -> int:
    parser = argparse.ArgumentParser(description='Run exchange certification pack against testnet/demo/live-guarded venues.')
    parser.add_argument('--venues', default='binance,bybit,mexc,bitget', help='Comma-separated venues')
    parser.add_argument('--out', default='certification_report.json', help='Where to write JSON report')
    args = parser.parse_args()

    venues = [part.strip().lower() for part in args.venues.split(',') if part.strip()]
    pack = ExchangeCertificationPack()
    report = await pack.run_and_serialize(venues)

    out_path = Path(args.out)
    out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps(report, indent=2, ensure_ascii=False))
    failures = [venue for venue, result in report.items() if not result.get('success')]
    if failures:
        print(f'FAILED venues: {", ".join(failures)}')
        return 1
    print('All requested venues passed certification.')
    return 0


if __name__ == '__main__':
    raise SystemExit(asyncio.run(_main()))
