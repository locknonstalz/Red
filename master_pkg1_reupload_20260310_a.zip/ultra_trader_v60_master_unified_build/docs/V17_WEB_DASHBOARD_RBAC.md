# v17 Web Dashboard, RBAC, Auth, Audit Signing, Slack/PagerDuty

## Что добавлено
- Web dashboard: `GET /dashboard`
- RBAC роли: `viewer`, `operator`, `admin`
- Bearer auth для control plane
- HMAC-signed audit trail для ручных действий оператора
- Реальные sinks для Slack webhook, PagerDuty Events API v2 и generic webhook

## Переменные среды
- `CONTROL_PLANE_AUTH_ENABLED=1`
- `CONTROL_PLANE_AUTH_SECRET=...`
- `CONTROL_PLANE_AUTH_ISSUER=ultra-trader`
- `CONTROL_PLANE_AUDIT_SECRET=...`
- `CONTROL_PLANE_STATIC_TOKENS_JSON={...}`

Пример:
```json
{
  "viewer-token": {"subject": "alice", "role": "viewer"},
  "ops-token": {"subject": "bob", "role": "operator"},
  "admin-token": {"subject": "carol", "role": "admin"}
}
```

## Роли
- `viewer`: dashboard, state, risk dashboard, protection events
- `operator`: plus only-close, strategy toggle, AI toggle
- `admin`: plus global kill switch

## Audit signing
Каждое ручное действие подписывается HMAC и пишется в `protection_events` как `audit_signed`.
Это позволяет проверять, что запись не была подменена задним числом без знания audit secret.

## Alerts
Для реальной отправки используйте:
- `SlackWebhookSink`
- `PagerDutyEventsSink`
- `GenericWebhookSink`

Обычно wiring делается в bootstrapping/runtime слое под ваши секреты.
