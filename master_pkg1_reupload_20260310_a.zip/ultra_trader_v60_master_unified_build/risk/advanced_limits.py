from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass

from common.models import Order, RiskDecision, Tick
from portfolio.portfolio_service import PortfolioService


@dataclass(slots=True)
class AdvancedRiskSettings:
    max_venue_notional: float = 8000.0
    max_symbol_concentration_pct: float = 0.45
    max_correlated_exposure_pct: float = 0.65
    correlation_window: int = 32
    correlation_threshold: float = 0.90


class CorrelationConcentrationRiskGuard:
    def __init__(self, portfolio: PortfolioService, settings: AdvancedRiskSettings | None = None) -> None:
        self.portfolio = portfolio
        self.settings = settings or AdvancedRiskSettings()
        self._returns: dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=self.settings.correlation_window))
        self._last_mid: dict[str, float] = {}

    def observe_tick(self, tick: Tick) -> None:
        last = self._last_mid.get(tick.symbol)
        if last:
            self._returns[tick.symbol].append((tick.mid - last) / last)
        self._last_mid[tick.symbol] = tick.mid

    def _corr(self, left: list[float], right: list[float]) -> float:
        n = min(len(left), len(right))
        if n < 8:
            return 0.0
        a = left[-n:]
        b = right[-n:]
        ma = sum(a) / n
        mb = sum(b) / n
        cov = sum((x - ma) * (y - mb) for x, y in zip(a, b))
        va = sum((x - ma) ** 2 for x in a)
        vb = sum((y - mb) ** 2 for y in b)
        if va <= 0 or vb <= 0:
            return 0.0
        return cov / (va ** 0.5 * vb ** 0.5)

    def check_order(self, order: Order, market_tick: Tick) -> RiskDecision:
        total = max(self.portfolio.snapshot().gross_notional, 1e-9)
        venue_notional = sum(abs(p.qty * p.mark_price) for p in self.portfolio.positions() if p.venue == order.venue)
        order_notional = order.qty * (market_tick.ask if order.side.value == 'BUY' else market_tick.bid)
        if venue_notional + order_notional > self.settings.max_venue_notional:
            return RiskDecision(False, 'max_venue_notional_exceeded')
        symbol_notional = abs(self.portfolio.get_position(order.symbol).qty * self.portfolio.get_position(order.symbol).mark_price)
        concentration = (symbol_notional + order_notional) / max(total + order_notional, 1e-9)
        if concentration > self.settings.max_symbol_concentration_pct:
            return RiskDecision(False, 'symbol_concentration_exceeded')
        correlated_exposure = 0.0
        target_returns = list(self._returns.get(order.symbol, ()))
        for pos in self.portfolio.positions():
            if pos.symbol == order.symbol or pos.qty == 0:
                continue
            corr = self._corr(target_returns, list(self._returns.get(pos.symbol, ())))
            if corr >= self.settings.correlation_threshold:
                correlated_exposure += abs(pos.qty * pos.mark_price)
        if (correlated_exposure + order_notional) / max(total + order_notional, 1e-9) > self.settings.max_correlated_exposure_pct:
            return RiskDecision(False, 'correlated_exposure_exceeded')
        return RiskDecision(True, 'OK')
