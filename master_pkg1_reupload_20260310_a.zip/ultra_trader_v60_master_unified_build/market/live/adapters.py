from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from common.bus import EventBus
from common.models import Tick
from market.live.base import BaseMarketAdapter
from ops.metrics import MetricsRegistry


def _utc_ms(ms: int | str) -> datetime:
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc)


class BinanceSpotMarketAdapter(BaseMarketAdapter):
    venue = "binance"
    ws_url = "wss://stream.binance.com:9443/ws"

    async def subscribe(self, ws) -> None:
        stream = self.symbol.replace("/", "").lower() + "@bookTicker"
        await ws.send(json.dumps({"method": "SUBSCRIBE", "params": [stream], "id": 1}))

    def parse_message(self, payload: dict[str, Any]) -> Tick | None:
        if payload.get("e") != "bookTicker":
            return None
        return Tick(
            venue=self.venue,
            symbol=self.symbol,
            price=(float(payload["b"]) + float(payload["a"])) / 2,
            bid=float(payload["b"]),
            ask=float(payload["a"]),
            ts=_utc_ms(payload["E"]),
        )


class BybitV5MarketAdapter(BaseMarketAdapter):
    venue = "bybit"
    ws_url = "wss://stream.bybit.com/v5/public/spot"

    async def subscribe(self, ws) -> None:
        channel = f"tickers.{self.symbol.replace('/', '')}"
        await ws.send(json.dumps({"op": "subscribe", "args": [channel]}))

    def parse_message(self, payload: dict[str, Any]) -> Tick | None:
        if not str(payload.get("topic", "")).startswith("tickers."):
            return None
        data = payload.get("data") or {}
        bid = float(data.get("bid1Price", data.get("bidPrice", 0.0)))
        ask = float(data.get("ask1Price", data.get("askPrice", 0.0)))
        last = float(data.get("lastPrice", (bid + ask) / 2 or 0.0))
        if bid <= 0 or ask <= 0:
            return None
        return Tick(venue=self.venue, symbol=self.symbol, price=last, bid=bid, ask=ask, ts=_utc_ms(payload.get("ts", 0) or data.get("time", 0)))


class MexcSpotMarketAdapter(BaseMarketAdapter):
    venue = "mexc"
    ws_url = "wss://wbs-api.mexc.com/ws"

    async def subscribe(self, ws) -> None:
        # New protobuf transport is preferred by MEXC since Aug 2025, but JSON ticker support remains a practical bootstrap path.
        # This adapter intentionally keeps the parsing boundary isolated for a later protobuf-only upgrade.
        await ws.send(json.dumps({"method": "SUBSCRIPTION", "params": [f"spot@public.bookTicker.v3.api@{self.symbol.replace('/', '')}"], "id": 1}))

    def parse_message(self, payload: dict[str, Any]) -> Tick | None:
        data = payload.get("d") or payload.get("data") or {}
        channel = payload.get("c") or payload.get("channel", "")
        if "bookTicker" not in str(channel) and not {"a", "b"}.issubset(data.keys()):
            return None
        bid = float(data["b"])
        ask = float(data["a"])
        return Tick(venue=self.venue, symbol=self.symbol, price=(bid + ask) / 2, bid=bid, ask=ask, ts=_utc_ms(data.get("t", payload.get("t", 0) or payload.get("ts", 0))))


class BitgetSpotMarketAdapter(BaseMarketAdapter):
    venue = "bitget"
    ws_url = "wss://ws.bitget.com/v2/ws/public"

    async def subscribe(self, ws) -> None:
        await ws.send(
            json.dumps(
                {
                    "op": "subscribe",
                    "args": [
                        {
                            "instType": "SPOT",
                            "channel": "ticker",
                            "instId": self.symbol.replace("/", ""),
                        }
                    ],
                }
            )
        )

    def parse_message(self, payload: dict[str, Any]) -> Tick | None:
        data = payload.get("data") or []
        if payload.get("arg", {}).get("channel") != "ticker" or not data:
            return None
        row = data[0]
        bid = float(row["bidPr"])
        ask = float(row["askPr"])
        last = float(row.get("lastPr", (bid + ask) / 2))
        return Tick(venue=self.venue, symbol=self.symbol, price=last, bid=bid, ask=ask, ts=_utc_ms(row.get("ts", 0)))


def build_market_adapter(venue: str, bus: EventBus, metrics: MetricsRegistry, symbol: str) -> BaseMarketAdapter:
    mapping = {
        "binance": BinanceSpotMarketAdapter,
        "bybit": BybitV5MarketAdapter,
        "mexc": MexcSpotMarketAdapter,
        "bitget": BitgetSpotMarketAdapter,
    }
    try:
        return mapping[venue.lower()](bus=bus, metrics=metrics, symbol=symbol)
    except KeyError as exc:
        raise ValueError(f"unsupported venue: {venue}") from exc
