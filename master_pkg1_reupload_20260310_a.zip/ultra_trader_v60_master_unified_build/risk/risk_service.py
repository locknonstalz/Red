from __future__ import annotations

from datetime import datetime, timezone

from common.models import Order, RiskDecision, Tick
from config.settings import RiskSettings
from risk.advanced_limits import CorrelationConcentrationRiskGuard
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService


class RiskService:
    def __init__(self, settings: RiskSettings, portfolio: PortfolioService, metrics: MetricsRegistry, *, advanced_guard: CorrelationConcentrationRiskGuard | None = None) -> None:
        self.settings = settings
        self.portfolio = portfolio
        self.metrics = metrics
        self.advanced_guard = advanced_guard
        self._open_order_ids: set[str] = set()

    def check_order(self, order: Order, market_tick: Tick | None) -> RiskDecision:
        if self.settings.kill_switch:
            self.metrics.increment("risk_rejections_total")
            return RiskDecision(False, "kill_switch_enabled")
        if order.client_order_id in self._open_order_ids:
            self.metrics.increment("risk_rejections_total")
            return RiskDecision(False, "duplicate_client_order_id")
        if market_tick is None:
            self.metrics.increment("risk_rejections_total")
            return RiskDecision(False, "missing_market_data")
        if self.advanced_guard is not None:
            advanced = self.advanced_guard.check_order(order, market_tick)
            if not advanced.allowed:
                self.metrics.increment('risk_rejections_total')
                return advanced
        age = (datetime.now(timezone.utc) - market_tick.ts).total_seconds()
        if age > self.settings.max_market_data_age_sec:
            self.metrics.increment("risk_rejections_total")
            return RiskDecision(False, "stale_market_data")
        price = market_tick.ask if order.side.value == "BUY" else market_tick.bid
        notional = price * order.qty
        if notional > self.settings.max_order_notional:
            self.metrics.increment("risk_rejections_total")
            return RiskDecision(False, "max_order_notional_exceeded")
        current = self.portfolio.get_position(order.symbol, venue=order.venue).qty
        if current == 0:
            current = self.portfolio.get_position(order.symbol).qty
        proposed = current + order.qty if order.side.value == "BUY" else current - order.qty
        if abs(proposed) > self.settings.max_position_abs:
            self.metrics.increment("risk_rejections_total")
            return RiskDecision(False, "max_position_abs_exceeded")
        if abs(proposed * price) > self.settings.max_symbol_notional:
            self.metrics.increment("risk_rejections_total")
            return RiskDecision(False, "max_symbol_notional_exceeded")
        self._open_order_ids.add(order.client_order_id)
        return RiskDecision(True, "OK")

    def on_terminal_order(self, client_order_id: str) -> None:
        self._open_order_ids.discard(client_order_id)
