from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import httpx


@dataclass(slots=True)
class AlertMessage:
    event: str
    severity: str
    summary: str
    payload: dict[str, Any] = field(default_factory=dict)


class AlertSink:
    def emit(self, message: AlertMessage) -> None:  # pragma: no cover - interface
        raise NotImplementedError


class InMemoryAlertSink(AlertSink):
    def __init__(self) -> None:
        self.messages: list[AlertMessage] = []

    def emit(self, message: AlertMessage) -> None:
        self.messages.append(message)


class NullAlertSink(AlertSink):
    def emit(self, message: AlertMessage) -> None:
        return None


class SlackWebhookSink(AlertSink):
    def __init__(self, webhook_url: str, *, timeout_sec: float = 5.0, client: httpx.Client | None = None) -> None:
        self.webhook_url = webhook_url
        self.timeout_sec = timeout_sec
        self.client = client or httpx.Client(timeout=timeout_sec)

    def emit(self, message: AlertMessage) -> None:
        payload = {
            'text': f'[{message.severity.upper()}] {message.event}: {message.summary}',
            'attachments': [
                {
                    'fallback': message.summary,
                    'fields': [{'title': k, 'value': str(v), 'short': True} for k, v in sorted(message.payload.items())],
                }
            ],
        }
        resp = self.client.post(self.webhook_url, json=payload)
        resp.raise_for_status()


class PagerDutyEventsSink(AlertSink):
    def __init__(self, routing_key: str, *, events_url: str = 'https://events.pagerduty.com/v2/enqueue', timeout_sec: float = 5.0, client: httpx.Client | None = None) -> None:
        self.routing_key = routing_key
        self.events_url = events_url
        self.client = client or httpx.Client(timeout=timeout_sec)

    def emit(self, message: AlertMessage) -> None:
        severity = message.severity.lower()
        if severity not in {'critical', 'error', 'warning', 'info'}:
            severity = 'warning'
        payload = {
            'routing_key': self.routing_key,
            'event_action': 'trigger',
            'payload': {
                'summary': f'{message.event}: {message.summary}',
                'severity': severity,
                'source': 'ultra-trader',
                'custom_details': message.payload,
            },
        }
        resp = self.client.post(self.events_url, json=payload)
        resp.raise_for_status()


class GenericWebhookSink(AlertSink):
    def __init__(self, url: str, *, timeout_sec: float = 5.0, client: httpx.Client | None = None) -> None:
        self.url = url
        self.client = client or httpx.Client(timeout=timeout_sec)

    def emit(self, message: AlertMessage) -> None:
        resp = self.client.post(self.url, json={'event': message.event, 'severity': message.severity, 'summary': message.summary, 'payload': message.payload})
        resp.raise_for_status()


class AlertRouter:
    def __init__(self, sinks: list[AlertSink] | None = None) -> None:
        self.sinks = sinks or [NullAlertSink()]

    def add_sink(self, sink: AlertSink) -> None:
        self.sinks.append(sink)

    @classmethod
    def noop(cls) -> 'AlertRouter':
        return cls([NullAlertSink()])

    def send_alert(self, *, event: str, severity: str, summary: str, payload: dict[str, Any] | None = None) -> None:
        msg = AlertMessage(event=event, severity=severity, summary=summary, payload=payload or {})
        for sink in self.sinks:
            sink.emit(msg)
