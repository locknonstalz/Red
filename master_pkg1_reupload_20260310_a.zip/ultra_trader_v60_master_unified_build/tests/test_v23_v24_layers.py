from fastapi.testclient import TestClient

from common.models import Signal, Side, Tick
from control_plane.api import create_control_plane_app
from control_plane.auth import AuthConfig, ControlPlanePrincipal, TokenAuthManager
from control_plane.service import ControlPlaneService
from futures.analytics import FuturesAnalyticsService
from futures.connectors import FuturesMarketIntelService
from futures.execution import FuturesExecutionService
from futures.live_adapters import FuturesBrokerFactory, build_futures_spec
from futures.models import FuturesOrderIntent
from market.live.base import ExchangeCredentials
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from research.asset_analysis import AssetAnalysisService
from research.allocator import StrategyAllocatorService
from research.attribution import StrategyAttributionService
from research.connectors import ExternalAnalyticsHub
from research.external_research import ExternalResearchIngestionLayer
from research.regime import MarketRegimeClassifier
from research.universe import UniverseSelectionEngine
from storage.journal import SqliteJournal
from capital.protection import CapitalProtectionService
from config.settings import CapitalProtectionSettings


def test_external_connectors_allocator_and_futures_layers(tmp_path):
    layer = ExternalResearchIngestionLayer()
    hub = ExternalAnalyticsHub(layer)
    hub.ingest('news', {'symbol': 'BTC/USDT', 'sentiment': 0.8, 'urgency': 0.9, 'confidence': 0.7})
    hub.ingest('onchain', {'symbol': 'BTC/USDT', 'exchange_inflow_usd': 100, 'exchange_outflow_usd': 200, 'confidence': 0.8})
    assert layer.aggregate_score('BTC/USDT') > 0

    attribution = StrategyAttributionService()
    regime = MarketRegimeClassifier(window=8)
    for px in [100, 101, 102, 103, 104, 105, 106, 107]:
        regime.observe_tick(Tick('binance', 'BTC/USDT', px, px - 0.1, px + 0.1))
    allocator = StrategyAllocatorService(attribution, regime, layer)
    decision = allocator.evaluate(
        Signal('momentum', 'binance', 'BTC/USDT', Side.BUY, 0.9, 'test', qty=1.0),
        Tick('binance', 'BTC/USDT', 107, 106.9, 107.1),
    )
    assert decision.accepted is True
    assert decision.signal is not None
    assert decision.signal.qty is not None and decision.signal.qty > 1.0

    analytics = FuturesAnalyticsService()
    intel = FuturesMarketIntelService(analytics)
    intel.from_payload('binance', 'BTCUSDT-PERP', {'funding_rate': 0.0008, 'basis_bps': 12.0, 'open_interest': 2500000})
    ranked = analytics.rank()
    assert ranked and ranked[0].symbol == 'BTCUSDT-PERP'

    plan = FuturesExecutionService().build_plan(
        FuturesOrderIntent('carry', 'binance', 'BTCUSDT-PERP', Side.SELL, qty=0.25, leverage=3.0, reduce_only=True)
    )
    assert plan.order.symbol == 'BTCUSDT-PERP'
    assert plan.leverage == 3.0
    assert plan.reduce_only is True

    spec = build_futures_spec('bybit')
    assert 'bybit' in spec.market_ws
    broker_meta = FuturesBrokerFactory(MetricsRegistry()).build('binance', ExchangeCredentials('k', 's', None))
    assert broker_meta['api_key_set'] == 'true'


def test_control_plane_research_screener_endpoint(tmp_path):
    metrics = MetricsRegistry()
    journal = SqliteJournal(str(tmp_path / 'cp.db'))
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    protection = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    asset_analysis = AssetAnalysisService()
    for venue, px in [('binance', 100.0), ('bybit', 100.2), ('mexc', 99.9)]:
        for step in range(10):
            asset_analysis.observe_tick(Tick(venue, 'BTC/USDT', px + step * 0.1, px + step * 0.1 - 0.05, px + step * 0.1 + 0.05))
    universe = UniverseSelectionEngine(asset_analysis, min_quality_score=0.0)
    allocation = StrategyAllocatorService(StrategyAttributionService(), MarketRegimeClassifier(), ExternalResearchIngestionLayer())
    futures_analytics = FuturesAnalyticsService()
    FuturesMarketIntelService(futures_analytics).from_payload('binance', 'BTCUSDT-PERP', {'funding_rate': 0.0004, 'basis_bps': 4, 'open_interest': 1000000})

    service = ControlPlaneService(
        capital_protection=protection,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        asset_analysis=asset_analysis,
        universe=universe,
        allocator=allocation,
        futures_analytics=futures_analytics,
    )
    auth = TokenAuthManager(AuthConfig(enabled=False, static_tokens={'viewer-token': ControlPlanePrincipal('viewer', 'viewer', ())}))
    app = create_control_plane_app(service, auth)
    client = TestClient(app)
    resp = client.get('/research/screener', headers={'Authorization': 'Bearer viewer-token'})
    assert resp.status_code == 200
    body = resp.json()
    assert len(body['screener']) >= 1
    assert 'weights' in body['allocator']
    assert body['futures_rankings'][0]['symbol'] == 'BTCUSDT-PERP'
