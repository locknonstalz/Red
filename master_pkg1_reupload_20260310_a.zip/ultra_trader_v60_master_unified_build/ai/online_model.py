from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


@dataclass(slots=True)
class OnlineLogisticModel:
    learning_rate: float = 0.08
    l2: float = 0.0005
    weights: dict[str, float] = field(default_factory=dict)
    bias: float = 0.0
    updates: int = 0

    def predict_proba(self, features: dict[str, float]) -> float:
        logit = self.bias
        for name, value in features.items():
            logit += self.weights.get(name, 0.0) * value
        if logit >= 0:
            z = math.exp(-logit)
            return 1.0 / (1.0 + z)
        z = math.exp(logit)
        return z / (1.0 + z)

    def update(self, features: dict[str, float], label: int, sample_weight: float = 1.0) -> float:
        prob = self.predict_proba(features)
        error = (float(label) - prob) * sample_weight
        self.bias += self.learning_rate * error
        for name, value in features.items():
            current = self.weights.get(name, 0.0)
            gradient = error * value - self.l2 * current
            self.weights[name] = current + self.learning_rate * gradient
        self.updates += 1
        return prob

    def save(self, path: str | Path) -> None:
        payload = {
            'learning_rate': self.learning_rate,
            'l2': self.l2,
            'weights': self.weights,
            'bias': self.bias,
            'updates': self.updates,
        }
        Path(path).write_text(json.dumps(payload, indent=2), encoding='utf-8')

    @classmethod
    def load(cls, path: str | Path) -> 'OnlineLogisticModel':
        data = json.loads(Path(path).read_text(encoding='utf-8'))
        return cls(
            learning_rate=float(data.get('learning_rate', 0.08)),
            l2=float(data.get('l2', 0.0005)),
            weights={k: float(v) for k, v in data.get('weights', {}).items()},
            bias=float(data.get('bias', 0.0)),
            updates=int(data.get('updates', 0)),
        )
