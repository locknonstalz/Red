from fastapi.testclient import TestClient

from ai.decision_engine import AIDecisionEngine
from capital.protection import CapitalProtectionService
from config.settings import AISettings, CapitalProtectionSettings
from control_plane.api import create_control_plane_app
from control_plane.auth import AuthConfig, ControlPlanePrincipal, TokenAuthManager
from control_plane.service import ControlPlaneService
from ops.alerts import InMemoryAlertSink, AlertRouter
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.journal import SqliteJournal


def build_app():
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    protection = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    ai = AIDecisionEngine(metrics=metrics, enabled=True)
    service = ControlPlaneService(
        capital_protection=protection,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        ai_engine=ai,
        alert_router=AlertRouter([InMemoryAlertSink()]),
    )
    auth = TokenAuthManager(AuthConfig(enabled=True, static_tokens={
        'viewer-token': ControlPlanePrincipal(subject='viewer1', role='viewer'),
        'operator-token': ControlPlanePrincipal(subject='ops1', role='operator'),
        'admin-token': ControlPlanePrincipal(subject='admin1', role='admin'),
    }))
    app = create_control_plane_app(service, auth)
    return TestClient(app), journal


def test_viewer_can_see_dashboard_but_not_toggle():
    client, _ = build_app()
    r = client.get('/dashboard', headers={'Authorization': 'Bearer viewer-token'})
    assert r.status_code == 200
    assert 'Ultra Trader v27 Control Dashboard' in r.text
    forbidden = client.post('/controls/only-close', json={'enabled': True, 'reason': 'test'}, headers={'Authorization': 'Bearer viewer-token'})
    assert forbidden.status_code == 403


def test_operator_can_toggle_only_close_but_not_global_kill():
    client, journal = build_app()
    r = client.post('/controls/only-close', json={'enabled': True, 'reason': 'manual'}, headers={'Authorization': 'Bearer operator-token'})
    assert r.status_code == 200
    events = journal.recent_protection_events(10)
    assert any(e['event_type'] == 'audit_signed' for e in events)
    r2 = client.post('/controls/global-kill', json={'enabled': True, 'reason': 'manual'}, headers={'Authorization': 'Bearer operator-token'})
    assert r2.status_code == 403


def test_admin_can_global_kill():
    client, _ = build_app()
    r = client.post('/controls/global-kill', json={'enabled': True, 'reason': 'manual'}, headers={'Authorization': 'Bearer admin-token'})
    assert r.status_code == 200
    assert r.json()['state']['global_kill_switch'] is True
