from __future__ import annotations

from pathlib import Path

from execution.quality import ExecutionBaseline, ExecutionQualityAttributionService
from futures.liquidations import LiquidationAnalyticsService, LiquidationEvent
from mlops.feature_store import FeatureRecord, FeatureStore
from mlops.lifecycle import AdvancedMLLifecycle, ChampionChallengerManager, FeatureDriftDetector
from mlops.model_registry import ModelRegistry
from mlops.trainer import TrainingExample
from mlops.validation import ValidationReport
from research.attribution import StrategyAttributionService
from research.onchain import OnChainAnalyticsService
from research.profitability import ProfitabilityAdvisorService
from research.venue_health import VenueHealthScoringService
from simulation.exchange import ExchangeSimulator, SimOrder
from microstructure.orderbook import BookLevel, L2BookSnapshot
from common.models import Fill, Side, Tick


def test_advanced_ml_lifecycle_and_drift(tmp_path: Path) -> None:
    store = FeatureStore(str(tmp_path / 'features.jsonl'))
    registry = ModelRegistry(str(tmp_path / 'registry.json'))
    lifecycle = AdvancedMLLifecycle(store, registry)
    examples = [
        TrainingExample(features={'x': -1.0, 'spread_bps': 8.0}, label=0),
        TrainingExample(features={'x': 1.0, 'spread_bps': 2.0}, label=1),
        TrainingExample(features={'x': 0.8, 'spread_bps': 2.5}, label=1),
        TrainingExample(features={'x': -0.9, 'spread_bps': 7.5}, label=0),
    ]
    result = lifecycle.train_and_register('entry_model', '1.0.0', examples, str(tmp_path / 'model.json'))
    assert result['validation']['folds'] >= 0
    baseline = [FeatureRecord(symbol='BTC/USDT', features={'x': 0.0, 'spread_bps': 2.0}) for _ in range(5)]
    live = [FeatureRecord(symbol='BTC/USDT', features={'x': 5.0, 'spread_bps': 9.0}) for _ in range(5)]
    health = lifecycle.evaluate_live_health('entry_model', '1.0.0', baseline, live, ValidationReport(folds=3, accuracy=0.7, precision=0.6))
    assert health.drift_alerts >= 1


def test_onchain_liquidation_simulation_and_profitability() -> None:
    onchain = OnChainAnalyticsService()
    onchain.ingest('BTC/USDT', exchange_inflow=100.0, exchange_outflow=300.0, stablecoin_flow=250.0, whale_score=70.0)
    assert onchain.alpha_bias('BTC/USDT') > 0

    liq = LiquidationAnalyticsService()
    liq.ingest(LiquidationEvent(venue='binance', symbol='BTC/USDT', side='LONG', notional=200000))
    liq.ingest(LiquidationEvent(venue='binance', symbol='BTC/USDT', side='SHORT', notional=400000))
    pressure = liq.snapshot('binance', 'BTC/USDT')
    assert pressure.cascade_risk > 0

    sim = ExchangeSimulator(fee_bps=0.0)
    sim.load_from_l2(L2BookSnapshot(
        venue='binance', symbol='BTC/USDT', sequence=1,
        bids=[BookLevel(100.0, 2.0), BookLevel(99.9, 2.0)],
        asks=[BookLevel(100.1, 1.0), BookLevel(100.2, 2.0)],
    ))
    fills = sim.submit(SimOrder(side='BUY', qty=2.5, order_type='MARKET'))
    assert len(fills) >= 2

    attribution = StrategyAttributionService()
    attribution.observe_fill(Fill(client_order_id='1', venue='binance', symbol='BTC/USDT', side=Side.BUY, qty=1.0, price=100.0, fee=0.0, strategy='alpha'))
    attribution.observe_fill(Fill(client_order_id='2', venue='binance', symbol='BTC/USDT', side=Side.SELL, qty=1.0, price=101.0, fee=0.0, strategy='alpha'))
    eq = ExecutionQualityAttributionService()
    eq._fills['strategy:alpha'] = 2
    eq._fees['strategy:alpha'] = 4.0
    eq._slippage_bps['strategy:alpha'] = 2.0
    eq._effective_spread_bps['strategy:alpha'] = 3.0
    eq._adverse['strategy:alpha'] = 0
    eq._notional['strategy:alpha'] = 201.0
    venue_health = VenueHealthScoringService()
    venue_health.observe_tick(Tick(venue='binance', symbol='BTC/USDT', price=100.0, bid=99.95, ask=100.05))
    advisor = ProfitabilityAdvisorService(attribution, eq, venue_health, onchain, liq)
    assessment = advisor.assess('alpha', 'binance', 'BTC/USDT')
    assert assessment.profitability_score > 0
    assert assessment.recommendation in {'scale_gradually', 'trade_selectively', 'keep_in_shadow_or_reduce'}
