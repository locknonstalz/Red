from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from common.models import Fill, Side


@dataclass(slots=True)
class StrategyAttribution:
    strategy: str
    realized_pnl: float
    gross_turnover: float
    fills: int
    win_trades: int
    loss_trades: int


class StrategyAttributionService:
    def __init__(self) -> None:
        self._positions: dict[tuple[str, str], tuple[float, float]] = {}
        self._pnl = defaultdict(float)
        self._turnover = defaultdict(float)
        self._fills = defaultdict(int)
        self._wins = defaultdict(int)
        self._losses = defaultdict(int)

    def observe_fill(self, fill: Fill) -> None:
        strategy = fill.strategy or 'unknown'
        key = (strategy, fill.symbol)
        qty, avg = self._positions.get(key, (0.0, 0.0))
        signed = fill.qty if fill.side == Side.BUY else -fill.qty
        turnover = abs(fill.qty * fill.price)
        self._turnover[strategy] += turnover
        self._fills[strategy] += 1
        if qty == 0 or qty * signed > 0:
            new_qty = qty + signed
            total_cost = abs(qty) * avg + abs(signed) * fill.price
            self._positions[key] = (new_qty, total_cost / abs(new_qty) if new_qty else 0.0)
            return
        closing = min(abs(qty), abs(signed))
        pnl_per_unit = (fill.price - avg) if qty > 0 else (avg - fill.price)
        pnl = pnl_per_unit * closing - fill.fee
        self._pnl[strategy] += pnl
        if pnl >= 0:
            self._wins[strategy] += 1
        else:
            self._losses[strategy] += 1
        new_qty = qty + signed
        self._positions[key] = (new_qty, avg if new_qty else 0.0)

    def snapshot(self) -> dict[str, StrategyAttribution]:
        names = set(self._fills) | set(self._pnl)
        return {
            name: StrategyAttribution(
                strategy=name,
                realized_pnl=self._pnl.get(name, 0.0),
                gross_turnover=self._turnover.get(name, 0.0),
                fills=self._fills.get(name, 0),
                win_trades=self._wins.get(name, 0),
                loss_trades=self._losses.get(name, 0),
            )
            for name in names
        }
