from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

from capital.protection import CapitalProtectionService
from live_validation.validation import LiveValidationService
from portfolio.portfolio_service import PortfolioService
from research.alpha_governance import AlphaGovernanceService
from research.attribution import StrategyAttributionService
from research.capacity import CapacityScoringService


@dataclass(slots=True)
class StrategyBudget:
    strategy: str
    stage: str
    health_score: float
    readiness_score: float
    target_notional: float
    max_notional: float
    action: str
    reason: str


@dataclass(slots=True)
class CapitalScalingSnapshot:
    deployable_notional: float
    reserved_buffer_pct: float
    only_close: bool
    global_kill: bool
    budgets: list[StrategyBudget]

    def as_dict(self) -> dict[str, Any]:
        return {
            'deployable_notional': round(self.deployable_notional, 4),
            'reserved_buffer_pct': self.reserved_buffer_pct,
            'only_close': self.only_close,
            'global_kill': self.global_kill,
            'budgets': [asdict(x) for x in self.budgets],
        }


class CapitalScalingEngine:
    def __init__(
        self,
        *,
        portfolio: PortfolioService,
        protection: CapitalProtectionService,
        governance: AlphaGovernanceService,
        live_validation: LiveValidationService,
        attribution: StrategyAttributionService,
        capacity: CapacityScoringService,
        reserved_buffer_pct: float = 0.25,
        max_strategy_alloc_pct: float = 0.35,
        micro_live_min_target_notional: float = 10.0,
    ) -> None:
        self.portfolio = portfolio
        self.protection = protection
        self.governance = governance
        self.live_validation = live_validation
        self.attribution = attribution
        self.capacity = capacity
        self.reserved_buffer_pct = reserved_buffer_pct
        self.max_strategy_alloc_pct = max_strategy_alloc_pct
        self.micro_live_min_target_notional = max(0.0, micro_live_min_target_notional)

    @staticmethod
    def _stage_multiplier(stage: str) -> float:
        return {
            'research': 0.0,
            'shadow': 0.0,
            'paper': 0.02,
            'micro_live': 0.10,
            'live': 0.25,
            'retired': 0.0,
        }.get(stage, 0.0)

    def _deployable_notional(self) -> float:
        balances = getattr(self.portfolio, '_balances', {})
        base = getattr(self.portfolio, 'base_currency', 'USDT')
        cash = sum(getattr(b, 'free', 0.0) + getattr(b, 'locked', 0.0) for (_, asset), b in balances.items() if asset == base)
        import os
        if cash <= 0:
            cash = float(os.getenv('MAX_TOTAL_NOTIONAL', '100.0'))
        snap = self.portfolio.snapshot()
        equity = float(cash + snap.unrealized_pnl + snap.realized_pnl)
        return max(0.0, equity * (1.0 - self.reserved_buffer_pct))

    def _strategy_stage(self, strategy: str) -> str:
        row = next((row for row in self.governance.promotions.list_promotions() if row['strategy'] == strategy), None)
        return 'research' if row is None else str(row['current_stage'])

    def budget_for(self, strategy: str, venue: str, symbol: str) -> StrategyBudget:
        protection = self.protection.state_snapshot()
        stage = self._strategy_stage(strategy)
        health = self.governance.strategy_health(strategy, venue, symbol)
        readiness = float(self.governance.go_live.strategy_score(strategy).get('score', 0.0))
        if readiness <= 1.0:
            readiness *= 100.0
        deployable = self._deployable_notional()
        capacity_rows = self.capacity.rank([(venue, symbol)])
        capacity_limit = capacity_rows[0].recommended_notional if capacity_rows else deployable
        attr = self.attribution.snapshot().get(strategy)
        fills = 0 if attr is None else int(getattr(attr, 'fills', 0))
        realized = 0.0 if attr is None else float(getattr(attr, 'realized_pnl', 0.0))
        expectancy = 0.0 if fills == 0 else realized / max(fills, 1)

        if protection.get('global_kill') or protection.get('global_kill_switch'):
            return StrategyBudget(strategy, stage, health.score, readiness, 0.0, 0.0, 'block', 'global_kill_active')
        if (protection.get('only_close') or protection.get('only_close_mode')) and stage in {'micro_live', 'live'}:
            return StrategyBudget(strategy, stage, health.score, readiness, 0.0, 0.0, 'block', 'only_close_mode')
        if strategy in set(protection.get('disabled_strategies', [])):
            return StrategyBudget(strategy, stage, health.score, readiness, 0.0, 0.0, 'block', 'strategy_disabled')

        stage_mult = self._stage_multiplier(stage)
        health_mult = max(0.0, min(1.0, health.score / 100.0))
        readiness_mult = max(0.0, min(1.0, readiness / 100.0))
        expectancy_mult = 1.0 if expectancy >= 0 else 0.6
        raw_target = deployable * self.max_strategy_alloc_pct * stage_mult * health_mult * max(0.2, readiness_mult) * expectancy_mult
        target = min(raw_target, capacity_limit)

        action = 'hold'
        reason = 'stable'
        if stage in {'research', 'shadow'}:
            target = 0.0
            action = 'observe'
            reason = 'non_live_stage'
        elif stage == 'paper':
            action = 'paper_only'
            reason = 'paper_stage_budget'
        elif stage == 'micro_live':
            if health.healthy and readiness >= 70:
                floor = min(max(0.0, self.micro_live_min_target_notional), capacity_limit, deployable)
                if floor > 0.0 and target < floor:
                    target = floor
                    reason = 'micro_live_budget_floor'
                else:
                    reason = 'micro_live_budget'
                action = 'scale_gradually'
            else:
                action = 'hold'
                reason = 'micro_live_health_hold'
        elif stage == 'live':
            if not health.healthy or readiness < 60:
                action = 'scale_down'
                target *= 0.5
                reason = 'health_or_readiness_soft_limit'
            elif readiness >= 85 and health.score >= 80:
                action = 'scale_up'
                reason = 'healthy_live_strategy'

        return StrategyBudget(
            strategy=strategy,
            stage=stage,
            health_score=round(health.score, 2),
            readiness_score=round(readiness, 2),
            target_notional=round(max(0.0, target), 4),
            max_notional=round(max(0.0, capacity_limit), 4),
            action=action,
            reason=reason,
        )

    def snapshot(self, strategies: list[str], venue: str, symbol: str) -> CapitalScalingSnapshot:
        budgets = [self.budget_for(strategy, venue, symbol) for strategy in strategies]
        protection = self.protection.state_snapshot()
        return CapitalScalingSnapshot(
            deployable_notional=self._deployable_notional(),
            reserved_buffer_pct=self.reserved_buffer_pct,
            only_close=bool(protection.get('only_close', False) or protection.get('only_close_mode', False)),
            global_kill=bool(protection.get('global_kill', False) or protection.get('global_kill_switch', False)),
            budgets=sorted(budgets, key=lambda x: x.target_notional, reverse=True),
        )
