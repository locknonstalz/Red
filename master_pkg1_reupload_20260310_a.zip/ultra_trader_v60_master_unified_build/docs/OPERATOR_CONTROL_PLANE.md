# Operator Control Plane

v16 добавляет операторский контур для live-движка.

## Что есть

- FastAPI admin/control plane
- ручное включение `only-close`
- ручное включение/снятие `global kill switch`
- ручное отключение/включение конкретной стратегии
- ручное отключение/включение AI overlay
- JSON risk dashboard
- recent protection events API
- alert router abstraction для Slack/PagerDuty/webhook интеграций

## API

### `GET /health`
Проверка живости control plane.

### `GET /state`
Полный снапшот:
- portfolio
- protection state
- ai state
- metrics
- recent protection events

### `GET /risk/dashboard`
Упрощённый risk/control срез.

### `GET /protection/events?limit=50`
Последние protection events из journal.

### `POST /controls/only-close`
```json
{"enabled": true, "reason": "operator_freeze"}
```

### `POST /controls/global-kill`
```json
{"enabled": true, "reason": "critical_incident"}
```

### `POST /controls/strategy`
```json
{"strategy": "market_making", "enabled": false, "reason": "manual_disable"}
```

### `POST /controls/ai`
```json
{"enabled": false, "reason": "shadow_mode_only"}
```

## Deployment

Для прод-режима control plane лучше поднимать как отдельный internal service:
- внутри private network / VPN
- за mTLS или identity-aware proxy
- с audit logging на все POST-операции
- с отдельной ролью operator / admin

## Alert routing

В коде заложен `AlertRouter`, который можно подключить к:
- Slack webhook sender
- PagerDuty Events API sender
- internal incident bus
- audit sink / SIEM

По умолчанию роутер noop, чтобы проект оставался воспроизводимым офлайн.
