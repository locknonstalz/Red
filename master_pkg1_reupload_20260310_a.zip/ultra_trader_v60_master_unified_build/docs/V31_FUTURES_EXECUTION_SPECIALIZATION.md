# V31 Futures Execution Specialization

Adds futures-specific execution planning with reduce-only/close-only semantics, funding-aware policy selection, liquidation-distance-aware venue routing, and perp-basis paired execution planning.
