from __future__ import annotations

from dataclasses import dataclass

from execution.quality import ExecutionQualityAttributionService
from research.asset_analysis import AssetAnalysisService
from research.venue_health import VenueHealthScoringService


@dataclass(slots=True)
class CapacityScore:
    venue: str
    symbol: str
    score: float
    recommended_notional: float
    drivers: dict[str, float]


class CapacityScoringService:
    def __init__(
        self,
        *,
        asset_analysis: AssetAnalysisService,
        execution_quality: ExecutionQualityAttributionService | None = None,
        venue_health: VenueHealthScoringService | None = None,
    ) -> None:
        self.asset_analysis = asset_analysis
        self.execution_quality = execution_quality
        self.venue_health = venue_health

    def score(self, venue: str, symbol: str) -> CapacityScore | None:
        asset = self.asset_analysis.snapshot(venue, symbol)
        if asset is None:
            return None
        quality_snap = self.execution_quality.snapshot() if self.execution_quality is not None else {}
        venue_stats = quality_snap.get(f'venue:{venue}')
        symbol_stats = quality_snap.get(f'symbol:{symbol}')
        adverse_rate = max(
            venue_stats.adverse_fill_rate if venue_stats is not None else 0.0,
            symbol_stats.adverse_fill_rate if symbol_stats is not None else 0.0,
        )
        slippage_bps = max(
            venue_stats.avg_slippage_bps if venue_stats is not None else 0.0,
            symbol_stats.avg_slippage_bps if symbol_stats is not None else 0.0,
        )
        venue_health_score = self.venue_health.snapshot(venue).score if self.venue_health is not None else 75.0
        spread_quality = max(0.0, 100.0 - asset.spread_bps * 4.0)
        slippage_penalty = min(40.0, max(0.0, slippage_bps) * 4.0)
        adverse_penalty = adverse_rate * 35.0
        score = max(0.0, min(100.0, asset.quality_score * 0.45 + venue_health_score * 0.35 + spread_quality * 0.2 - slippage_penalty - adverse_penalty))
        recommended_notional = round(max(50.0, score * 15.0), 2)
        return CapacityScore(
            venue=venue,
            symbol=symbol,
            score=round(score, 4),
            recommended_notional=recommended_notional,
            drivers={
                'asset_quality': round(asset.quality_score, 4),
                'venue_health': round(venue_health_score, 4),
                'spread_quality': round(spread_quality, 4),
                'avg_slippage_bps': round(slippage_bps, 6),
                'adverse_fill_rate': round(adverse_rate, 6),
            },
        )

    def rank(self, pairs: list[tuple[str, str]]) -> list[CapacityScore]:
        rows = [score for venue, symbol in pairs if (score := self.score(venue, symbol)) is not None]
        return sorted(rows, key=lambda row: (row.score, row.recommended_notional), reverse=True)
