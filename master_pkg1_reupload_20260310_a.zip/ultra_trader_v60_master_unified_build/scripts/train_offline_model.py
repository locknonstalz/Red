from __future__ import annotations

import argparse

from mlops.feature_store import FeatureStore
from mlops.model_registry import ModelRegistry
from mlops.trainer import OfflineTrainer, TrainingExample
from mlops.validation import WalkForwardValidator


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--feature-store', default='feature_store.jsonl')
    parser.add_argument('--model-out', default='artifacts/offline_model.json')
    parser.add_argument('--registry', default='model_registry.json')
    args = parser.parse_args()

    store = FeatureStore(args.feature_store)
    records = store.read_all()
    examples = [TrainingExample(features=rec.features, label=int(rec.label or 0)) for rec in records if rec.label is not None]
    trainer = OfflineTrainer()
    validator = WalkForwardValidator(trainer=trainer)
    report = validator.validate(examples)
    model = trainer.train(examples)
    trainer.persist(model, args.model_out)
    ModelRegistry(args.registry).register('entry_quality', 'v1', {'accuracy': report.accuracy, 'precision': report.precision}, args.model_out)
    print({'records': len(records), 'examples': len(examples), 'accuracy': report.accuracy, 'precision': report.precision, 'model_out': args.model_out})


if __name__ == '__main__':
    main()
