import asyncio

from common.bus import EventBus
from common.models import Order, OrderStatus, Side
from execution.live.ws_sessions import ReplayPrivateWsSession
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from services.live_orchestration import LiveOrchestrationService
from storage.journal import SqliteJournal


def test_live_orchestration_applies_fill_and_balance(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'orch.db'))
    metrics = MetricsRegistry()
    portfolio = PortfolioService('USDT', journal, metrics)
    bus = EventBus()

    order = Order(strategy='s', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=0.01)
    journal.record_order(order)
    journal.update_order_status(order.client_order_id, OrderStatus.ACCEPTED)

    session = ReplayPrivateWsSession('binance', [
        {'e': 'executionReport', 'x': 'TRADE', 'c': order.client_order_id, 'i': 1, 's': 'BTCUSDT', 'S': 'BUY', 'l': '0.01', 'L': '100', 'n': '0.01', 't': 10, 'E': 1700000000000},
        {'e': 'outboundAccountPosition', 'E': 1700000000000, 'B': [{'a': 'USDT', 'f': '100', 'l': '2'}]},
        {'e': 'executionReport', 'x': 'TRADE', 'c': order.client_order_id, 'i': 1, 's': 'BTCUSDT', 'S': 'BUY', 'l': '0.01', 'L': '100', 'n': '0.01', 't': 10, 'E': 1700000000000},
    ])
    service = LiveOrchestrationService(sessions={'binance': session}, journal=journal, portfolio=portfolio, metrics=metrics, bus=bus)
    asyncio.run(service.run())

    pos = portfolio.get_position('BTCUSDT')
    assert pos.qty == 0.01
    assert journal.seen_reconciliation_event('binance', 'balance', 'USDT')
    assert metrics.snapshot()['orchestration_duplicate_events_total'] == 1


def test_live_orchestration_bitget_order_update(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'orch2.db'))
    metrics = MetricsRegistry()
    portfolio = PortfolioService('USDT', journal, metrics)
    session = ReplayPrivateWsSession('bitget', [
        {'arg': {'channel': 'orders'}, 'data': [{'clientOid': 'c1', 'orderId': '1', 'instId': 'BTCUSDT', 'status': 'filled', 'accBaseVolume': '0.01', 'priceAvg': '101', 'uTime': '1700000000000'}]},
    ])
    journal.record_order(Order(strategy='s', venue='bitget', symbol='BTCUSDT', side=Side.BUY, qty=0.01, client_order_id='c1'))
    service = LiveOrchestrationService(sessions={'bitget': session}, journal=journal, portfolio=portfolio, metrics=metrics)
    asyncio.run(service.run())
    assert metrics.snapshot()['orchestration_order_updates_total'] == 1
