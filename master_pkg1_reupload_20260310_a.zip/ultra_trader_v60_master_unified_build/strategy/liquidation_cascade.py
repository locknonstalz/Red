from __future__ import annotations

from collections import deque
from typing import Sequence

from common.models import Side, Signal, Tick
from strategy.base import Strategy


class LiquidationCascadeStrategy(Strategy):
    """Fast breakout strategy keyed off liquidation pressure and order-book vacuum.

    Expects optional tick attributes: liquidation_long_pressure, liquidation_short_pressure,
    cascade_risk, toxicity_score. Falls back to zero if missing so the strategy remains safe.
    """

    def __init__(
        self,
        name: str,
        venue: str,
        symbol: str,
        trade_size: float,
        lookback: int = 12,
        min_cascade_risk: float = 0.28,
        min_liquidation_pressure: float = 0.55,
        breakout_bps: float = 7.0,
    ) -> None:
        self.name = name
        self.venue = venue
        self.symbol = symbol
        self.trade_size = trade_size
        self.lookback = deque(maxlen=lookback)
        self.min_cascade_risk = min_cascade_risk
        self.min_liquidation_pressure = min_liquidation_pressure
        self.breakout_bps = breakout_bps
        self._cooldown = 0

    def on_tick(self, tick: Tick) -> Sequence[Signal]:
        if tick.venue != self.venue or tick.symbol != self.symbol:
            return []
        self.lookback.append(tick.mid)
        if self._cooldown > 0:
            self._cooldown -= 1
            return []
        if len(self.lookback) < self.lookback.maxlen:
            return []
        long_pressure = float(getattr(tick, 'liquidation_long_pressure', 0.0) or 0.0)
        short_pressure = float(getattr(tick, 'liquidation_short_pressure', 0.0) or 0.0)
        cascade_risk = float(getattr(tick, 'cascade_risk', 0.0) or 0.0)
        toxicity = float(getattr(tick, 'toxicity_score', 0.0) or 0.0)
        if cascade_risk < self.min_cascade_risk or toxicity > 0.75:
            return []
        base = min(self.lookback)
        top = max(self.lookback)
        up_move_bps = ((tick.mid - base) / base) * 10000 if base else 0.0
        down_move_bps = ((top - tick.mid) / top) * 10000 if top else 0.0
        self._cooldown = 4
        if short_pressure >= self.min_liquidation_pressure and up_move_bps >= self.breakout_bps:
            return [Signal(self.name, self.venue, self.symbol, Side.BUY, min(3.0, short_pressure + cascade_risk), f'liquidation_breakout_long={short_pressure:.2f}', qty=self.trade_size, tags={'sleeve': 'liquidation', 'cascade_risk': cascade_risk, 'short_pressure': short_pressure})]
        if long_pressure >= self.min_liquidation_pressure and down_move_bps >= self.breakout_bps:
            return [Signal(self.name, self.venue, self.symbol, Side.SELL, min(3.0, long_pressure + cascade_risk), f'liquidation_breakout_short={long_pressure:.2f}', qty=self.trade_size, tags={'sleeve': 'liquidation', 'cascade_risk': cascade_risk, 'long_pressure': long_pressure})]
        self._cooldown = 0
        return []
