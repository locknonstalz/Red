from common.models import Fill, Side
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.journal import SqliteJournal


def make_portfolio(tmp_path):
    journal = SqliteJournal(str(tmp_path / "portfolio.db"))
    metrics = MetricsRegistry()
    return PortfolioService("USDT", journal, metrics)


def test_portfolio_realized_pnl_on_close(tmp_path):
    portfolio = make_portfolio(tmp_path)
    portfolio.apply_fill(Fill("1", "demo", "BTC/USDT", Side.BUY, 1.0, 100.0, 0.0))
    portfolio.apply_fill(Fill("2", "demo", "BTC/USDT", Side.SELL, 1.0, 110.0, 0.0))
    pos = portfolio.get_position("BTC/USDT")
    assert pos.qty == 0.0
    assert pos.realized_pnl == 10.0


def test_portfolio_marks_unrealized(tmp_path):
    portfolio = make_portfolio(tmp_path)
    portfolio.apply_fill(Fill("1", "demo", "BTC/USDT", Side.BUY, 2.0, 100.0, 0.0))
    portfolio.mark_price("BTC/USDT", 105.0)
    snap = portfolio.snapshot()
    assert snap.unrealized_pnl == 10.0
