from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from common.models import Balance, Fill, OrderUpdate, Side


def _utc_ms(ms: int | str) -> datetime:
    value = int(ms or 0)
    if value == 0:
        return datetime.now(timezone.utc)
    return datetime.fromtimestamp(value / 1000, tz=timezone.utc)


class BinancePrivateStreamAdapter:
    venue = 'binance'
    def parse_execution(self, payload: dict[str, Any]) -> Fill | None:
        if payload.get('e') != 'executionReport' or payload.get('x') not in {'TRADE', 'TRADE_PREVENTION'}:
            return None
        return Fill(client_order_id=payload.get('c', ''), exchange_order_id=str(payload.get('i', '')), venue=self.venue, symbol=payload.get('s', ''), side=Side(payload.get('S', 'BUY')), qty=float(payload.get('l', 0)), price=float(payload.get('L', 0) or payload.get('p', 0)), fee=float(payload.get('n', 0) or 0), trade_id=str(payload.get('t', '')), ts=_utc_ms(payload.get('E', 0)))
    def parse_balance(self, payload: dict[str, Any]) -> list[Balance]:
        if payload.get('e') != 'outboundAccountPosition':
            return []
        return [Balance(self.venue, row['a'], float(row['f']), float(row['l']), _utc_ms(payload.get('E', 0))) for row in payload.get('B', [])]
    def parse_order_update(self, payload: dict[str, Any]) -> OrderUpdate | None:
        if payload.get('e') != 'executionReport':
            return None
        if payload.get('x') in {'TRADE', 'TRADE_PREVENTION'}:
            return None
        return OrderUpdate(venue=self.venue, client_order_id=payload.get('c', ''), exchange_order_id=str(payload.get('i', '')), symbol=payload.get('s', ''), status=str(payload.get('X', payload.get('x', 'NEW'))), filled_qty=float(payload.get('z', 0) or 0), avg_price=float(payload.get('Z', 0) or payload.get('L', 0) or 0), raw=payload, ts=_utc_ms(payload.get('E', 0)))


class BybitPrivateStreamAdapter:
    venue = 'bybit'
    def parse_execution(self, payload: dict[str, Any]) -> list[Fill]:
        if not str(payload.get('topic', '')).startswith('execution'):
            return []
        fills=[]
        for row in payload.get('data', []):
            fills.append(Fill(client_order_id=row.get('orderLinkId', ''), exchange_order_id=row.get('orderId', ''), venue=self.venue, symbol=row.get('symbol', ''), side=Side(row.get('side', 'Buy').upper()), qty=float(row.get('execQty', 0)), price=float(row.get('execPrice', 0)), fee=float(row.get('execFee', 0)), trade_id=row.get('execId', ''), ts=_utc_ms(payload.get('creationTime', 0))))
        return fills
    def parse_wallet(self, payload: dict[str, Any]) -> list[Balance]:
        if payload.get('topic') != 'wallet':
            return []
        res=[]
        for acct in payload.get('data', []):
            for coin in acct.get('coin', []):
                res.append(Balance(self.venue, coin['coin'], float(coin.get('walletBalance', 0)), 0.0, _utc_ms(payload.get('creationTime', 0))))
        return res
    def parse_order(self, payload: dict[str, Any]) -> list[OrderUpdate]:
        if payload.get('topic') != 'order':
            return []
        rows=[]
        for row in payload.get('data', []):
            rows.append(OrderUpdate(venue=self.venue, client_order_id=row.get('orderLinkId', ''), exchange_order_id=row.get('orderId', ''), symbol=row.get('symbol', ''), status=row.get('orderStatus', row.get('cancelType', 'New')), filled_qty=float(row.get('cumExecQty', 0) or 0), avg_price=float(row.get('avgPrice', 0) or 0), raw=row, ts=_utc_ms(payload.get('creationTime', 0))))
        return rows


class MexcPrivateStreamAdapter:
    venue = 'mexc'
    def parse_orders(self, payload: dict[str, Any]) -> Fill | None:
        if payload.get('c') != 'spot@private.orders.v3.api':
            return None
        d = payload.get('d', {}).get('privateOrders', {})
        filled = float(d.get('amount', 0))
        price = float(d.get('avgPrice', 0) or d.get('price', 0))
        if filled <= 0:
            return None
        return Fill(client_order_id=d.get('clientId', ''), exchange_order_id=str(d.get('orderId', '')), venue=self.venue, symbol=payload.get('s', d.get('symbol', '')), side=Side('BUY' if int(d.get('tradeType', 1)) == 1 else 'SELL'), qty=filled, price=price, trade_id=str(d.get('tradeId', '')), ts=_utc_ms(payload.get('t', payload.get('sendTime', 0) or 0)))
    def parse_order_update(self, payload: dict[str, Any]) -> OrderUpdate | None:
        if payload.get('c') != 'spot@private.orders.v3.api':
            return None
        d = payload.get('d', {}).get('privateOrders', {})
        return OrderUpdate(venue=self.venue, client_order_id=d.get('clientId', ''), exchange_order_id=str(d.get('orderId', '')), symbol=payload.get('s', d.get('symbol', '')), status=d.get('status', d.get('state', 'NEW')), filled_qty=float(d.get('amount', 0) or 0), avg_price=float(d.get('avgPrice', 0) or d.get('price', 0) or 0), raw=d, ts=_utc_ms(payload.get('t', payload.get('sendTime', 0) or 0)))


class BitgetPrivateStreamAdapter:
    venue = 'bitget'
    def parse_order(self, payload: dict[str, Any]) -> list[OrderUpdate]:
        if payload.get('arg', {}).get('channel') != 'orders':
            return []
        rows=[]
        for row in payload.get('data', []):
            rows.append(OrderUpdate(venue=self.venue, client_order_id=row.get('clientOid', ''), exchange_order_id=row.get('orderId', ''), symbol=row.get('instId', ''), status=row.get('status', ''), filled_qty=float(row.get('accBaseVolume', 0) or 0), avg_price=float(row.get('priceAvg', 0) or 0), raw=row, ts=_utc_ms(row.get('uTime', 0) or 0)))
        return rows
    def parse_account(self, payload: dict[str, Any]) -> list[Balance]:
        if payload.get('arg', {}).get('channel') != 'account':
            return []
        return [Balance(self.venue, row.get('coin', ''), float(row.get('available', 0)), float(row.get('frozen', 0)), _utc_ms(row.get('uTime', 0) or 0)) for row in payload.get('data', [])]
