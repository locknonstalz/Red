# HA Postgres and backup strategy

- Primary Postgres 16 with WAL archiving.
- Daily full backups and 5-minute WAL shipping.
- Alembic migrations as the only schema change path.
- Read replica for analytics/reports; trading writes only to primary.
- Restore drills should be run at least weekly.
- Point-in-time recovery target: under 15 minutes.
