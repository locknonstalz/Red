from common.models import ExecutionPolicy, Side
from futures.execution import FuturesExecutionContext, FuturesExecutionService
from futures.models import FuturesOrderIntent


def test_futures_execution_close_only_clamps_qty_and_goes_aggressive() -> None:
    svc = FuturesExecutionService(min_liquidation_distance_bps=250.0)
    intent = FuturesOrderIntent(
        strategy='hedge_exit',
        venue='binance',
        symbol='BTCUSDT-PERP',
        side=Side.SELL,
        qty=5.0,
        leverage=3.0,
        reduce_only=True,
        close_only=True,
    )
    plan = svc.build_plan(
        intent,
        FuturesExecutionContext(mark_price=100.0, liquidation_distance_bps=120.0, position_qty=1.25),
    )
    assert plan.order.qty == 1.25
    assert plan.execution_policy == ExecutionPolicy.AGGRESSIVE
    assert plan.order.order_type.value == 'MARKET'


def test_futures_execution_applies_funding_aware_bias_for_costly_long() -> None:
    svc = FuturesExecutionService(funding_passive_threshold=0.0004)
    intent = FuturesOrderIntent('carry_long', 'bybit', 'ETHUSDT-PERP', Side.BUY, qty=1.0, leverage=2.0)
    plan = svc.build_plan(
        intent,
        FuturesExecutionContext(mark_price=2000.0, funding_rate=0.0008, liquidation_distance_bps=600.0, venue_health_score=70.0),
    )
    assert plan.funding_bias == 'costly_to_hold'
    assert plan.execution_policy == ExecutionPolicy.PASSIVE


def test_futures_route_ranking_prefers_safer_healthier_venue() -> None:
    svc = FuturesExecutionService(min_liquidation_distance_bps=250.0)
    intent = FuturesOrderIntent('basis_carry', 'binance', 'BTCUSDT-PERP', Side.SELL, qty=0.5, leverage=2.0)
    routes = svc.rank_routes(
        {
            'binance': FuturesExecutionContext(mark_price=100.0, liquidation_distance_bps=180.0, venue_health_score=88.0),
            'bybit': FuturesExecutionContext(mark_price=100.0, liquidation_distance_bps=900.0, venue_health_score=82.0, basis_bps=12.0),
        },
        intent,
    )
    assert routes[0].venue == 'bybit'
    assert routes[0].policy in {ExecutionPolicy.VWAP, ExecutionPolicy.AGGRESSIVE}


def test_basis_pair_builds_opposite_spot_and_perp_legs() -> None:
    svc = FuturesExecutionService()
    pair = svc.build_basis_pair(venue='bitget', symbol='BTCUSDT-PERP', qty=0.2, basis_bps=14.0, leverage=2.0)
    assert pair.carry_direction == 'short_perp_long_spot'
    assert pair.futures_intent.side == Side.SELL
    assert pair.spot_side == Side.BUY
