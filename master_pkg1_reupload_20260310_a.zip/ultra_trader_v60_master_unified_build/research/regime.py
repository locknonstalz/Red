from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from math import sqrt

from common.models import Tick


@dataclass(slots=True)
class RegimeSnapshot:
    venue: str
    symbol: str
    regime: str
    trend_bps: float
    volatility_bps: float


class MarketRegimeClassifier:
    def __init__(self, window: int = 32) -> None:
        self.window = max(window, 8)
        self._prices: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=self.window))

    def observe_tick(self, tick: Tick) -> None:
        self._prices[(tick.venue, tick.symbol)].append(float(tick.mid))

    def snapshot(self, venue: str, symbol: str) -> RegimeSnapshot | None:
        prices = list(self._prices.get((venue, symbol), ()))
        if len(prices) < 5:
            return None
        returns = [(b - a) / a for a, b in zip(prices, prices[1:]) if a]
        trend_bps = ((prices[-1] - prices[0]) / prices[0] * 10000.0) if prices[0] else 0.0
        volatility_bps = sqrt(sum(r * r for r in returns) / len(returns)) * 10000.0 if returns else 0.0
        if abs(trend_bps) > max(12.0, volatility_bps * 1.2):
            regime = 'trend'
        elif volatility_bps > 30.0:
            regime = 'volatile'
        else:
            regime = 'range'
        return RegimeSnapshot(venue=venue, symbol=symbol, regime=regime, trend_bps=trend_bps, volatility_bps=volatility_bps)
