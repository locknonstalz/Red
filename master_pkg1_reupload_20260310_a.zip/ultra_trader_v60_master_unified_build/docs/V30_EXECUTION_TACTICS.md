# V30 Execution Tactics Upgrade

This release adds a first production-style execution tactics layer:

- child-order execution
- TWAP/VWAP-style slicing
- passive/aggressive execution policy
- queue/fill probability model
- venue-aware execution planning

## New pieces

- `execution/tactics.py`
- `ExecutionPolicy` on orders
- `ExecutionService(..., tactics=...)` integration

## Behavior

Large orders can be automatically sliced into child orders when tactics are enabled for the strategy.
Policies are chosen from market conditions and venue health:

- `PASSIVE` for maker-style quoting
- `AGGRESSIVE` for tight-spread urgent execution
- `TWAP`/`VWAP` for larger notional flow

## Environment

- `EXECUTION_TACTICS_ENABLED=1`
- `EXECUTION_TACTICS_STRATEGIES=liquidity_taking,cross_exchange_arbitrage`
- `EXECUTION_TACTICS_MIN_SLICE_NOTIONAL=500`
- `EXECUTION_TACTICS_DEFAULT_SLICES=3`
- `EXECUTION_TACTICS_PASSIVE_OFFSET_BPS=1`
- `EXECUTION_TACTICS_AGGRESSIVE_CROSS_BPS=2`
