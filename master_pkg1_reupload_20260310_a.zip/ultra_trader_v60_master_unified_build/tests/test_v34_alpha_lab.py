from fastapi.testclient import TestClient

from capital.protection import CapitalProtectionService
from common.models import Fill, Side, Tick
from config.settings import CapitalProtectionSettings
from control_plane.api import create_control_plane_app
from control_plane.auth import AuthConfig, ControlPlanePrincipal, TokenAuthManager
from control_plane.service import ControlPlaneService
from ops.alerts import AlertRouter
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from research.alpha_lab import AlphaLabService
from research.asset_analysis import AssetAnalysisService
from research.attribution import StrategyAttributionService
from research.onchain import OnChainAnalyticsService
from research.profitability import ProfitabilityAdvisorService
from research.venue_health import VenueHealthScoringService
from execution.quality import ExecutionQualityAttributionService
from futures.liquidations import LiquidationAnalyticsService
from storage.journal import SqliteJournal


def test_alpha_lab_tracks_hypotheses_experiments_and_decay() -> None:
    attribution = StrategyAttributionService()
    profitability = ProfitabilityAdvisorService(
        attribution=attribution,
        execution_quality=ExecutionQualityAttributionService(),
        venue_health=VenueHealthScoringService(),
        onchain=OnChainAnalyticsService(),
        liquidations=LiquidationAnalyticsService(),
    )
    lab = AlphaLabService(profitability=profitability, attribution=attribution)
    lab.hypotheses.register(
        'h1',
        'Microprice skew edge',
        'Microprice bias should improve maker fills in trend-neutral regimes.',
        strategies=['market_making'],
        factors=['microprice_bias_bps', 'toxicity_score'],
        expected_edge='better passive fill quality',
    )
    lab.experiments.start('exp1', 'h1', 'market_making', 'range', features={'microprice_bias_bps': 1.2, 'toxicity_score': -0.3})
    lab.experiments.complete('exp1', pnl=12.5, trades=8, win_rate=0.625, sharpe_like=1.4, turnover=15000.0)

    attribution.observe_fill(Fill(client_order_id='1', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1, price=100, strategy='market_making'))
    attribution.observe_fill(Fill(client_order_id='2', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1, price=102, strategy='market_making'))
    lab.update_regime('binance', 'BTCUSDT', 'range')
    lab.observe_fill(Fill(client_order_id='3', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1, price=101, strategy='market_making'), realized_pnl_hint=-1.0)
    lab.observe_fill(Fill(client_order_id='4', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1, price=99, strategy='market_making'), realized_pnl_hint=-1.2)
    lab.observe_fill(Fill(client_order_id='5', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1, price=98, strategy='market_making'), realized_pnl_hint=-1.5)
    lab.observe_fill(Fill(client_order_id='6', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1, price=97, strategy='market_making'), realized_pnl_hint=-1.4)
    lab.observe_fill(Fill(client_order_id='7', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1, price=96, strategy='market_making'), realized_pnl_hint=-1.6)
    lab.refresh_factor_snapshot({'microprice_bias_bps': 0.8, 'toxicity_score': -0.4})

    snap = lab.snapshot(['market_making'], 'binance', 'BTCUSDT')
    assert snap.hypotheses and snap.hypotheses[0].hypothesis_id == 'h1'
    assert snap.factor_importance and snap.factor_importance[0].factor in {'microprice_bias_bps', 'toxicity_score'}
    assert snap.regime_performance and snap.regime_performance[0].regime == 'range'
    assert snap.decay_reports and snap.decay_reports[0].is_decaying is True
    assert snap.sleeve_allocations and snap.sleeve_allocations[0].strategy == 'market_making'


def test_alpha_lab_endpoint_exposed_in_control_plane() -> None:
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    protection = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    asset = AssetAnalysisService()
    asset.observe_tick(Tick(venue='binance', symbol='BTCUSDT', price=100.0, bid=99.9, ask=100.1))
    attribution = StrategyAttributionService()
    profitability = ProfitabilityAdvisorService(
        attribution=attribution,
        execution_quality=ExecutionQualityAttributionService(),
        venue_health=VenueHealthScoringService(),
        onchain=OnChainAnalyticsService(),
        liquidations=LiquidationAnalyticsService(),
    )
    alpha_lab = AlphaLabService(profitability=profitability, attribution=attribution)
    alpha_lab.hypotheses.register('h1', 'Test edge', 'Desc', strategies=['momentum'], factors=['spread_bps'], expected_edge='more selective entries')

    service = ControlPlaneService(
        capital_protection=protection,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        alert_router=AlertRouter([]),
        asset_analysis=asset,
        alpha_lab=alpha_lab,
    )
    auth = TokenAuthManager(AuthConfig(enabled=True, static_tokens={
        'viewer-token': ControlPlanePrincipal(subject='viewer1', role='viewer'),
    }))
    client = TestClient(create_control_plane_app(service, auth))
    resp = client.get('/alpha-lab', headers={'Authorization': 'Bearer viewer-token'})
    assert resp.status_code == 200
    data = resp.json()['alpha_lab']
    assert data['hypotheses'][0]['hypothesis_id'] == 'h1'
