from __future__ import annotations

from config.settings import Settings
from strategy.cross_exchange_arbitrage import CrossExchangeArbitrageStrategy
from strategy.funding_carry import FundingCarryStrategy
from strategy.liquidity_taking import LiquidityTakingStrategy
from strategy.liquidation_cascade import LiquidationCascadeStrategy
from strategy.market_making import MarketMakingStrategy
from strategy.momentum import MomentumStrategy
from strategy.statistical_arbitrage import StatisticalArbitrageStrategy


def build_default_strategies(settings: Settings):
    symbol = settings.default_symbol
    primary = settings.default_venue
    universe = settings.strategy.cross_exchange_venues or [primary]
    lead = universe[0]
    lag = universe[1] if len(universe) > 1 else universe[0]
    strategies = []
    if settings.strategy.enable_market_making:
        strategies.append(MarketMakingStrategy(name='market_making', venue=primary, symbol=symbol, quote_size=settings.strategy.market_making.quote_size, min_spread_bps=settings.strategy.market_making.min_spread_bps, inventory_limit=settings.strategy.market_making.inventory_limit, requote_cooldown_ticks=settings.strategy.market_making.requote_cooldown_ticks))
    if settings.strategy.enable_cross_exchange_arb and len(universe) > 1:
        strategies.append(CrossExchangeArbitrageStrategy(name='cross_exchange_arbitrage', symbol=symbol, trade_size=settings.strategy.cross_exchange.trade_size, min_edge_bps=settings.strategy.cross_exchange.min_edge_bps))
    if settings.strategy.enable_stat_arb and len(universe) > 1:
        strategies.append(StatisticalArbitrageStrategy(name='statistical_arbitrage', lead_venue=lead, lag_venue=lag, symbol=symbol, trade_size=settings.strategy.stat_arb.trade_size, window=settings.strategy.stat_arb.window, entry_z=settings.strategy.stat_arb.entry_z, exit_z=settings.strategy.stat_arb.exit_z))
    if settings.strategy.enable_liquidity_taking:
        strategies.append(LiquidityTakingStrategy(name='liquidity_taking', venue=primary, symbol=symbol, trade_size=settings.strategy.liquidity_taking.trade_size, lookback=settings.strategy.liquidity_taking.lookback, breakout_bps=settings.strategy.liquidity_taking.breakout_bps, min_spread_bps=settings.strategy.liquidity_taking.min_spread_bps))
    if settings.strategy.enable_funding_carry:
        strategies.append(FundingCarryStrategy(name='funding_carry', spot_venue=settings.strategy.funding_carry.spot_venue, perp_venue=settings.strategy.funding_carry.perp_venue, symbol=symbol, trade_size=settings.strategy.funding_carry.trade_size, min_funding_rate=settings.strategy.funding_carry.min_funding_rate, min_basis_bps=settings.strategy.funding_carry.min_basis_bps, max_basis_bps=settings.strategy.funding_carry.max_basis_bps))
    if settings.strategy.enable_liquidation_cascade:
        strategies.append(LiquidationCascadeStrategy(name='liquidation_cascade', venue=primary, symbol=symbol, trade_size=settings.strategy.liquidation_cascade.trade_size, lookback=settings.strategy.liquidation_cascade.lookback, min_cascade_risk=settings.strategy.liquidation_cascade.min_cascade_risk, min_liquidation_pressure=settings.strategy.liquidation_cascade.min_liquidation_pressure, breakout_bps=settings.strategy.liquidation_cascade.breakout_bps))
    if settings.strategy.enable_momentum:
        strategies.append(MomentumStrategy(name='momentum_xover', venue=primary, symbol=symbol, fast_window=5, slow_window=20, order_size=settings.strategy.order_size))
    return strategies
