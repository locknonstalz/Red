from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from math import exp


@dataclass(slots=True)
class BookLevel:
    price: float
    size: float
    orders: int = 1


@dataclass(slots=True)
class L2BookSnapshot:
    venue: str
    symbol: str
    bids: list[BookLevel]
    asks: list[BookLevel]
    sequence: int = 0


@dataclass(slots=True)
class L3Order:
    order_id: str
    side: str
    price: float
    size: float
    ts_ns: int = 0


@dataclass(slots=True)
class L3BookSnapshot:
    venue: str
    symbol: str
    bids: list[L3Order]
    asks: list[L3Order]
    sequence: int = 0


@dataclass(slots=True)
class OrderBookFeatures:
    venue: str
    symbol: str
    mid: float
    microprice: float
    spread_bps: float
    l1_imbalance: float
    l5_imbalance: float
    queue_ahead_bid: float
    queue_ahead_ask: float
    sweep_risk_bps: float
    toxicity_score: float
    adverse_selection_risk: float


class OrderBookIntelligenceService:
    def __init__(self, history: int = 64) -> None:
        self.history = max(history, 8)
        self._l2: dict[tuple[str, str], L2BookSnapshot] = {}
        self._l3: dict[tuple[str, str], L3BookSnapshot] = {}
        self._sequence: dict[tuple[str, str], int] = {}
        self._microprices: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=self.history))
        self._imbalances: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=self.history))

    def observe_l2(self, snapshot: L2BookSnapshot) -> None:
        key = (snapshot.venue, snapshot.symbol)
        self._l2[key] = snapshot
        self._sequence[key] = max(self._sequence.get(key, 0), snapshot.sequence)
        feats = self.snapshot(snapshot.venue, snapshot.symbol)
        if feats is not None:
            self._microprices[key].append(feats.microprice)
            self._imbalances[key].append(feats.l1_imbalance)

    def observe_l3(self, snapshot: L3BookSnapshot) -> None:
        key = (snapshot.venue, snapshot.symbol)
        self._l3[key] = snapshot
        self._sequence[key] = max(self._sequence.get(key, 0), snapshot.sequence)

    def _aggregate_l3(self, orders: list[L3Order], reverse: bool) -> list[BookLevel]:
        bucket: dict[float, list[L3Order]] = defaultdict(list)
        for order in orders:
            bucket[float(order.price)].append(order)
        levels = [BookLevel(price=price, size=sum(item.size for item in items), orders=len(items)) for price, items in bucket.items()]
        return sorted(levels, key=lambda row: row.price, reverse=reverse)

    def _best_levels(self, venue: str, symbol: str) -> tuple[list[BookLevel], list[BookLevel]]:
        key = (venue, symbol)
        l2 = self._l2.get(key)
        bids = list(l2.bids) if l2 is not None else []
        asks = list(l2.asks) if l2 is not None else []
        l3 = self._l3.get(key)
        if l3 is not None:
            bids = self._aggregate_l3(l3.bids, reverse=True)[: max(len(bids), 10) or 10]
            asks = self._aggregate_l3(l3.asks, reverse=False)[: max(len(asks), 10) or 10]
        return bids, asks

    def snapshot(self, venue: str, symbol: str) -> OrderBookFeatures | None:
        bids, asks = self._best_levels(venue, symbol)
        if not bids or not asks:
            return None
        best_bid = bids[0]
        best_ask = asks[0]
        mid = (best_bid.price + best_ask.price) / 2.0
        if mid <= 0:
            return None
        microprice = ((best_ask.price * best_bid.size) + (best_bid.price * best_ask.size)) / max(best_bid.size + best_ask.size, 1e-12)
        spread_bps = max(best_ask.price - best_bid.price, 0.0) / mid * 10000.0
        bid_l1 = best_bid.size
        ask_l1 = best_ask.size
        l1_imbalance = (bid_l1 - ask_l1) / max(bid_l1 + ask_l1, 1e-12)
        bid5 = sum(level.size for level in bids[:5])
        ask5 = sum(level.size for level in asks[:5])
        l5_imbalance = (bid5 - ask5) / max(bid5 + ask5, 1e-12)
        queue_ahead_bid = bid_l1
        queue_ahead_ask = ask_l1
        impact_notional = mid * max(min(bid5, ask5) * 0.5, 1e-9)
        sweep_risk_bps = min(250.0, 10000.0 / impact_notional)
        hist_micro = self._microprices.get((venue, symbol), deque())
        hist_imb = self._imbalances.get((venue, symbol), deque())
        micro_drift = abs((microprice - (hist_micro[-1] if hist_micro else microprice)) / mid * 10000.0)
        imbalance_vol = (sum(abs(x) for x in hist_imb) / len(hist_imb)) if hist_imb else 0.0
        toxicity_score = min(100.0, micro_drift * 0.6 + abs(l1_imbalance) * 40.0 + imbalance_vol * 20.0)
        adverse_selection_risk = min(1.0, 1.0 / (1.0 + exp(-(toxicity_score - 25.0) / 10.0)))
        return OrderBookFeatures(
            venue=venue,
            symbol=symbol,
            mid=mid,
            microprice=microprice,
            spread_bps=spread_bps,
            l1_imbalance=l1_imbalance,
            l5_imbalance=l5_imbalance,
            queue_ahead_bid=queue_ahead_bid,
            queue_ahead_ask=queue_ahead_ask,
            sweep_risk_bps=sweep_risk_bps,
            toxicity_score=toxicity_score,
            adverse_selection_risk=adverse_selection_risk,
        )

    def score_for_passive_execution(self, venue: str, symbol: str) -> float:
        features = self.snapshot(venue, symbol)
        if features is None:
            return 0.0
        return max(0.0, min(1.0, 1.0 - features.adverse_selection_risk - features.spread_bps / 100.0 + max(features.l1_imbalance, 0.0) * 0.2))
