from __future__ import annotations

from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from typing import Any

from execution.quality import ExecutionQualityAttributionService
from ops.incidents import AlertInboxSink, IncidentWorkflowService
from portfolio.portfolio_service import PortfolioService


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class MicroLiveRun:
    strategy: str
    venue: str
    symbol: str
    notional: float
    started_at: datetime = field(default_factory=utc_now)
    status: str = 'planned'
    notes: str = ''


class LiveValidationService:
    def __init__(self, *, portfolio: PortfolioService, execution_quality: ExecutionQualityAttributionService, alerts: AlertInboxSink, incidents: IncidentWorkflowService) -> None:
        self.portfolio = portfolio
        self.execution_quality = execution_quality
        self.alerts = alerts
        self.incidents = incidents
        self._micro_runs: list[MicroLiveRun] = []
        self._scenarios: list[dict[str, Any]] = []

    def plan_micro_live(self, strategy: str, venue: str, symbol: str, *, notional: float) -> dict[str, Any]:
        run = MicroLiveRun(strategy=strategy, venue=venue, symbol=symbol, notional=notional)
        global_q = self.execution_quality.snapshot().get('global')
        if global_q and global_q.avg_slippage_bps > 15:
            run.status = 'blocked'
            run.notes = 'global_slippage_too_high'
        elif self.incidents.list_incidents(active_only=True, limit=1):
            run.status = 'blocked'
            run.notes = 'active_incident_present'
        else:
            run.status = 'ready'
            run.notes = 'micro_live_allowed'
        self._micro_runs.append(run)
        return asdict(run) | {'started_at': run.started_at.isoformat()}

    def run_stress_scenario(self, name: str, *, venue_disconnects: int = 0, latency_ms: float = 0.0, spread_bps: float = 0.0) -> dict[str, Any]:
        severity = 'ok'
        if venue_disconnects >= 2 or latency_ms >= 500 or spread_bps >= 30:
            severity = 'critical'
        elif venue_disconnects == 1 or latency_ms >= 200 or spread_bps >= 15:
            severity = 'warning'
        row = {
            'name': name,
            'ts': utc_now().isoformat(),
            'venue_disconnects': venue_disconnects,
            'latency_ms': latency_ms,
            'spread_bps': spread_bps,
            'severity': severity,
        }
        self._scenarios.append(row)
        return row

    def capacity_discovery(self) -> dict[str, Any]:
        snap = self.execution_quality.snapshot()
        global_q = snap.get('global')
        slip = 0.0 if global_q is None else global_q.avg_slippage_bps
        import os
        max_total = float(os.getenv('MAX_TOTAL_NOTIONAL', '100.0'))
        recommended = min(max_total, 1000.0 if slip < 5 else 500.0 if slip < 10 else 100.0)
        return {
            'recommended_micro_live_notional': recommended,
            'slippage_bps': slip,
            'alerts_unacked': len(self.alerts.list_alerts(only_unacked=True, limit=500)),
        }

    def snapshot(self) -> dict[str, Any]:
        return {
            'micro_live_runs': [asdict(x) | {'started_at': x.started_at.isoformat()} for x in self._micro_runs[-20:]],
            'stress_scenarios': self._scenarios[-20:],
            'capacity': self.capacity_discovery(),
        }
