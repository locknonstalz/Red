from __future__ import annotations

import abc
import asyncio
import json
from dataclasses import dataclass
from typing import Any

import websockets

from common.bus import EventBus
from common.models import Tick
from ops.metrics import MetricsRegistry


@dataclass(slots=True)
class ExchangeCredentials:
    api_key: str
    api_secret: str
    passphrase: str | None = None


class BaseMarketAdapter(abc.ABC):
    venue: str
    ws_url: str

    def __init__(self, bus: EventBus, metrics: MetricsRegistry, symbol: str, reconnect_delay_sec: float = 2.0) -> None:
        self.bus = bus
        self.metrics = metrics
        self.symbol = symbol
        self.reconnect_delay_sec = reconnect_delay_sec
        self._stop = False

    @abc.abstractmethod
    async def subscribe(self, ws) -> None:
        raise NotImplementedError

    @abc.abstractmethod
    def parse_message(self, payload: dict[str, Any]) -> Tick | None:
        raise NotImplementedError

    async def run(self) -> None:
        while not self._stop:
            try:
                async with websockets.connect(self.ws_url, ping_interval=20, ping_timeout=20) as ws:
                    await self.subscribe(ws)
                    async for raw in ws:
                        payload = json.loads(raw)
                        tick = self.parse_message(payload)
                        if tick is None:
                            continue
                        self.metrics.increment(f'ticks_{self.venue}_total')
                        await self.bus.publish('ticks', tick)
            except asyncio.CancelledError:
                raise
            except Exception:
                self.metrics.increment(f'market_adapter_errors_{self.venue}_total')
                await asyncio.sleep(self.reconnect_delay_sec)

    async def close(self) -> None:
        self._stop = True
