from __future__ import annotations

from dataclasses import asdict
from html import escape

from fastapi import Depends, FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from control_plane.auth import TokenAuthManager, require_principal
from control_plane.hardening import apply_security_hardening
from control_plane.service import ControlPlaneService


class ToggleRequest(BaseModel):
    enabled: bool
    reason: str = Field(default='manual_operator_action', min_length=1)


class StrategyToggleRequest(BaseModel):
    strategy: str
    enabled: bool
    reason: str = Field(default='manual_strategy_toggle', min_length=1)


class AIRequest(BaseModel):
    enabled: bool
    reason: str = Field(default='manual_ai_toggle', min_length=1)


class ConfirmationExecuteRequest(BaseModel):
    confirmation_id: str = Field(min_length=8)


class AlertAckRequest(BaseModel):
    alert_id: str = Field(min_length=8)


class IncidentOpenRequest(BaseModel):
    alert_id: str = Field(min_length=8)
    note: str = ''


class IncidentUpdateRequest(BaseModel):
    incident_id: str = Field(min_length=8)
    note: str = ''


class PromotionRequest(BaseModel):
    strategy: str
    target_stage: str
    reason: str = Field(min_length=1)
    checks: dict[str, bool] = Field(default_factory=dict)


class PromotionApproveRequest(BaseModel):
    strategy: str




class DrillRequest(BaseModel):
    drill_type: str
    context: dict[str, bool | str | float | int] = Field(default_factory=dict)


class CertificationIngestRequest(BaseModel):
    venue: str
    credentials_ok: bool = True
    public_connectivity_ok: bool = True
    private_connectivity_ok: bool = True
    balances_ok: bool = True
    place_order_ok: bool = False
    cancel_order_ok: bool = False
    final_status_ok: bool = False
    payload: dict[str, object] = Field(default_factory=dict)


class StrategyEvidenceRequest(BaseModel):
    strategy: str
    checks: dict[str, bool]
    payload: dict[str, object] = Field(default_factory=dict)

class AckResponse(BaseModel):
    ok: bool = True
    state: dict


def _dashboard_html(service: ControlPlaneService) -> str:
    snap = service.snapshot()
    rows = ''.join(
        f"<tr><td>{escape(evt['created_at'])}</td><td>{escape(evt['event_type'])}</td><td>{escape(evt['subject'])}</td><td>{escape(evt['reason'])}</td></tr>"
        for evt in snap.recent_protection_events[:15]
    )
    confirmations = ''.join(
        f"<tr><td>{escape(row['created_at'])}</td><td>{escape(row['action'])}</td><td>{escape(row['actor'])}</td><td>{escape(row['expires_at'])}</td></tr>"
        for row in snap.pending_confirmations[:10]
    )
    alerts = ''.join(
        f"<tr><td>{escape(row['created_at'])}</td><td>{escape(row['severity'])}</td><td>{escape(row['event'])}</td><td>{escape(str(row['acknowledged']))}</td></tr>"
        for row in snap.alerts[:10]
    )
    incidents = ''.join(
        f"<tr><td>{escape(row['created_at'])}</td><td>{escape(row['severity'])}</td><td>{escape(row['status'])}</td><td>{escape(row['title'])}</td></tr>"
        for row in snap.incidents[:10]
    )
    promotions = ''.join(
        f"<tr><td>{escape(row['strategy'])}</td><td>{escape(row['current_stage'])}</td><td>{escape(str(row['pending_stage']))}</td><td>{escape(str(row['ready']))}</td></tr>"
        for row in snap.promotions[:10]
    )
    drills = ''.join(
        f"<tr><td>{escape(row['created_at'])}</td><td>{escape(row['drill_type'])}</td><td>{escape(row['status'])}</td><td>{escape(row['actor'])}</td></tr>"
        for row in snap.drills[:10]
    )
    scores = ''.join(
        f"<tr><td>{escape(row['strategy'])}</td><td>{escape(str(row['score']))}</td><td>{escape(row['verdict'])}</td><td>{escape(str(row['components']['current_stage']))}</td></tr>"
        for row in snap.go_live_scores[:10]
    )
    execution_quality = ''.join(
        f"<tr><td>{escape(row['group'])}</td><td>{escape(str(row['fills']))}</td><td>{escape(str(row['avg_slippage_bps']))}</td><td>{escape(str(row['avg_fee_bps']))}</td></tr>"
        for row in snap.execution_quality[:10]
    )
    rollout = ''.join(
        f"<tr><td>{escape(row['strategy'])}</td><td>{escape(row['requested_stage'])}</td><td>{escape(row['allowed_stage'])}</td><td>{escape(str(row['allowed']))}</td></tr>"
        for row in snap.rollout_guardrails[:10]
    )
    alpha_lab = snap.alpha_lab
    factor_rows = ''.join(
        f"<tr><td>{escape(row['factor'])}</td><td>{escape(str(round(row['score'], 4)))}</td><td>{escape(str(row['support']))}</td></tr>"
        for row in alpha_lab.get('factor_importance', [])[:10]
    )
    decay_rows = ''.join(
        f"<tr><td>{escape(row['strategy'])}</td><td>{escape(str(round(row['decay_score'], 2)))}</td><td>{escape(str(row['is_decaying']))}</td><td>{escape(row['recommendation'])}</td></tr>"
        for row in alpha_lab.get('decay_reports', [])[:10]
    )
    return f"""
    <html><head><title>Ultra Trader v38 Dashboard</title>
    <style>
    body {{ font-family: Arial, sans-serif; margin: 24px; }}
    .grid {{ display:grid; grid-template-columns: repeat(3, minmax(220px, 1fr)); gap: 16px; }}
    .card {{ border:1px solid #ddd; border-radius: 14px; padding: 16px; box-shadow: 0 2px 10px rgba(0,0,0,.05); }}
    table {{ width:100%; border-collapse: collapse; margin-top:16px; }}
    td,th {{ border-bottom:1px solid #eee; text-align:left; padding:8px; }}
    code {{ background:#f6f6f6; padding:2px 6px; border-radius:6px; }}
    </style></head>
    <body>
      <h1>Ultra Trader v27 Control Dashboard</h1><p>v38 governance, production data, live validation, and capital scaling enabled.</p>
      <div class='grid'>
        <div class='card'><h3>Protection</h3><pre>{escape(str(snap.protection))}</pre></div>
        <div class='card'><h3>Portfolio</h3><pre>{escape(str(snap.portfolio))}</pre></div>
        <div class='card'><h3>AI + Metrics</h3><pre>{escape(str({'ai': snap.ai, 'metrics': snap.metrics}))}</pre></div>
      </div>
      <h2>Allocator / Screener / Shadow</h2>
      <div class='grid'>
        <div class='card'><h3>Allocator</h3><pre>{escape(str(snap.allocator))}</pre></div>
        <div class='card'><h3>Asset Screener</h3><pre>{escape(str(snap.screener[:8]))}</pre></div>
        <div class='card'><h3>Shadow</h3><pre>{escape(str(snap.shadow))}</pre></div>
      </div>
      <h2>Alerts / Incidents / Promotions</h2>
      <div class='grid'>
        <div class='card'><h3>Alerts</h3><table><tr><th>Time</th><th>Severity</th><th>Event</th><th>Ack</th></tr>{alerts}</table></div>
        <div class='card'><h3>Incidents</h3><table><tr><th>Time</th><th>Severity</th><th>Status</th><th>Title</th></tr>{incidents}</table></div>
        <div class='card'><h3>Promotions</h3><table><tr><th>Strategy</th><th>Current</th><th>Pending</th><th>Ready</th></tr>{promotions}</table></div>
      </div>
      <h2>Go-live readiness / drills</h2>
      <div class='grid'>
        <div class='card'><h3>Go-live scores</h3><table><tr><th>Strategy</th><th>Score</th><th>Verdict</th><th>Stage</th></tr>{scores}</table></div>
        <div class='card'><h3>Venue certification</h3><pre>{escape(str(snap.venue_certification[:8]))}</pre></div>
        <div class='card'><h3>Operator drills</h3><table><tr><th>Time</th><th>Drill</th><th>Status</th><th>Actor</th></tr>{drills}</table></div>
      </div>
      <h2>Execution quality / capacity / rollout guardrails</h2>
      <div class='grid'>
        <div class='card'><h3>Execution quality</h3><table><tr><th>Group</th><th>Fills</th><th>Slip bps</th><th>Fee bps</th></tr>{execution_quality}</table></div>
        <div class='card'><h3>Capacity rankings</h3><pre>{escape(str(snap.capacity_rankings[:8]))}</pre></div>
        <div class='card'><h3>Rollout guardrails</h3><table><tr><th>Strategy</th><th>Requested</th><th>Allowed</th><th>OK</th></tr>{rollout}</table></div>
      </div>
      <h2>Alpha lab</h2>
      <div class='grid'>
        <div class='card'><h3>Hypotheses</h3><pre>{escape(str(alpha_lab.get('hypotheses', [])[:6]))}</pre></div>
        <div class='card'><h3>Factor importance</h3><table><tr><th>Factor</th><th>Score</th><th>Support</th></tr>{factor_rows}</table></div>
        <div class='card'><h3>Decay reports</h3><table><tr><th>Strategy</th><th>Decay</th><th>Flag</th><th>Action</th></tr>{decay_rows}</table></div>
      </div>
      <h2>Alpha governance / production data / live validation</h2>
      <div class='grid'>
        <div class='card'><h3>Alpha governance</h3><pre>{escape(str(snap.alpha_governance))}</pre></div>
        <div class='card'><h3>Production data</h3><pre>{escape(str(snap.production_data))}</pre></div>
        <div class='card'><h3>Live validation</h3><pre>{escape(str(snap.live_validation))}</pre></div>
      </div>
      <h2>Capital scaling</h2>
      <div class='grid'>
        <div class='card'><h3>Scaling engine</h3><pre>{escape(str(snap.capital_scaling))}</pre></div>
      </div>
      <h2>Pending confirmations</h2>
      <table><tr><th>Created</th><th>Action</th><th>Actor</th><th>Expires</th></tr>{confirmations}</table>
      <h2>Recent protection events</h2>
      <table><tr><th>Time</th><th>Type</th><th>Subject</th><th>Reason</th></tr>{rows}</table>
    </body></html>
    """


def create_control_plane_app(service: ControlPlaneService, auth_manager: TokenAuthManager | None = None) -> FastAPI:
    auth_manager = auth_manager or TokenAuthManager.__new__(TokenAuthManager)
    if not hasattr(auth_manager, 'config'):
        from control_plane.auth import AuthConfig
        auth_manager = TokenAuthManager(AuthConfig(enabled=False))
    app = FastAPI(title='Ultra Trader Operator Control Plane', version='38.0')
    apply_security_hardening(app)

    viewer = require_principal(auth_manager, 'viewer')
    operator = require_principal(auth_manager, 'operator')
    admin = require_principal(auth_manager, 'admin')

    @app.get('/health')
    def health() -> dict:
        return {'ok': True, 'version': '38.0'}

    @app.get('/dashboard', response_class=HTMLResponse)
    def dashboard(_=Depends(viewer)) -> str:
        return _dashboard_html(service)

    @app.get('/state')
    def state(_=Depends(viewer)) -> dict:
        return asdict(service.snapshot())

    @app.get('/risk/dashboard')
    def risk_dashboard(_=Depends(viewer)) -> dict:
        snap = service.snapshot()
        return {
            'portfolio': snap.portfolio,
            'protection': snap.protection,
            'metrics': snap.metrics,
            'recent_protection_events': snap.recent_protection_events[:20],
            'allocator': snap.allocator,
            'screener': snap.screener[:20],
            'futures_rankings': snap.futures_rankings[:20],
            'venue_health': snap.venue_health,
            'shadow': snap.shadow,
            'pending_confirmations': snap.pending_confirmations,
            'alerts': snap.alerts[:20],
            'incidents': snap.incidents[:20],
            'promotions': snap.promotions,
            'drills': snap.drills,
            'certification_evidence': snap.certification_evidence[:20],
            'go_live_scores': snap.go_live_scores,
            'venue_certification': snap.venue_certification,
            'execution_quality': snap.execution_quality,
            'capacity_rankings': snap.capacity_rankings,
            'rollout_guardrails': snap.rollout_guardrails,
            'alpha_lab': snap.alpha_lab,
            'alpha_governance': snap.alpha_governance,
            'production_data': snap.production_data,
            'live_validation': snap.live_validation,
            'capital_scaling': snap.capital_scaling,
        }

    @app.get('/research/screener')
    def research_screener(_=Depends(viewer)) -> dict:
        snap = service.snapshot()
        return {'screener': snap.screener, 'allocator': snap.allocator, 'futures_rankings': snap.futures_rankings}

    @app.get('/alpha-lab')
    def alpha_lab(_=Depends(viewer)) -> dict:
        snap = service.snapshot()
        return {'alpha_lab': snap.alpha_lab, 'alpha_governance': snap.alpha_governance}

    @app.get('/data/quality')
    def data_quality(_=Depends(viewer)) -> dict:
        snap = service.snapshot()
        return {'production_data': snap.production_data}

    @app.get('/live-validation')
    def live_validation(_=Depends(viewer)) -> dict:
        snap = service.snapshot()
        return {'live_validation': snap.live_validation}

    @app.get('/capital/scaling')
    def capital_scaling(_=Depends(viewer)) -> dict:
        snap = service.snapshot()
        return {'capital_scaling': snap.capital_scaling}

    @app.get('/protection/events')
    def protection_events(limit: int = 50, _=Depends(viewer)) -> dict:
        return {'events': service.journal.recent_protection_events(limit=max(1, min(limit, 500)))}

    @app.get('/alerts')
    def alerts(only_unacked: bool = False, limit: int = 100, _=Depends(viewer)) -> dict:
        return {'alerts': service.list_alerts(only_unacked=only_unacked, limit=max(1, min(limit, 500)))}

    @app.post('/alerts/ack')
    def alert_ack(req: AlertAckRequest, principal=Depends(operator)) -> dict:
        return service.acknowledge_alert(req.alert_id, actor=principal.subject)

    @app.get('/incidents')
    def incidents(active_only: bool = False, _=Depends(viewer)) -> dict:
        return {'incidents': service.incidents.list_incidents(active_only=active_only)}

    @app.post('/incidents/open')
    def incident_open(req: IncidentOpenRequest, principal=Depends(operator)) -> dict:
        return service.open_incident_from_alert(req.alert_id, actor=principal.subject, note=req.note)

    @app.post('/incidents/ack')
    def incident_ack(req: IncidentUpdateRequest, principal=Depends(operator)) -> dict:
        return service.acknowledge_incident(req.incident_id, actor=principal.subject, note=req.note)

    @app.post('/incidents/resolve')
    def incident_resolve(req: IncidentUpdateRequest, principal=Depends(operator)) -> dict:
        return service.resolve_incident(req.incident_id, actor=principal.subject, note=req.note)

    @app.get('/promotions')
    def promotions(_=Depends(viewer)) -> dict:
        return {'promotions': service.promotions.list_promotions()}

    @app.post('/promotions/request')
    def promotion_request(req: PromotionRequest, principal=Depends(operator)) -> dict:
        return service.request_promotion(req.strategy, req.target_stage, req.checks, actor=principal.subject, reason=req.reason)

    @app.post('/promotions/approve')
    def promotion_approve(req: PromotionApproveRequest, principal=Depends(admin)) -> dict:
        return service.approve_promotion(req.strategy, actor=principal.subject)


    @app.get('/execution/quality')
    def execution_quality(_=Depends(viewer)) -> dict:
        snap = service.snapshot()
        return {'execution_quality': snap.execution_quality, 'capacity_rankings': snap.capacity_rankings, 'rollout_guardrails': snap.rollout_guardrails}

    @app.get('/go-live/scores')
    def go_live_scores(strategy: str | None = None, _=Depends(viewer)) -> dict:
        if strategy:
            return {'score': service.go_live_readiness(strategy)}
        return {'scores': service.snapshot().go_live_scores, 'venue_certification': service.snapshot().venue_certification}

    @app.get('/drills')
    def drills(_=Depends(viewer)) -> dict:
        return {'drills': service.snapshot().drills}

    @app.post('/drills/run')
    def drills_run(req: DrillRequest, principal=Depends(operator)) -> dict:
        return service.run_operator_drill(req.drill_type, actor=principal.subject, context=dict(req.context))

    @app.post('/certification/ingest')
    def certification_ingest(req: CertificationIngestRequest, principal=Depends(operator)) -> dict:
        payload = req.model_dump()
        return service.ingest_certification_report(payload, actor=principal.subject)

    @app.post('/go-live/evidence')
    def go_live_evidence(req: StrategyEvidenceRequest, principal=Depends(operator)) -> dict:
        return service.record_strategy_go_live_evidence(req.strategy, req.checks, actor=principal.subject, payload=req.payload)

    @app.post('/controls/only-close', response_model=AckResponse)
    def set_only_close(req: ToggleRequest, principal=Depends(operator)) -> AckResponse:
        return AckResponse(state=service.set_only_close(req.enabled, req.reason, actor=principal.subject))

    @app.post('/controls/global-kill', response_model=AckResponse)
    def set_global_kill(req: ToggleRequest, principal=Depends(admin)) -> AckResponse:
        return AckResponse(state=service.set_global_kill(req.enabled, req.reason, actor=principal.subject))

    @app.post('/controls/strategy', response_model=AckResponse)
    def set_strategy(req: StrategyToggleRequest, principal=Depends(operator)) -> AckResponse:
        return AckResponse(state=service.set_strategy(req.strategy, req.enabled, req.reason, actor=principal.subject))

    @app.post('/controls/ai', response_model=AckResponse)
    def set_ai(req: AIRequest, principal=Depends(operator)) -> AckResponse:
        return AckResponse(state=service.set_ai(req.enabled, req.reason, actor=principal.subject))

    @app.post('/controls/request/only-close')
    def request_only_close(req: ToggleRequest, principal=Depends(operator)) -> dict:
        return service.request_only_close(req.enabled, req.reason, actor=principal.subject)

    @app.post('/controls/request/global-kill')
    def request_global_kill(req: ToggleRequest, principal=Depends(admin)) -> dict:
        return service.request_global_kill(req.enabled, req.reason, actor=principal.subject)

    @app.post('/controls/request/strategy')
    def request_strategy(req: StrategyToggleRequest, principal=Depends(operator)) -> dict:
        return service.request_strategy(req.strategy, req.enabled, req.reason, actor=principal.subject)

    @app.post('/controls/request/ai')
    def request_ai(req: AIRequest, principal=Depends(operator)) -> dict:
        return service.request_ai(req.enabled, req.reason, actor=principal.subject)

    @app.post('/controls/confirm/execute')
    def execute_confirmation(req: ConfirmationExecuteRequest, principal=Depends(viewer)) -> dict:
        return service.execute_confirmation(req.confirmation_id, actor=principal.subject)

    return app
