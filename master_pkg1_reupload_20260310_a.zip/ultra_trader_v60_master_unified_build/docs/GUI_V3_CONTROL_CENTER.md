# GUI v3 Control Center

Что нового:
- мастер первого запуска
- отдельная вкладка стратегий
- быстрые пресеты: только Funding Carry / все стратегии
- улучшенный визуальный стиль
- удобная сводка важных параметров из `.env`
- готовый `start_gui.bat`

Запуск в Windows:
1. Откройте папку проекта.
2. Дважды кликните `start_gui.bat`.
3. В GUI нажмите `Мастер первого запуска`, затем `Preflight`, затем `Start`.

Рекомендуемый первый сценарий:
- режим `micro_live`
- включена только `Funding Carry`
- `MAX_TOTAL_NOTIONAL=100`
- `MAX_ORDER_NOTIONAL=15`
- `MICRO_LIVE_MIN_TARGET_NOTIONAL=10`
