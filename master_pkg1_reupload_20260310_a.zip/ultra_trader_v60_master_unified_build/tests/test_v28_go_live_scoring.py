from fastapi.testclient import TestClient

from ai.decision_engine import AIDecisionEngine
from capital.protection import CapitalProtectionService
from config.settings import CapitalProtectionSettings
from control_plane.api import create_control_plane_app
from control_plane.auth import AuthConfig, ControlPlanePrincipal, TokenAuthManager
from control_plane.service import ControlPlaneService
from ops.alerts import AlertRouter
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from strategy.shadow import ShadowDeploymentService
from storage.journal import SqliteJournal


def _client() -> TestClient:
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    capital = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    ai = AIDecisionEngine(metrics=metrics, enabled=True, model_path='/tmp/nonexistent-v28.json')
    shadow = ShadowDeploymentService(journal=journal, shadow_strategies={'alpha'})
    service = ControlPlaneService(
        capital_protection=capital,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        ai_engine=ai,
        alert_router=AlertRouter([]),
        shadow=shadow,
    )
    auth = TokenAuthManager(AuthConfig(enabled=True, static_tokens={
        'viewer-token': ControlPlanePrincipal(subject='viewer1', role='viewer'),
        'operator-token': ControlPlanePrincipal(subject='ops1', role='operator'),
        'admin-token': ControlPlanePrincipal(subject='admin1', role='admin'),
    }))
    return TestClient(create_control_plane_app(service, auth))


def test_drill_and_certification_endpoints_flow() -> None:
    client = _client()
    drill = client.post(
        '/drills/run',
        json={'drill_type': 'only_close', 'context': {'only_close_after': True}},
        headers={'Authorization': 'Bearer operator-token'},
    )
    assert drill.status_code == 200
    assert drill.json()['ok'] is True

    cert = client.post(
        '/certification/ingest',
        json={
            'venue': 'binance',
            'credentials_ok': True,
            'public_connectivity_ok': True,
            'private_connectivity_ok': True,
            'balances_ok': True,
            'place_order_ok': True,
            'cancel_order_ok': True,
            'final_status_ok': True,
            'payload': {'mode': 'testnet'},
        },
        headers={'Authorization': 'Bearer operator-token'},
    )
    assert cert.status_code == 200
    assert cert.json()['evidence']['status'] == 'passed'

    ev = client.post(
        '/go-live/evidence',
        json={'strategy': 'alpha', 'checks': {'shadow_pnl_ok': True, 'checklist_ok': True, 'alerts_clear': True}},
        headers={'Authorization': 'Bearer operator-token'},
    )
    assert ev.status_code == 200
    assert ev.json()['evidence']['status'] == 'passed'

    req = client.post(
        '/promotions/request',
        json={'strategy': 'alpha', 'target_stage': 'shadow', 'reason': 'ready', 'checks': {'shadow_pnl_ok': True, 'checklist_ok': True}},
        headers={'Authorization': 'Bearer operator-token'},
    )
    assert req.status_code == 200
    approve = client.post('/promotions/approve', json={'strategy': 'alpha'}, headers={'Authorization': 'Bearer admin-token'})
    assert approve.status_code == 200

    scores = client.get('/go-live/scores?strategy=alpha', headers={'Authorization': 'Bearer viewer-token'})
    assert scores.status_code == 200
    assert scores.json()['score']['strategy'] == 'alpha'
    assert scores.json()['score']['score'] > 0


def test_dashboard_and_risk_dashboard_include_new_sections() -> None:
    client = _client()
    client.post(
        '/drills/run',
        json={'drill_type': 'only_close', 'context': {'only_close_after': True}},
        headers={'Authorization': 'Bearer operator-token'},
    )
    dash = client.get('/dashboard', headers={'Authorization': 'Bearer viewer-token'})
    assert dash.status_code == 200
    assert 'Go-live scores' in dash.text
    assert 'Operator drills' in dash.text

    risk = client.get('/risk/dashboard', headers={'Authorization': 'Bearer viewer-token'})
    data = risk.json()
    assert 'go_live_scores' in data
    assert 'venue_certification' in data
    assert 'drills' in data
