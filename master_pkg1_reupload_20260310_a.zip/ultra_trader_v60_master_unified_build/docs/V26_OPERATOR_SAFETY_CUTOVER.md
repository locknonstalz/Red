
# V26 Operator Safety, Confirmations, Shadow PnL and Live Cutover

## Added
- expiring operator confirmations for risky manual actions
- pending confirmation visibility in dashboard and `/risk/dashboard`
- shadow PnL attribution with unrealized and realized proxy PnL
- safer live cutover workflow docs and checklist

## Confirmation flow
1. request action via `/controls/request/*`
2. receive `confirmation_id`
3. execute via `/controls/confirm/execute`

This is intended for production-style two-step operations such as enabling/disabling global kill, only-close, strategy state changes, or AI toggles when an operator wants an extra safety barrier.

## Shadow PnL
Shadow mode now tracks:
- number of captured orders
- open shadow orders
- unrealized proxy PnL by strategy
- realized proxy PnL when a shadow strategy is manually re-enabled or closed

## Live cutover workflow
Use the script below before moving a strategy from shadow to live:

```bash
python scripts/live_cutover_checklist.py --strategy market_making --venue binance
```

Minimum gate:
- no active global kill
- only-close disabled
- strategy enabled
- no pending critical confirmation older than SLA
- venue health present
- shadow strategy has non-negative proxy PnL over review window
