from alembic import op
import sqlalchemy as sa

revision = '0001_initial'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
    CREATE TABLE IF NOT EXISTS orders (
        client_order_id TEXT PRIMARY KEY,
        strategy TEXT,
        venue TEXT,
        symbol TEXT,
        side TEXT,
        qty DOUBLE PRECISION,
        order_type TEXT,
        limit_price DOUBLE PRECISION,
        status TEXT,
        filled_qty DOUBLE PRECISION DEFAULT 0,
        avg_fill_price DOUBLE PRECISION DEFAULT 0,
        exchange_order_id TEXT,
        exchange_status TEXT,
        ts TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        note TEXT
    )
    """)
    op.execute("""
    CREATE TABLE IF NOT EXISTS fills (
        id BIGSERIAL PRIMARY KEY,
        client_order_id TEXT,
        venue TEXT,
        symbol TEXT,
        side TEXT,
        qty DOUBLE PRECISION,
        price DOUBLE PRECISION,
        fee DOUBLE PRECISION,
        trade_id TEXT,
        exchange_order_id TEXT,
        ts TEXT,
        UNIQUE (venue, trade_id)
    )
    """)
    op.execute("""
    CREATE TABLE IF NOT EXISTS balances (
        venue TEXT,
        asset TEXT,
        free DOUBLE PRECISION,
        locked DOUBLE PRECISION,
        ts TEXT,
        PRIMARY KEY (venue, asset)
    )
    """)
    op.execute("""
    CREATE TABLE IF NOT EXISTS positions (
        venue TEXT,
        symbol TEXT,
        qty DOUBLE PRECISION,
        avg_price DOUBLE PRECISION,
        realized_pnl DOUBLE PRECISION,
        mark_price DOUBLE PRECISION,
        updated_at TIMESTAMP,
        PRIMARY KEY (venue, symbol)
    )
    """)
    op.execute("""
    CREATE TABLE IF NOT EXISTS reconciliation_events (
        venue TEXT,
        event_type TEXT,
        external_id TEXT,
        payload_hash TEXT,
        recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (venue, event_type, external_id)
    )
    """)
    op.execute("""
    CREATE TABLE IF NOT EXISTS dead_letter_queue (
        id BIGSERIAL PRIMARY KEY,
        topic TEXT,
        payload TEXT,
        reason TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)


def downgrade() -> None:
    for table in ['dead_letter_queue', 'reconciliation_events', 'positions', 'balances', 'fills', 'orders']:
        op.execute(f'DROP TABLE IF EXISTS {table}')
