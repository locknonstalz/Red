# Ultra Trader v60 Audit Report

## What was audited

- configuration bootstrap and preflight
- dependency completeness
- paper-mode runtime startup
- micro-live risk envelope for a first `$100` launch
- repository hygiene for redistribution
- full automated test suite

## Critical issues found and fixed

### 1) Preflight/runtime config crash

**Issue:** `LiquidationCascadeSettings` was declared as a plain class instead of a dataclass, but the settings factory instantiated it with keyword arguments.

**Impact:** `scripts/preflight.py` crashed before validating startup readiness.

**Fix:** Converted `LiquidationCascadeSettings` into a dataclass with slots.

### 2) Missing declared dependency

**Issue:** `app.py`, `scripts/preflight.py`, and `scripts/run_exchange_certification.py` import `python-dotenv`, but it was missing from `requirements.txt`.

**Impact:** Fresh environments could fail before startup.

**Fix:** Added `python-dotenv>=1.0` to `requirements.txt`.

### 3) Unsafe credential material inside `.env.example`

**Issue:** Example env file contained hard-coded exchange credential values.

**Impact:** High operational and security risk.

**Fix:** Sanitized `.env.example` so all exchange keys and secrets are blank placeholders.

### 4) Micro-live readiness checks too weak

**Issue:** Preflight validated missing credentials only for `live`, not `micro_live`.

**Impact:** Real-money micro-live could pass validation without required exchange auth or with oversized notional.

**Fix:**
- require credentials in both `live` and `micro_live`
- require persistent storage in both `live` and `micro_live`
- add first-launch hardening rule: `MAX_TOTAL_NOTIONAL <= 100` for `micro_live`

## New launch template added

Added `.env.micro_live_100.example` with a conservative first real-money profile:

- `TRADING_MODE=micro_live`
- total notional capped at `$100`
- per-order notional capped at `$8`
- per-strategy daily loss capped at `$1`
- global daily loss capped at `$2`
- only `funding_carry` enabled for the first launch
- other higher-complexity strategies disabled

## Validation results

### Automated tests

- `103 passed`
- `4 skipped`

### Additional checks

- `python -m compileall` passed
- `python scripts/preflight.py` passed in clean paper-mode smoke config
- `python app.py` paper-mode smoke launch passed

## Remaining operational cautions

These are not code crashes, but still matter before sending real orders:

1. Live exchange credentials still must be reviewed manually by the operator.
2. The first micro-live run should remain on a single strategy until fills, fees, slippage, and reconciliation are verified on the target venues.
3. “Zero-error first launch” cannot be guaranteed without running in the exact target environment, with real venue connectivity, clocks, balances, permissions, and rate limits.

## Recommended first launch sequence

1. Copy `.env.micro_live_100.example` to `.env`
2. Insert real exchange API keys
3. Run `python scripts/preflight.py`
4. Run in paper mode once more if any venue or account settings changed
5. Start micro-live with the `$100` template
6. Review execution quality, incidents, and reconciliation after the first session before scaling

# stage unlock patch applied

## Additional hardening pass
- Added `MICRO_LIVE_MIN_TARGET_NOTIONAL` floor so micro-live budgets do not stall at uneconomic levels.
- Added funding-carry no-trade diagnostics via `strategy_waiting` logs with blocker states.
- Strengthened preflight with budget-floor and strategy-size checks.
