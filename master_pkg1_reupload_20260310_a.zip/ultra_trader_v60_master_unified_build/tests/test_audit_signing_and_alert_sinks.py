import httpx

from control_plane.audit import AuditSigner
from ops.alerts import AlertMessage, GenericWebhookSink, PagerDutyEventsSink, SlackWebhookSink


def test_audit_signer_roundtrip():
    signer = AuditSigner('secret')
    record = signer.sign(actor='alice', action='global_kill_enabled', payload={'enabled': True})
    assert signer.verify(record) is True


def test_slack_and_pagerduty_sinks_send_expected_payloads():
    sent = []

    def handler(request: httpx.Request) -> httpx.Response:
        sent.append((str(request.url), request.content.decode()))
        return httpx.Response(200, json={'ok': True})

    transport = httpx.MockTransport(handler)
    client = httpx.Client(transport=transport)
    msg = AlertMessage(event='global_kill_enabled', severity='critical', summary='manual', payload={'actor': 'alice'})

    SlackWebhookSink('https://hooks.slack.test/services/x', client=client).emit(msg)
    PagerDutyEventsSink('routing-key', client=client).emit(msg)
    GenericWebhookSink('https://hook.test/alerts', client=client).emit(msg)

    assert len(sent) == 3
    assert 'slack.test' in sent[0][0]
    assert 'pagerduty.com' in sent[1][0]
    assert 'hook.test' in sent[2][0]
