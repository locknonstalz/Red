from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


class ModelRegistry:
    def __init__(self, path: str = 'model_registry.json') -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text(json.dumps({'models': []}, indent=2), encoding='utf-8')

    def register(self, name: str, version: str, metrics: dict[str, float], artifact_path: str) -> None:
        payload = json.loads(self.path.read_text(encoding='utf-8'))
        payload['models'].append({
            'name': name,
            'version': version,
            'metrics': metrics,
            'artifact_path': artifact_path,
            'registered_at': datetime.now(timezone.utc).isoformat(),
        })
        self.path.write_text(json.dumps(payload, indent=2), encoding='utf-8')

    def latest(self, name: str) -> dict | None:
        payload = json.loads(self.path.read_text(encoding='utf-8'))
        models = [m for m in payload.get('models', []) if m.get('name') == name]
        return models[-1] if models else None
