from __future__ import annotations

from dataclasses import dataclass

from futures.models import FuturesOrderIntent
from futures.portfolio import FuturesPortfolioService


@dataclass(slots=True)
class FuturesRiskDecision:
    allowed: bool
    reason: str = 'OK'


class FuturesRiskService:
    def __init__(self, portfolio: FuturesPortfolioService, max_leverage: float = 5.0, min_liquidation_distance_bps: float = 250.0) -> None:
        self.portfolio = portfolio
        self.max_leverage = max_leverage
        self.min_liquidation_distance_bps = min_liquidation_distance_bps

    def check_intent(self, intent: FuturesOrderIntent) -> FuturesRiskDecision:
        if intent.leverage > self.max_leverage:
            return FuturesRiskDecision(False, 'leverage_limit')
        position = self.portfolio.get_position(intent.venue, intent.symbol)
        if intent.close_only and position is None:
            return FuturesRiskDecision(False, 'no_position_to_close')
        if position is not None and not intent.reduce_only and position.liquidation_distance_bps < self.min_liquidation_distance_bps:
            return FuturesRiskDecision(False, 'liquidation_distance_too_small')
        return FuturesRiskDecision(True, 'OK')
