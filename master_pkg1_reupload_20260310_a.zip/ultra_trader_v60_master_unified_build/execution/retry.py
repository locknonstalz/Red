from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Awaitable, Callable, TypeVar

T = TypeVar('T')


@dataclass(slots=True)
class RetryPolicy:
    attempts: int = 3
    base_delay: float = 0.25
    retryable_statuses: tuple[int, ...] = (408, 409, 425, 429, 500, 502, 503, 504)


async def retry_async(fn: Callable[[], Awaitable[T]], policy: RetryPolicy) -> T:
    last_exc: Exception | None = None
    for i in range(policy.attempts):
        try:
            return await fn()
        except Exception as exc:
            last_exc = exc
            if i == policy.attempts - 1:
                break
            await asyncio.sleep(policy.base_delay * (2 ** i))
    assert last_exc is not None
    raise last_exc
