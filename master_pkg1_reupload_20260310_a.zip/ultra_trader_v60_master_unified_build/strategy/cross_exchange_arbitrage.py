from __future__ import annotations

from typing import Sequence

from common.models import Side, Signal, Tick
from strategy.base import Strategy


class CrossExchangeArbitrageStrategy(Strategy):
    def __init__(self, name: str, symbol: str, trade_size: float, min_edge_bps: float = 8.0, max_quote_age_ticks: int = 10) -> None:
        self.name = name
        self.symbol = symbol
        self.trade_size = trade_size
        self.min_edge_bps = min_edge_bps
        self.max_quote_age_ticks = max_quote_age_ticks
        self._ticks_seen = 0
        self._latest: dict[str, tuple[int, Tick]] = {}
        self._last_pair: tuple[str, str] | None = None

    def on_tick(self, tick: Tick) -> Sequence[Signal]:
        if tick.symbol != self.symbol:
            return []
        self._ticks_seen += 1
        self._latest[tick.venue] = (self._ticks_seen, tick)
        fresh = {venue: row for venue, row in self._latest.items() if self._ticks_seen - row[0] <= self.max_quote_age_ticks}
        if len(fresh) < 2:
            return []
        cheapest = min(fresh.values(), key=lambda item: item[1].ask)[1]
        richest = max(fresh.values(), key=lambda item: item[1].bid)[1]
        if cheapest.venue == richest.venue:
            return []
        edge = richest.bid - cheapest.ask
        edge_bps = (edge / cheapest.ask) * 10000 if cheapest.ask else 0.0
        pair = (cheapest.venue, richest.venue)
        if edge_bps < self.min_edge_bps or self._last_pair == pair:
            return []
        self._last_pair = pair
        return [
            Signal(self.name, cheapest.venue, self.symbol, Side.BUY, min(edge_bps / max(self.min_edge_bps, 1e-9), 3.0), f"arb_buy_leg_edge_bps={edge_bps:.2f}", qty=self.trade_size, tags={"pair": f"{cheapest.venue}->{richest.venue}"}),
            Signal(self.name, richest.venue, self.symbol, Side.SELL, min(edge_bps / max(self.min_edge_bps, 1e-9), 3.0), f"arb_sell_leg_edge_bps={edge_bps:.2f}", qty=self.trade_size, tags={"pair": f"{cheapest.venue}->{richest.venue}"}),
        ]
