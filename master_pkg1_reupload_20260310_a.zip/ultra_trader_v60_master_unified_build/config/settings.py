from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass(slots=True)
class MarketMakingSettings:
    quote_size: float = 0.01
    min_spread_bps: float = 4.0
    inventory_limit: float = 0.05
    requote_cooldown_ticks: int = 8


@dataclass(slots=True)
class CrossExchangeSettings:
    trade_size: float = 0.01
    min_edge_bps: float = 8.0


@dataclass(slots=True)
class StatisticalArbitrageSettings:
    trade_size: float = 0.01
    window: int = 40
    entry_z: float = 1.8
    exit_z: float = 0.4


@dataclass(slots=True)
class LiquidityTakingSettings:
    trade_size: float = 0.01
    lookback: int = 12
    breakout_bps: float = 6.0
    min_spread_bps: float = 1.5


@dataclass(slots=True)
class FundingCarrySettings:
    trade_size: float = 0.01
    spot_venue: str = 'binance'
    perp_venue: str = 'bybit'
    min_funding_rate: float = 0.00021
    min_basis_bps: float = 4.0
    max_basis_bps: float = 80.0


@dataclass(slots=True)
class LiquidationCascadeSettings:
    trade_size: float = 0.01
    lookback: int = 12
    min_cascade_risk: float = 0.28
    min_liquidation_pressure: float = 0.55
    breakout_bps: float = 7.0


@dataclass(slots=True)
class StrategySettings:
    order_size: float = 0.01
    enable_market_making: bool = True
    enable_cross_exchange_arb: bool = True
    enable_stat_arb: bool = True
    enable_liquidity_taking: bool = True
    enable_momentum: bool = True
    enable_funding_carry: bool = True
    enable_liquidation_cascade: bool = True
    cross_exchange_venues: list[str] = field(default_factory=lambda: ['binance', 'bybit'])
    market_making: MarketMakingSettings = field(default_factory=MarketMakingSettings)
    cross_exchange: CrossExchangeSettings = field(default_factory=CrossExchangeSettings)
    stat_arb: StatisticalArbitrageSettings = field(default_factory=StatisticalArbitrageSettings)
    liquidity_taking: LiquidityTakingSettings = field(default_factory=LiquidityTakingSettings)
    funding_carry: FundingCarrySettings = field(default_factory=FundingCarrySettings)
    liquidation_cascade: LiquidationCascadeSettings = field(default_factory=LiquidationCascadeSettings)


@dataclass(slots=True)
class AISettings:
    enabled: bool = True
    entry_horizon_ticks: int = 8
    min_training_move_bps: float = 2.0
    min_accept_probability: float = 0.53
    strong_probability: float = 0.63
    size_boost: float = 1.5
    size_cut: float = 0.6
    model_path: str = 'ultra_trader_ai_model.json'


@dataclass(slots=True)
class RiskSettings:
    max_order_notional: float = 5000.0
    max_position_abs: float = 0.05
    max_symbol_notional: float = 10000.0
    max_market_data_age_sec: float = 5.0
    kill_switch: bool = False


@dataclass(slots=True)
class DailyLossGuardSettings:
    max_daily_loss: float = 250.0
    lockout_on_breach: bool = True


@dataclass(slots=True)
class DrawdownGovernorSettings:
    reduce_at: float = 250.0
    pause_at: float = 500.0
    kill_at: float = 1000.0
    reduced_size_factor: float = 0.5


@dataclass(slots=True)
class StrategyKillSwitchSettings:
    max_strategy_daily_loss: float = 150.0
    max_consecutive_losses: int = 4


@dataclass(slots=True)
class ProtectionCircuitBreakerSettings:
    max_spread_bps: float = 25.0
    max_volatility_bps: float = 50.0
    max_rejections: int = 5
    cooldown_ticks: int = 12


@dataclass(slots=True)
class PositionProtectionSettings:
    stop_loss_bps: float = 40.0
    trailing_stop_bps: float = 25.0
    take_profit_bps: float = 80.0
    max_holding_ticks: int = 100


@dataclass(slots=True)
class CapitalAllocatorSettings:
    max_total_notional: float = 15000.0
    default_strategy_weight: float = 0.25
    micro_live_min_target_notional: float = 10.0
    strategy_weights: dict[str, float] = field(default_factory=lambda: {
        'market_making': 0.25,
        'cross_exchange_arbitrage': 0.25,
        'statistical_arbitrage': 0.25,
        'liquidity_taking': 0.10,
        'momentum': 0.10,
        'funding_carry': 0.20,
        'liquidation_cascade': 0.10,
    })


@dataclass(slots=True)
class CapitalProtectionSettings:
    enabled: bool = True
    only_close_mode: bool = False
    global_kill_switch: bool = False
    daily_loss: DailyLossGuardSettings = field(default_factory=DailyLossGuardSettings)
    drawdown: DrawdownGovernorSettings = field(default_factory=DrawdownGovernorSettings)
    strategy_kill: StrategyKillSwitchSettings = field(default_factory=StrategyKillSwitchSettings)
    circuit_breaker: ProtectionCircuitBreakerSettings = field(default_factory=ProtectionCircuitBreakerSettings)
    position_protection: PositionProtectionSettings = field(default_factory=PositionProtectionSettings)
    allocator: CapitalAllocatorSettings = field(default_factory=CapitalAllocatorSettings)




@dataclass(slots=True)
class ResearchSettings:
    enabled: bool = True
    min_signal_score: float = 0.45
    universe_min_quality: float = 35.0


@dataclass(slots=True)
class RoutingSettings:
    enabled: bool = True
    strategies: list[str] = field(default_factory=lambda: ['liquidity_taking', 'momentum'])
    health_weight: float = 0.35


@dataclass(slots=True)
class ExecutionTacticsSettings:
    enabled: bool = True
    strategies: list[str] = field(default_factory=lambda: ['liquidity_taking', 'cross_exchange_arbitrage'])
    min_slice_notional: float = 500.0
    default_slices: int = 3
    passive_offset_bps: float = 1.0
    aggressive_cross_bps: float = 2.0


@dataclass(slots=True)
class AdvancedRiskGuardSettings:
    enabled: bool = True
    max_venue_notional: float = 8000.0
    max_symbol_concentration_pct: float = 0.45
    max_correlated_exposure_pct: float = 0.65
    correlation_window: int = 32
    correlation_threshold: float = 0.90


@dataclass(slots=True)
class ShadowDeploymentSettings:
    enabled: bool = False
    strategies: list[str] = field(default_factory=list)


@dataclass(slots=True)
class FuturesSettings:
    enabled: bool = False
    default_leverage: float = 2.0
    max_leverage: float = 5.0
    min_liquidation_distance_bps: float = 250.0
    funding_passive_threshold: float = 0.0005
    basis_aggressive_threshold_bps: float = 8.0


@dataclass(slots=True)
class MLOpsSettings:
    feature_store_path: str = 'feature_store.jsonl'
    model_registry_path: str = 'model_registry.json'
    offline_model_path: str = 'artifacts/offline_model.json'


@dataclass(slots=True)
class DatabaseSettings:
    prefer_postgres: bool = False
    postgres_dsn: str | None = None
    sqlite_path: str = 'ultra_trader_v18.db'


@dataclass(slots=True)
class CircuitBreakerSettings:
    max_consecutive_errors: int = 5
    cooldown_sec: float = 30.0


@dataclass(slots=True)
class OrchestrationSettings:
    reconnect_attempts: int = 5
    reconnect_backoff_sec: float = 0.25
    prometheus_enabled: bool = False
    prometheus_port: int = 9108
    lease_ttl_sec: int = 30
    process_owner: str = 'local-dev'


@dataclass(slots=True)
class VenueCredentials:
    api_key: str = ''
    api_secret: str = ''
    passphrase: str = ''
    testnet: bool = False


@dataclass(slots=True)
class ControlPlaneSettings:
    enabled: bool = False
    host: str = '127.0.0.1'
    port: int = 8080
    auth_enabled: bool = False
    auth_issuer: str = 'ultra-trader'
    auth_secret: str = 'change-me'
    static_tokens_json: str = ''
    audit_secret: str = 'audit-secret'


@dataclass(slots=True)
class AlertingSettings:
    slack_webhook_url: str = ''
    pagerduty_routing_key: str = ''
    generic_webhook_url: str = ''


@dataclass(slots=True)
class Settings:
    log_level: str = 'INFO'
    base_currency: str = 'USDT'
    mode: str = 'paper'
    default_venue: str = 'binance'
    default_symbol: str = 'BTC/USDT'
    live_venues: list[str] = field(default_factory=lambda: ['binance'])
    runtime_seconds: float = 8.0
    strategy: StrategySettings = field(default_factory=StrategySettings)
    ai: AISettings = field(default_factory=AISettings)
    risk: RiskSettings = field(default_factory=RiskSettings)
    capital_protection: CapitalProtectionSettings = field(default_factory=CapitalProtectionSettings)
    database: DatabaseSettings = field(default_factory=DatabaseSettings)
    circuit_breakers: CircuitBreakerSettings = field(default_factory=CircuitBreakerSettings)
    orchestration: OrchestrationSettings = field(default_factory=OrchestrationSettings)
    binance: VenueCredentials = field(default_factory=VenueCredentials)
    bybit: VenueCredentials = field(default_factory=VenueCredentials)
    mexc: VenueCredentials = field(default_factory=VenueCredentials)
    bitget: VenueCredentials = field(default_factory=VenueCredentials)
    control_plane: ControlPlaneSettings = field(default_factory=ControlPlaneSettings)
    alerts: AlertingSettings = field(default_factory=AlertingSettings)
    research: ResearchSettings = field(default_factory=ResearchSettings)
    routing: RoutingSettings = field(default_factory=RoutingSettings)
    execution_tactics: ExecutionTacticsSettings = field(default_factory=ExecutionTacticsSettings)
    advanced_risk: AdvancedRiskGuardSettings = field(default_factory=AdvancedRiskGuardSettings)
    shadow: ShadowDeploymentSettings = field(default_factory=ShadowDeploymentSettings)
    futures: FuturesSettings = field(default_factory=FuturesSettings)
    mlops: MLOpsSettings = field(default_factory=MLOpsSettings)


ALLOWED_VENUES = {'binance', 'bybit', 'mexc', 'bitget'}


def _creds(prefix: str) -> VenueCredentials:
    return VenueCredentials(
        api_key=os.getenv(f'{prefix}_API_KEY', ''),
        api_secret=os.getenv(f'{prefix}_API_SECRET', ''),
        passphrase=os.getenv(f'{prefix}_API_PASSPHRASE', ''),
        testnet=os.getenv(f'{prefix}_TESTNET', '0') == '1',
    )


def _split_csv(name: str, default: str) -> list[str]:
    raw = os.getenv(name, default)
    return [part.strip().lower() for part in raw.split(',') if part.strip()]


def get_settings() -> Settings:
    live_venues = _split_csv('LIVE_VENUES', os.getenv('DEFAULT_VENUE', 'binance'))
    live_venues = [venue for venue in live_venues if venue in ALLOWED_VENUES] or ['binance']
    return Settings(
        log_level=os.getenv('LOG_LEVEL', 'INFO'),
        base_currency=os.getenv('BASE_CURRENCY', 'USDT'),
        mode=os.getenv('TRADING_MODE', 'paper'),
        default_venue=os.getenv('DEFAULT_VENUE', 'binance').lower(),
        default_symbol=os.getenv('DEFAULT_SYMBOL', 'BTC/USDT'),
        live_venues=live_venues,
        runtime_seconds=float(os.getenv('RUNTIME_SECONDS', '8.0')),
        strategy=StrategySettings(
    order_size=float(os.getenv('ORDER_SIZE', '0.01')),
    enable_market_making=os.getenv('ENABLE_MARKET_MAKING', '1') == '1',
    enable_cross_exchange_arb=os.getenv('ENABLE_CROSS_EXCHANGE_ARB', '1') == '1',
    enable_stat_arb=os.getenv('ENABLE_STAT_ARB', '1') == '1',
    enable_liquidity_taking=os.getenv('ENABLE_LIQUIDITY_TAKING', '1') == '1',
    enable_momentum=os.getenv('ENABLE_MOMENTUM', '1') == '1',
    enable_funding_carry=os.getenv('ENABLE_FUNDING_CARRY', '1') == '1',
    enable_liquidation_cascade=os.getenv('ENABLE_LIQUIDATION_CASCADE', '0') == '1',
    cross_exchange_venues=_split_csv('CROSS_EXCHANGE_VENUES', 'binance,bybit'),
    market_making=MarketMakingSettings(
        quote_size=float(os.getenv('MM_QUOTE_SIZE', '0.01')),
        min_spread_bps=float(os.getenv('MM_MIN_SPREAD_BPS', '4.0')),
        inventory_limit=float(os.getenv('MM_INVENTORY_LIMIT', '0.05')),
        requote_cooldown_ticks=int(os.getenv('MM_REQUOTE_COOLDOWN_TICKS', '8')),
    ),
    cross_exchange=CrossExchangeSettings(
        trade_size=float(os.getenv('ARB_TRADE_SIZE', '0.01')),
        min_edge_bps=float(os.getenv('ARB_MIN_EDGE_BPS', '8.0')),
    ),
    stat_arb=StatisticalArbitrageSettings(
        trade_size=float(os.getenv('STAT_ARB_TRADE_SIZE', '0.01')),
        window=int(os.getenv('STAT_ARB_WINDOW', '40')),
        entry_z=float(os.getenv('STAT_ARB_ENTRY_Z', '1.8')),
        exit_z=float(os.getenv('STAT_ARB_EXIT_Z', '0.4')),
    ),
    liquidity_taking=LiquidityTakingSettings(
        trade_size=float(os.getenv('LT_TRADE_SIZE', '0.01')),
        lookback=int(os.getenv('LT_LOOKBACK', '12')),
        breakout_bps=float(os.getenv('LT_BREAKOUT_BPS', '6.0')),
        min_spread_bps=float(os.getenv('LT_MIN_SPREAD_BPS', '1.5')),
    ),
    funding_carry=FundingCarrySettings(
        trade_size=float(os.getenv('FUNDING_CARRY_TRADE_SIZE', '0.001')),
        spot_venue=os.getenv('FUNDING_CARRY_SPOT_VENUE', 'binance'),
        perp_venue=os.getenv('FUNDING_CARRY_PERP_VENUE', 'bybit'),
        min_funding_rate=float(os.getenv('FUNDING_CARRY_MIN_FUNDING_RATE', '0.0002')),
        min_basis_bps=float(os.getenv('FUNDING_CARRY_MIN_BASIS_BPS', '4.0')),
        max_basis_bps=float(os.getenv('FUNDING_CARRY_MAX_BASIS_BPS', '80.0')),
    ),
    liquidation_cascade=LiquidationCascadeSettings(
        trade_size=float(os.getenv('LIQ_CASCADE_TRADE_SIZE', '0.001')),
        lookback=int(os.getenv('LIQ_CASCADE_LOOKBACK', '12')),
        min_cascade_risk=float(os.getenv('LIQ_CASCADE_MIN_CASCADE_RISK', '0.28')),
        min_liquidation_pressure=float(os.getenv('LIQ_CASCADE_MIN_LIQ_PRESSURE', '0.55')),
        breakout_bps=float(os.getenv('LIQ_CASCADE_BREAKOUT_BPS', '7.0')),
    ),
),
        ai=AISettings(
            enabled=os.getenv('AI_ENABLED', '1') == '1',
            entry_horizon_ticks=int(os.getenv('AI_ENTRY_HORIZON_TICKS', '8')),
            min_training_move_bps=float(os.getenv('AI_MIN_TRAINING_MOVE_BPS', '2.0')),
            min_accept_probability=float(os.getenv('AI_MIN_ACCEPT_PROBABILITY', '0.53')),
            strong_probability=float(os.getenv('AI_STRONG_PROBABILITY', '0.63')),
            size_boost=float(os.getenv('AI_SIZE_BOOST', '1.5')),
            size_cut=float(os.getenv('AI_SIZE_CUT', '0.6')),
            model_path=os.getenv('AI_MODEL_PATH', 'ultra_trader_ai_model.json'),
        ),
        risk=RiskSettings(
            max_order_notional=float(os.getenv('MAX_ORDER_NOTIONAL', '5000')),
            max_position_abs=float(os.getenv('MAX_POSITION_ABS', '0.05')),
            max_symbol_notional=float(os.getenv('MAX_SYMBOL_NOTIONAL', '10000')),
            max_market_data_age_sec=float(os.getenv('MAX_MARKET_DATA_AGE_SEC', '5')),
            kill_switch=os.getenv('KILL_SWITCH', '0') == '1',
        ),
        capital_protection=CapitalProtectionSettings(
            enabled=os.getenv('CAPITAL_PROTECTION_ENABLED', '1') == '1',
            only_close_mode=os.getenv('ONLY_CLOSE_MODE', '0') == '1',
            global_kill_switch=os.getenv('GLOBAL_KILL_SWITCH', '0') == '1',
            daily_loss=DailyLossGuardSettings(
                max_daily_loss=float(os.getenv('MAX_DAILY_LOSS', '250.0')),
                lockout_on_breach=os.getenv('LOCKOUT_ON_BREACH', '1') == '1',
            ),
            drawdown=DrawdownGovernorSettings(
                reduce_at=float(os.getenv('DRAWDOWN_REDUCE_AT', '250.0')),
                pause_at=float(os.getenv('DRAWDOWN_PAUSE_AT', '500.0')),
                kill_at=float(os.getenv('DRAWDOWN_KILL_AT', '1000.0')),
                reduced_size_factor=float(os.getenv('DRAWDOWN_REDUCED_SIZE_FACTOR', '0.5')),
            ),
            strategy_kill=StrategyKillSwitchSettings(
                max_strategy_daily_loss=float(os.getenv('MAX_STRATEGY_DAILY_LOSS', '150.0')),
                max_consecutive_losses=int(os.getenv('MAX_STRATEGY_CONSECUTIVE_LOSSES', '4')),
            ),
            circuit_breaker=ProtectionCircuitBreakerSettings(
                max_spread_bps=float(os.getenv('MAX_SPREAD_BPS', '25.0')),
                max_volatility_bps=float(os.getenv('MAX_VOLATILITY_BPS', '50.0')),
                max_rejections=int(os.getenv('MAX_REJECTIONS', '5')),
                cooldown_ticks=int(os.getenv('PROTECTION_COOLDOWN_TICKS', '12')),
            ),
            position_protection=PositionProtectionSettings(
                stop_loss_bps=float(os.getenv('STOP_LOSS_BPS', '40.0')),
                trailing_stop_bps=float(os.getenv('TRAILING_STOP_BPS', '25.0')),
                take_profit_bps=float(os.getenv('TAKE_PROFIT_BPS', '80.0')),
                max_holding_ticks=int(os.getenv('MAX_HOLDING_TICKS', '100')),
            ),
            allocator=CapitalAllocatorSettings(
                max_total_notional=float(os.getenv('MAX_TOTAL_NOTIONAL', '15000.0')),
                default_strategy_weight=float(os.getenv('DEFAULT_STRATEGY_WEIGHT', '0.25')),
                micro_live_min_target_notional=float(os.getenv('MICRO_LIVE_MIN_TARGET_NOTIONAL', '10.0')),
            ),
        ),
        database=DatabaseSettings(
            prefer_postgres=os.getenv('PREFER_POSTGRES', '0') == '1',
            postgres_dsn=os.getenv('DATABASE_URL'),
            sqlite_path=os.getenv('SQLITE_PATH', 'ultra_trader_v18.db'),
        ),
        circuit_breakers=CircuitBreakerSettings(
            max_consecutive_errors=int(os.getenv('MAX_CONSECUTIVE_ERRORS', '5')),
            cooldown_sec=float(os.getenv('CIRCUIT_BREAKER_COOLDOWN_SEC', '30.0')),
        ),
        orchestration=OrchestrationSettings(
            reconnect_attempts=int(os.getenv('PRIVATE_STREAM_RECONNECT_ATTEMPTS', '5')),
            reconnect_backoff_sec=float(os.getenv('PRIVATE_STREAM_RECONNECT_BACKOFF_SEC', '0.25')),
            prometheus_enabled=os.getenv('PROMETHEUS_ENABLED', '0') == '1',
            prometheus_port=int(os.getenv('PROMETHEUS_PORT', '9108')),
            lease_ttl_sec=int(os.getenv('ORCHESTRATION_LEASE_TTL_SEC', '30')),
            process_owner=os.getenv('PROCESS_OWNER', 'local-dev'),
        ),
        binance=_creds('BINANCE'),
        bybit=_creds('BYBIT'),
        mexc=_creds('MEXC'),
        bitget=_creds('BITGET'),
        control_plane=ControlPlaneSettings(
            enabled=os.getenv('CONTROL_PLANE_ENABLED', '0') == '1',
            host=os.getenv('CONTROL_PLANE_HOST', '127.0.0.1'),
            port=int(os.getenv('CONTROL_PLANE_PORT', '8080')),
            auth_enabled=os.getenv('CONTROL_PLANE_AUTH_ENABLED', '0') == '1',
            auth_issuer=os.getenv('CONTROL_PLANE_AUTH_ISSUER', 'ultra-trader'),
            auth_secret=os.getenv('CONTROL_PLANE_AUTH_SECRET', 'change-me'),
            static_tokens_json=os.getenv('CONTROL_PLANE_STATIC_TOKENS_JSON', ''),
            audit_secret=os.getenv('CONTROL_PLANE_AUDIT_SECRET', 'audit-secret'),
        ),
        alerts=AlertingSettings(
            slack_webhook_url=os.getenv('SLACK_WEBHOOK_URL', ''),
            pagerduty_routing_key=os.getenv('PAGERDUTY_ROUTING_KEY', ''),
            generic_webhook_url=os.getenv('ALERT_WEBHOOK_URL', ''),
        ),
        research=ResearchSettings(
            enabled=os.getenv('RESEARCH_ENABLED', '1') == '1',
            min_signal_score=float(os.getenv('RESEARCH_MIN_SIGNAL_SCORE', '0.45')),
            universe_min_quality=float(os.getenv('RESEARCH_UNIVERSE_MIN_QUALITY', '35.0')),
        ),
        routing=RoutingSettings(
            enabled=os.getenv('SMART_ROUTING_ENABLED', '1') == '1',
            strategies=_split_csv('SMART_ROUTING_STRATEGIES', 'liquidity_taking,momentum'),
            health_weight=float(os.getenv('SMART_ROUTING_HEALTH_WEIGHT', '0.35')),
        ),
        execution_tactics=ExecutionTacticsSettings(
            enabled=os.getenv('EXECUTION_TACTICS_ENABLED', '1') == '1',
            strategies=_split_csv('EXECUTION_TACTICS_STRATEGIES', 'liquidity_taking,cross_exchange_arbitrage'),
            min_slice_notional=float(os.getenv('EXECUTION_TACTICS_MIN_SLICE_NOTIONAL', '500.0')),
            default_slices=int(os.getenv('EXECUTION_TACTICS_DEFAULT_SLICES', '3')),
            passive_offset_bps=float(os.getenv('EXECUTION_TACTICS_PASSIVE_OFFSET_BPS', '1.0')),
            aggressive_cross_bps=float(os.getenv('EXECUTION_TACTICS_AGGRESSIVE_CROSS_BPS', '2.0')),
        ),
        advanced_risk=AdvancedRiskGuardSettings(
            enabled=os.getenv('ADVANCED_RISK_ENABLED', '1') == '1',
            max_venue_notional=float(os.getenv('MAX_VENUE_NOTIONAL', '8000.0')),
            max_symbol_concentration_pct=float(os.getenv('MAX_SYMBOL_CONCENTRATION_PCT', '0.45')),
            max_correlated_exposure_pct=float(os.getenv('MAX_CORRELATED_EXPOSURE_PCT', '0.65')),
            correlation_window=int(os.getenv('CORRELATION_WINDOW', '32')),
            correlation_threshold=float(os.getenv('CORRELATION_THRESHOLD', '0.90')),
        ),
        shadow=ShadowDeploymentSettings(
            enabled=os.getenv('SHADOW_ENABLED', '0') == '1',
            strategies=_split_csv('SHADOW_STRATEGIES', ''),
        ),
        futures=FuturesSettings(
            enabled=os.getenv('FUTURES_ENABLED', '0') == '1',
            default_leverage=float(os.getenv('FUTURES_DEFAULT_LEVERAGE', '2.0')),
            max_leverage=float(os.getenv('FUTURES_MAX_LEVERAGE', '5.0')),
            min_liquidation_distance_bps=float(os.getenv('FUTURES_MIN_LIQUIDATION_DISTANCE_BPS', '250.0')),
            funding_passive_threshold=float(os.getenv('FUTURES_FUNDING_PASSIVE_THRESHOLD', '0.0005')),
            basis_aggressive_threshold_bps=float(os.getenv('FUTURES_BASIS_AGGRESSIVE_THRESHOLD_BPS', '8.0')),
        ),
    )
