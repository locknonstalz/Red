from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict

@dataclass
class StrategyCosts:
    gross_pnl: float = 0.0
    fees: float = 0.0
    slippage_cost: float = 0.0
    funding_drag: float = 0.0
    hedge_cost: float = 0.0

    @property
    def net_pnl(self) -> float:
        return self.gross_pnl - self.fees - self.slippage_cost - self.funding_drag - self.hedge_cost


def make_scorecard(strategy: str, venue: str, costs: StrategyCosts, adverse_fill_rate: float, capacity_score: float) -> Dict[str, float | str]:
    recommendation = "hold"
    if costs.net_pnl > 0 and adverse_fill_rate < 0.2 and capacity_score > 0.6:
        recommendation = "scale_gradually"
    elif costs.net_pnl <= 0:
        recommendation = "do_not_scale"
    return {
        "strategy": strategy,
        "venue": venue,
        **asdict(costs),
        "net_pnl": costs.net_pnl,
        "adverse_fill_rate": adverse_fill_rate,
        "capacity_score": capacity_score,
        "recommendation": recommendation,
    }
