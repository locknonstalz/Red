from __future__ import annotations

import asyncio
import hashlib
import json
from dataclasses import dataclass
from typing import Any

from common.bus import EventBus
from common.models import Balance, Fill, OrderStatus, OrderUpdate, Position
from execution.circuit_breakers import CircuitBreaker
from execution.live.private_streams import BinancePrivateStreamAdapter, BitgetPrivateStreamAdapter, BybitPrivateStreamAdapter, MexcPrivateStreamAdapter
from execution.live.session_choreography import LeaseCoordinator, VenueSessionChoreographer
from execution.live.stateful_session import ReconnectPolicy, StatefulSessionManager
from execution.live.ws_sessions import BasePrivateWsSession
from ops.dead_letter import DeadLetterQueue
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.base import Journal


TERMINAL_STATUSES = {'filled': OrderStatus.FILLED, 'cancelled': OrderStatus.CANCELLED, 'canceled': OrderStatus.CANCELLED, 'rejected': OrderStatus.REJECTED}
ACTIVE_STATUSES = {'new': OrderStatus.NEW, 'open': OrderStatus.ACCEPTED, 'accepted': OrderStatus.ACCEPTED, 'partially_filled': OrderStatus.PARTIALLY_FILLED, 'partial-fill': OrderStatus.PARTIALLY_FILLED, 'partiallyfilled': OrderStatus.PARTIALLY_FILLED, 'partiallyfilledcancelled': OrderStatus.CANCELLED, 'amended': OrderStatus.ACCEPTED, 'updated': OrderStatus.ACCEPTED}


@dataclass(slots=True)
class OrchestrationStats:
    sessions_started: int = 0
    messages_processed: int = 0
    fills_applied: int = 0
    balances_synced: int = 0
    positions_synced: int = 0
    order_updates_applied: int = 0


class LiveOrchestrationService:
    def __init__(self, *, sessions: dict[str, BasePrivateWsSession], journal: Journal, portfolio: PortfolioService, metrics: MetricsRegistry, bus: EventBus | None = None, dlq: DeadLetterQueue | None = None, circuit_breaker: CircuitBreaker | None = None, reconnect_policy: ReconnectPolicy | None = None, lease_owner: str = 'local-dev', lease_ttl_sec: int = 30) -> None:
        self.sessions = sessions
        self.journal = journal
        self.portfolio = portfolio
        self.metrics = metrics
        self.bus = bus or EventBus()
        self.dlq = dlq or DeadLetterQueue(journal)
        self.circuit_breaker = circuit_breaker or CircuitBreaker(max_failures=5, cooldown_sec=30.0)
        self.reconnect_policy = reconnect_policy or ReconnectPolicy(max_attempts=5, backoff_sec=0.25)
        self.lease = LeaseCoordinator(journal, owner=lease_owner, ttl_sec=lease_ttl_sec)
        self.stats = OrchestrationStats()
        self._adapters = {'binance': BinancePrivateStreamAdapter(), 'bybit': BybitPrivateStreamAdapter(), 'mexc': MexcPrivateStreamAdapter(), 'bitget': BitgetPrivateStreamAdapter()}
        self._plans = VenueSessionChoreographer()

    def _payload_hash(self, payload: dict[str, Any]) -> str:
        return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()

    def _mark_seen(self, venue: str, event_type: str, external_id: str, payload: dict[str, Any]) -> bool:
        if self.journal.seen_reconciliation_event(venue, event_type, external_id):
            self.metrics.increment('orchestration_duplicate_events_total')
            return False
        self.journal.record_reconciliation_event(venue, event_type, external_id, self._payload_hash(payload))
        return True

    async def _apply_fill(self, fill: Fill, raw: dict[str, Any]) -> None:
        external_id = fill.trade_id or f'{fill.exchange_order_id}:{fill.client_order_id}:{fill.ts.isoformat()}'
        if not self._mark_seen(fill.venue, 'fill', external_id, raw):
            return
        self.journal.record_fill(fill)
        self.portfolio.apply_fill(fill)
        self.stats.fills_applied += 1
        self.metrics.increment('orchestration_fills_total')
        await self.bus.publish('fills', fill)
        if fill.client_order_id:
            self.journal.update_order_status(fill.client_order_id, OrderStatus.FILLED, note='private_stream_fill')

    def _apply_balance(self, balance: Balance, raw: dict[str, Any]) -> None:
        external_id = balance.asset
        if not self._mark_seen(balance.venue, 'balance', external_id, raw):
            return
        self.portfolio.sync_balance(balance)
        self.journal.save_balance_snapshot(balance)
        self.stats.balances_synced += 1
        self.metrics.increment('orchestration_balances_total')

    def _apply_position(self, position: Position, raw: dict[str, Any]) -> None:
        external_id = position.symbol
        if not self._mark_seen(position.venue, 'position', external_id, raw):
            return
        self.portfolio.sync_position(position)
        self.journal.save_position_snapshot(position)
        self.stats.positions_synced += 1
        self.metrics.increment('orchestration_positions_total')

    def _map_status(self, status: str) -> OrderStatus:
        key = status.lower().replace(' ', '_')
        if key in TERMINAL_STATUSES:
            return TERMINAL_STATUSES[key]
        return ACTIVE_STATUSES.get(key, OrderStatus.ACCEPTED)

    def _apply_order_update(self, update: OrderUpdate) -> None:
        external_id = update.exchange_order_id or update.client_order_id
        if not external_id:
            return
        if not self._mark_seen(update.venue, 'order_update', external_id + ':' + update.status + ':' + str(update.filled_qty), update.raw):
            return
        mapped = self._map_status(update.status)
        note = f'private_stream_status={update.status}'
        if 'cancel' in update.status.lower():
            note = f'cancel_truth={update.status}'
        if 'amend' in update.status.lower() or 'replace' in update.status.lower() or 'update' in update.status.lower():
            note = f'amend_truth={update.status}'
        self.journal.update_order_status(update.client_order_id, mapped, note=note)
        self.stats.order_updates_applied += 1
        self.metrics.increment('orchestration_order_updates_total')

    async def _dispatch(self, venue: str, payload: dict[str, Any]) -> None:
        if 'recovery' in payload:
            self.metrics.increment('orchestration_recovery_messages_total')
            return
        adapter = self._adapters[venue]
        self.stats.messages_processed += 1
        self.metrics.increment('orchestration_messages_total')
        if venue == 'binance':
            order_update = adapter.parse_order_update(payload)
            if order_update:
                self._apply_order_update(order_update)
            fill = adapter.parse_execution(payload)
            if fill:
                await self._apply_fill(fill, payload)
            for balance in adapter.parse_balance(payload):
                self._apply_balance(balance, payload)
            return
        if venue == 'bybit':
            for update in adapter.parse_order(payload):
                self._apply_order_update(update)
            for fill in adapter.parse_execution(payload):
                await self._apply_fill(fill, payload)
            for balance in adapter.parse_wallet(payload):
                self._apply_balance(balance, payload)
            return
        if venue == 'mexc':
            order_update = adapter.parse_order_update(payload)
            if order_update:
                self._apply_order_update(order_update)
            fill = adapter.parse_orders(payload)
            if fill:
                await self._apply_fill(fill, payload)
            return
        if venue == 'bitget':
            for update in adapter.parse_order(payload):
                self._apply_order_update(update)
            for balance in adapter.parse_account(payload):
                self._apply_balance(balance, payload)
            return

    async def _run_session(self, venue: str, session: BasePrivateWsSession) -> None:
        checkpoint = self.journal.load_stream_checkpoint(venue, session.channel)
        plan = self._plans.build(venue, checkpoint, getattr(session, 'symbol', None))
        self.metrics.increment(f'{venue}_recovery_requests_total', len(plan.recovery))
        manager = StatefulSessionManager(venue, session, self.journal, self.metrics, self.reconnect_policy)
        async for message in manager.stream():
            self.lease.renew(f'private-stream:{venue}')
            await self._dispatch(venue, message.payload)

    async def run(self) -> None:
        async with asyncio.TaskGroup() as tg:
            for venue, session in self.sessions.items():
                self.stats.sessions_started += 1
                tg.create_task(self._guarded_session(venue, session), name=f'private-ws-{venue}')

    async def _guarded_session(self, venue: str, session: BasePrivateWsSession) -> None:
        lease_name = f'private-stream:{venue}'
        if not self.lease.acquire(lease_name):
            self.metrics.increment('orchestration_failover_standby_total')
            return
        if not self.circuit_breaker.allow():
            self.metrics.increment('orchestration_circuit_open_total')
            return
        try:
            await self._run_session(venue, session)
            self.circuit_breaker.on_success()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.circuit_breaker.on_failure()
            self.metrics.increment('orchestration_failures_total')
            self.dlq.push('private_ws', venue, str(exc))
            raise
        finally:
            self.lease.release(lease_name)

    async def stop(self) -> None:
        await asyncio.gather(*(session.stop() for session in self.sessions.values()), return_exceptions=True)
