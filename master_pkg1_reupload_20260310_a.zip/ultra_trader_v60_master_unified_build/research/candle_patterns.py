from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from common.models import Tick


@dataclass(slots=True)
class Candle:
    open: float
    high: float
    low: float
    close: float


class CandlePatternEngine:
    def __init__(self, bucket_size: int = 5) -> None:
        self.bucket_size = max(bucket_size, 2)
        self._buffers: dict[tuple[str, str], list[float]] = defaultdict(list)
        self._candles: dict[tuple[str, str], list[Candle]] = defaultdict(list)

    def observe_tick(self, tick: Tick) -> None:
        key = (tick.venue, tick.symbol)
        buf = self._buffers[key]
        buf.append(float(tick.mid))
        if len(buf) >= self.bucket_size:
            candle = Candle(open=buf[0], high=max(buf), low=min(buf), close=buf[-1])
            self._candles[key].append(candle)
            self._candles[key] = self._candles[key][-16:]
            buf.clear()

    def latest_patterns(self, venue: str, symbol: str) -> set[str]:
        candles = self._candles.get((venue, symbol), [])
        patterns: set[str] = set()
        if not candles:
            return patterns
        last = candles[-1]
        body = abs(last.close - last.open)
        full = max(last.high - last.low, 1e-9)
        upper = last.high - max(last.close, last.open)
        lower = min(last.close, last.open) - last.low
        if body / full < 0.15:
            patterns.add('doji')
        if lower > body * 2 and upper < body:
            patterns.add('hammer')
        if upper > body * 2 and lower < body:
            patterns.add('shooting_star')
        if len(candles) >= 2:
            prev = candles[-2]
            prev_low = min(prev.open, prev.close)
            prev_high = max(prev.open, prev.close)
            curr_low = min(last.open, last.close)
            curr_high = max(last.open, last.close)
            if last.close > last.open and curr_low <= prev_low and curr_high >= prev_high:
                patterns.add('bullish_engulfing')
            if last.close < last.open and curr_low <= prev_low and curr_high >= prev_high:
                patterns.add('bearish_engulfing')
            if last.high > prev.high and last.low > prev.low and last.close > prev.close:
                patterns.add('breakout_up')
            if last.low < prev.low and last.high < prev.high and last.close < prev.close:
                patterns.add('breakout_down')
        return patterns
