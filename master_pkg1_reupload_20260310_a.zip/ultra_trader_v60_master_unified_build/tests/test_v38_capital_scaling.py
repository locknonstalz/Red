from __future__ import annotations

from common.models import Fill, Side
from capital.protection import CapitalProtectionService
from capital.scaling import CapitalScalingEngine
from control_plane.service import ControlPlaneService
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from research.alpha_governance import AlphaGovernanceService
from research.alpha_lab import AlphaLabService
from research.attribution import StrategyAttributionService
from research.capacity import CapacityScoringService
from research.venue_health import VenueHealthScoringService
from execution.quality import ExecutionQualityAttributionService
from config.settings import CapitalProtectionSettings
from live_validation.validation import LiveValidationService
from storage.journal import SqliteJournal
from datetime import datetime, timezone


class _ProfitabilityStub:
    class R:
        profitability_score = 75.0
        recommendation = 'scale_gradually'
    def assess(self, strategy: str, venue: str, symbol: str):
        return self.R()




class _AssetSnapshot:
    def __init__(self) -> None:
        self.quality_score = 80.0
        self.spread_bps = 5.0
        self.liquidity_score = 75.0
        self.volatility_score = 60.0


class _AssetAnalysisStub:
    def snapshot(self, venue: str, symbol: str):
        return _AssetSnapshot()


def _promote(promotions, target: str):
    order = ['shadow', 'paper', 'micro_live', 'live']
    for stage in order:
        promotions.request_promotion(strategy='momentum', target_stage=stage, checks={'a': True}, actor='tester', reason='ok')
        promotions.approve('momentum', actor='admin')
        if stage == target:
            return


def _build_stack():
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    protection = CapitalProtectionService(settings=CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    attribution = StrategyAttributionService()
    execution_quality = ExecutionQualityAttributionService()
    venue_health = VenueHealthScoringService()
    capacity = CapacityScoringService(asset_analysis=_AssetAnalysisStub(), execution_quality=execution_quality, venue_health=venue_health)
    alpha_lab = AlphaLabService(profitability=_ProfitabilityStub(), attribution=attribution)
    service = ControlPlaneService(capital_protection=protection, portfolio=portfolio, metrics=metrics, journal=journal)
    governance = AlphaGovernanceService(alpha_lab=alpha_lab, promotions=service.promotions, go_live=service.go_live)
    live_validation = LiveValidationService(portfolio=portfolio, execution_quality=execution_quality, alerts=service.alert_inbox, incidents=service.incidents)
    scaling = CapitalScalingEngine(portfolio=portfolio, protection=protection, governance=governance, live_validation=live_validation, attribution=attribution, capacity=capacity)
    service.alpha_lab = alpha_lab
    service.alpha_governance = governance
    service.live_validation = live_validation
    service.capital_scaling = scaling
    return service, governance, scaling, attribution


def test_capital_scaling_blocks_on_global_kill():
    _, governance, scaling, _ = _build_stack()
    _promote(governance.promotions, 'live')
    scaling.protection.trigger_global_kill('test')
    budget = scaling.budget_for('momentum', 'binance', 'BTCUSDT')
    assert budget.action == 'block'
    assert budget.target_notional == 0.0


def test_capital_scaling_snapshot_contains_budgets():
    _, governance, scaling, attribution = _build_stack()
    _promote(governance.promotions, 'micro_live')
    attribution.observe_fill(Fill(client_order_id='1', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0, price=100.0, fee=0.01, strategy='momentum', ts=datetime.now(timezone.utc)))
    attribution.observe_fill(Fill(client_order_id='1', venue='binance', symbol='BTCUSDT', side=Side.SELL, qty=1.0, price=101.0, fee=0.01, strategy='momentum', ts=datetime.now(timezone.utc)))
    snap = scaling.snapshot(['momentum'], 'binance', 'BTCUSDT').as_dict()
    assert snap['deployable_notional'] > 0
    assert snap['budgets'][0]['strategy'] == 'momentum'


def test_control_plane_snapshot_exposes_capital_scaling():
    service, governance, _, _ = _build_stack()
    _promote(governance.promotions, 'paper')
    snap = service.snapshot()
    assert 'budgets' in snap.capital_scaling



def test_micro_live_budget_floor_applies():
    _, governance, scaling, _ = _build_stack()
    _promote(governance.promotions, 'micro_live')
    scaling.micro_live_min_target_notional = 10.0
    budget = scaling.budget_for('momentum', 'binance', 'BTCUSDT')
    assert budget.target_notional >= 10.0
    assert budget.reason in {'micro_live_budget_floor', 'micro_live_budget'}
