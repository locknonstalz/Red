from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from common.models import Balance, OrderUpdate, Position, StreamCheckpoint


@dataclass(slots=True)
class RecoveryRequest:
    method: str
    path: str
    params: dict[str, Any]


@dataclass(slots=True)
class RecoveryResult:
    venue: str
    orders: list[OrderUpdate]
    balances: list[Balance]
    positions: list[Position]
    source: str
    checkpoint: str = ''


class BaseRecoveryEngine:
    venue: str = 'base'

    def build_requests(self, checkpoint: StreamCheckpoint | None, symbol: str | None = None) -> list[RecoveryRequest]:
        raise NotImplementedError

    def replay_window_start(self, checkpoint: StreamCheckpoint | None) -> str:
        if checkpoint and checkpoint.checkpoint:
            return checkpoint.checkpoint
        return 'latest'


class BinanceRecoveryEngine(BaseRecoveryEngine):
    venue = 'binance'

    def build_requests(self, checkpoint: StreamCheckpoint | None, symbol: str | None = None) -> list[RecoveryRequest]:
        params = {'symbol': symbol or 'ALL'}
        if checkpoint and checkpoint.sequence is not None:
            params['fromExecutionId'] = checkpoint.sequence
        return [
            RecoveryRequest('GET', '/api/v3/openOrders', {'symbol': symbol} if symbol else {}),
            RecoveryRequest('GET', '/api/v3/account', {}),
            RecoveryRequest('GET', '/api/v3/myTrades', params),
        ]


class BybitRecoveryEngine(BaseRecoveryEngine):
    venue = 'bybit'

    def build_requests(self, checkpoint: StreamCheckpoint | None, symbol: str | None = None) -> list[RecoveryRequest]:
        cursor = checkpoint.checkpoint if checkpoint else ''
        return [
            RecoveryRequest('GET', '/v5/order/realtime', {'category': 'spot', 'symbol': symbol} if symbol else {'category': 'spot'}),
            RecoveryRequest('GET', '/v5/account/wallet-balance', {'accountType': 'UNIFIED'}),
            RecoveryRequest('GET', '/v5/execution/list', {'category': 'spot', 'symbol': symbol, 'cursor': cursor} if symbol else {'category': 'spot', 'cursor': cursor}),
        ]


class MexcRecoveryEngine(BaseRecoveryEngine):
    venue = 'mexc'

    def build_requests(self, checkpoint: StreamCheckpoint | None, symbol: str | None = None) -> list[RecoveryRequest]:
        params = {'symbol': symbol.replace('/', '') if symbol else 'BTCUSDT'}
        if checkpoint and checkpoint.sequence is not None:
            params['fromId'] = checkpoint.sequence
        return [
            RecoveryRequest('GET', '/api/v3/openOrders', {'symbol': params['symbol']}),
            RecoveryRequest('GET', '/api/v3/account', {}),
            RecoveryRequest('GET', '/api/v3/myTrades', params),
        ]


class BitgetRecoveryEngine(BaseRecoveryEngine):
    venue = 'bitget'

    def build_requests(self, checkpoint: StreamCheckpoint | None, symbol: str | None = None) -> list[RecoveryRequest]:
        inst = (symbol or 'BTCUSDT').replace('/', '')
        params = {'symbol': inst}
        if checkpoint and checkpoint.sequence is not None:
            params['idLessThan'] = checkpoint.sequence
        return [
            RecoveryRequest('GET', '/api/v2/spot/trade/unfilled-orders', {'symbol': inst}),
            RecoveryRequest('GET', '/api/v2/spot/account/assets', {}),
            RecoveryRequest('GET', '/api/v2/spot/trade/fills', params),
        ]


RECOVERY_ENGINES = {
    'binance': BinanceRecoveryEngine(),
    'bybit': BybitRecoveryEngine(),
    'mexc': MexcRecoveryEngine(),
    'bitget': BitgetRecoveryEngine(),
}


def get_recovery_engine(venue: str) -> BaseRecoveryEngine:
    try:
        return RECOVERY_ENGINES[venue.lower()]
    except KeyError as exc:
        raise ValueError(f'unsupported recovery venue: {venue}') from exc
