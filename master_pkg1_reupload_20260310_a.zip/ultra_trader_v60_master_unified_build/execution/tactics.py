from __future__ import annotations

from dataclasses import dataclass
from statistics import mean

from common.models import ExecutionPolicy, Order, OrderType, Side, Tick
from config.settings import ExecutionTacticsSettings


@dataclass(slots=True)
class ExecutionSlice:
    qty: float
    order_type: OrderType
    limit_price: float | None
    execution_policy: ExecutionPolicy


@dataclass(slots=True)
class ExecutionPlan:
    parent_order_id: str
    venue: str
    symbol: str
    policy: ExecutionPolicy
    slices: list[ExecutionSlice]
    queue_fill_probability: float
    recommended_notional: float

    @property
    def slice_count(self) -> int:
        return len(self.slices)


class QueueFillProbabilityModel:
    def estimate(self, tick: Tick, order: Order, *, venue_health_score: float = 0.7) -> float:
        spread_bps = 0.0 if tick.mid <= 0 else (tick.spread / tick.mid) * 10000
        aggressive_bonus = 0.15 if order.execution_policy in {ExecutionPolicy.AGGRESSIVE, ExecutionPolicy.VWAP} or order.order_type == OrderType.MARKET else 0.0
        passive_penalty = 0.10 if order.execution_policy == ExecutionPolicy.PASSIVE else 0.0
        spread_term = max(0.05, 1.0 - min(spread_bps / 50.0, 0.9))
        side_term = 0.03 if (order.side == Side.BUY and order.limit_price and order.limit_price >= tick.ask) or (order.side == Side.SELL and order.limit_price and order.limit_price <= tick.bid) else 0.0
        score = 0.35 * venue_health_score + 0.45 * spread_term + aggressive_bonus + side_term - passive_penalty
        return max(0.01, min(score, 0.99))


class ExecutionTacticsService:
    def __init__(self, settings: ExecutionTacticsSettings, queue_model: QueueFillProbabilityModel | None = None) -> None:
        self.settings = settings
        self.queue_model = queue_model or QueueFillProbabilityModel()

    def enabled_for(self, strategy: str) -> bool:
        return self.settings.enabled and strategy.lower() in set(self.settings.strategies)

    def choose_policy(self, order: Order, tick: Tick, *, venue_health_score: float = 0.7, futures_mode: bool = False) -> ExecutionPolicy:
        if order.execution_policy != ExecutionPolicy.AUTO:
            return order.execution_policy
        spread_bps = 0.0 if tick.mid <= 0 else (tick.spread / tick.mid) * 10000
        if futures_mode:
            return ExecutionPolicy.AGGRESSIVE if spread_bps <= 6 else ExecutionPolicy.VWAP
        if order.strategy == 'market_making':
            return ExecutionPolicy.PASSIVE
        if spread_bps <= 3 and venue_health_score >= 0.6:
            return ExecutionPolicy.AGGRESSIVE
        return ExecutionPolicy.TWAP

    def build_plan(self, order: Order, tick: Tick, *, venue_health_score: float = 0.7, futures_mode: bool = False) -> ExecutionPlan:
        policy = self.choose_policy(order, tick, venue_health_score=venue_health_score, futures_mode=futures_mode)
        market_price = tick.ask if order.side == Side.BUY else tick.bid
        notional = abs(order.qty * market_price)
        slices_count = 1
        if policy in {ExecutionPolicy.TWAP, ExecutionPolicy.VWAP} and notional >= self.settings.min_slice_notional:
            slices_count = max(2, self.settings.default_slices)
        qtys = self._split_qty(order.qty, slices_count)
        slices = [
            ExecutionSlice(
                qty=q,
                order_type=self._slice_order_type(policy),
                limit_price=self._slice_limit_price(policy, tick, order.side),
                execution_policy=policy,
            )
            for q in qtys
        ]
        probe = Order(strategy=order.strategy, venue=order.venue, symbol=order.symbol, side=order.side, qty=order.qty, order_type=slices[0].order_type, limit_price=slices[0].limit_price, execution_policy=policy)
        fill_prob = self.queue_model.estimate(tick, probe, venue_health_score=venue_health_score)
        return ExecutionPlan(parent_order_id=order.client_order_id, venue=order.venue, symbol=order.symbol, policy=policy, slices=slices, queue_fill_probability=fill_prob, recommended_notional=notional * mean([1.0, fill_prob]))

    def _split_qty(self, qty: float, count: int) -> list[float]:
        base = qty / count
        chunks = [base] * count
        chunks[-1] = qty - sum(chunks[:-1])
        return chunks

    def _slice_order_type(self, policy: ExecutionPolicy) -> OrderType:
        if policy in {ExecutionPolicy.PASSIVE, ExecutionPolicy.TWAP}:
            return OrderType.LIMIT
        return OrderType.MARKET

    def _slice_limit_price(self, policy: ExecutionPolicy, tick: Tick, side: Side) -> float | None:
        if policy not in {ExecutionPolicy.PASSIVE, ExecutionPolicy.TWAP}:
            return None
        offset = self.settings.passive_offset_bps / 10000
        if side == Side.BUY:
            return tick.bid * (1 - offset) if policy == ExecutionPolicy.PASSIVE else tick.ask
        return tick.ask * (1 + offset) if policy == ExecutionPolicy.PASSIVE else tick.bid
