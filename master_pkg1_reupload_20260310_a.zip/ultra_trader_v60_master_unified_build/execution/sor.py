from __future__ import annotations

from dataclasses import dataclass

from common.models import Side, Tick
from research.venue_health import VenueHealthScoringService


@dataclass(slots=True)
class RoutingDecision:
    selected_venue: str
    score: float
    reason: str


class SmartOrderRouter:
    def __init__(self, venue_health: VenueHealthScoringService, *, health_weight: float = 0.35) -> None:
        self.venue_health = venue_health
        self.health_weight = health_weight

    def route(self, symbol: str, side: Side, ticks: dict[str, Tick]) -> RoutingDecision | None:
        candidates = [(venue, tick) for venue, tick in ticks.items() if tick.symbol == symbol]
        if not candidates:
            return None
        scored: list[tuple[float, str]] = []
        for venue, tick in candidates:
            px = tick.ask if side == Side.BUY else tick.bid
            if px <= 0:
                continue
            px_score = (1.0 / px) if side == Side.BUY else px
            health = self.venue_health.snapshot(venue).score / 100.0
            score = px_score * (1.0 - self.health_weight) + health * self.health_weight
            scored.append((score, venue))
        if not scored:
            return None
        selected_score, selected_venue = max(scored, key=lambda item: item[0])
        return RoutingDecision(selected_venue=selected_venue, score=selected_score, reason='best_price_plus_health')
