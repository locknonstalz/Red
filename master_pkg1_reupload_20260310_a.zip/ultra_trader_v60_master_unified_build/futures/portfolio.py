from __future__ import annotations

from dataclasses import dataclass

from futures.models import DerivativeInstrument


@dataclass(slots=True)
class FuturesPosition:
    symbol: str
    venue: str
    qty: float
    entry_price: float
    mark_price: float
    leverage: float

    @property
    def liquidation_distance_bps(self) -> float:
        if self.entry_price <= 0 or self.leverage <= 0:
            return 0.0
        maintenance = 1.0 / max(self.leverage, 1.0)
        return maintenance * 10000.0


class FuturesPortfolioService:
    def __init__(self) -> None:
        self._positions: dict[tuple[str, str], FuturesPosition] = {}
        self._instruments: dict[tuple[str, str], DerivativeInstrument] = {}

    def register_instrument(self, instrument: DerivativeInstrument) -> None:
        self._instruments[(instrument.venue, instrument.symbol)] = instrument

    def upsert_position(self, position: FuturesPosition) -> None:
        self._positions[(position.venue, position.symbol)] = position

    def get_position(self, venue: str, symbol: str) -> FuturesPosition | None:
        return self._positions.get((venue, symbol))
