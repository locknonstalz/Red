from fastapi.testclient import TestClient

from ai.decision_engine import AIDecisionEngine
from capital.protection import CapitalProtectionService
from config.settings import CapitalProtectionSettings
from control_plane.api import create_control_plane_app
from control_plane.service import ControlPlaneService
from ops.alerts import AlertRouter, InMemoryAlertSink
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.journal import SqliteJournal


def build_test_app():
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    capital = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    ai = AIDecisionEngine(metrics=metrics, enabled=True, model_path='/tmp/nonexistent-ai-model.json')
    sink = InMemoryAlertSink()
    control = ControlPlaneService(
        capital_protection=capital,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        ai_engine=ai,
        alert_router=AlertRouter([sink]),
    )
    return create_control_plane_app(control), sink


def test_operator_control_plane_toggles_only_close_and_ai() -> None:
    app, sink = build_test_app()
    client = TestClient(app)

    r = client.post('/controls/only-close', json={'enabled': True, 'reason': 'operator_freeze'})
    assert r.status_code == 200
    assert r.json()['state']['only_close_mode'] is True

    r = client.post('/controls/ai', json={'enabled': False, 'reason': 'shadow_mode'})
    assert r.status_code == 200
    assert r.json()['state']['enabled'] is False

    state = client.get('/state').json()
    assert state['protection']['only_close_mode'] is True
    assert state['ai']['enabled'] is False
    assert sink.messages[-1].event == 'ai_toggle'


def test_operator_control_plane_strategy_toggle_and_events() -> None:
    app, sink = build_test_app()
    client = TestClient(app)

    r = client.post('/controls/strategy', json={'strategy': 'market_making', 'enabled': False, 'reason': 'manual_disable'})
    assert r.status_code == 200
    assert 'market_making' in r.json()['state']['disabled_strategies']

    events = client.get('/protection/events?limit=10').json()['events']
    assert any(e['event_type'] == 'strategy_kill' for e in events)
    assert any(m.event == 'strategy_disabled' for m in sink.messages)
