from config.settings import VenueCredentials
from execution.live.ws_sessions import BinancePrivateWsSession, MexcPrivateWsSession


def test_binance_ws_api_endpoint_switches_for_testnet():
    session = BinancePrivateWsSession(VenueCredentials(testnet=True))
    assert 'testnet' in session.ws_url


def test_mexc_listen_key_requests_shape():
    session = MexcPrivateWsSession(VenueCredentials())
    assert session.create_listen_key_request()['path'] == '/api/v3/userDataStream'
