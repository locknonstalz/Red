# V23 Futures Live + V24 External Analytics

## Что добавлено

- futures venue specs для Binance / Bybit / MEXC / Bitget
- funding / basis / open-interest ingestion service
- futures execution plan builder
- external analytics connectors:
  - news sentiment
  - on-chain flow
  - derivatives metrics
- strategy allocator
- research screener endpoints в control plane

## Что это даёт

- база под деривативные venue-specific execution paths
- единый ingestion слой для funding/basis/OI
- внешний research input для signal scoring
- allocator, который режет/усиливает стратегии по regime + attribution
- UI/API для asset screener и allocator state
