from __future__ import annotations

from dataclasses import dataclass

from common.models import Signal, Tick
from research.asset_analysis import AssetAnalysisService
from research.external_research import ExternalResearchIngestionLayer
from research.indicators import IndicatorEngine
from research.regime import MarketRegimeClassifier


@dataclass(slots=True)
class SignalScoreDecision:
    accepted: bool
    signal: Signal | None
    reason: str
    score: float


class SignalScoringLayer:
    def __init__(
        self,
        asset_analysis: AssetAnalysisService,
        indicators: IndicatorEngine,
        regime_classifier: MarketRegimeClassifier,
        external_research: ExternalResearchIngestionLayer,
        min_score: float = 0.45,
    ) -> None:
        self.asset_analysis = asset_analysis
        self.indicators = indicators
        self.regime_classifier = regime_classifier
        self.external_research = external_research
        self.min_score = min_score

    def score(self, signal: Signal, tick: Tick) -> SignalScoreDecision:
        asset = self.asset_analysis.snapshot(signal.venue, signal.symbol)
        regime = self.regime_classifier.snapshot(signal.venue, signal.symbol)
        inds = self.indicators.snapshot(signal.venue, signal.symbol)
        ext = self.external_research.aggregate_score(signal.symbol)
        score = min(max(signal.strength, 0.0), 1.0) * 0.35
        if asset is not None:
            score += min(asset.quality_score / 100.0, 1.0) * 0.25
            if asset.spread_bps > 20:
                score -= 0.15
        if regime is not None:
            if signal.strategy == 'market_making' and regime.regime == 'range':
                score += 0.12
            if signal.strategy in {'liquidity_taking', 'momentum_xover'} and regime.regime == 'trend':
                score += 0.12
            if regime.regime == 'volatile':
                score -= 0.08
        if inds is not None:
            score += 0.1 if inds.ema_fast > inds.ema_slow and signal.side.value == 'BUY' else 0.0
            score += 0.1 if inds.ema_fast < inds.ema_slow and signal.side.value == 'SELL' else 0.0
            if inds.rsi > 75 and signal.side.value == 'BUY':
                score -= 0.05
            if inds.rsi < 25 and signal.side.value == 'SELL':
                score -= 0.05
        score += max(min(ext, 1.0), -1.0) * 0.1
        accepted = score >= self.min_score
        adjusted = signal if accepted else None
        if adjusted is not None and asset is not None and asset.quality_score > 60:
            adjusted.tags = {**adjusted.tags, 'quality': 'high'}
            adjusted.qty = (adjusted.qty or 0.01) * 1.1
        return SignalScoreDecision(accepted=accepted, signal=adjusted, reason='accepted' if accepted else 'score_below_threshold', score=score)
