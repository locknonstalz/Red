from config.settings import Settings, StrategySettings, ControlPlaneSettings
from runtime.bootstrap import CompositeBroker, build_runtime_bundle


def test_build_runtime_bundle_paper_multi_venue(tmp_path):
    settings = Settings(
        mode='paper',
        runtime_seconds=0.01,
        database=type(Settings().database)(sqlite_path=str(tmp_path / 'runtime.db')),
        strategy=StrategySettings(cross_exchange_venues=['binance', 'bybit', 'mexc']),
        control_plane=ControlPlaneSettings(enabled=False),
    )
    bundle = build_runtime_bundle(settings)
    assert bundle.settings.mode == 'paper'
    assert bundle.orchestration is None
    assert bundle.feed.__class__.__name__ == 'MultiVenueDemoFeed'
    assert bundle.control_plane_app is not None
    bundle.journal.close()


def test_build_runtime_bundle_live_multi_venue(tmp_path):
    base = Settings().database
    settings = Settings(
        mode='live',
        runtime_seconds=0.01,
        live_venues=['binance', 'bybit'],
        database=type(base)(sqlite_path=str(tmp_path / 'runtime_live.db')),
        binance=type(Settings().binance)(api_key='a', api_secret='b'),
        bybit=type(Settings().bybit)(api_key='c', api_secret='d'),
        control_plane=ControlPlaneSettings(enabled=False),
    )
    bundle = build_runtime_bundle(settings)
    assert bundle.orchestration is not None
    assert isinstance(bundle.broker, CompositeBroker)
    assert set(bundle.orchestration.sessions.keys()) == {'binance', 'bybit'}
    bundle.journal.close()
