from __future__ import annotations

from typing import Sequence

from common.models import OrderType, Side, Signal, Tick
from strategy.base import Strategy


class FundingCarryStrategy(Strategy):
    """Spot/perp carry entry strategy.

    Emits paired legs when funding and basis exceed configured thresholds.
    Tags indicate that the spot leg is intended to be hedged by a perp leg.
    """

    def __init__(
        self,
        name: str,
        spot_venue: str,
        perp_venue: str,
        symbol: str,
        trade_size: float,
        min_funding_rate: float = 0.0008,
        min_basis_bps: float = 4.0,
        max_basis_bps: float = 80.0,
    ) -> None:
        self.name = name
        self.spot_venue = spot_venue
        self.perp_venue = perp_venue
        self.symbol = symbol
        self.trade_size = trade_size
        self.min_funding_rate = min_funding_rate
        self.min_basis_bps = min_basis_bps
        self.max_basis_bps = max_basis_bps
        self._ticks: dict[str, Tick] = {}
        self._active_direction = 0
        self._evaluation_count = 0
        self._last_state: dict[str, float | int | str | bool] = {'status': 'booting', 'reason_code': 'booting'}

    def on_tick(self, tick: Tick) -> Sequence[Signal]:
        if tick.symbol != self.symbol:
            self._last_state = {'status': 'ignored_symbol', 'tick_symbol': tick.symbol, 'strategy_symbol': self.symbol}
            return []
        self._ticks[tick.venue] = tick
        self._evaluation_count += 1
        if self.spot_venue not in self._ticks or self.perp_venue not in self._ticks:
            self._last_state = {
                'status': 'waiting_for_both_venues',
                'reason_code': 'waiting_for_both_venues',
                'reason_text': 'Need both spot and perp venue ticks before evaluating funding carry',
                'evaluation_count': self._evaluation_count,
                'trade_size': self.trade_size,
                'spot_ready': self.spot_venue in self._ticks,
                'perp_ready': self.perp_venue in self._ticks,
                'spot_venue': self.spot_venue,
                'perp_venue': self.perp_venue,
            }
            return []
        spot = self._ticks[self.spot_venue]
        perp = self._ticks[self.perp_venue]
        funding = float(getattr(perp, 'funding_rate', getattr(tick, 'funding_rate', 0.0)) or 0.0)
        basis_bps = ((perp.mid - spot.mid) / spot.mid) * 10000 if spot.mid else 0.0
        self._last_state = {
            'status': 'evaluating',
            'reason_code': 'evaluating',
            'reason_text': 'Funding carry is evaluating current spot/perp state',
            'spot_mid': round(spot.mid, 8),
            'perp_mid': round(perp.mid, 8),
            'trade_size': self.trade_size,
            'evaluation_count': self._evaluation_count,
            'delta_to_min_funding': round(max(self.min_funding_rate - abs(funding), 0.0), 8),
            'delta_to_min_basis_bps': round(max(self.min_basis_bps - abs(basis_bps), 0.0), 4),
            'delta_over_max_basis_bps': round(max(abs(basis_bps) - self.max_basis_bps, 0.0), 4),
            'funding_rate': round(funding, 8),
            'basis_bps': round(basis_bps, 4),
            'min_funding_rate': self.min_funding_rate,
            'min_basis_bps': self.min_basis_bps,
            'max_basis_bps': self.max_basis_bps,
            'active_direction': self._active_direction,
        }

        # positive funding: prefer long spot / short perp
        if self._active_direction == 0 and funding >= self.min_funding_rate and self.min_basis_bps <= basis_bps <= self.max_basis_bps:
            self._active_direction = 1
            self._last_state = {'status': 'enter_long_spot_short_perp', 'reason_code': 'entry_ready_long_spot_short_perp', 'reason_text': 'Positive funding and acceptable basis allow long-spot/short-perp entry', 'funding_rate': round(funding, 8), 'basis_bps': round(basis_bps, 4), 'spot_mid': round(spot.mid, 8), 'perp_mid': round(perp.mid, 8), 'trade_size': self.trade_size, 'evaluation_count': self._evaluation_count, 'active_direction': self._active_direction}
            return [
                Signal(self.name, self.spot_venue, self.symbol, Side.BUY, min(3.0, basis_bps / max(self.min_basis_bps, 1e-9)), f'carry_enter_long_spot_funding={funding:.5f}', qty=self.trade_size, order_type=OrderType.MARKET, tags={'sleeve': 'carry', 'leg': 'spot', 'funding_rate': funding, 'basis_bps': round(basis_bps, 3)}),
                Signal(self.name, self.perp_venue, self.symbol, Side.SELL, min(3.0, basis_bps / max(self.min_basis_bps, 1e-9)), f'carry_enter_short_perp_funding={funding:.5f}', qty=self.trade_size, order_type=OrderType.MARKET, tags={'sleeve': 'carry', 'leg': 'perp', 'hedge_pair': self.spot_venue, 'funding_rate': funding, 'basis_bps': round(basis_bps, 3)}),
            ]
        # negative funding: prefer short spot proxy / long perp; in spot-only engines, use perp-only long as signal and leave hedge routing to inventory engine.
        if self._active_direction == 0 and funding <= -self.min_funding_rate and -self.max_basis_bps <= basis_bps <= -self.min_basis_bps:
            self._active_direction = -1
            self._last_state = {'status': 'enter_long_perp', 'reason_code': 'entry_ready_long_perp', 'reason_text': 'Negative funding and acceptable inverse basis allow long-perp entry', 'funding_rate': round(funding, 8), 'basis_bps': round(basis_bps, 4), 'spot_mid': round(spot.mid, 8), 'perp_mid': round(perp.mid, 8), 'trade_size': self.trade_size, 'evaluation_count': self._evaluation_count, 'active_direction': self._active_direction}
            return [
                Signal(self.name, self.perp_venue, self.symbol, Side.BUY, min(3.0, abs(basis_bps) / max(self.min_basis_bps, 1e-9)), f'carry_enter_long_perp_funding={funding:.5f}', qty=self.trade_size, order_type=OrderType.MARKET, tags={'sleeve': 'carry', 'leg': 'perp', 'funding_rate': funding, 'basis_bps': round(basis_bps, 3)}),
            ]
        # exit once basis compresses materially or funding flips
        if self._active_direction != 0 and (abs(basis_bps) < self.min_basis_bps * 0.35 or funding * self._active_direction < 0):
            direction = self._active_direction
            self._active_direction = 0
            if direction > 0:
                self._last_state = {'status': 'exit_long_spot_short_perp', 'reason_code': 'exit_long_spot_short_perp', 'reason_text': 'Basis compressed or funding flipped against active carry', 'funding_rate': round(funding, 8), 'basis_bps': round(basis_bps, 4), 'trade_size': self.trade_size, 'evaluation_count': self._evaluation_count}
                return [
                    Signal(self.name, self.spot_venue, self.symbol, Side.SELL, 0.6, f'carry_exit_spot_funding={funding:.5f}', qty=self.trade_size, tags={'sleeve': 'carry', 'leg': 'spot_close'}),
                    Signal(self.name, self.perp_venue, self.symbol, Side.BUY, 0.6, f'carry_exit_perp_funding={funding:.5f}', qty=self.trade_size, tags={'sleeve': 'carry', 'leg': 'perp_close'}),
                ]
            self._last_state = {'status': 'exit_long_perp', 'reason_code': 'exit_long_perp', 'reason_text': 'Negative carry conditions have normalized or reversed', 'funding_rate': round(funding, 8), 'basis_bps': round(basis_bps, 4), 'trade_size': self.trade_size, 'evaluation_count': self._evaluation_count}
            return [
                Signal(self.name, self.perp_venue, self.symbol, Side.SELL, 0.6, f'carry_exit_perp_funding={funding:.5f}', qty=self.trade_size, tags={'sleeve': 'carry', 'leg': 'perp_close'}),
            ]
        if self._active_direction != 0:
            self._last_state = {'status': 'holding_active_carry', 'reason_code': 'holding_active_carry', 'reason_text': 'Existing carry position remains valid; no new entry signal required', 'funding_rate': round(funding, 8), 'basis_bps': round(basis_bps, 4), 'trade_size': self.trade_size, 'evaluation_count': self._evaluation_count, 'active_direction': self._active_direction}
            return []
        if abs(funding) < self.min_funding_rate:
            self._last_state = {'status': 'blocked_funding_below_threshold', 'reason_code': 'funding_below_min', 'reason_text': 'Absolute funding rate is below the configured minimum threshold', 'funding_rate': round(funding, 8), 'min_funding_rate': self.min_funding_rate, 'basis_bps': round(basis_bps, 4), 'spot_mid': round(spot.mid, 8), 'perp_mid': round(perp.mid, 8), 'trade_size': self.trade_size, 'evaluation_count': self._evaluation_count, 'delta_to_min_funding': round(max(self.min_funding_rate - abs(funding), 0.0), 8)}
        elif abs(basis_bps) < self.min_basis_bps:
            self._last_state = {'status': 'blocked_basis_too_small', 'reason_code': 'basis_below_min', 'reason_text': 'Basis is below the configured minimum threshold for carry entry', 'funding_rate': round(funding, 8), 'basis_bps': round(basis_bps, 4), 'min_basis_bps': self.min_basis_bps, 'spot_mid': round(spot.mid, 8), 'perp_mid': round(perp.mid, 8), 'trade_size': self.trade_size, 'evaluation_count': self._evaluation_count, 'delta_to_min_basis_bps': round(max(self.min_basis_bps - abs(basis_bps), 0.0), 4)}
        elif abs(basis_bps) > self.max_basis_bps:
            self._last_state = {'status': 'blocked_basis_too_wide', 'reason_code': 'basis_above_max', 'reason_text': 'Basis is above the configured maximum threshold and is too wide for safe entry', 'funding_rate': round(funding, 8), 'basis_bps': round(basis_bps, 4), 'max_basis_bps': self.max_basis_bps, 'spot_mid': round(spot.mid, 8), 'perp_mid': round(perp.mid, 8), 'trade_size': self.trade_size, 'evaluation_count': self._evaluation_count, 'delta_over_max_basis_bps': round(max(abs(basis_bps) - self.max_basis_bps, 0.0), 4)}
        return []

    def debug_state(self) -> dict[str, float | int | str | bool]:
        return dict(self._last_state)
