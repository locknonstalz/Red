from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class FeatureRecord:
    symbol: str
    features: dict[str, float]
    label: int | None = None
    ts: datetime = field(default_factory=utc_now)


class FeatureStore:
    def __init__(self, path: str = 'feature_store.jsonl') -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, record: FeatureRecord) -> None:
        with self.path.open('a', encoding='utf-8') as fh:
            payload = asdict(record)
            payload['ts'] = record.ts.isoformat()
            fh.write(json.dumps(payload, ensure_ascii=False) + '\n')

    def read_all(self) -> list[FeatureRecord]:
        if not self.path.exists():
            return []
        out = []
        for line in self.path.read_text(encoding='utf-8').splitlines():
            if not line.strip():
                continue
            payload = json.loads(line)
            out.append(FeatureRecord(symbol=payload['symbol'], features={k: float(v) for k, v in payload['features'].items()}, label=payload.get('label'), ts=datetime.fromisoformat(payload['ts'])))
        return out
