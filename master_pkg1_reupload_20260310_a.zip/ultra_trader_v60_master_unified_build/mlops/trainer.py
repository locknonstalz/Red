from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class TrainingExample:
    features: dict[str, float]
    label: int


class OfflineTrainer:
    def train(self, examples: list[TrainingExample]) -> dict[str, float]:
        if not examples:
            return {}
        sums_pos: dict[str, float] = {}
        sums_neg: dict[str, float] = {}
        n_pos = 0
        n_neg = 0
        for ex in examples:
            if ex.label > 0:
                n_pos += 1
                target = sums_pos
            else:
                n_neg += 1
                target = sums_neg
            for key, value in ex.features.items():
                target[key] = target.get(key, 0.0) + value
        weights = {}
        keys = set(sums_pos) | set(sums_neg)
        for key in keys:
            pos_mean = sums_pos.get(key, 0.0) / max(n_pos, 1)
            neg_mean = sums_neg.get(key, 0.0) / max(n_neg, 1)
            weights[key] = pos_mean - neg_mean
        return weights

    def persist(self, model: dict[str, float], path: str) -> None:
        Path(path).write_text(json.dumps(model, indent=2), encoding='utf-8')
