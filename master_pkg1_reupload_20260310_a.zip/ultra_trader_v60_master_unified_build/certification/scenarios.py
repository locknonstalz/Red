from __future__ import annotations

from certification.models import VenueCertificationConfig


def default_certification_configs() -> dict[str, VenueCertificationConfig]:
    return {
        'binance': VenueCertificationConfig(
            venue='binance',
            environment='testnet',
            notes='Spot testnet order-flow over REST plus public/private websocket validation.',
        ),
        'bybit': VenueCertificationConfig(
            venue='bybit',
            environment='testnet',
            notes='V5 testnet order-flow with private topic validation.',
        ),
        'mexc': VenueCertificationConfig(
            venue='mexc',
            environment='live-guarded',
            enable_private_ws=True,
            allow_live_micro_orders=False,
            notes='MEXC spot docs expose live endpoints and user-data streams; pack defaults to read-only unless explicitly allowed.',
        ),
        'bitget': VenueCertificationConfig(
            venue='bitget',
            environment='demo',
            require_passphrase=True,
            notes='Bitget demo API requires demo API key and paptrading=1 header.',
        ),
    }
