from __future__ import annotations

from dataclasses import dataclass

from futures.analytics import FuturesAnalyticsService
from futures.models import FundingSnapshot


@dataclass(slots=True)
class FundingBasisOISnapshot:
    venue: str
    symbol: str
    funding_rate: float
    basis_bps: float
    open_interest: float


class FuturesMarketIntelService:
    def __init__(self, analytics: FuturesAnalyticsService) -> None:
        self.analytics = analytics
        self._latest: dict[tuple[str, str], FundingBasisOISnapshot] = {}

    def observe(self, snapshot: FundingBasisOISnapshot) -> None:
        self._latest[(snapshot.venue, snapshot.symbol)] = snapshot
        self.analytics.observe_snapshot(
            FundingSnapshot(
                venue=snapshot.venue,
                symbol=snapshot.symbol,
                funding_rate=snapshot.funding_rate,
                basis_bps=snapshot.basis_bps,
                open_interest=snapshot.open_interest,
            )
        )

    def from_payload(self, venue: str, symbol: str, payload: dict) -> FundingBasisOISnapshot:
        snap = FundingBasisOISnapshot(
            venue=venue,
            symbol=symbol,
            funding_rate=float(payload.get('funding_rate', 0.0)),
            basis_bps=float(payload.get('basis_bps', 0.0)),
            open_interest=float(payload.get('open_interest', payload.get('openInterest', 0.0))),
        )
        self.observe(snap)
        return snap

    def latest(self, venue: str, symbol: str) -> FundingBasisOISnapshot | None:
        return self._latest.get((venue, symbol))
