from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from math import sqrt

from common.models import Tick


@dataclass(slots=True)
class IndicatorSnapshot:
    venue: str
    symbol: str
    sma_fast: float
    sma_slow: float
    ema_fast: float
    ema_slow: float
    rsi: float
    atr_bps: float
    bollinger_z: float
    zscore: float
    vwap: float


class IndicatorEngine:
    def __init__(self, fast_window: int = 5, slow_window: int = 20) -> None:
        self.fast_window = fast_window
        self.slow_window = slow_window
        self._prices: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=max(self.slow_window * 3, 64)))
        self._spreads: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=max(self.slow_window * 3, 64)))
        self._volumes: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=max(self.slow_window * 3, 64)))

    def observe_tick(self, tick: Tick) -> None:
        key = (tick.venue, tick.symbol)
        self._prices[key].append(float(tick.mid))
        self._spreads[key].append(float(tick.spread))
        self._volumes[key].append(max(tick.mid, 1.0))

    def _ema(self, values: list[float], window: int) -> float:
        if not values:
            return 0.0
        alpha = 2.0 / (window + 1)
        ema = values[0]
        for value in values[1:]:
            ema = alpha * value + (1 - alpha) * ema
        return ema

    def snapshot(self, venue: str, symbol: str) -> IndicatorSnapshot | None:
        key = (venue, symbol)
        prices = list(self._prices.get(key, ()))
        spreads = list(self._spreads.get(key, ()))
        volumes = list(self._volumes.get(key, ()))
        if len(prices) < max(self.fast_window, 3):
            return None
        fast = prices[-self.fast_window:]
        slow = prices[-min(len(prices), self.slow_window):]
        sma_fast = sum(fast) / len(fast)
        sma_slow = sum(slow) / len(slow)
        ema_fast = self._ema(fast, self.fast_window)
        ema_slow = self._ema(slow, min(len(slow), self.slow_window))
        gains = []
        losses = []
        for a, b in zip(prices, prices[1:]):
            delta = b - a
            gains.append(max(delta, 0.0))
            losses.append(max(-delta, 0.0))
        avg_gain = sum(gains[-14:]) / min(len(gains), 14) if gains else 0.0
        avg_loss = sum(losses[-14:]) / min(len(losses), 14) if losses else 0.0
        rs = avg_gain / avg_loss if avg_loss > 1e-12 else 99.0
        rsi = 100.0 - (100.0 / (1.0 + rs))
        atr_bps = ((sum(spreads[-14:]) / min(len(spreads), 14)) / prices[-1] * 10000.0) if spreads else 0.0
        mean = sma_slow
        variance = sum((p - mean) ** 2 for p in slow) / len(slow)
        std = sqrt(variance) if variance > 0 else 0.0
        bollinger_z = (prices[-1] - mean) / std if std > 1e-12 else 0.0
        recent = prices[-20:]
        recent_mean = sum(recent) / len(recent)
        recent_var = sum((p - recent_mean) ** 2 for p in recent) / len(recent)
        recent_std = sqrt(recent_var) if recent_var > 0 else 0.0
        zscore = (prices[-1] - recent_mean) / recent_std if recent_std > 1e-12 else 0.0
        vwap = sum(p * v for p, v in zip(prices[-20:], volumes[-20:])) / sum(volumes[-20:])
        return IndicatorSnapshot(venue=venue, symbol=symbol, sma_fast=sma_fast, sma_slow=sma_slow, ema_fast=ema_fast, ema_slow=ema_slow, rsi=rsi, atr_bps=atr_bps, bollinger_z=bollinger_z, zscore=zscore, vwap=vwap)
