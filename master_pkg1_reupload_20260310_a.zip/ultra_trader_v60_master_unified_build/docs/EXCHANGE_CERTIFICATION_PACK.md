# Exchange Certification Pack (v19)

This pack turns the platform from “architecturally ready” into “verifiable against real exchange surfaces”.

## What it does

For each venue it runs a concrete order-flow checklist:

1. Credentials present
2. Public market connectivity
3. Symbol metadata / filters
4. Balance fetch
5. Place a small far-away limit order
6. Verify order shows up in open orders
7. Cancel the order
8. Query final order status
9. Record a machine-readable JSON report

## Venue mapping

### Binance
- Environment: **Spot Testnet**
- Base REST URL: `https://testnet.binance.vision`
- Intended use: testnet order placement/cancel/verification

### Bybit
- Environment: **V5 Testnet**
- Base REST URL: `https://api-testnet.bybit.com`
- Intended use: testnet order placement/cancel/verification

### Bitget
- Environment: **Demo Trading**
- Base REST URL: `https://api.bitget.com`
- Required header: `paptrading: 1`
- Intended use: demo order placement/cancel/verification

### MEXC
- Environment: **Live-guarded**
- Base REST URL: `https://api.mexc.com`
- Default mode: **read-only**
- To allow live micro-order certification you must set `MEXC_ALLOW_LIVE_CERT=1`

MEXC is handled differently because the project did not have a dedicated official spot testnet/demo endpoint wired in. Read-only checks still validate connectivity, filters and balances. Micro-order certification is opt-in so the pack cannot accidentally place a real order.

## Safety design

The pack posts **far-away limit sell orders** so that the order should remain open and then get cancelled, which is the safest way to verify placement/cancel flow without intentionally taking liquidity.

Still, you should only run this with dedicated sandbox/demo accounts, and only enable `MEXC_ALLOW_LIVE_CERT=1` on a segregated low-balance account.

## Required environment variables

### Binance
- `BINANCE_API_KEY`
- `BINANCE_API_SECRET`

### Bybit
- `BYBIT_API_KEY`
- `BYBIT_API_SECRET`

### MEXC
- `MEXC_API_KEY`
- `MEXC_API_SECRET`
- optional: `MEXC_ALLOW_LIVE_CERT=1`

### Bitget
- `BITGET_API_KEY`
- `BITGET_API_SECRET`
- `BITGET_API_PASSPHRASE`

## Run

```bash
python scripts/run_exchange_certification.py --venues binance,bybit,bitget --out certification_report.json
```

To include MEXC read-only checks:

```bash
python scripts/run_exchange_certification.py --venues mexc --out mexc_report.json
```

To include MEXC live micro-order certification explicitly:

```bash
MEXC_ALLOW_LIVE_CERT=1 python scripts/run_exchange_certification.py --venues mexc --out mexc_report.json
```

## Expected outcome

A passing venue report means:
- credentials signed correctly
- exchange accepted authenticated requests
- market metadata can be fetched
- balances can be fetched
- the system can place and cancel a small certification order
- order state can be queried afterwards

That is the minimum factual proof that the venue path works beyond architecture alone.
