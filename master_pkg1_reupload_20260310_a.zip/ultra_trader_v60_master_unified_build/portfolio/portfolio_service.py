from __future__ import annotations

from dataclasses import dataclass

from common.models import Balance, Fill, Position, Side
from ops.metrics import MetricsRegistry
from storage.base import Journal


@dataclass(slots=True)
class PortfolioSnapshot:
    realized_pnl: float
    unrealized_pnl: float
    gross_notional: float


class PortfolioService:
    def __init__(self, base_currency: str, journal: Journal, metrics: MetricsRegistry) -> None:
        self.base_currency = base_currency
        self.journal = journal
        self.metrics = metrics
        self._positions: dict[tuple[str, str], Position] = {}
        self._balances: dict[tuple[str, str], Balance] = {}

    def _key(self, symbol: str, venue: str = '') -> tuple[str, str]:
        return (venue, symbol)

    def get_position(self, symbol: str, venue: str = '') -> Position:
        if venue:
            key = self._key(symbol, venue)
            return self._positions.setdefault(key, Position(symbol=symbol, venue=venue))
        matches = [p for (v, s), p in self._positions.items() if s == symbol]
        if not matches:
            return self._positions.setdefault(self._key(symbol, ''), Position(symbol=symbol, venue=''))
        return Position(
            symbol=symbol,
            venue='',
            qty=sum(p.qty for p in matches),
            avg_price=(sum(abs(p.qty) * p.avg_price for p in matches) / sum(abs(p.qty) for p in matches)) if sum(abs(p.qty) for p in matches) else 0.0,
            realized_pnl=sum(p.realized_pnl for p in matches),
            mark_price=(sum(abs(p.qty) * p.mark_price for p in matches) / sum(abs(p.qty) for p in matches)) if sum(abs(p.qty) for p in matches) else 0.0,
        )

    def sync_position(self, position: Position) -> None:
        self._positions[self._key(position.symbol, position.venue)] = position
        self.journal.save_position_snapshot(position)

    def sync_balance(self, balance: Balance) -> None:
        self._balances[(balance.venue, balance.asset)] = balance
        self.journal.save_balance_snapshot(balance)

    def mark_price(self, symbol: str, price: float, venue: str = '') -> None:
        if venue:
            self.get_position(symbol, venue=venue).mark_price = price
            return
        matched = False
        for (v, s), pos in self._positions.items():
            if s == symbol:
                pos.mark_price = price
                matched = True
        if not matched:
            self.get_position(symbol, venue='').mark_price = price

    def apply_fill(self, fill: Fill) -> None:
        pos = self.get_position(fill.symbol, venue=fill.venue)
        signed_qty = fill.qty if fill.side == Side.BUY else -fill.qty
        if pos.qty == 0 or (pos.qty > 0 and signed_qty > 0) or (pos.qty < 0 and signed_qty < 0):
            new_qty = pos.qty + signed_qty
            total_cost = (pos.avg_price * abs(pos.qty)) + (fill.price * abs(signed_qty))
            pos.qty = new_qty
            pos.avg_price = total_cost / abs(new_qty) if new_qty != 0 else 0.0
        else:
            closing_qty = min(abs(pos.qty), abs(signed_qty))
            pnl_per_unit = (fill.price - pos.avg_price) if pos.qty > 0 else (pos.avg_price - fill.price)
            pos.realized_pnl += pnl_per_unit * closing_qty - fill.fee
            pos.qty += signed_qty
            if pos.qty == 0:
                pos.avg_price = 0.0
            elif (pos.qty > 0 and signed_qty > 0) or (pos.qty < 0 and signed_qty < 0):
                pos.avg_price = fill.price
        pos.mark_price = fill.price
        self.metrics.increment('portfolio_fills_applied_total')

    def positions(self) -> list[Position]:
        return list(self._positions.values())

    def snapshot(self) -> PortfolioSnapshot:
        realized = sum(p.realized_pnl for p in self._positions.values())
        unrealized = sum(p.unrealized_pnl for p in self._positions.values())
        gross_notional = sum(abs(p.qty * p.mark_price) for p in self._positions.values())
        return PortfolioSnapshot(realized, unrealized, gross_notional)
