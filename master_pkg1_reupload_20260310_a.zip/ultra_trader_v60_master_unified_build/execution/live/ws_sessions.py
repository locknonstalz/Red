from __future__ import annotations

import abc
import asyncio
import base64
import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from typing import Any, AsyncIterator, Protocol

import websockets

from common.models import StreamCheckpoint
from config.settings import VenueCredentials
from execution.live.recovery_engines import get_recovery_engine


@dataclass(slots=True)
class SessionMessage:
    venue: str
    channel: str
    payload: dict[str, Any]
    sequence: int | None = None
    checkpoint: str = ''


class SupportsRecovery(Protocol):
    venue: str
    channel: str
    async def lifecycle(self, resume_from: StreamCheckpoint | None = None) -> AsyncIterator[SessionMessage]: ...
    async def recover_gap(self, since: StreamCheckpoint | None, until_sequence: int | None) -> list[SessionMessage]: ...
    async def stop(self) -> None: ...


class BasePrivateWsSession(abc.ABC):
    venue: str
    ws_url: str
    channel: str = 'private'

    def __init__(self, credentials: VenueCredentials, *, testnet: bool = False, symbol: str = '') -> None:
        self.credentials = credentials
        self.testnet = testnet
        self.symbol = symbol
        self._stop = asyncio.Event()
        self.recovery_engine = get_recovery_engine(self.venue)

    async def __aiter__(self) -> AsyncIterator[SessionMessage]:
        async for item in self.messages():
            yield item

    async def stop(self) -> None:
        self._stop.set()

    @abc.abstractmethod
    async def messages(self) -> AsyncIterator[SessionMessage]:
        raise NotImplementedError

    async def lifecycle(self, resume_from: StreamCheckpoint | None = None) -> AsyncIterator[SessionMessage]:
        _ = resume_from
        async for item in self.messages():
            yield item

    async def recover_gap(self, since: StreamCheckpoint | None, until_sequence: int | None) -> list[SessionMessage]:
        _ = until_sequence
        requests = self.recovery_engine.build_requests(since, self.symbol or None)
        synthesized = []
        base_seq = since.sequence if since and since.sequence is not None else 0
        for idx, req in enumerate(requests, start=1):
            synthesized.append(SessionMessage(self.venue, self.channel, {'recovery': {'method': req.method, 'path': req.path, 'params': req.params}}, sequence=base_seq + idx, checkpoint=str(base_seq + idx)))
        return synthesized

    def extract_sequence(self, payload: dict[str, Any]) -> int | None:
        for key in ('seq', 'sequence', 'u', 'updateId', 'id'):
            value = payload.get(key)
            if isinstance(value, int):
                return value
            if isinstance(value, str) and value.isdigit():
                return int(value)
        return None

    def extract_checkpoint(self, payload: dict[str, Any]) -> str:
        for key in ('checkpoint', 'cursor', 'token', 'sequence', 'seq', 'creationTime'):
            value = payload.get(key)
            if value not in (None, ''):
                return str(value)
        return ''


class ReplayPrivateWsSession(BasePrivateWsSession):
    venue = 'replay'
    ws_url = ''

    def __init__(self, venue: str, frames: list[dict[str, Any]], *, reconnect_frames: list[list[dict[str, Any]]] | None = None, gap_frames: list[dict[str, Any]] | None = None, fail_after_batches: int = 0) -> None:
        self.venue = venue
        super().__init__(VenueCredentials())
        self.frames = frames
        self.reconnect_frames = reconnect_frames or []
        self.gap_frames = gap_frames or []
        self.fail_after_batches = fail_after_batches
        self.channel = 'private'
        self._lifecycle_calls = 0

    async def messages(self) -> AsyncIterator[SessionMessage]:
        async for item in self.lifecycle(None):
            yield item

    async def lifecycle(self, resume_from: StreamCheckpoint | None = None) -> AsyncIterator[SessionMessage]:
        self._lifecycle_calls += 1
        batches = [self.frames] + self.reconnect_frames
        batch = batches[min(self._lifecycle_calls - 1, len(batches) - 1)]
        for idx, frame in enumerate(batch, start=1):
            if self._stop.is_set():
                break
            await asyncio.sleep(0)
            checkpoint = self.extract_checkpoint(frame) or (resume_from.checkpoint if resume_from else '')
            yield SessionMessage(venue=self.venue, channel=self.channel, payload=frame, sequence=self.extract_sequence(frame), checkpoint=checkpoint)
            if self.fail_after_batches and idx >= self.fail_after_batches and self._lifecycle_calls == 1:
                raise ConnectionError(f'{self.venue} simulated disconnect')

    async def recover_gap(self, since: StreamCheckpoint | None, until_sequence: int | None) -> list[SessionMessage]:
        _ = until_sequence
        out = []
        for frame in self.gap_frames:
            out.append(SessionMessage(self.venue, self.channel, frame, sequence=self.extract_sequence(frame), checkpoint=self.extract_checkpoint(frame)))
        if out:
            return out
        return await super().recover_gap(since, until_sequence)


class WebsocketJsonSession(BasePrivateWsSession):
    heartbeat_sec: float = 15.0

    async def auth_payload(self) -> dict[str, Any] | None:
        return None

    async def subscriptions(self) -> list[dict[str, Any]]:
        return []

    async def on_connected(self, ws, resume_from: StreamCheckpoint | None = None) -> None:
        _ = ws, resume_from

    async def pre_auth(self, ws, resume_from: StreamCheckpoint | None = None) -> None:
        auth = await self.auth_payload()
        if auth:
            await ws.send(json.dumps(auth))
        await self.on_connected(ws, resume_from)
        for sub in await self.subscriptions():
            await ws.send(json.dumps(sub))

    async def messages(self) -> AsyncIterator[SessionMessage]:
        async for item in self.lifecycle(None):
            yield item

    async def lifecycle(self, resume_from: StreamCheckpoint | None = None) -> AsyncIterator[SessionMessage]:
        async with websockets.connect(self.ws_url, ping_interval=self.heartbeat_sec) as ws:
            await self.pre_auth(ws, resume_from)
            while not self._stop.is_set():
                raw = await ws.recv()
                payload = json.loads(raw)
                yield SessionMessage(venue=self.venue, channel=self.channel, payload=payload, sequence=self.extract_sequence(payload), checkpoint=self.extract_checkpoint(payload))


class BinancePrivateWsSession(WebsocketJsonSession):
    venue = 'binance'
    ws_url = 'wss://ws-api.binance.com:443/ws-api/v3'

    def __init__(self, credentials: VenueCredentials, *, testnet: bool = False, symbol: str = '') -> None:
        effective_testnet = testnet or credentials.testnet
        super().__init__(credentials, testnet=effective_testnet, symbol=symbol)
        if effective_testnet:
            self.ws_url = 'wss://ws-api.testnet.binance.vision/ws-api/v3'

    async def auth_payload(self) -> dict[str, Any] | None:
        ts = int(time.time() * 1000)
        payload = f'apiKey={self.credentials.api_key}&timestamp={ts}'
        signature = hmac.new(self.credentials.api_secret.encode(), payload.encode(), hashlib.sha256).hexdigest()
        return {'method': 'session.logon', 'params': {'apiKey': self.credentials.api_key, 'timestamp': ts, 'signature': signature}, 'id': 1}

    async def subscriptions(self) -> list[dict[str, Any]]:
        return [{'method': 'userDataStream.subscribe', 'id': 2}]

    def extract_sequence(self, payload: dict[str, Any]) -> int | None:
        event = payload.get('event', payload)
        return super().extract_sequence(event)

    def extract_checkpoint(self, payload: dict[str, Any]) -> str:
        event = payload.get('event', payload)
        return super().extract_checkpoint(event)


class BybitPrivateWsSession(WebsocketJsonSession):
    venue = 'bybit'
    ws_url = 'wss://stream.bybit.com/v5/private'

    def __init__(self, credentials: VenueCredentials, *, testnet: bool = False, symbol: str = '') -> None:
        super().__init__(credentials, testnet=testnet, symbol=symbol)
        if testnet:
            self.ws_url = 'wss://stream-testnet.bybit.com/v5/private'

    async def auth_payload(self) -> dict[str, Any] | None:
        expires = int((time.time() + 10) * 1000)
        sign_payload = f'GET/realtime{expires}'
        signature = hmac.new(self.credentials.api_secret.encode(), sign_payload.encode(), hashlib.sha256).hexdigest()
        return {'op': 'auth', 'args': [self.credentials.api_key, expires, signature]}

    async def subscriptions(self) -> list[dict[str, Any]]:
        return [{'op': 'subscribe', 'args': ['execution', 'wallet', 'order']}]

    def extract_sequence(self, payload: dict[str, Any]) -> int | None:
        if 'creationTime' in payload and str(payload['creationTime']).isdigit():
            return int(payload['creationTime'])
        if isinstance(payload.get('data'), list) and payload['data']:
            item = payload['data'][0]
            if 'creationTime' in item and str(item['creationTime']).isdigit():
                return int(item['creationTime'])
        return super().extract_sequence(payload)

    def extract_checkpoint(self, payload: dict[str, Any]) -> str:
        return str(payload.get('id') or payload.get('creationTime') or super().extract_checkpoint(payload))


class MexcPrivateWsSession(WebsocketJsonSession):
    venue = 'mexc'
    ws_url = 'wss://wbs-api.mexc.com/ws'

    def __init__(self, credentials: VenueCredentials, *, testnet: bool = False, symbol: str = '') -> None:
        super().__init__(credentials, testnet=testnet, symbol=symbol)
        self.listen_key = ''

    def create_listen_key_request(self) -> dict[str, Any]:
        return {'method': 'POST', 'path': '/api/v3/userDataStream'}

    def extend_listen_key_request(self) -> dict[str, Any]:
        return {'method': 'PUT', 'path': '/api/v3/userDataStream', 'params': {'listenKey': self.listen_key}}

    async def auth_payload(self) -> dict[str, Any] | None:
        return None

    async def on_connected(self, ws, resume_from: StreamCheckpoint | None = None) -> None:
        _ = ws, resume_from
        if self.listen_key:
            self.ws_url = f'wss://wbs-api.mexc.com/ws?listenKey={self.listen_key}'

    async def subscriptions(self) -> list[dict[str, Any]]:
        return []


class BitgetPrivateWsSession(WebsocketJsonSession):
    venue = 'bitget'
    ws_url = 'wss://ws.bitget.com/v2/ws/private'

    async def auth_payload(self) -> dict[str, Any] | None:
        ts = str(int(time.time()))
        sign_payload = f'{ts}GET/user/verify'
        digest = hmac.new(self.credentials.api_secret.encode(), sign_payload.encode(), hashlib.sha256).digest()
        signature = base64.b64encode(digest).decode()
        return {'op': 'login', 'args': [{'apiKey': self.credentials.api_key, 'passphrase': self.credentials.passphrase, 'timestamp': ts, 'sign': signature}]}

    async def subscriptions(self) -> list[dict[str, Any]]:
        return [{'op': 'subscribe', 'args': [{'instType': 'SPOT', 'channel': 'orders', 'instId': 'default'}, {'instType': 'SPOT', 'channel': 'account', 'instId': 'default'}]}]

    def extract_sequence(self, payload: dict[str, Any]) -> int | None:
        if isinstance(payload.get('data'), list) and payload['data']:
            item = payload['data'][0]
            for key in ('uTime', 'cTime'):
                if key in item and str(item[key]).isdigit():
                    return int(item[key])
        return super().extract_sequence(payload)

    def extract_checkpoint(self, payload: dict[str, Any]) -> str:
        if isinstance(payload.get('data'), list) and payload['data']:
            item = payload['data'][0]
            return str(item.get('uTime') or item.get('cTime') or super().extract_checkpoint(payload))
        return super().extract_checkpoint(payload)


def build_private_ws_session(venue: str, credentials: VenueCredentials) -> BasePrivateWsSession:
    mapping = {
        'binance': BinancePrivateWsSession,
        'bybit': BybitPrivateWsSession,
        'mexc': MexcPrivateWsSession,
        'bitget': BitgetPrivateWsSession,
    }
    try:
        return mapping[venue.lower()](credentials, testnet=credentials.testnet)
    except KeyError as exc:
        raise ValueError(f'unsupported venue: {venue}') from exc
