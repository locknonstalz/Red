from __future__ import annotations

from common.bus import EventBus
from common.models import Fill, Order, OrderStatus, Tick
from execution.broker import Broker
from execution.circuit_breakers import CircuitBreaker
from execution.filters import PrecisionFilterService
from execution.live.rest_base import BaseRestBroker
from execution.retry import RetryPolicy, retry_async
from execution.quality import ExecutionQualityAttributionService
from execution.tactics import ExecutionTacticsService
from capital.protection import CapitalProtectionService
from common.logging import get_logger
from research.venue_health import VenueHealthScoringService
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from risk.risk_service import RiskService
from storage.base import Journal


class ExecutionService:
    def __init__(self, bus: EventBus, broker: Broker, journal: Journal, portfolio: PortfolioService, risk: RiskService, metrics: MetricsRegistry, *, circuit_breaker: CircuitBreaker | None = None, filters: PrecisionFilterService | None = None, capital_protection: CapitalProtectionService | None = None, venue_health: VenueHealthScoringService | None = None, execution_quality: ExecutionQualityAttributionService | None = None, tactics: ExecutionTacticsService | None = None) -> None:
        self.bus = bus
        self.broker = broker
        self.journal = journal
        self.portfolio = portfolio
        self.risk = risk
        self.metrics = metrics
        self.circuit_breaker = circuit_breaker or CircuitBreaker(5, 30)
        self.filters = filters or PrecisionFilterService()
        self.capital_protection = capital_protection
        self.venue_health = venue_health
        self.execution_quality = execution_quality
        self.tactics = tactics
        self._last_ticks: dict[tuple[str, str], Tick] = {}
        self.log = get_logger('execution')

    def update_market_tick(self, tick: Tick) -> None:
        self._last_ticks[(tick.venue, tick.symbol)] = tick
        if self.venue_health is not None:
            self.venue_health.observe_tick(tick)
        self.portfolio.mark_price(tick.symbol, tick.price, venue=tick.venue)

    def last_tick_for(self, venue: str, symbol: str) -> Tick | None:
        return self._last_ticks.get((venue, symbol))

    async def submit_order(self, order: Order, market_tick: Tick | None) -> bool:
        self.log.info('order_submit_started', extra={'strategy': order.strategy, 'venue': order.venue, 'symbol': order.symbol, 'side': order.side.value, 'qty': order.qty, 'order_type': order.order_type.value, 'limit_price': order.limit_price})
        if self.capital_protection is not None:
            capital_decision = self.capital_protection.evaluate_order(order, market_tick)
            if capital_decision.adjusted_qty is not None:
                order.qty = capital_decision.adjusted_qty
            self.journal.record_order(order, note=f'capital={capital_decision.reason}')
            if not capital_decision.allowed:
                order.status = OrderStatus.REJECTED
                self.journal.update_order_status(order.client_order_id, order.status, note=capital_decision.reason)
                self.metrics.increment('capital_protection_rejections_total')
                self.capital_protection.note_execution_rejection(capital_decision.reason)
                self.log.info('order_submit_failed', extra={'strategy': order.strategy, 'venue': order.venue, 'symbol': order.symbol, 'reason_code': capital_decision.reason, 'reason_text': 'Capital protection rejected order before submit'})
                return False
        decision = self.risk.check_order(order, market_tick)
        self.journal.record_order(order, note=f'risk={decision.reason}')
        if not decision.allowed:
            order.status = OrderStatus.REJECTED
            self.journal.update_order_status(order.client_order_id, order.status)
            if self.capital_protection is not None:
                self.capital_protection.note_execution_rejection(decision.reason)
            self.log.info('order_submit_failed', extra={'strategy': order.strategy, 'venue': order.venue, 'symbol': order.symbol, 'reason_code': decision.reason, 'reason_text': 'Risk service rejected order before submit'})
            return False
        if not self.circuit_breaker.allow():
            order.status = OrderStatus.REJECTED
            self.journal.update_order_status(order.client_order_id, order.status, note='circuit_breaker_open')
            self.metrics.increment('execution_rejections_circuit_total')
            if self.capital_protection is not None:
                self.capital_protection.note_execution_rejection('execution_circuit_breaker')
            self.log.info('order_submit_failed', extra={'strategy': order.strategy, 'venue': order.venue, 'symbol': order.symbol, 'reason_code': 'execution_circuit_breaker', 'reason_text': 'Execution circuit breaker is open'})
            return False
        market_price = market_tick.ask if order.side.value == 'BUY' else market_tick.bid
        venue_health_score = 0.7 if self.venue_health is None else (self.venue_health.snapshot(order.venue).score / 100.0)
        plan = None
        if self.tactics is not None and self.tactics.enabled_for(order.strategy):
            plan = self.tactics.build_plan(order, market_tick, venue_health_score=venue_health_score)
            self.journal.record_order(order, note=f'execution_plan={plan.policy.value.lower()} slices={plan.slice_count} fill_prob={plan.queue_fill_probability:.2f}')
        try:
            if isinstance(self.broker, BaseRestBroker):
                venue_filter = await self.broker.fetch_symbol_filter(order.symbol)
                self.log.info('order_submit_validated', extra={'strategy': order.strategy, 'venue': order.venue, 'symbol': order.symbol, 'tick_size': venue_filter.tick_size, 'step_size': venue_filter.step_size, 'min_qty': venue_filter.min_qty, 'min_notional': venue_filter.min_notional, 'reference_price': market_price})
                order = self.filters.normalize(order, venue_filter, market_price)
            order.status = OrderStatus.ACCEPTED
            self.journal.update_order_status(order.client_order_id, order.status)
            child_fills = []
            if plan is None:
                if self.execution_quality is not None:
                    self.execution_quality.observe_submission(order, market_tick)
                child_fills = [await retry_async(lambda: self.broker.submit(order, market_price=market_price), RetryPolicy())]
            else:
                for idx, slice_plan in enumerate(plan.slices, start=1):
                    child_order = Order(strategy=order.strategy, venue=order.venue, symbol=order.symbol, side=order.side, qty=slice_plan.qty, order_type=slice_plan.order_type, limit_price=slice_plan.limit_price, execution_policy=slice_plan.execution_policy, parent_order_id=order.client_order_id, slice_index=idx, slice_count=plan.slice_count)
                    if self.execution_quality is not None:
                        self.execution_quality.observe_submission(child_order, market_tick)
                    child_fill = await retry_async(lambda o=child_order: self.broker.submit(o, market_price=market_price), RetryPolicy())
                    child_fill.client_order_id = order.client_order_id
                    child_fill.strategy = order.strategy
                    child_fills.append(child_fill)
            fill_qty = sum(f.qty for f in child_fills)
            fill_fee = sum(f.fee for f in child_fills)
            fill_price = (sum(f.qty * f.price for f in child_fills) / fill_qty) if fill_qty > 0 else market_price
            fill = Fill(client_order_id=order.client_order_id, venue=order.venue, symbol=order.symbol, side=order.side, qty=fill_qty, price=fill_price, fee=fill_fee, strategy=order.strategy)
            self.circuit_breaker.on_success()
            if self.venue_health is not None:
                self.venue_health.record_execution_result(order.venue, success=True)
        except Exception as exc:
            self.log.info('order_submit_failed', extra={'strategy': order.strategy, 'venue': order.venue, 'symbol': order.symbol, 'reason_code': str(exc), 'reason_text': f'Order submit failed: {exc}'})
            self.circuit_breaker.on_failure()
            self.journal.enqueue_dead_letter('orders', order.client_order_id, str(exc))
            self.metrics.increment('execution_dlq_total')
            if self.venue_health is not None:
                self.venue_health.record_execution_result(order.venue, success=False)
            raise
        if fill.qty > 0:
            order.filled_qty = fill.qty
            order.avg_fill_price = fill.price
            order.status = OrderStatus.FILLED
            self.journal.update_order_status(order.client_order_id, order.status)
            self.journal.record_fill(fill)
            self.portfolio.apply_fill(fill)
            self.log.info('order_submit_succeeded', extra={'strategy': order.strategy, 'venue': order.venue, 'symbol': order.symbol, 'filled_qty': fill.qty, 'avg_fill_price': fill.price, 'status': order.status.value})
            if self.execution_quality is not None:
                self.execution_quality.observe_fill(fill)
            if self.capital_protection is not None:
                self.capital_protection.on_fill(fill)
            self.risk.on_terminal_order(order.client_order_id)
            await self.bus.publish('fills', fill)
        else:
            order.status = OrderStatus.ACCEPTED
            self.journal.record_order(order, note='accepted_live_no_fill_yet')
        self.metrics.increment('orders_submitted_total')
        self.metrics.increment(f'orders_{order.strategy}_submitted_total')
        return True
