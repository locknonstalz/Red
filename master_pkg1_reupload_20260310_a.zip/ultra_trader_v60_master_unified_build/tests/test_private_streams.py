from execution.live.private_streams import BinancePrivateStreamAdapter, BybitPrivateStreamAdapter, BitgetPrivateStreamAdapter, MexcPrivateStreamAdapter


def test_binance_private_execution_and_balance_parsing():
    adapter = BinancePrivateStreamAdapter()
    fill = adapter.parse_execution({'e': 'executionReport', 'x': 'TRADE', 'c': 'abc', 'i': 1, 's': 'BTCUSDT', 'S': 'BUY', 'l': '0.01', 'L': '100', 'n': '0.01', 't': 10, 'E': 1700000000000})
    assert fill and fill.client_order_id == 'abc' and fill.qty == 0.01
    balances = adapter.parse_balance({'e': 'outboundAccountPosition', 'E': 1700000000000, 'B': [{'a': 'USDT', 'f': '100', 'l': '2'}]})
    assert balances and balances[0].asset == 'USDT'


def test_bybit_and_bitget_and_mexc_private_parsers():
    bybit = BybitPrivateStreamAdapter()
    fills = bybit.parse_execution({'topic': 'execution.spot', 'creationTime': 1700000000000, 'data': [{'orderLinkId': 'oid', 'orderId': '1', 'symbol': 'BTCUSDT', 'side': 'Buy', 'execQty': '0.01', 'execPrice': '100', 'execFee': '0.1', 'execId': 't1'}]})
    assert fills and fills[0].trade_id == 't1'
    bitget = BitgetPrivateStreamAdapter()
    updates = bitget.parse_order({'arg': {'channel': 'orders'}, 'data': [{'clientOid': 'c1', 'orderId': '1', 'instId': 'BTCUSDT', 'status': 'filled', 'accBaseVolume': '0.01', 'priceAvg': '101', 'uTime': '1700000000000'}]})
    assert updates and updates[0].status == 'filled'
    mexc = MexcPrivateStreamAdapter()
    fill = mexc.parse_orders({'c': 'spot@private.orders.v3.api', 't': 1700000000000, 's': 'BTCUSDT', 'd': {'privateOrders': {'clientId': 'c1', 'orderId': '2', 'tradeType': 1, 'quantity': '0.01', 'amount': '0.01', 'avgPrice': '100', 'tradeId': 't2'}}})
    assert fill and fill.trade_id == 't2'
