from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from statistics import mean

from common.models import Fill
from research.attribution import StrategyAttributionService
from research.profitability import ProfitabilityAdvisorService


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class Hypothesis:
    hypothesis_id: str
    title: str
    description: str
    strategies: tuple[str, ...]
    factors: tuple[str, ...]
    expected_edge: str
    status: str = 'draft'
    created_at: datetime = field(default_factory=utc_now)
    tags: tuple[str, ...] = ()


class HypothesisRegistry:
    def __init__(self) -> None:
        self._items: dict[str, Hypothesis] = {}

    def register(self, hypothesis_id: str, title: str, description: str, *, strategies: list[str] | tuple[str, ...], factors: list[str] | tuple[str, ...], expected_edge: str, tags: list[str] | tuple[str, ...] = ()) -> Hypothesis:
        item = Hypothesis(hypothesis_id=hypothesis_id, title=title, description=description, strategies=tuple(strategies), factors=tuple(factors), expected_edge=expected_edge, tags=tuple(tags))
        self._items[hypothesis_id] = item
        return item

    def set_status(self, hypothesis_id: str, status: str) -> Hypothesis | None:
        item = self._items.get(hypothesis_id)
        if item is not None:
            item.status = status
        return item

    def list(self) -> list[Hypothesis]:
        return sorted(self._items.values(), key=lambda x: x.created_at)


@dataclass(slots=True)
class ExperimentRun:
    experiment_id: str
    hypothesis_id: str
    strategy: str
    regime: str
    started_at: datetime
    completed_at: datetime | None = None
    pnl: float = 0.0
    trades: int = 0
    win_rate: float = 0.0
    sharpe_like: float = 0.0
    turnover: float = 0.0
    notes: str = ''
    features: dict[str, float] = field(default_factory=dict)
    outcomes: dict[str, float] = field(default_factory=dict)


class ExperimentTracker:
    def __init__(self) -> None:
        self._runs: dict[str, ExperimentRun] = {}

    def start(self, experiment_id: str, hypothesis_id: str, strategy: str, regime: str, *, features: dict[str, float] | None = None) -> ExperimentRun:
        run = ExperimentRun(experiment_id=experiment_id, hypothesis_id=hypothesis_id, strategy=strategy, regime=regime, started_at=utc_now(), features=dict(features or {}))
        self._runs[experiment_id] = run
        return run

    def complete(self, experiment_id: str, *, pnl: float, trades: int, win_rate: float, sharpe_like: float, turnover: float, notes: str = '', outcomes: dict[str, float] | None = None) -> ExperimentRun | None:
        run = self._runs.get(experiment_id)
        if run is None:
            return None
        run.completed_at = utc_now()
        run.pnl = pnl
        run.trades = trades
        run.win_rate = win_rate
        run.sharpe_like = sharpe_like
        run.turnover = turnover
        run.notes = notes
        run.outcomes = dict(outcomes or {})
        return run

    def list(self, strategy: str | None = None) -> list[ExperimentRun]:
        rows = self._runs.values()
        if strategy is not None:
            rows = [row for row in rows if row.strategy == strategy]
        return sorted(rows, key=lambda x: x.started_at)


@dataclass(slots=True)
class FactorImportance:
    factor: str
    score: float
    support: int


class FactorImportanceService:
    def from_runs(self, runs: list[ExperimentRun]) -> list[FactorImportance]:
        agg: dict[str, list[float]] = defaultdict(list)
        support: dict[str, int] = defaultdict(int)
        for run in runs:
            outcome = float(run.pnl + run.sharpe_like * 100.0 + run.win_rate * 25.0)
            for factor, value in run.features.items():
                agg[factor].append(value * outcome)
                support[factor] += 1
        rows = [FactorImportance(factor=factor, score=sum(vals) / max(len(vals), 1), support=support[factor]) for factor, vals in agg.items()]
        return sorted(rows, key=lambda x: abs(x.score), reverse=True)

    def from_model_weights(self, weights: dict[str, float]) -> list[FactorImportance]:
        return sorted([FactorImportance(factor=k, score=v, support=1) for k, v in weights.items()], key=lambda x: abs(x.score), reverse=True)


@dataclass(slots=True)
class RegimePerformance:
    strategy: str
    regime: str
    realized_pnl: float
    fills: int
    avg_pnl_per_fill: float
    win_rate: float


class RegimePerformanceDecomposer:
    def __init__(self) -> None:
        self._current_regime: dict[tuple[str, str], str] = {}
        self._stats: dict[tuple[str, str], dict[str, float]] = defaultdict(lambda: defaultdict(float))

    def update_regime(self, venue: str, symbol: str, regime: str) -> None:
        self._current_regime[(venue, symbol)] = regime

    def observe_fill(self, fill: Fill, realized_pnl_hint: float | None = None) -> None:
        regime = self._current_regime.get((fill.venue, fill.symbol), 'unknown')
        key = (fill.strategy or 'unknown', regime)
        pnl = float(realized_pnl_hint or (-fill.fee))
        self._stats[key]['realized_pnl'] += pnl
        self._stats[key]['fills'] += 1
        if pnl >= 0:
            self._stats[key]['wins'] += 1

    def snapshot(self) -> list[RegimePerformance]:
        out: list[RegimePerformance] = []
        for (strategy, regime), stats in self._stats.items():
            fills = int(stats.get('fills', 0))
            wins = float(stats.get('wins', 0))
            out.append(RegimePerformance(strategy=strategy, regime=regime, realized_pnl=float(stats.get('realized_pnl', 0.0)), fills=fills, avg_pnl_per_fill=float(stats.get('realized_pnl', 0.0)) / max(fills, 1), win_rate=wins / max(fills, 1)))
        return sorted(out, key=lambda x: (x.strategy, x.regime))


@dataclass(slots=True)
class DecayReport:
    strategy: str
    decay_score: float
    is_decaying: bool
    recent_mean_pnl: float
    baseline_mean_pnl: float
    recommendation: str


class StrategyDecayDetector:
    def __init__(self, window: int = 20) -> None:
        self.window = window
        self._recent: dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=window))

    def observe_fill(self, fill: Fill, realized_pnl_hint: float | None = None) -> None:
        self._recent[fill.strategy or 'unknown'].append(float(realized_pnl_hint or (-fill.fee)))

    def assess(self, strategy: str, attribution: StrategyAttributionService) -> DecayReport:
        recent = list(self._recent.get(strategy, ()))
        recent_mean = mean(recent) if recent else 0.0
        snap = attribution.snapshot().get(strategy)
        baseline = 0.0 if snap is None else snap.realized_pnl / max(snap.fills, 1)
        decay_score = 0.0 if baseline == 0 else max(0.0, (baseline - recent_mean) / max(abs(baseline), 1.0)) * 100.0
        is_decaying = len(recent) >= min(5, self.window) and recent_mean < baseline * 0.5
        recommendation = 'keep_running'
        if is_decaying and decay_score >= 50.0:
            recommendation = 'cut_risk_or_shadow'
        elif decay_score >= 25.0:
            recommendation = 'watch_closely'
        return DecayReport(strategy=strategy, decay_score=decay_score, is_decaying=is_decaying, recent_mean_pnl=recent_mean, baseline_mean_pnl=baseline, recommendation=recommendation)


@dataclass(slots=True)
class SleeveAllocation:
    strategy: str
    weight: float
    target_notional_pct: float
    rationale: str


class AlphaSleevePortfolioOptimizer:
    def __init__(self, profitability: ProfitabilityAdvisorService, attribution: StrategyAttributionService, decay_detector: StrategyDecayDetector) -> None:
        self.profitability = profitability
        self.attribution = attribution
        self.decay_detector = decay_detector

    def optimize(self, strategies: list[str], venue: str, symbol: str) -> list[SleeveAllocation]:
        rows: list[tuple[str, float, str]] = []
        for strategy in strategies:
            prof = self.profitability.assess(strategy, venue, symbol)
            attr = self.attribution.snapshot().get(strategy)
            decay = self.decay_detector.assess(strategy, self.attribution)
            turnover_penalty = 0.0 if attr is None else min(attr.gross_turnover / 1_000_000.0, 15.0)
            raw = max(prof.profitability_score - turnover_penalty - decay.decay_score * 0.5, 0.0)
            rationale = f"profitability={prof.profitability_score:.1f}; decay={decay.decay_score:.1f}; recommendation={prof.recommendation}/{decay.recommendation}"
            rows.append((strategy, raw, rationale))
        total = sum(score for _, score, _ in rows) or 1.0
        return [SleeveAllocation(strategy=s, weight=score / total, target_notional_pct=score / total * 100.0, rationale=r) for s, score, r in sorted(rows, key=lambda x: x[1], reverse=True)]


@dataclass(slots=True)
class AlphaLabSnapshot:
    hypotheses: list[Hypothesis]
    experiments: list[ExperimentRun]
    factor_importance: list[FactorImportance]
    regime_performance: list[RegimePerformance]
    decay_reports: list[DecayReport]
    sleeve_allocations: list[SleeveAllocation]


class AlphaLabService:
    def __init__(self, profitability: ProfitabilityAdvisorService, attribution: StrategyAttributionService) -> None:
        self.hypotheses = HypothesisRegistry()
        self.experiments = ExperimentTracker()
        self.factor_importance = FactorImportanceService()
        self.regime = RegimePerformanceDecomposer()
        self.decay = StrategyDecayDetector()
        self.optimizer = AlphaSleevePortfolioOptimizer(profitability, attribution, self.decay)
        self.attribution = attribution
        self._last_factor_snapshot: list[FactorImportance] = []

    def update_regime(self, venue: str, symbol: str, regime: str) -> None:
        self.regime.update_regime(venue, symbol, regime)

    def observe_fill(self, fill: Fill, realized_pnl_hint: float | None = None) -> None:
        self.regime.observe_fill(fill, realized_pnl_hint=realized_pnl_hint)
        self.decay.observe_fill(fill, realized_pnl_hint=realized_pnl_hint)

    def refresh_factor_snapshot(self, model_weights: dict[str, float] | None = None) -> list[FactorImportance]:
        runs = [run for run in self.experiments.list() if run.completed_at is not None]
        ranked = self.factor_importance.from_runs(runs)
        if model_weights:
            ranked.extend(self.factor_importance.from_model_weights(model_weights))
            merged: dict[str, list[float]] = defaultdict(list)
            support: dict[str, int] = defaultdict(int)
            for row in ranked:
                merged[row.factor].append(row.score)
                support[row.factor] += row.support
            ranked = [FactorImportance(factor=f, score=sum(vals) / len(vals), support=support[f]) for f, vals in merged.items()]
            ranked = sorted(ranked, key=lambda x: abs(x.score), reverse=True)
        self._last_factor_snapshot = ranked[:25]
        return self._last_factor_snapshot

    def snapshot(self, strategies: list[str], venue: str, symbol: str) -> AlphaLabSnapshot:
        return AlphaLabSnapshot(
            hypotheses=self.hypotheses.list(),
            experiments=self.experiments.list(),
            factor_importance=list(self._last_factor_snapshot),
            regime_performance=self.regime.snapshot(),
            decay_reports=[self.decay.assess(name, self.attribution) for name in strategies],
            sleeve_allocations=self.optimizer.optimize(strategies, venue, symbol),
        )
