from __future__ import annotations

from backtesting.engine import BacktestConfig, BacktestEngine
from common.models import OrderType, Signal, Side, Tick
from microstructure.orderbook import BookLevel, L2BookSnapshot, L3BookSnapshot, L3Order, OrderBookIntelligenceService


class FlipStrategy:
    def __init__(self) -> None:
        self.step = 0

    def on_tick(self, tick: Tick):
        self.step += 1
        if self.step == 1:
            return Signal(strategy='flip', venue=tick.venue, symbol=tick.symbol, side=Side.BUY, strength=0.8, reason='entry', qty=0.1, order_type=OrderType.MARKET)
        if self.step == 5:
            return Signal(strategy='flip', venue=tick.venue, symbol=tick.symbol, side=Side.SELL, strength=0.8, reason='exit', qty=0.1, order_type=OrderType.MARKET)
        return None


def test_orderbook_intelligence_supports_l2_and_l3() -> None:
    svc = OrderBookIntelligenceService()
    svc.observe_l2(L2BookSnapshot(
        venue='binance',
        symbol='BTC/USDT',
        bids=[BookLevel(100.0, 3.0), BookLevel(99.9, 4.0)],
        asks=[BookLevel(100.1, 2.0), BookLevel(100.2, 5.0)],
        sequence=1,
    ))
    base = svc.snapshot('binance', 'BTC/USDT')
    assert base is not None
    assert base.microprice > 0
    svc.observe_l3(L3BookSnapshot(
        venue='binance',
        symbol='BTC/USDT',
        bids=[L3Order('b1', 'BUY', 100.0, 1.0), L3Order('b2', 'BUY', 100.0, 1.0), L3Order('b3', 'BUY', 99.9, 2.0)],
        asks=[L3Order('a1', 'SELL', 100.1, 0.5), L3Order('a2', 'SELL', 100.1, 0.5), L3Order('a3', 'SELL', 100.2, 3.0)],
        sequence=2,
    ))
    enriched = svc.snapshot('binance', 'BTC/USDT')
    assert enriched is not None
    assert enriched.queue_ahead_bid >= 2.0
    assert 0.0 <= enriched.adverse_selection_risk <= 1.0


def test_backtesting_engine_generates_report() -> None:
    ticks = [
        Tick(venue='binance', symbol='BTC/USDT', price=p, bid=p - 0.05, ask=p + 0.05)
        for p in [100.0, 100.3, 100.5, 100.7, 101.0, 101.2]
    ]
    report = BacktestEngine(BacktestConfig(fee_bps=0.0, slippage_bps=0.0, initial_cash=1000.0, max_position=0.5)).run(ticks, FlipStrategy())
    assert report.trades == 1
    assert report.realized_pnl > 0
    assert 0.0 <= report.win_rate <= 1.0
