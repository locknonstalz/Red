# Ultra Trader Control Center

Локальный desktop GUI для Windows.

## Что умеет
- Start / Stop / Restart движка
- запуск preflight одной кнопкой
- живой просмотр логов
- вкладка диагностики `strategy_waiting` и `strategy_signal_blocked`
- быстрый доступ к `.env`
- показ ключевых runtime-полей:
  - mode
  - venues
  - strategy stage
  - target notional
  - budget reason
  - equity
  - portfolio snapshot

## Запуск
1. Создайте и активируйте `.venv`
2. Установите зависимости
3. Запустите:

```powershell
.\.venv\Scripts\Activate.ps1
python .\gui_launcher.py
```

Либо двойным кликом по `start_gui.bat`.

## Важно
GUI не заменяет сам движок. Он запускает `app.py` как отдельный процесс и показывает его лог/состояние.
