from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from dataclasses import dataclass
from typing import Any

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer


@dataclass(frozen=True, slots=True)
class ControlPlanePrincipal:
    subject: str
    role: str
    scopes: tuple[str, ...] = ()


@dataclass(slots=True)
class AuthConfig:
    enabled: bool = False
    issuer: str = 'ultra-trader'
    signing_secret: str = 'change-me'
    token_ttl_sec: int = 3600
    static_tokens: dict[str, ControlPlanePrincipal] | None = None

    @classmethod
    def from_env(cls) -> 'AuthConfig':
        raw = os.getenv('CONTROL_PLANE_STATIC_TOKENS_JSON', '').strip()
        tokens: dict[str, ControlPlanePrincipal] = {}
        if raw:
            parsed = json.loads(raw)
            for token, meta in parsed.items():
                tokens[token] = ControlPlanePrincipal(
                    subject=str(meta.get('subject', meta.get('user', 'operator'))),
                    role=str(meta.get('role', 'viewer')),
                    scopes=tuple(meta.get('scopes', [])),
                )
        return cls(
            enabled=os.getenv('CONTROL_PLANE_AUTH_ENABLED', '0') == '1',
            issuer=os.getenv('CONTROL_PLANE_AUTH_ISSUER', 'ultra-trader'),
            signing_secret=os.getenv('CONTROL_PLANE_AUTH_SECRET', 'change-me'),
            token_ttl_sec=int(os.getenv('CONTROL_PLANE_TOKEN_TTL_SEC', '3600')),
            static_tokens=tokens or None,
        )


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()


def _b64url_decode(value: str) -> bytes:
    padding = '=' * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


class TokenAuthManager:
    def __init__(self, config: AuthConfig) -> None:
        self.config = config

    def mint_token(self, principal: ControlPlanePrincipal) -> str:
        payload = {
            'iss': self.config.issuer,
            'sub': principal.subject,
            'role': principal.role,
            'scopes': list(principal.scopes),
        }
        encoded = _b64url(json.dumps(payload, separators=(',', ':'), sort_keys=True).encode())
        sig = hmac.new(self.config.signing_secret.encode(), encoded.encode(), hashlib.sha256).hexdigest()
        return f'{encoded}.{sig}'

    def authenticate(self, token: str) -> ControlPlanePrincipal:
        if self.config.static_tokens and token in self.config.static_tokens:
            return self.config.static_tokens[token]
        if '.' not in token:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='invalid_token')
        encoded, sig = token.rsplit('.', 1)
        expected = hmac.new(self.config.signing_secret.encode(), encoded.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='invalid_signature')
        try:
            payload: dict[str, Any] = json.loads(_b64url_decode(encoded).decode())
        except Exception as exc:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='invalid_payload') from exc
        if payload.get('iss') != self.config.issuer:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='invalid_issuer')
        return ControlPlanePrincipal(
            subject=str(payload.get('sub', 'operator')),
            role=str(payload.get('role', 'viewer')),
            scopes=tuple(payload.get('scopes', [])),
        )


bearer = HTTPBearer(auto_error=False)


def require_principal(manager: TokenAuthManager, min_role: str = 'viewer'):
    hierarchy = {'viewer': 1, 'operator': 2, 'admin': 3}

    async def _dep(
        request: Request,
        credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
    ) -> ControlPlanePrincipal:
        if not manager.config.enabled:
            principal = ControlPlanePrincipal(subject='anonymous', role='admin')
            request.state.principal = principal
            return principal
        if credentials is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='missing_bearer_token')
        principal = manager.authenticate(credentials.credentials)
        if hierarchy.get(principal.role, 0) < hierarchy[min_role]:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail='insufficient_role')
        request.state.principal = principal
        return principal

    return _dep
