from __future__ import annotations

import asyncio
import json
from dataclasses import asdict, dataclass
from typing import Any

import uvicorn

from ai.decision_engine import AIDecisionEngine
from capital.protection import CapitalProtectionService
from common.bus import EventBus
from common.logging import get_logger
from config.settings import Settings, VenueCredentials
from control_plane.api import create_control_plane_app
from control_plane.auth import AuthConfig, ControlPlanePrincipal, TokenAuthManager
from control_plane.audit import AuditSigner
from control_plane.service import ControlPlaneService
from execution.broker import PaperBroker
from execution.circuit_breakers import CircuitBreaker
from execution.execution_service import ExecutionService
from execution.live.adapters import build_live_broker
from execution.live.ws_sessions import BasePrivateWsSession, build_private_ws_session
from market.demo_feed import DemoFeed, MultiVenueDemoFeed
from market.live.adapters import build_market_adapter
from market.live.base import BaseMarketAdapter, ExchangeCredentials
from ops.alerts import AlertRouter, GenericWebhookSink, PagerDutyEventsSink, SlackWebhookSink
from ops.metrics import MetricsRegistry
from ops.prometheus_exporter import start_metrics_server
from portfolio.portfolio_service import PortfolioService
from research.asset_analysis import AssetAnalysisService
from research.attribution import StrategyAttributionService
from research.candle_patterns import CandlePatternEngine
from research.external_research import ExternalResearchIngestionLayer
from research.indicators import IndicatorEngine
from research.regime import MarketRegimeClassifier
from research.scoring import SignalScoringLayer
from research.universe import UniverseSelectionEngine
from mlops.feature_store import FeatureRecord, FeatureStore
from mlops.lifecycle import AdvancedMLLifecycle
from research.allocator import StrategyAllocatorService
from research.connectors import ExternalAnalyticsHub
from research.venue_health import VenueHealthScoringService
from research.capacity import CapacityScoringService
from research.onchain import OnChainAnalyticsService
from research.profitability import ProfitabilityAdvisorService
from research.alpha_lab import AlphaLabService
from research.alpha_governance import AlphaGovernanceService
from data.production_data import ProductionDataLayer
from live_validation.validation import LiveValidationService
from capital.scaling import CapitalScalingEngine
from futures.analytics import FuturesAnalyticsService
from futures.connectors import FuturesMarketIntelService
from futures.liquidations import LiquidationAnalyticsService, LiquidationEvent
from futures.live_adapters import FuturesBrokerFactory
from risk.risk_service import RiskService
from risk.advanced_limits import AdvancedRiskSettings, CorrelationConcentrationRiskGuard
from services.live_orchestration import LiveOrchestrationService
from services.reconciliation import ReconciliationService
from storage.base import Journal
from storage.journal import build_journal
from strategy.factory import build_default_strategies
from strategy.shadow import ShadowDeploymentService
from strategy.strategy_service import StrategyService
from execution.sor import SmartOrderRouter
from execution.quality import ExecutionQualityAttributionService
from microstructure.orderbook import BookLevel, L2BookSnapshot, OrderBookIntelligenceService


class FeedGroup:
    def __init__(self, feeds: list[Any]) -> None:
        self.feeds = feeds

    async def run(self) -> None:
        async with asyncio.TaskGroup() as tg:
            for idx, feed in enumerate(self.feeds):
                tg.create_task(feed.run(), name=f'feed-{idx}')

    async def close(self) -> None:
        await asyncio.gather(*(feed.close() for feed in self.feeds), return_exceptions=True)


class CompositeBroker:
    venue = 'composite'

    def __init__(self, brokers: dict[str, Any]) -> None:
        self.brokers = brokers

    def _for(self, venue: str):
        try:
            return self.brokers[venue]
        except KeyError as exc:
            raise ValueError(f'unsupported broker venue: {venue}') from exc

    async def submit(self, order, market_price: float):
        return await self._for(order.venue).submit(order, market_price=market_price)

    async def list_open_orders(self) -> list[str]:
        out: list[str] = []
        for broker in self.brokers.values():
            out.extend(await broker.list_open_orders())
        return out

    async def fetch_balances(self):
        out = []
        for broker in self.brokers.values():
            out.extend(await broker.fetch_balances())
        return out

    async def fetch_positions(self):
        out = []
        for broker in self.brokers.values():
            out.extend(await broker.fetch_positions())
        return out

    async def aclose(self) -> None:
        await asyncio.gather(*(broker.aclose() for broker in self.brokers.values() if hasattr(broker, 'aclose')), return_exceptions=True)


@dataclass(slots=True)
class RuntimeBundle:
    settings: Settings
    bus: EventBus
    metrics: MetricsRegistry
    journal: Journal
    portfolio: PortfolioService
    risk: RiskService
    capital_protection: CapitalProtectionService
    broker: Any
    feed: Any
    execution: ExecutionService
    ai_engine: AIDecisionEngine
    strategy_service: StrategyService
    reconciliation: ReconciliationService
    orchestration: LiveOrchestrationService | None
    control_plane_service: ControlPlaneService
    control_plane_app: Any
    auth_manager: TokenAuthManager
    asset_analysis: AssetAnalysisService
    indicators: IndicatorEngine
    candles: CandlePatternEngine
    regime_classifier: MarketRegimeClassifier
    attribution: StrategyAttributionService
    universe: UniverseSelectionEngine
    external_research: ExternalResearchIngestionLayer
    feature_store: FeatureStore
    allocator: StrategyAllocatorService
    futures_analytics: FuturesAnalyticsService
    futures_intel: FuturesMarketIntelService
    analytics_hub: ExternalAnalyticsHub
    venue_health: VenueHealthScoringService
    shadow: ShadowDeploymentService
    execution_quality: ExecutionQualityAttributionService
    capacity: CapacityScoringService
    orderbook: OrderBookIntelligenceService
    onchain: OnChainAnalyticsService
    liquidations: LiquidationAnalyticsService
    ml_lifecycle: AdvancedMLLifecycle
    profitability: ProfitabilityAdvisorService
    alpha_lab: AlphaLabService
    alpha_governance: AlphaGovernanceService
    production_data: ProductionDataLayer
    live_validation: LiveValidationService
    capital_scaling: CapitalScalingEngine

    def snapshot(self) -> dict[str, Any]:
        return {
            'mode': self.settings.mode,
            'venues': list(self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues),
            'symbol': self.settings.default_symbol,
            'metrics': self.metrics.snapshot(),
            'protection': self.capital_protection.state_snapshot(),
            'portfolio': asdict(self.portfolio.snapshot()),
            'attribution': {k: asdict(v) for k, v in self.attribution.snapshot().items()},
            'selected_universe': [asdict(x) for x in self.universe.select([(venue, self.settings.default_symbol) for venue in (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)]).selected],
            'allocator': asdict(self.allocator.snapshot()),
            'futures_rankings': [asdict(x) for x in self.futures_analytics.rank()[:10]],
            'venue_health': [asdict(x) for x in self.venue_health.rank(self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)],
            'shadow': self.shadow.snapshot(),
            'execution_quality': {k: asdict(v) for k, v in self.execution_quality.snapshot().items()},
            'capacity_rankings': [asdict(x) for x in self.capacity.rank([(item.venue, item.symbol) for item in self.universe.select([(venue, self.settings.default_symbol) for venue in (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)]).selected])[:10]],
            'orderbook': (asdict(ob) if (ob := self.orderbook.snapshot((self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol)) is not None else {}),
            'onchain': (asdict(oc) if (oc := self.onchain.snapshot(self.settings.default_symbol)) is not None else {}),
            'liquidation': asdict(self.liquidations.snapshot((self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol)),
            'profitability': asdict(self.profitability.assess(next(iter(self.attribution.snapshot()), 'funding_carry'), (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol)),
            'alpha_lab': {
                'hypotheses': [asdict(x) for x in self.alpha_lab.snapshot(sorted(self.attribution.snapshot().keys()) or ['funding_carry'], (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol).hypotheses],
                'experiments': [asdict(x) for x in self.alpha_lab.snapshot(sorted(self.attribution.snapshot().keys()) or ['funding_carry'], (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol).experiments[-10:]],
                'factor_importance': [asdict(x) for x in self.alpha_lab.snapshot(sorted(self.attribution.snapshot().keys()) or ['funding_carry'], (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol).factor_importance[:10]],
                'decay_reports': [asdict(x) for x in self.alpha_lab.snapshot(sorted(self.attribution.snapshot().keys()) or ['funding_carry'], (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol).decay_reports],
                'sleeve_allocations': [asdict(x) for x in self.alpha_lab.snapshot(sorted(self.attribution.snapshot().keys()) or ['funding_carry'], (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol).sleeve_allocations],
            },
            'alpha_governance': self.alpha_governance.snapshot(sorted(self.attribution.snapshot().keys()) or ['funding_carry'], (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol),
            'production_data': self.production_data.snapshot(),
            'live_validation': self.live_validation.snapshot(),
            'capital_scaling': self.capital_scaling.snapshot(sorted(self.attribution.snapshot().keys()) or ['funding_carry'], (self.settings.live_venues if self.settings.mode in {'live', 'micro_live'} else self.settings.strategy.cross_exchange_venues)[0], self.settings.default_symbol).as_dict(),
        }


class TradingRuntime:
    def __init__(self, bundle: RuntimeBundle) -> None:
        self.bundle = bundle
        self.log = get_logger('runtime')
        self._tasks: list[asyncio.Task[Any]] = []
        self._server: uvicorn.Server | None = None
        self._server_task: asyncio.Task[Any] | None = None

    async def start(self) -> None:
        tick_watcher = self.bundle.bus.subscribe('ticks')

        async def market_cache() -> None:
            while True:
                tick = await tick_watcher.get()
                self.bundle.execution.update_market_tick(tick)
                self.bundle.asset_analysis.observe_tick(tick)
                self.bundle.indicators.observe_tick(tick)
                self.bundle.candles.observe_tick(tick)
                self.bundle.regime_classifier.observe_tick(tick)
                if (reg := self.bundle.regime_classifier.snapshot(tick.venue, tick.symbol)) is not None:
                    self.bundle.alpha_lab.update_regime(tick.venue, tick.symbol, reg.regime)
                self.bundle.venue_health.observe_tick(tick)
                synthetic_book = L2BookSnapshot(
                    venue=tick.venue,
                    symbol=tick.symbol,
                    bids=[BookLevel(price=tick.bid * (1 - i * 0.0001), size=max(1.0, tick.mid / (10000 + i * 1000)), orders=2 + i) for i in range(5)],
                    asks=[BookLevel(price=tick.ask * (1 + i * 0.0001), size=max(1.0, tick.mid / (10000 + i * 1000)), orders=2 + i) for i in range(5)],
                    sequence=int(tick.ts.timestamp() * 1_000_000),
                )
                self.bundle.orderbook.observe_l2(synthetic_book)
                if self.bundle.risk.advanced_guard is not None:
                    self.bundle.risk.advanced_guard.observe_tick(tick)
                self.bundle.futures_intel.from_payload(tick.venue, tick.symbol, {
                    'funding_rate': ((tick.ask - tick.bid) / tick.mid * 0.1) if tick.mid else 0.0,
                    'basis_bps': ((tick.price - tick.mid) / tick.mid * 10000.0) if tick.mid else 0.0,
                    'open_interest': max(tick.mid, 1.0) * 1000.0,
                })
                self.bundle.onchain.ingest(tick.symbol, exchange_inflow=max(tick.spread * 1000.0, 1.0), exchange_outflow=max((tick.mid - tick.bid) * 1500.0, 1.0), stablecoin_flow=max((tick.ask - tick.mid) * 1200.0, 1.0), whale_score=min(100.0, abs((tick.ask - tick.bid) / tick.mid * 100000.0) if tick.mid else 0.0))
                self.bundle.production_data.ingest(tick.venue, 'trade', {'venue': tick.venue, 'symbol': tick.symbol, 'price': tick.price, 'qty': max(tick.mid / 10000.0, 0.001)})
                self.bundle.production_data.ingest(tick.venue, 'l2_book', {'venue': tick.venue, 'symbol': tick.symbol, 'bids': len(synthetic_book.bids), 'asks': len(synthetic_book.asks)})
                self.bundle.production_data.ingest('onchain', 'onchain', {'symbol': tick.symbol, 'exchange_inflow': max(tick.spread * 1000.0, 1.0), 'exchange_outflow': max((tick.mid - tick.bid) * 1500.0, 1.0)})
                self.bundle.production_data.ingest('derivatives', 'funding', {'venue': tick.venue, 'symbol': tick.symbol, 'funding_rate': ((tick.ask - tick.bid) / tick.mid * 0.1) if tick.mid else 0.0})
                if tick.spread / max(tick.mid, 1e-12) > 0.00005:
                    self.bundle.liquidations.ingest(LiquidationEvent(venue=tick.venue, symbol=tick.symbol, side='LONG' if tick.price < tick.mid else 'SHORT', notional=max(tick.mid * 5, 1000.0)))
                feature_payload = {
                    'mid': tick.mid,
                    'spread_bps': (tick.spread / tick.mid * 10000.0) if tick.mid else 0.0,
                    'microprice_bias_bps': ((ob.microprice - ob.mid) / ob.mid * 10000.0) if (ob := self.bundle.orderbook.snapshot(tick.venue, tick.symbol)) is not None and ob.mid else 0.0,
                    'onchain_bias': self.bundle.onchain.alpha_bias(tick.symbol),
                }
                self.bundle.feature_store.append(FeatureRecord(symbol=tick.symbol, features=feature_payload, label=None))
                self.bundle.alpha_lab.refresh_factor_snapshot(getattr(getattr(self.bundle.ai_engine, 'model', None), 'weights', None))

        fill_watcher = self.bundle.bus.subscribe('fills')

        async def alpha_lab_fill_watch() -> None:
            while True:
                fill = await fill_watcher.get()
                self.bundle.alpha_lab.observe_fill(fill)

        self._tasks = [
            asyncio.create_task(market_cache(), name='market-cache'),
            asyncio.create_task(alpha_lab_fill_watch(), name='alpha-lab-fills'),
            asyncio.create_task(self.bundle.strategy_service.run(), name='strategy-service'),
            asyncio.create_task(self.bundle.feed.run(), name='market-feed'),
            asyncio.create_task(self.bundle.reconciliation.run(), name='reconciliation'),
        ]
        if self.bundle.orchestration is not None:
            self._tasks.append(asyncio.create_task(self.bundle.orchestration.run(), name='live-orchestration'))
        if self.bundle.settings.orchestration.prometheus_enabled:
            start_metrics_server(self.bundle.settings.orchestration.prometheus_port, self.bundle.metrics)
        if self.bundle.settings.control_plane.enabled:
            config = uvicorn.Config(
                self.bundle.control_plane_app,
                host=self.bundle.settings.control_plane.host,
                port=self.bundle.settings.control_plane.port,
                log_level='warning',
                access_log=False,
            )
            self._server = uvicorn.Server(config)
            self._server_task = asyncio.create_task(self._server.serve(), name='control-plane-server')
        self.log.info('runtime_started', extra=self.bundle.snapshot())

    async def run_for(self, seconds: float | None = None) -> None:
        await self.start()
        try:
            await asyncio.sleep(seconds if seconds is not None else self.bundle.settings.runtime_seconds)
        finally:
            await self.stop()

    async def stop(self) -> None:
        await self.bundle.feed.close()
        if self.bundle.orchestration is not None:
            await self.bundle.orchestration.stop()
        for task in self._tasks:
            task.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        if self._server is not None:
            self._server.should_exit = True
        if self._server_task is not None:
            await asyncio.gather(self._server_task, return_exceptions=True)
        if hasattr(self.bundle.broker, 'aclose'):
            await self.bundle.broker.aclose()
        self.bundle.ai_engine.persist()
        self.bundle.journal.close()
        self.log.info('runtime_stopped', extra={'metrics': self.bundle.metrics.snapshot()})


def venue_credentials(settings: Settings, venue: str) -> VenueCredentials:
    return {'binance': settings.binance, 'bybit': settings.bybit, 'mexc': settings.mexc, 'bitget': settings.bitget}[venue]


def _make_alert_router(settings: Settings) -> AlertRouter:
    sinks = []
    if settings.alerts.slack_webhook_url:
        sinks.append(SlackWebhookSink(settings.alerts.slack_webhook_url))
    if settings.alerts.pagerduty_routing_key:
        sinks.append(PagerDutyEventsSink(settings.alerts.pagerduty_routing_key))
    if settings.alerts.generic_webhook_url:
        sinks.append(GenericWebhookSink(settings.alerts.generic_webhook_url))
    return AlertRouter(sinks=sinks)


def _make_live_brokers(settings: Settings, metrics: MetricsRegistry) -> dict[str, Any]:
    brokers: dict[str, Any] = {}
    for venue in settings.live_venues:
        creds = venue_credentials(settings, venue)
        brokers[venue] = build_live_broker(
            venue,
            ExchangeCredentials(api_key=creds.api_key, api_secret=creds.api_secret, passphrase=creds.passphrase or None),
            metrics,
        )
    return brokers


def _make_live_feeds(settings: Settings, bus: EventBus, metrics: MetricsRegistry) -> FeedGroup:
    feeds: list[BaseMarketAdapter] = []
    for venue in settings.live_venues:
        feeds.append(build_market_adapter(venue, bus=bus, metrics=metrics, symbol=settings.default_symbol))
    return FeedGroup(feeds)


def _make_live_sessions(settings: Settings) -> dict[str, BasePrivateWsSession]:
    sessions: dict[str, BasePrivateWsSession] = {}
    for venue in settings.live_venues:
        session = build_private_ws_session(venue, venue_credentials(settings, venue))
        session.symbol = settings.default_symbol
        sessions[venue] = session
    return sessions


def _build_auth_manager(settings: Settings) -> TokenAuthManager:
    static_tokens = None
    if settings.control_plane.static_tokens_json:
        parsed = json.loads(settings.control_plane.static_tokens_json)
        static_tokens = {
            token: ControlPlanePrincipal(
                subject=str(meta.get('subject', meta.get('user', 'operator'))),
                role=str(meta.get('role', 'viewer')),
                scopes=tuple(meta.get('scopes', [])),
            )
            for token, meta in parsed.items()
        }
    return TokenAuthManager(AuthConfig(
        enabled=settings.control_plane.auth_enabled,
        issuer=settings.control_plane.auth_issuer,
        signing_secret=settings.control_plane.auth_secret,
        static_tokens=static_tokens,
    ))


def build_runtime_bundle(settings: Settings) -> RuntimeBundle:
    bus = EventBus()
    metrics = MetricsRegistry()
    journal = build_journal(
        sqlite_path=settings.database.sqlite_path,
        postgres_dsn=settings.database.postgres_dsn,
        prefer_postgres=settings.database.prefer_postgres,
    )
    portfolio = PortfolioService(base_currency=settings.base_currency, journal=journal, metrics=metrics)
    asset_analysis = AssetAnalysisService()
    indicators = IndicatorEngine()
    candles = CandlePatternEngine()
    regime_classifier = MarketRegimeClassifier()
    attribution = StrategyAttributionService()
    external_research = ExternalResearchIngestionLayer()
    analytics_hub = ExternalAnalyticsHub(external_research)
    allocator = StrategyAllocatorService(attribution, regime_classifier, external_research)
    universe = UniverseSelectionEngine(asset_analysis, min_quality_score=settings.research.universe_min_quality)
    feature_store = FeatureStore(settings.mlops.feature_store_path)
    ml_lifecycle = AdvancedMLLifecycle(feature_store)
    futures_analytics = FuturesAnalyticsService()
    orderbook = OrderBookIntelligenceService()
    onchain = OnChainAnalyticsService()
    liquidations = LiquidationAnalyticsService()
    futures_intel = FuturesMarketIntelService(futures_analytics)
    venue_health = VenueHealthScoringService()
    execution_quality = ExecutionQualityAttributionService()
    advanced_guard = CorrelationConcentrationRiskGuard(portfolio, AdvancedRiskSettings(
        max_venue_notional=settings.advanced_risk.max_venue_notional,
        max_symbol_concentration_pct=settings.advanced_risk.max_symbol_concentration_pct,
        max_correlated_exposure_pct=settings.advanced_risk.max_correlated_exposure_pct,
        correlation_window=settings.advanced_risk.correlation_window,
        correlation_threshold=settings.advanced_risk.correlation_threshold,
    )) if settings.advanced_risk.enabled else None
    risk = RiskService(settings.risk, portfolio=portfolio, metrics=metrics, advanced_guard=advanced_guard)
    capital_protection = CapitalProtectionService(settings.capital_protection, portfolio=portfolio, journal=journal, metrics=metrics)

    orchestration = None
    if settings.mode in {'live', 'micro_live'}:
        brokers = _make_live_brokers(settings, metrics)
        broker = CompositeBroker(brokers)
        futures_broker_factory = FuturesBrokerFactory(metrics)
        for venue in settings.live_venues:
            creds = venue_credentials(settings, venue)
            futures_broker_factory.build(venue, ExchangeCredentials(api_key=creds.api_key, api_secret=creds.api_secret, passphrase=creds.passphrase or None))
        feed = _make_live_feeds(settings, bus, metrics)
        orchestration = LiveOrchestrationService(
            sessions=_make_live_sessions(settings),
            journal=journal,
            portfolio=portfolio,
            metrics=metrics,
            bus=bus,
            lease_owner=settings.orchestration.process_owner,
            lease_ttl_sec=settings.orchestration.lease_ttl_sec,
        )
    else:
        broker = PaperBroker(metrics=metrics)
        venues = settings.strategy.cross_exchange_venues
        feed = MultiVenueDemoFeed(bus=bus, symbol=settings.default_symbol, venues=venues, tick_interval_sec=0.2) if len(venues) > 1 else DemoFeed(bus=bus, venue=settings.default_venue, symbol=settings.default_symbol, tick_interval_sec=0.2)

    execution = ExecutionService(
        bus=bus,
        broker=broker,
        journal=journal,
        portfolio=portfolio,
        risk=risk,
        metrics=metrics,
        circuit_breaker=CircuitBreaker(settings.circuit_breakers.max_consecutive_errors, settings.circuit_breakers.cooldown_sec),
        capital_protection=capital_protection,
        venue_health=venue_health,
        execution_quality=execution_quality,
    )
    ai_engine = AIDecisionEngine(
        metrics=metrics,
        enabled=settings.ai.enabled,
        entry_horizon_ticks=settings.ai.entry_horizon_ticks,
        min_training_move_bps=settings.ai.min_training_move_bps,
        min_accept_probability=settings.ai.min_accept_probability,
        strong_probability=settings.ai.strong_probability,
        size_boost=settings.ai.size_boost,
        size_cut=settings.ai.size_cut,
        model_path=settings.ai.model_path,
    )
    strategies = build_default_strategies(settings)
    shadow = ShadowDeploymentService(journal, set(settings.shadow.strategies) if settings.shadow.enabled else set())
    capacity = CapacityScoringService(asset_analysis=asset_analysis, execution_quality=execution_quality, venue_health=venue_health)
    profitability = ProfitabilityAdvisorService(attribution=attribution, execution_quality=execution_quality, venue_health=venue_health, onchain=onchain, liquidations=liquidations)
    alpha_lab = AlphaLabService(profitability=profitability, attribution=attribution)
    production_data = ProductionDataLayer()
    alpha_lab.hypotheses.register(
        'h-default-microstructure',
        'Microstructure + onchain alpha sleeve',
        'Prefer entries when microprice bias, onchain flow and venue health align with execution quality.',
        strategies=[s.name for s in strategies] if 'strategies' in locals() else ['funding_carry'],
        factors=['microprice_bias_bps', 'onchain_bias', 'venue_health', 'slippage_bps'],
        expected_edge='higher signal quality and better capacity-adjusted returns',
        tags=['default', 'runtime'],
    )
    strategy_service = StrategyService(
        bus=bus,
        execution=execution,
        strategies=strategies,
        metrics=metrics,
        ai_engine=ai_engine,
        capital_protection=capital_protection,
        signal_scorer=SignalScoringLayer(asset_analysis, indicators, regime_classifier, external_research, min_score=settings.research.min_signal_score) if settings.research.enabled else None,
        attribution=attribution,
        allocator=allocator,
        router=SmartOrderRouter(venue_health, health_weight=settings.routing.health_weight) if settings.routing.enabled else None,
        shadow=shadow,
        routed_strategies=set(settings.routing.strategies),
    )
    reconciliation = ReconciliationService(broker=broker, journal=journal, interval_sec=3.0, metrics=metrics, portfolio=portfolio)

    auth_manager = _build_auth_manager(settings)
    control_service = ControlPlaneService(
        capital_protection=capital_protection,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        ai_engine=ai_engine,
        alert_router=_make_alert_router(settings),
        audit_signer=AuditSigner(settings.control_plane.audit_secret),
        asset_analysis=asset_analysis,
        universe=universe,
        allocator=allocator,
        futures_analytics=futures_analytics,
        venue_health=venue_health,
        shadow=shadow,
        execution_quality=execution_quality,
        capacity=capacity,
        alpha_lab=alpha_lab,
    )
    if settings.mode == 'micro_live':
        record = control_service.promotions._record('funding_carry')
        previous_stage = record.current_stage
        record.current_stage = 'micro_live'
        record.pending_stage = None
        record.reason = 'auto_unlocked_for_micro_live_runtime'
        record.history.append({
            'ts': __import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
            'actor': 'runtime_bootstrap',
            'event': 'stage_forced',
            'from_stage': previous_stage,
            'to_stage': 'micro_live',
            'reason': 'micro_live_mode_bootstrap',
        })
    alpha_governance = AlphaGovernanceService(alpha_lab=alpha_lab, promotions=control_service.promotions, go_live=control_service.go_live)
    live_validation = LiveValidationService(portfolio=portfolio, execution_quality=execution_quality, alerts=control_service.alert_inbox, incidents=control_service.incidents)
    capital_scaling = CapitalScalingEngine(
        portfolio=portfolio,
        protection=capital_protection,
        governance=alpha_governance,
        live_validation=live_validation,
        attribution=attribution,
        capacity=capacity,
        micro_live_min_target_notional=settings.capital_protection.allocator.micro_live_min_target_notional,
    )
    control_service.alpha_governance = alpha_governance
    control_service.production_data = production_data
    control_service.live_validation = live_validation
    control_service.capital_scaling = capital_scaling
    control_app = create_control_plane_app(control_service, auth_manager)

    return RuntimeBundle(
        settings=settings,
        bus=bus,
        metrics=metrics,
        journal=journal,
        portfolio=portfolio,
        risk=risk,
        capital_protection=capital_protection,
        broker=broker,
        feed=feed,
        execution=execution,
        ai_engine=ai_engine,
        strategy_service=strategy_service,
        reconciliation=reconciliation,
        orchestration=orchestration,
        control_plane_service=control_service,
        control_plane_app=control_app,
        auth_manager=auth_manager,
        asset_analysis=asset_analysis,
        indicators=indicators,
        candles=candles,
        regime_classifier=regime_classifier,
        attribution=attribution,
        universe=universe,
        external_research=external_research,
        feature_store=feature_store,
        allocator=allocator,
        futures_analytics=futures_analytics,
        futures_intel=futures_intel,
        analytics_hub=analytics_hub,
        venue_health=venue_health,
        shadow=shadow,
        execution_quality=execution_quality,
        capacity=capacity,
        orderbook=orderbook,
        onchain=onchain,
        liquidations=liquidations,
        ml_lifecycle=ml_lifecycle,
        profitability=profitability,
        alpha_lab=alpha_lab,
        alpha_governance=alpha_governance,
        production_data=production_data,
        live_validation=live_validation,
        capital_scaling=capital_scaling,
    )
