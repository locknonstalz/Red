from __future__ import annotations

from collections import deque
from statistics import fmean, pstdev
from typing import Sequence

from common.models import OrderType, Side, Signal, Tick
from strategy.base import Strategy


class MarketMakingStrategy(Strategy):
    def __init__(
        self,
        name: str,
        venue: str,
        symbol: str,
        quote_size: float,
        min_spread_bps: float = 4.0,
        inventory_limit: float = 0.05,
        requote_cooldown_ticks: int = 8,
        vol_window: int = 30,
        max_toxicity: float = 0.55,
        max_microprice_bias_bps: float = 5.0,
    ) -> None:
        self.name = name
        self.venue = venue
        self.symbol = symbol
        self.quote_size = quote_size
        self.min_spread_bps = min_spread_bps
        self.inventory_limit = inventory_limit
        self.requote_cooldown_ticks = requote_cooldown_ticks
        self.mid_window: deque[float] = deque(maxlen=vol_window)
        self._ticks_since_quote = requote_cooldown_ticks
        self._inventory = 0.0
        self.max_toxicity = max_toxicity
        self.max_microprice_bias_bps = max_microprice_bias_bps

    def on_fill(self, side: Side, qty: float) -> None:
        self._inventory += qty if side == Side.BUY else -qty

    def on_tick(self, tick: Tick) -> Sequence[Signal]:
        if tick.venue != self.venue or tick.symbol != self.symbol:
            return []
        self.mid_window.append(tick.mid)
        self._ticks_since_quote += 1
        spread_bps = (tick.spread / tick.mid) * 10000 if tick.mid else 0.0
        toxicity = float(getattr(tick, 'toxicity_score', 0.0) or 0.0)
        microprice_bias_bps = abs(float(getattr(tick, 'microprice_bias_bps', 0.0) or 0.0))
        if (
            len(self.mid_window) < self.mid_window.maxlen
            or spread_bps < self.min_spread_bps
            or self._ticks_since_quote < self.requote_cooldown_ticks
            or toxicity > self.max_toxicity
            or microprice_bias_bps > self.max_microprice_bias_bps
        ):
            return []
        mids = list(self.mid_window)
        sigma = pstdev(mids) if len(mids) > 1 else 0.0
        fair = fmean(mids[-5:]) if len(mids) >= 5 else tick.mid
        half_spread = max(tick.spread / 2.0, sigma * 0.35, fair * (self.min_spread_bps / 10000) / 2.0)
        inventory_skew = min(max(self._inventory / max(self.inventory_limit, 1e-9), -1.0), 1.0)
        buy_price = round(fair - half_spread - inventory_skew * tick.spread * 0.25, 2)
        sell_price = round(fair + half_spread - inventory_skew * tick.spread * 0.25, 2)
        self._ticks_since_quote = 0
        signals: list[Signal] = []
        common_tags = {'style': 'maker', 'toxicity_score': round(toxicity, 4), 'microprice_bias_bps': round(microprice_bias_bps, 4), 'sleeve': 'market_making'}
        if self._inventory < self.inventory_limit:
            signals.append(Signal(self.name, self.venue, self.symbol, Side.BUY, 0.45, 'passive_bid_quote', qty=self.quote_size, order_type=OrderType.LIMIT, limit_price=buy_price, tags={**common_tags, 'side_bias': 'bid'}))
        if self._inventory > -self.inventory_limit:
            signals.append(Signal(self.name, self.venue, self.symbol, Side.SELL, 0.45, 'passive_ask_quote', qty=self.quote_size, order_type=OrderType.LIMIT, limit_price=sell_price, tags={**common_tags, 'side_bias': 'ask'}))
        return signals
