from .pipeline import IntegratedAlphaPipeline
