v21 Futures & Derivatives Layer

Adds derivative instrument models, funding/open-interest analytics, futures portfolio/risk controls, and intent checks for leverage/reduce-only/close-only semantics.
