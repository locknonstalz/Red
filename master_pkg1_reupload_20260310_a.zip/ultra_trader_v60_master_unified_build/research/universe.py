from __future__ import annotations

from dataclasses import dataclass

from research.asset_analysis import AssetAnalysisService, AssetSnapshot


@dataclass(slots=True)
class UniverseSelection:
    selected: list[AssetSnapshot]
    rejected: list[AssetSnapshot]


class UniverseSelectionEngine:
    def __init__(self, asset_analysis: AssetAnalysisService, min_quality_score: float = 35.0, max_assets: int = 8) -> None:
        self.asset_analysis = asset_analysis
        self.min_quality_score = min_quality_score
        self.max_assets = max_assets

    def select(self, universe: list[tuple[str, str]]) -> UniverseSelection:
        ranked = self.asset_analysis.rank(universe)
        selected = [snap for snap in ranked if snap.quality_score >= self.min_quality_score][: self.max_assets]
        rejected = [snap for snap in ranked if snap not in selected]
        return UniverseSelection(selected=selected, rejected=rejected)
