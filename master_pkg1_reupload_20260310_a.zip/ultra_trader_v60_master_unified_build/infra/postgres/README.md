# Postgres HA Blueprint

Recommended stack:
- Patroni
- etcd
- pgBackRest
- synchronous replication for journal tables

Use a dedicated primary for trading writes and restrict analytics to replicas.
