from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class SpecialistSleeve:
    name: str
    family: str
    expected_edge: float
    realized_net_pnl: float
    drawdown_pct: float
    cost_drag_pct: float


@dataclass
class RegimeAwareSpecialistEnsemble:
    """A meta-architecture common in profitable quant desks.

    Instead of one universal strategy, run specialists and rotate by regime.
    This often improves risk-adjusted returns because weak sleeves are muted.
    """
    regime_family_weights: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        "carry": {"funding_carry": 1.0, "cross_exchange_arb": 0.7, "market_making": 0.4, "liquidation_cascade": 0.2, "stat_arb": 0.2},
        "trend": {"funding_carry": 0.4, "cross_exchange_arb": 0.5, "market_making": 0.5, "liquidation_cascade": 1.0, "stat_arb": 0.1},
        "mean_revert": {"funding_carry": 0.2, "cross_exchange_arb": 0.6, "market_making": 0.9, "liquidation_cascade": 0.2, "stat_arb": 1.0},
    })

    def allocate(self, sleeves: List[SpecialistSleeve], regime: str) -> Dict[str, float]:
        weights = self.regime_family_weights.get(regime, {})
        raw: Dict[str, float] = {}
        for s in sleeves:
            family_w = weights.get(s.family, 0.2)
            health = max(0.0, s.expected_edge + max(s.realized_net_pnl, 0.0) / 1000.0)
            penalties = (s.drawdown_pct * 0.03) + s.cost_drag_pct
            raw[s.name] = max(0.0, family_w * health - penalties)
        total = sum(raw.values()) or 1.0
        return {k: round(v / total, 4) for k, v in raw.items()}
