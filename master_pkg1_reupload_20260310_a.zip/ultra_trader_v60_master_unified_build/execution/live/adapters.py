from __future__ import annotations

import json
from urllib.parse import urlencode

from common.models import Balance, Order, Position, VenueFilter
from execution.live.rest_base import BaseRestBroker, ExchangeOrderAck
from market.live.base import ExchangeCredentials
from ops.metrics import MetricsRegistry


def _tick_size_from_precision(precision: str | int | float) -> float:
    if isinstance(precision, str) and precision.startswith('0.'):
        return float(precision)
    try:
        p = int(precision)
        return 10 ** (-p)
    except Exception:
        return 0.0


class BinanceRestBroker(BaseRestBroker):
    venue = 'binance'
    base_url = 'https://api.binance.com'

    async def submit_live(self, order: Order) -> ExchangeOrderAck:
        params = {'symbol': order.symbol.replace('/', ''), 'side': order.side.value, 'type': order.order_type.value, 'quantity': order.qty, 'newClientOrderId': order.client_order_id, 'timestamp': self.ts_ms()}
        if order.limit_price is not None:
            params['price'] = order.limit_price
            params['timeInForce'] = 'GTC'
        query = urlencode(params)
        signature = self.sign_hmac_sha256(self.credentials.api_secret, query)
        response = await self.client.post(f'/api/v3/order?{query}&signature={signature}', headers={'X-MBX-APIKEY': self.credentials.api_key})
        response.raise_for_status()
        payload = response.json()
        return ExchangeOrderAck(str(payload.get('orderId')), str(payload.get('status', 'NEW')), payload)

    async def list_open_orders(self) -> list[str]:
        query = urlencode({'timestamp': self.ts_ms()})
        signature = self.sign_hmac_sha256(self.credentials.api_secret, query)
        response = await self.client.get(f'/api/v3/openOrders?{query}&signature={signature}', headers={'X-MBX-APIKEY': self.credentials.api_key})
        response.raise_for_status()
        return [r.get('clientOrderId') for r in response.json() if r.get('clientOrderId')]

    async def fetch_balances(self) -> list[Balance]:
        query = urlencode({'timestamp': self.ts_ms()})
        signature = self.sign_hmac_sha256(self.credentials.api_secret, query)
        response = await self.client.get(f'/api/v3/account?{query}&signature={signature}', headers={'X-MBX-APIKEY': self.credentials.api_key})
        response.raise_for_status()
        return [Balance(self.venue, b['asset'], float(b['free']), float(b['locked'])) for b in response.json().get('balances', []) if float(b.get('free', 0)) or float(b.get('locked', 0))]

    async def fetch_positions(self) -> list[Position]:
        return []

    async def fetch_symbol_filter(self, symbol: str) -> VenueFilter:
        response = await self.client.get('/api/v3/exchangeInfo', params={'symbol': symbol.replace('/', '')})
        response.raise_for_status()
        data = response.json()['symbols'][0]
        fs = {f['filterType']: f for f in data['filters']}
        return VenueFilter(self.venue, symbol, float(fs['PRICE_FILTER']['tickSize']), float(fs['LOT_SIZE']['stepSize']), float(fs['LOT_SIZE']['minQty']), float(fs.get('MIN_NOTIONAL', fs.get('NOTIONAL', {'minNotional': 0}))['minNotional']))


class BybitRestBroker(BaseRestBroker):
    venue = 'bybit'
    base_url = 'https://api.bybit.com'

    async def submit_live(self, order: Order) -> ExchangeOrderAck:
        body = {'category': 'spot', 'symbol': order.symbol.replace('/', ''), 'side': order.side.value.title(), 'orderType': order.order_type.value.title(), 'qty': str(order.qty), 'orderLinkId': order.client_order_id}
        if order.limit_price is not None:
            body['price'] = str(order.limit_price)
        ts = self.ts_ms(); recv = '5000'; body_raw = json.dumps(body, separators=(',', ':'))
        sign_payload = f"{ts}{self.credentials.api_key}{recv}{body_raw}"
        signature = self.sign_hmac_sha256(self.credentials.api_secret, sign_payload)
        response = await self.client.post('/v5/order/create', content=body_raw, headers={'X-BAPI-API-KEY': self.credentials.api_key, 'X-BAPI-TIMESTAMP': ts, 'X-BAPI-RECV-WINDOW': recv, 'X-BAPI-SIGN': signature, 'Content-Type': 'application/json'})
        response.raise_for_status(); payload = response.json(); result = payload.get('result', {})
        return ExchangeOrderAck(str(result.get('orderId')), str(result.get('orderStatus', 'Created')), payload)

    async def list_open_orders(self) -> list[str]:
        params = {'category': 'spot', 'openOnly': 0, 'limit': 50}; query = urlencode(params)
        ts = self.ts_ms(); recv = '5000'; sign_payload = f"{ts}{self.credentials.api_key}{recv}{query}"
        signature = self.sign_hmac_sha256(self.credentials.api_secret, sign_payload)
        response = await self.client.get(f'/v5/order/realtime?{query}', headers={'X-BAPI-API-KEY': self.credentials.api_key, 'X-BAPI-TIMESTAMP': ts, 'X-BAPI-RECV-WINDOW': recv, 'X-BAPI-SIGN': signature})
        response.raise_for_status(); items = response.json().get('result', {}).get('list', [])
        return [i.get('orderLinkId') for i in items if i.get('orderLinkId')]

    async def fetch_balances(self) -> list[Balance]:
        params = {'accountType': 'UNIFIED'}; query = urlencode(params)
        ts = self.ts_ms(); recv = '5000'; signature = self.sign_hmac_sha256(self.credentials.api_secret, f"{ts}{self.credentials.api_key}{recv}{query}")
        response = await self.client.get(f'/v5/account/wallet-balance?{query}', headers={'X-BAPI-API-KEY': self.credentials.api_key, 'X-BAPI-TIMESTAMP': ts, 'X-BAPI-RECV-WINDOW': recv, 'X-BAPI-SIGN': signature})
        response.raise_for_status(); items = response.json().get('result', {}).get('list', [])
        balances=[]
        for acct in items:
            for coin in acct.get('coin', []):
                balances.append(Balance(self.venue, coin['coin'], float(coin.get('walletBalance', 0.0)), 0.0))
        return balances

    async def fetch_positions(self) -> list[Position]:
        return []

    async def fetch_symbol_filter(self, symbol: str) -> VenueFilter:
        response = await self.client.get('/v5/market/instruments-info', params={'category': 'spot', 'symbol': symbol.replace('/', '')})
        response.raise_for_status(); row = response.json()['result']['list'][0]
        lot = row.get('lotSizeFilter', {}); price = row.get('priceFilter', {})
        return VenueFilter(self.venue, symbol, float(price.get('tickSize', 0)), float(lot.get('basePrecision', lot.get('qtyStep', 0)) or 0), float(lot.get('minOrderQty', 0) or 0), float(lot.get('minOrderAmt', 0) or 0))


class MexcRestBroker(BaseRestBroker):
    venue = 'mexc'
    base_url = 'https://api.mexc.com'

    async def submit_live(self, order: Order) -> ExchangeOrderAck:
        params = {'symbol': order.symbol.replace('/', ''), 'side': order.side.value, 'type': order.order_type.value, 'quantity': str(order.qty), 'newClientOrderId': order.client_order_id, 'timestamp': self.ts_ms()}
        if order.limit_price is not None:
            params['price'] = str(order.limit_price)
        query = urlencode(params); signature = self.sign_hmac_sha256(self.credentials.api_secret, query)
        response = await self.client.post(f'/api/v3/order?{query}&signature={signature}', headers={'X-MEXC-APIKEY': self.credentials.api_key})
        response.raise_for_status(); payload = response.json()
        return ExchangeOrderAck(str(payload.get('orderId')), str(payload.get('status', 'NEW')), payload)

    async def list_open_orders(self) -> list[str]:
        query = urlencode({'timestamp': self.ts_ms()}); signature = self.sign_hmac_sha256(self.credentials.api_secret, query)
        response = await self.client.get(f'/api/v3/openOrders?{query}&signature={signature}', headers={'X-MEXC-APIKEY': self.credentials.api_key})
        response.raise_for_status(); return [r.get('clientOrderId') for r in response.json() if r.get('clientOrderId')]

    async def fetch_balances(self) -> list[Balance]:
        query = urlencode({'timestamp': self.ts_ms()}); signature = self.sign_hmac_sha256(self.credentials.api_secret, query)
        response = await self.client.get(f'/api/v3/account?{query}&signature={signature}', headers={'X-MEXC-APIKEY': self.credentials.api_key})
        response.raise_for_status(); return [Balance(self.venue, b['asset'], float(b['free']), float(b['locked'])) for b in response.json().get('balances', []) if float(b.get('free', 0)) or float(b.get('locked', 0))]

    async def fetch_positions(self) -> list[Position]:
        return []

    async def fetch_symbol_filter(self, symbol: str) -> VenueFilter:
        response = await self.client.get('/api/v3/exchangeInfo', params={'symbol': symbol.replace('/', '')})
        response.raise_for_status(); row = response.json()['symbols'][0]
        return VenueFilter(self.venue, symbol, _tick_size_from_precision(row.get('quotePrecision', 8)), _tick_size_from_precision(row.get('baseSizePrecision', row.get('baseAssetPrecision', 8))), float(row.get('baseSizePrecision', 0) or 0), float(row.get('quoteAmountPrecision', 0) or 0))


class BitgetRestBroker(BaseRestBroker):
    venue = 'bitget'
    base_url = 'https://api.bitget.com'

    async def submit_live(self, order: Order) -> ExchangeOrderAck:
        body = {'symbol': order.symbol.replace('/', ''), 'productType': 'spot', 'marginMode': 'cash', 'side': order.side.value.lower(), 'orderType': order.order_type.value.lower(), 'size': str(order.qty), 'clientOid': order.client_order_id}
        if order.limit_price is not None:
            body['price'] = str(order.limit_price); body['force'] = 'gtc'
        body_raw = json.dumps(body, separators=(',', ':')); ts = self.ts_ms(); path = '/api/v2/spot/trade/place-order'
        signature = self.sign_base64_hmac_sha256(self.credentials.api_secret, f"{ts}POST{path}{body_raw}")
        response = await self.client.post(path, content=body_raw, headers={'ACCESS-KEY': self.credentials.api_key, 'ACCESS-SIGN': signature, 'ACCESS-TIMESTAMP': ts, 'ACCESS-PASSPHRASE': self.credentials.passphrase or '', 'Content-Type': 'application/json'})
        response.raise_for_status(); payload = response.json(); data = payload.get('data', {})
        return ExchangeOrderAck(str(data.get('orderId')), str(data.get('status', 'new')), payload)

    async def list_open_orders(self) -> list[str]:
        ts = self.ts_ms(); path = '/api/v2/spot/trade/unfilled-orders'; signature = self.sign_base64_hmac_sha256(self.credentials.api_secret, f"{ts}GET{path}")
        response = await self.client.get(path, headers={'ACCESS-KEY': self.credentials.api_key, 'ACCESS-SIGN': signature, 'ACCESS-TIMESTAMP': ts, 'ACCESS-PASSPHRASE': self.credentials.passphrase or ''})
        response.raise_for_status(); return [r.get('clientOid') for r in response.json().get('data', []) if r.get('clientOid')]

    async def fetch_balances(self) -> list[Balance]:
        ts = self.ts_ms(); path = '/api/v2/spot/account/assets'; signature = self.sign_base64_hmac_sha256(self.credentials.api_secret, f"{ts}GET{path}")
        response = await self.client.get(path, headers={'ACCESS-KEY': self.credentials.api_key, 'ACCESS-SIGN': signature, 'ACCESS-TIMESTAMP': ts, 'ACCESS-PASSPHRASE': self.credentials.passphrase or ''})
        response.raise_for_status(); return [Balance(self.venue, b.get('coin', ''), float(b.get('available', 0)), float(b.get('frozen', 0))) for b in response.json().get('data', []) if float(b.get('available', 0)) or float(b.get('frozen', 0))]

    async def fetch_positions(self) -> list[Position]:
        return []

    async def fetch_symbol_filter(self, symbol: str) -> VenueFilter:
        response = await self.client.get('/api/v2/spot/public/symbols', params={'symbol': symbol.replace('/', '')})
        response.raise_for_status(); row = response.json().get('data', [])[0]
        return VenueFilter(self.venue, symbol, _tick_size_from_precision(row.get('pricePrecision', 8)), _tick_size_from_precision(row.get('quantityPrecision', 8)), float(row.get('minTradeAmount', 0) or 0), float(row.get('minTradeUSDT', row.get('minTradeAmount', 0)) or 0))


def build_live_broker(venue: str, credentials: ExchangeCredentials, metrics: MetricsRegistry):
    mapping = {'binance': BinanceRestBroker, 'bybit': BybitRestBroker, 'mexc': MexcRestBroker, 'bitget': BitgetRestBroker}
    try:
        return mapping[venue.lower()](credentials=credentials, metrics=metrics)
    except KeyError as exc:
        raise ValueError(f'unsupported venue: {venue}') from exc
