from __future__ import annotations

from collections import deque
from typing import Sequence

from common.models import Side, Signal, Tick
from strategy.base import Strategy


class MomentumStrategy(Strategy):
    def __init__(self, name: str, venue: str, symbol: str, fast_window: int, slow_window: int, order_size: float) -> None:
        self.name = name
        self.venue = venue
        self.symbol = symbol
        self.fast_window = fast_window
        self.slow_window = slow_window
        self.order_size = order_size
        self.window = deque(maxlen=slow_window)
        self._last_side: Side | None = None

    def on_tick(self, tick: Tick) -> Sequence[Signal]:
        if tick.symbol != self.symbol or tick.venue != self.venue:
            return []
        self.window.append(tick.price)
        if len(self.window) < self.slow_window:
            return []
        fast = sum(list(self.window)[-self.fast_window:]) / self.fast_window
        slow = sum(self.window) / self.slow_window
        if fast > slow and self._last_side != Side.BUY:
            self._last_side = Side.BUY
            return [Signal(self.name, tick.venue, tick.symbol, Side.BUY, 0.6, "fast_above_slow", qty=self.order_size)]
        if fast < slow and self._last_side != Side.SELL:
            self._last_side = Side.SELL
            return [Signal(self.name, tick.venue, tick.symbol, Side.SELL, 0.6, "fast_below_slow", qty=self.order_size)]
        return []
