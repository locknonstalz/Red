# Operations Runbook

## Normal startup
1. Confirm Postgres primary healthy.
2. Confirm Vault/KMS reachable.
3. Confirm Prometheus and Alertmanager healthy.
4. Start orchestration standbys before leaders.
5. Verify lease ownership and session state.
6. Run reconciliation warm-up.
7. Enable outbound trading only after truth state is green.

## Incident classes
- venue auth failures
- websocket reconnect storms
- sequence gaps not recoverable
- journal lag or Postgres failover
- duplicate leader detected
- stale balance/position truth

## Immediate operator actions
- disable outbound trading switch for affected venue
- preserve journal and exporter logs
- capture current checkpoint and leader identity
- reroute alerts to incident bridge
- trigger rollback or standby takeover if needed
