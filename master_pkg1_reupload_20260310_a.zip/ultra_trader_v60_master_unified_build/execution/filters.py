from __future__ import annotations

from decimal import Decimal, ROUND_DOWN

from common.models import Order, VenueFilter


class PrecisionFilterService:
    @staticmethod
    def _round_down(value: float, step: float) -> float:
        if step <= 0:
            return value
        v = Decimal(str(value))
        s = Decimal(str(step))
        return float((v / s).to_integral_value(rounding=ROUND_DOWN) * s)

    def normalize(self, order: Order, venue_filter: VenueFilter, reference_price: float) -> Order:
        order.qty = self._round_down(order.qty, venue_filter.step_size)
        if order.limit_price is not None:
            order.limit_price = self._round_down(order.limit_price, venue_filter.tick_size)
        notional = reference_price * order.qty
        if order.qty < venue_filter.min_qty:
            raise ValueError('qty_below_min_qty')
        if notional < venue_filter.min_notional:
            raise ValueError('notional_below_min_notional')
        return order
