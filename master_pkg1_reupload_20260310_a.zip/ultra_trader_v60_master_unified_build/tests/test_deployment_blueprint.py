from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]


def test_required_blueprint_files_exist():
    required = [
        ROOT / "deploy/systemd/ultra-trader.service",
        ROOT / "deploy/k8s/base/deployment.yaml",
        ROOT / "deploy/k8s/overlays/prod/kustomization.yaml",
        ROOT / "infra/alertmanager.yml",
        ROOT / "docs/LIVE_CERTIFICATION_MATRIX.md",
        ROOT / "docs/MULTI_NODE_DEPLOYMENT_BLUEPRINT.md",
    ]
    for path in required:
        assert path.exists(), f"missing {path}"


def test_yaml_manifests_parse():
    yaml_files = [
        ROOT / "deploy/k8s/base/deployment.yaml",
        ROOT / "deploy/k8s/base/service.yaml",
        ROOT / "deploy/k8s/base/configmap.yaml",
        ROOT / "deploy/k8s/base/poddisruptionbudget.yaml",
        ROOT / "infra/prometheus.yml",
        ROOT / "infra/alertmanager.yml",
        ROOT / "infra/alert_rules.yml",
    ]
    for path in yaml_files:
        with path.open("r", encoding="utf-8") as fh:
            assert yaml.safe_load(fh) is not None, f"invalid yaml: {path}"
