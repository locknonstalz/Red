
from alpha_factory.factory import CandidateTemplate
from integrated_alpha.pipeline import IntegratedAlphaPipeline
from ops.micro_live_controller import StrategyRunInput
from ops.micro_live_hardening import DriftSnapshot, StrategyRunStats


def build_templates():
    return [
        CandidateTemplate(
            name='funding_carry_candidate',
            family='funding_carry',
            required_features=['funding_rate', 'basis_bps'],
            param_grid={'threshold': [1, 2]},
            supported_regimes=['carry', 'trend'],
            supported_venues=['binance', 'bybit'],
        ),
        CandidateTemplate(
            name='cross_exchange_candidate',
            family='cross_exchange_arb',
            required_features=['spread_bps', 'venue_health'],
            param_grid={'spread': [4, 6]},
            supported_regimes=['carry', 'mean_revert'],
            supported_venues=['binance', 'bybit'],
        ),
    ]


def test_discover_test_route_returns_ranked_candidates():
    pipe = IntegratedAlphaPipeline(build_templates())
    out = pipe.discover_test_route('carry', ['binance', 'bybit'], {
        'regime_alpha': 0.4,
        'liquidity_score': 0.8,
        'volatility_score': 0.3,
        'carry_score': 0.9,
        'shock_score': 0.1,
    })
    assert out['candidates']
    assert out['routed']
    assert out['routed'][0].experiment.score >= out['routed'][-1].experiment.score


def test_micro_live_evaluation_integrates_scorecard_guards_and_allocation():
    pipe = IntegratedAlphaPipeline(build_templates())
    runs = [
        StrategyRunInput(
            strategy='funding_carry', venue='binance', gross_pnl=12, fees=1, slippage_cost=0.4, funding_drag=-2.5, hedge_cost=0.2,
            adverse_fill_rate=0.05, capacity_score=0.9,
            drift=DriftSnapshot(),
            stats=StrategyRunStats(strategy='funding_carry', days_live=8, net_pnl_days_positive=6),
        ),
        StrategyRunInput(
            strategy='cross_exchange_arbitrage', venue='bybit', gross_pnl=8, fees=1.5, slippage_cost=1.0, funding_drag=0.0, hedge_cost=0.7,
            adverse_fill_rate=0.12, capacity_score=0.8,
            drift=DriftSnapshot(),
            stats=StrategyRunStats(strategy='cross_exchange_arbitrage', days_live=8, net_pnl_days_positive=5),
        ),
    ]
    out = pipe.evaluate_micro_live(runs)
    assert 'funding_carry' in out['results']
    assert out['results']['funding_carry']['scorecard']['net_pnl'] > 0
    assert out['results']['funding_carry']['hardening']['final_action'] in {'hold', 'scale_gradually'}
    assert abs(sum(out['allocation'].values()) - 1.0) < 0.001
