from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Sequence
import math


@dataclass(frozen=True)
class CandidateTemplate:
    name: str
    family: str
    required_features: Sequence[str]
    param_grid: Dict[str, Sequence[float | int]]
    supported_regimes: Sequence[str]
    supported_venues: Sequence[str]


@dataclass
class StrategyBlueprint:
    name: str
    family: str
    params: Dict[str, float | int]
    regime: str
    venues: List[str]
    required_features: List[str]


@dataclass
class BacktestResult:
    sharpe: float
    max_drawdown_pct: float
    net_pnl: float
    turnover: float
    hit_rate: float
    slippage_bps: float
    capacity_score: float


@dataclass
class ExperimentResult:
    blueprint: StrategyBlueprint
    backtest: BacktestResult
    score: float


@dataclass
class AlphaCandidate:
    blueprint: StrategyBlueprint
    experiment: ExperimentResult
    stage: str = "research"
    approval_status: str = "pending"
    shadow_days: int = 0
    shadow_net_pnl: float = 0.0
    micro_live_days: int = 0
    micro_live_net_pnl: float = 0.0


@dataclass
class AlphaScorer:
    max_slippage_bps: float = 8.0
    min_hit_rate: float = 0.45

    def score(self, result: BacktestResult) -> float:
        if result.hit_rate < self.min_hit_rate:
            return -1.0
        quality = result.sharpe * 35.0
        drawdown_penalty = result.max_drawdown_pct * 2.0
        pnl_bonus = math.log1p(max(result.net_pnl, 0.0)) * 8.0
        slippage_penalty = max(result.slippage_bps - self.max_slippage_bps, 0.0) * 1.5
        turnover_penalty = result.turnover * 0.2
        capacity_bonus = result.capacity_score * 15.0
        return round(quality - drawdown_penalty + pnl_bonus - slippage_penalty - turnover_penalty + capacity_bonus, 3)


@dataclass
class StrategyGenerator:
    templates: List[CandidateTemplate]

    def generate(self, regime: str, allowed_venues: Sequence[str]) -> List[StrategyBlueprint]:
        blueprints: List[StrategyBlueprint] = []
        for tmpl in self.templates:
            if regime not in tmpl.supported_regimes:
                continue
            venues = [v for v in tmpl.supported_venues if v in allowed_venues]
            if not venues:
                continue
            grids = list(tmpl.param_grid.items())
            if not grids:
                blueprints.append(
                    StrategyBlueprint(
                        name=f"{tmpl.name}_{regime}",
                        family=tmpl.family,
                        params={},
                        regime=regime,
                        venues=venues,
                        required_features=list(tmpl.required_features),
                    )
                )
                continue
            key, values = grids[0]
            for value in values:
                params = {key: value}
                if len(grids) > 1:
                    key2, values2 = grids[1]
                    params[key2] = values2[0]
                blueprints.append(
                    StrategyBlueprint(
                        name=f"{tmpl.name}_{regime}_{key}_{value}",
                        family=tmpl.family,
                        params=params,
                        regime=regime,
                        venues=venues,
                        required_features=list(tmpl.required_features),
                    )
                )
        return blueprints


@dataclass
class ExperimentRunner:
    scorer: AlphaScorer = field(default_factory=AlphaScorer)

    def run(self, blueprint: StrategyBlueprint, market_snapshot: Dict[str, float]) -> ExperimentResult:
        regime_alpha = market_snapshot.get("regime_alpha", 0.0)
        liquidity = market_snapshot.get("liquidity_score", 0.5)
        volatility = market_snapshot.get("volatility_score", 0.5)
        carry = market_snapshot.get("carry_score", 0.0)
        shock = market_snapshot.get("shock_score", 0.0)
        family_bias = {
            "funding_carry": carry,
            "cross_exchange_arb": liquidity,
            "market_making": liquidity - shock,
            "liquidation_cascade": shock,
            "stat_arb": 1.0 - volatility,
        }.get(blueprint.family, regime_alpha)
        edge = max(0.0, 0.4 + regime_alpha + family_bias)
        slippage = max(0.5, 9.0 - liquidity * 8.0 + shock * 3.0)
        turnover = 4.0 + shock * 12.0 + volatility * 6.0
        sharpe = max(0.1, edge * 2.4 - volatility * 0.8)
        max_dd = max(1.0, 12.0 - edge * 4.0 + shock * 5.0)
        net_pnl = round(1000.0 * edge - 100.0 * slippage - 15.0 * turnover, 2)
        hit_rate = min(0.85, max(0.40, 0.48 + edge * 0.1 - shock * 0.05))
        capacity_score = max(0.1, min(1.0, liquidity * 0.8 + edge * 0.2))
        bt = BacktestResult(
            sharpe=round(sharpe, 3),
            max_drawdown_pct=round(max_dd, 3),
            net_pnl=net_pnl,
            turnover=round(turnover, 3),
            hit_rate=round(hit_rate, 3),
            slippage_bps=round(slippage, 3),
            capacity_score=round(capacity_score, 3),
        )
        return ExperimentResult(blueprint=blueprint, backtest=bt, score=self.scorer.score(bt))


@dataclass
class ShadowPromotionGate:
    min_backtest_score: float = 20.0
    min_shadow_days: int = 5
    require_positive_shadow_pnl: bool = True
    min_micro_live_days: int = 5

    def to_shadow(self, candidate: AlphaCandidate) -> bool:
        return candidate.experiment.score >= self.min_backtest_score

    def to_micro_live(self, candidate: AlphaCandidate) -> bool:
        if candidate.shadow_days < self.min_shadow_days:
            return False
        if self.require_positive_shadow_pnl and candidate.shadow_net_pnl <= 0:
            return False
        return True

    def to_live(self, candidate: AlphaCandidate) -> bool:
        return candidate.micro_live_days >= self.min_micro_live_days and candidate.micro_live_net_pnl > 0


@dataclass
class RegimeRouter:
    regime_weights: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        "carry": {"funding_carry": 1.0, "cross_exchange_arb": 0.7, "market_making": 0.4, "liquidation_cascade": 0.2, "stat_arb": 0.3},
        "trend": {"funding_carry": 0.5, "cross_exchange_arb": 0.6, "market_making": 0.5, "liquidation_cascade": 1.0, "stat_arb": 0.2},
        "mean_revert": {"funding_carry": 0.4, "cross_exchange_arb": 0.7, "market_making": 0.8, "liquidation_cascade": 0.3, "stat_arb": 1.0},
    })

    def select(self, candidates: Sequence[AlphaCandidate], regime: str, top_n: int = 3) -> List[AlphaCandidate]:
        weights = self.regime_weights.get(regime, {})
        ranked = sorted(
            candidates,
            key=lambda c: c.experiment.score * weights.get(c.blueprint.family, 0.5),
            reverse=True,
        )
        return ranked[:top_n]


@dataclass
class StrategyFactoryService:
    generator: StrategyGenerator
    runner: ExperimentRunner = field(default_factory=ExperimentRunner)
    gate: ShadowPromotionGate = field(default_factory=ShadowPromotionGate)
    router: RegimeRouter = field(default_factory=RegimeRouter)

    def discover(self, regime: str, allowed_venues: Sequence[str], market_snapshot: Dict[str, float]) -> List[AlphaCandidate]:
        blueprints = self.generator.generate(regime=regime, allowed_venues=allowed_venues)
        experiments = [self.runner.run(bp, market_snapshot) for bp in blueprints]
        experiments.sort(key=lambda x: x.score, reverse=True)
        return [AlphaCandidate(blueprint=e.blueprint, experiment=e) for e in experiments]

    def promote(self, candidate: AlphaCandidate) -> str:
        if candidate.stage == "research" and self.gate.to_shadow(candidate):
            candidate.stage = "shadow"
        elif candidate.stage == "shadow" and self.gate.to_micro_live(candidate):
            candidate.stage = "micro_live"
        elif candidate.stage == "micro_live" and self.gate.to_live(candidate):
            candidate.stage = "live"
        return candidate.stage
