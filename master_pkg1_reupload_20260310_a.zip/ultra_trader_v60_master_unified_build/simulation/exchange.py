from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4

from microstructure.orderbook import BookLevel, L2BookSnapshot


@dataclass(slots=True)
class SimOrder:
    side: str
    qty: float
    order_type: str = 'LIMIT'
    limit_price: float | None = None
    order_id: str = field(default_factory=lambda: str(uuid4()))


@dataclass(slots=True)
class SimFill:
    order_id: str
    qty: float
    price: float
    fee: float = 0.0


@dataclass(slots=True)
class SimOrderBook:
    bids: list[BookLevel]
    asks: list[BookLevel]


class ExchangeSimulator:
    def __init__(self, fee_bps: float = 5.0) -> None:
        self.fee_bps = fee_bps
        self.book: SimOrderBook | None = None

    def load_from_l2(self, snapshot: L2BookSnapshot) -> None:
        self.book = SimOrderBook(bids=[BookLevel(x.price, x.size, x.orders) for x in snapshot.bids], asks=[BookLevel(x.price, x.size, x.orders) for x in snapshot.asks])

    def submit(self, order: SimOrder) -> list[SimFill]:
        if self.book is None:
            return []
        fills: list[SimFill] = []
        remaining = order.qty
        side = order.side.upper()
        levels = self.book.asks if side == 'BUY' else self.book.bids
        idx = 0
        while remaining > 1e-12 and idx < len(levels):
            level = levels[idx]
            marketable = order.order_type.upper() == 'MARKET'
            if order.limit_price is not None:
                marketable = marketable or (side == 'BUY' and level.price <= order.limit_price) or (side == 'SELL' and level.price >= order.limit_price)
            if not marketable:
                break
            taken = min(level.size, remaining)
            fee = taken * level.price * self.fee_bps / 10000.0
            fills.append(SimFill(order_id=order.order_id, qty=taken, price=level.price, fee=fee))
            remaining -= taken
            level.size -= taken
            if level.size <= 1e-12:
                idx += 1
        return fills
