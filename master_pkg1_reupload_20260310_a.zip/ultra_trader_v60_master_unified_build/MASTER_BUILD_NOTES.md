# ULTRA TRADER V60 MASTER UNIFIED BUILD

Эта master-сборка объединяет ключевые доработки прошлых итераций:

- audited/fixed baseline
- real micro_live execution path
- stage unlock для funding_carry
- micro-live budget floor
- explain-why-no-trade diagnostics
- GUI v1/v2/v3 operator desktop
- preflight hardening
- bat launchers и GUI docs

## Что запускать
- `start_gui.bat` — графический интерфейс Windows
- `python gui_launcher.py` — GUI напрямую
- `python scripts/preflight.py` — проверка окружения
- `python app.py` — прямой запуск движка без GUI

## Базовые режимы
- paper
- live
- micro_live

## Важная оговорка
Master-сборка объединяет лучшие доступные улучшения, но не заменяет полноценную интеграционную сертификацию на каждой бирже и по каждому маршруту исполнения.


## Package #1 hardening added
- detailed funding_carry no-trade diagnostics
- strategy signal blocker logs
- order submit lifecycle logs
- venue/instrument preflight validation
- GUI diagnostics updated for blocker and submit lifecycle visibility
