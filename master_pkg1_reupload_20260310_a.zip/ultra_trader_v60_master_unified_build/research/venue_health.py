from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass

from common.models import Tick


@dataclass(slots=True)
class VenueHealthSnapshot:
    venue: str
    score: float
    spread_bps: float
    volatility_bps: float
    success_rate: float
    failure_rate: float


class VenueHealthScoringService:
    def __init__(self, window: int = 64) -> None:
        self.window = max(window, 8)
        self._spreads: dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=self.window))
        self._mids: dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=self.window))
        self._submissions: dict[str, deque[int]] = defaultdict(lambda: deque(maxlen=self.window))
        self._failures: dict[str, deque[int]] = defaultdict(lambda: deque(maxlen=self.window))

    def observe_tick(self, tick: Tick) -> None:
        if tick.mid <= 0:
            return
        self._spreads[tick.venue].append(tick.spread / tick.mid * 10000.0)
        self._mids[tick.venue].append(tick.mid)

    def record_execution_result(self, venue: str, *, success: bool) -> None:
        self._submissions[venue].append(1)
        self._failures[venue].append(0 if success else 1)

    def snapshot(self, venue: str) -> VenueHealthSnapshot:
        spreads = list(self._spreads.get(venue, ()))
        mids = list(self._mids.get(venue, ()))
        failures = list(self._failures.get(venue, ()))
        submissions = max(len(self._submissions.get(venue, ())), 1)
        spread_bps = sum(spreads) / len(spreads) if spreads else 25.0
        returns = []
        for a, b in zip(mids, mids[1:]):
            if a:
                returns.append((b - a) / a * 10000.0)
        volatility_bps = (sum(abs(x) for x in returns) / len(returns)) if returns else 0.0
        failure_rate = (sum(failures) / submissions) if failures else 0.0
        success_rate = 1.0 - failure_rate
        score = max(0.0, min(100.0, 100.0 - spread_bps * 1.6 - volatility_bps * 0.4 - failure_rate * 55.0))
        return VenueHealthSnapshot(
            venue=venue,
            score=score,
            spread_bps=spread_bps,
            volatility_bps=volatility_bps,
            success_rate=success_rate,
            failure_rate=failure_rate,
        )

    def best(self, venues: list[str]) -> str | None:
        if not venues:
            return None
        ranked = sorted((self.snapshot(v) for v in venues), key=lambda item: item.score, reverse=True)
        return ranked[0].venue if ranked else None

    def rank(self, venues: list[str]) -> list[VenueHealthSnapshot]:
        return sorted((self.snapshot(v) for v in venues), key=lambda item: item.score, reverse=True)
