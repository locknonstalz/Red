from __future__ import annotations

from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Lock, Thread

from ops.metrics import MetricsRegistry


class PrometheusExporter:
    def __init__(self, metrics: MetricsRegistry) -> None:
        self.metrics = metrics
        self._lock = Lock()

    def render(self) -> str:
        with self._lock:
            lines = []
            for key, value in sorted(self.metrics.snapshot().items()):
                metric = ''.join(ch if ch.isalnum() or ch == '_' else '_' for ch in key.lower())
                lines.append(f'# TYPE {metric} counter')
                lines.append(f'{metric} {value}')
            return '\n'.join(lines) + '\n'


def start_metrics_server(port: int, metrics: MetricsRegistry) -> HTTPServer:
    exporter = PrometheusExporter(metrics)

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            if self.path not in {'/metrics', '/'}:
                self.send_response(404)
                self.end_headers()
                return
            payload = exporter.render().encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain; version=0.0.4')
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, *args, **kwargs):
            return

    server = HTTPServer(('0.0.0.0', port), Handler)
    Thread(target=server.serve_forever, daemon=True).start()
    return server
