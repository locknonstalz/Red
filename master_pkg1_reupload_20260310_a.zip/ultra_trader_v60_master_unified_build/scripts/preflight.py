from __future__ import annotations

import asyncio

from dotenv import load_dotenv
load_dotenv()

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config.settings import ALLOWED_VENUES, get_settings
from execution.live.adapters import build_live_broker
from market.live.base import ExchangeCredentials
from ops.metrics import MetricsRegistry



async def _instrument_errors(settings) -> list[str]:
    errors: list[str] = []
    if settings.mode not in {'live', 'micro_live'}:
        return errors
    metrics = MetricsRegistry()
    checks: list[tuple[str, str]] = [(settings.default_venue, settings.default_symbol)]
    if settings.strategy.enable_funding_carry:
        checks.append((settings.strategy.funding_carry.spot_venue, settings.default_symbol))
        checks.append((settings.strategy.funding_carry.perp_venue, settings.default_symbol))
    seen = set()
    brokers = []
    try:
        for venue, symbol in checks:
            key = (venue, symbol)
            if key in seen or venue not in ALLOWED_VENUES:
                continue
            seen.add(key)
            creds_cfg = getattr(settings, venue)
            creds = ExchangeCredentials(api_key=creds_cfg.api_key, api_secret=creds_cfg.api_secret, passphrase=creds_cfg.passphrase or None)
            broker = build_live_broker(venue, creds, metrics)
            brokers.append(broker)
            try:
                vf = await broker.fetch_symbol_filter(symbol)
                if vf.step_size <= 0:
                    errors.append(f'{venue}:{symbol} invalid step_size={vf.step_size}')
                if vf.tick_size < 0:
                    errors.append(f'{venue}:{symbol} invalid tick_size={vf.tick_size}')
                if vf.min_qty < 0:
                    errors.append(f'{venue}:{symbol} invalid min_qty={vf.min_qty}')
                if vf.min_notional < 0:
                    errors.append(f'{venue}:{symbol} invalid min_notional={vf.min_notional}')
                if settings.strategy.enable_funding_carry and settings.strategy.funding_carry.trade_size < vf.min_qty and venue in {settings.strategy.funding_carry.spot_venue, settings.strategy.funding_carry.perp_venue}:
                    errors.append(f'FUNDING_CARRY_TRADE_SIZE={settings.strategy.funding_carry.trade_size} is below {venue}:{symbol} min_qty={vf.min_qty}')
                est_notional = max(settings.strategy.funding_carry.trade_size, settings.risk.max_position_abs) * 0  # placeholder to keep branch explicit
                if settings.strategy.enable_funding_carry and settings.strategy.funding_carry.trade_size > 0 and vf.min_notional > 0:
                    errors.append(f'info:{venue}:{symbol} filters tick={vf.tick_size} step={vf.step_size} min_qty={vf.min_qty} min_notional={vf.min_notional}')
            except Exception as exc:
                errors.append(f'failed instrument check for {venue}:{symbol}: {exc}')
    finally:
        for broker in brokers:
            try:
                await broker.aclose()
            except Exception:
                pass
    return errors

REQUIRED_FILES = [
    ROOT / 'infra/prometheus.yml',
    ROOT / 'infra/alertmanager.yml',
    ROOT / 'docs/LIVE_CERTIFICATION_MATRIX.md',
]


def _cred_errors(settings) -> list[str]:
    errors: list[str] = []
    if settings.mode not in {'live', 'micro_live'}:
        return errors
    for venue in settings.live_venues:
        creds = getattr(settings, venue)
        if not creds.api_key or not creds.api_secret:
            errors.append(f'missing credentials for {venue}')
    return errors


def main() -> int:
    settings = get_settings()
    errors: list[str] = []

    if settings.mode not in {"paper", "live", "micro_live", "shadow"}:
        errors.append("TRADING_MODE must be paper, live, micro_live, or shadow")
    if settings.default_venue not in ALLOWED_VENUES:
        errors.append(f'DEFAULT_VENUE must be one of {sorted(ALLOWED_VENUES)}')
    if settings.mode in {'live', 'micro_live'} and not settings.database.postgres_dsn and not settings.database.sqlite_path:
        errors.append(f'{settings.mode} mode needs DATABASE_URL or SQLITE_PATH')
    if settings.control_plane.enabled and settings.control_plane.auth_enabled and settings.control_plane.auth_secret == 'change-me':
        errors.append('CONTROL_PLANE_AUTH_SECRET must be changed before authenticated startup')
    if settings.control_plane.enabled and settings.control_plane.audit_secret == 'audit-secret':
        errors.append('CONTROL_PLANE_AUDIT_SECRET must be changed before control plane startup')
    if settings.mode in {'live', 'micro_live'} and len(set(settings.live_venues)) != len(settings.live_venues):
        errors.append('LIVE_VENUES must not contain duplicates')
    if settings.mode == 'micro_live' and settings.capital_protection.allocator.max_total_notional > 100.0:
        errors.append('MAX_TOTAL_NOTIONAL must be <= 100.0 for first micro_live launch hardening')
    if settings.capital_protection.allocator.micro_live_min_target_notional <= 0:
        errors.append('MICRO_LIVE_MIN_TARGET_NOTIONAL must be > 0')
    if settings.capital_protection.allocator.micro_live_min_target_notional > settings.capital_protection.allocator.max_total_notional:
        errors.append('MICRO_LIVE_MIN_TARGET_NOTIONAL must be <= MAX_TOTAL_NOTIONAL')
    if settings.risk.max_order_notional <= 0:
        errors.append('MAX_ORDER_NOTIONAL must be > 0')
    if settings.strategy.enable_funding_carry and settings.strategy.funding_carry.trade_size <= 0:
        errors.append('FUNDING_CARRY_TRADE_SIZE must be > 0 when funding carry is enabled')

    errors.extend(_cred_errors(settings))
    instrument_errors = asyncio.run(_instrument_errors(settings))
    info_lines = [e for e in instrument_errors if e.startswith('info:')]
    errors.extend(e for e in instrument_errors if not e.startswith('info:'))
    missing_files = [str(path.relative_to(ROOT)) for path in REQUIRED_FILES if not path.exists()]
    if missing_files:
        errors.extend(f'missing file: {path}' for path in missing_files)

    if errors:
        print('Preflight failed')
        for err in errors:
            print('-', err)
        return 1

    print('Preflight OK')
    print(f'mode={settings.mode}')
    print(f'venues={settings.live_venues if settings.mode == "live" else settings.strategy.cross_exchange_venues}')
    print(f'control_plane={settings.control_plane.enabled}')
    for info in info_lines:
        print(info)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
