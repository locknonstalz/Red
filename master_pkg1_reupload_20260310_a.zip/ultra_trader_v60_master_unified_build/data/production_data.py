from __future__ import annotations

from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from statistics import mean
from typing import Any


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class FeedHealth:
    source: str
    category: str
    healthy: bool
    freshness_sec: float
    records: int
    quality_score: float


@dataclass(slots=True)
class StoredEvent:
    source: str
    category: str
    payload: dict[str, Any]
    ts: datetime = field(default_factory=utc_now)


class ProductionDataLayer:
    def __init__(self) -> None:
        self._events: list[StoredEvent] = []
        self._required = {
            'l2_book': ['venue', 'symbol', 'bids', 'asks'],
            'trade': ['venue', 'symbol', 'price', 'qty'],
            'funding': ['venue', 'symbol', 'funding_rate'],
            'news': ['headline', 'sentiment'],
            'onchain': ['symbol', 'exchange_inflow', 'exchange_outflow'],
        }

    def ingest(self, source: str, category: str, payload: dict[str, Any]) -> None:
        self._events.append(StoredEvent(source=source, category=category, payload=dict(payload)))

    def quality(self, source: str | None = None) -> list[FeedHealth]:
        groups: dict[tuple[str, str], list[StoredEvent]] = {}
        for ev in self._events:
            if source is not None and ev.source != source:
                continue
            groups.setdefault((ev.source, ev.category), []).append(ev)
        out: list[FeedHealth] = []
        now = utc_now()
        for (src, cat), rows in groups.items():
            latest = max(rows, key=lambda x: x.ts)
            freshness = max((now - latest.ts).total_seconds(), 0.0)
            req = self._required.get(cat, [])
            completeness = [sum(1 for key in req if key in row.payload) / max(len(req), 1) for row in rows] or [1.0]
            score = max(0.0, min(100.0, mean(completeness) * 70.0 + max(0.0, 30.0 - freshness)))
            out.append(FeedHealth(source=src, category=cat, healthy=score >= 60.0, freshness_sec=freshness, records=len(rows), quality_score=round(score, 3)))
        return sorted(out, key=lambda x: (x.source, x.category))

    def snapshot(self) -> dict[str, Any]:
        return {
            'feeds': [asdict(x) for x in self.quality()],
            'event_count': len(self._events),
            'categories': sorted({x.category for x in self._events}),
        }
