
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from secrets import token_urlsafe
from typing import Any

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

@dataclass(slots=True)
class PendingConfirmation:
    confirmation_id: str
    actor: str
    action: str
    payload: dict[str, Any]
    reason: str
    expires_at: datetime
    created_at: datetime = field(default_factory=utc_now)

    @property
    def expired(self) -> bool:
        return utc_now() >= self.expires_at

class ConfirmationManager:
    def __init__(self, ttl_seconds: int = 120) -> None:
        self.ttl_seconds = ttl_seconds
        self._pending: dict[str, PendingConfirmation] = {}

    def request(self, *, actor: str, action: str, payload: dict[str, Any], reason: str) -> PendingConfirmation:
        self.prune()
        confirmation = PendingConfirmation(
            confirmation_id=token_urlsafe(12),
            actor=actor,
            action=action,
            payload=dict(payload),
            reason=reason,
            expires_at=utc_now() + timedelta(seconds=self.ttl_seconds),
        )
        self._pending[confirmation.confirmation_id] = confirmation
        return confirmation

    def get(self, confirmation_id: str) -> PendingConfirmation | None:
        self.prune()
        conf = self._pending.get(confirmation_id)
        if conf is None or conf.expired:
            self._pending.pop(confirmation_id, None)
            return None
        return conf

    def consume(self, confirmation_id: str) -> PendingConfirmation | None:
        conf = self.get(confirmation_id)
        if conf is None:
            return None
        self._pending.pop(confirmation_id, None)
        return conf

    def prune(self) -> None:
        for key in list(self._pending.keys()):
            conf = self._pending[key]
            if conf.expired:
                self._pending.pop(key, None)

    def snapshot(self) -> list[dict[str, Any]]:
        self.prune()
        out: list[dict[str, Any]] = []
        for conf in self._pending.values():
            out.append({
                "confirmation_id": conf.confirmation_id,
                "actor": conf.actor,
                "action": conf.action,
                "reason": conf.reason,
                "payload": dict(conf.payload),
                "expires_at": conf.expires_at.isoformat(),
                "created_at": conf.created_at.isoformat(),
            })
        return sorted(out, key=lambda row: row["created_at"], reverse=True)
