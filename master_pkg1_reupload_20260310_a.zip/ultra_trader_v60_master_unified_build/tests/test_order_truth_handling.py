import asyncio
import sqlite3

from common.models import Order, Side
from execution.live.ws_sessions import ReplayPrivateWsSession
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from services.live_orchestration import LiveOrchestrationService
from storage.journal import SqliteJournal


def _status_and_note(db_path: str, client_order_id: str):
    conn = sqlite3.connect(db_path)
    row = conn.execute('SELECT status, note FROM orders WHERE client_order_id = ?', (client_order_id,)).fetchone()
    conn.close()
    return row


def test_cancel_truth_is_applied(tmp_path):
    path = str(tmp_path / 'cancel.db')
    journal = SqliteJournal(path)
    metrics = MetricsRegistry()
    portfolio = PortfolioService('USDT', journal, metrics)
    journal.record_order(Order(strategy='s', venue='bitget', symbol='BTCUSDT', side=Side.BUY, qty=0.01, client_order_id='c1'))
    session = ReplayPrivateWsSession('bitget', [
        {'arg': {'channel': 'orders'}, 'data': [{'clientOid': 'c1', 'orderId': '1', 'instId': 'BTCUSDT', 'status': 'cancelled', 'accBaseVolume': '0', 'priceAvg': '0', 'uTime': '1700000000000'}]},
    ])
    asyncio.run(LiveOrchestrationService(sessions={'bitget': session}, journal=journal, portfolio=portfolio, metrics=metrics).run())
    status, note = _status_and_note(path, 'c1')
    assert status == 'CANCELLED'
    assert 'cancel_truth=' in note


def test_amend_truth_is_applied(tmp_path):
    path = str(tmp_path / 'amend.db')
    journal = SqliteJournal(path)
    metrics = MetricsRegistry()
    portfolio = PortfolioService('USDT', journal, metrics)
    journal.record_order(Order(strategy='s', venue='bybit', symbol='BTCUSDT', side=Side.BUY, qty=0.01, client_order_id='c2'))
    session = ReplayPrivateWsSession('bybit', [
        {'topic': 'order', 'creationTime': '1700000000000', 'data': [{'orderLinkId': 'c2', 'orderId': '2', 'symbol': 'BTCUSDT', 'orderStatus': 'amended', 'cumExecQty': '0', 'avgPrice': '0'}]},
    ])
    asyncio.run(LiveOrchestrationService(sessions={'bybit': session}, journal=journal, portfolio=portfolio, metrics=metrics).run())
    status, note = _status_and_note(path, 'c2')
    assert status == 'ACCEPTED'
    assert 'amend_truth=' in note
