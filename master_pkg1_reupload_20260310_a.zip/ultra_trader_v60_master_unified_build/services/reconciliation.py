from __future__ import annotations

import asyncio
import hashlib
import json

from common.models import Balance, Position
from execution.broker import Broker
from execution.live.rest_base import BaseRestBroker
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.base import Journal


class ReconciliationService:
    def __init__(self, broker: Broker, journal: Journal, interval_sec: float, metrics: MetricsRegistry, portfolio: PortfolioService | None = None) -> None:
        self.broker = broker
        self.journal = journal
        self.interval_sec = interval_sec
        self.metrics = metrics
        self.portfolio = portfolio

    def _payload_hash(self, payload: dict) -> str:
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def _apply_balance(self, balance: Balance) -> None:
        event_id = f'{balance.asset}'
        payload = {'asset': balance.asset, 'free': balance.free, 'locked': balance.locked}
        if self.journal.seen_reconciliation_event(balance.venue, 'balance', event_id):
            return
        self.journal.record_reconciliation_event(balance.venue, 'balance', event_id, self._payload_hash(payload))
        self.journal.save_balance_snapshot(balance)
        if self.portfolio:
            self.portfolio.sync_balance(balance)

    def _apply_position(self, position: Position) -> None:
        event_id = f'{position.symbol}'
        payload = {'symbol': position.symbol, 'qty': position.qty, 'avg_price': position.avg_price}
        if self.journal.seen_reconciliation_event(position.venue, 'position', event_id):
            return
        self.journal.record_reconciliation_event(position.venue, 'position', event_id, self._payload_hash(payload))
        self.journal.save_position_snapshot(position)
        if self.portfolio:
            self.portfolio.sync_position(position)

    async def run(self) -> None:
        while True:
            broker_open = set(await self.broker.list_open_orders())
            journal_open = set(self.journal.open_order_ids())
            if broker_open != journal_open:
                self.metrics.increment('reconciliation_breaks_total')
            if isinstance(self.broker, BaseRestBroker):
                for balance in await self.broker.fetch_balances():
                    self._apply_balance(balance)
                for position in await self.broker.fetch_positions():
                    self._apply_position(position)
            await asyncio.sleep(self.interval_sec)
