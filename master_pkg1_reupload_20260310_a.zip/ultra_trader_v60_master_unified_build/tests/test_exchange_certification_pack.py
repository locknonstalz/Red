from certification.runner import ExchangeCertificationPack
from certification.scenarios import default_certification_configs


def test_default_pack_has_all_four_venues():
    pack = ExchangeCertificationPack()
    assert set(pack.configured_venues()) == {'binance', 'bybit', 'mexc', 'bitget'}


def test_default_configs_match_expected_environments():
    configs = default_certification_configs()
    assert configs['binance'].environment == 'testnet'
    assert configs['bybit'].environment == 'testnet'
    assert configs['bitget'].environment == 'demo'
    assert configs['mexc'].environment == 'live-guarded'


def test_bitget_requires_passphrase_and_mexc_is_guarded():
    configs = default_certification_configs()
    assert configs['bitget'].require_passphrase is True
    assert configs['mexc'].allow_live_micro_orders is False
