from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from common.models import Order, Side


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class DerivativeInstrument:
    venue: str
    symbol: str
    contract_type: str = 'perpetual'
    quote_asset: str = 'USDT'
    tick_size: float = 0.1
    step_size: float = 0.001
    min_notional: float = 5.0
    max_leverage: float = 20.0


@dataclass(slots=True)
class FundingSnapshot:
    venue: str
    symbol: str
    funding_rate: float
    open_interest: float = 0.0
    basis_bps: float = 0.0
    ts: datetime = field(default_factory=utc_now)


@dataclass(slots=True)
class FuturesOrderIntent:
    strategy: str
    venue: str
    symbol: str
    side: Side
    qty: float
    leverage: float = 1.0
    reduce_only: bool = False
    close_only: bool = False

    def to_order(self) -> Order:
        tags = {}
        return Order(strategy=self.strategy, venue=self.venue, symbol=self.symbol, side=self.side, qty=self.qty)
