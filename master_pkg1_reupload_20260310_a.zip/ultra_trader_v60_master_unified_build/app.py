from dotenv import load_dotenv
load_dotenv()

import asyncio

from common.logging import configure_logging, get_logger
from config.settings import get_settings
from runtime.bootstrap import TradingRuntime, build_runtime_bundle

async def main() -> None:
    settings = get_settings()
    configure_logging(settings.log_level)
    log = get_logger('app')
    bundle = build_runtime_bundle(settings)
    runtime = TradingRuntime(bundle)
    log.info('bootstrap_complete', extra={'mode': settings.mode, 'venues': settings.live_venues, 'control_plane': settings.control_plane.enabled})
    await runtime.run_for(settings.runtime_seconds)


if __name__ == '__main__':
    asyncio.run(main())
