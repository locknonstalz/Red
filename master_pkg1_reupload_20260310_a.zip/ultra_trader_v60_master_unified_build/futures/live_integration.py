from __future__ import annotations

import asyncio
import hashlib
import json
from dataclasses import dataclass
from typing import Any

from common.models import Balance, Fill, OrderStatus, Position
from execution.circuit_breakers import CircuitBreaker
from execution.live.session_choreography import LeaseCoordinator, VenueSessionChoreographer
from execution.live.stateful_session import ReconnectPolicy, StatefulSessionManager
from execution.live.ws_sessions import BasePrivateWsSession
from futures.private_streams import BinanceFuturesPrivateAdapter, BitgetFuturesPrivateAdapter, BybitFuturesPrivateAdapter, MexcFuturesPrivateAdapter
from futures.reconciliation import FuturesTruthReconciliationService
from ops.dead_letter import DeadLetterQueue
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.base import Journal


@dataclass(slots=True)
class FuturesOrchestrationStats:
    sessions_started: int = 0
    fills_applied: int = 0
    balances_synced: int = 0
    positions_synced: int = 0
    order_updates_applied: int = 0
    funding_updates: int = 0


class FuturesLiveOrchestrationService:
    def __init__(self, *, sessions: dict[str, BasePrivateWsSession], journal: Journal, portfolio: PortfolioService, metrics: MetricsRegistry, dlq: DeadLetterQueue | None = None, reconnect_policy: ReconnectPolicy | None = None, lease_owner: str = 'local-dev', lease_ttl_sec: int = 30) -> None:
        self.sessions = sessions
        self.journal = journal
        self.portfolio = portfolio
        self.metrics = metrics
        self.truth = FuturesTruthReconciliationService(journal)
        self.dlq = dlq or DeadLetterQueue(journal)
        self.circuit_breaker = CircuitBreaker(max_failures=5, cooldown_sec=30.0)
        self.reconnect_policy = reconnect_policy or ReconnectPolicy(max_attempts=5, backoff_sec=0.25)
        self.lease = LeaseCoordinator(journal, owner=lease_owner, ttl_sec=lease_ttl_sec)
        self.stats = FuturesOrchestrationStats()
        self._plans = VenueSessionChoreographer()
        self._adapters = {
            'binance': BinanceFuturesPrivateAdapter(),
            'bybit': BybitFuturesPrivateAdapter(),
            'mexc': MexcFuturesPrivateAdapter(),
            'bitget': BitgetFuturesPrivateAdapter(),
        }

    def _payload_hash(self, payload: dict[str, Any]) -> str:
        return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()

    def _mark_seen(self, venue: str, event_type: str, external_id: str, payload: dict[str, Any]) -> bool:
        if self.journal.seen_reconciliation_event(venue, event_type, external_id):
            self.metrics.increment('futures_orchestration_duplicate_events_total')
            return False
        self.journal.record_reconciliation_event(venue, event_type, external_id, self._payload_hash(payload))
        return True

    def _apply_balance(self, balance: Balance, raw: dict[str, Any]) -> None:
        external_id = balance.asset + ':' + balance.ts.isoformat()
        if not self._mark_seen(balance.venue, 'futures_balance', external_id, raw):
            return
        self.portfolio.sync_balance(balance)
        self.journal.save_balance_snapshot(balance)
        self.stats.balances_synced += 1

    def _apply_position(self, position: Position, raw: dict[str, Any]) -> None:
        external_id = f'{position.symbol}:{position.qty}:{position.avg_price}'
        if not self._mark_seen(position.venue, 'futures_position', external_id, raw):
            return
        self.portfolio.sync_position(position)
        self.truth.apply_position_truth(position)
        self.stats.positions_synced += 1

    def _apply_order_update(self, venue: str, update, raw: dict[str, Any]) -> None:
        external_id = f'{update.exchange_order_id}:{update.status}:{update.filled_qty}'
        if not self._mark_seen(venue, 'futures_order_update', external_id, raw):
            return
        status = str(update.status).lower()
        mapped = OrderStatus.FILLED if 'filled' in status else OrderStatus.CANCELLED if 'cancel' in status else OrderStatus.PARTIALLY_FILLED if 'partial' in status else OrderStatus.ACCEPTED
        self.journal.update_order_status(update.client_order_id, mapped, note=f'futures_private_stream_status={update.status}')
        self.stats.order_updates_applied += 1

    def _apply_fill(self, fill: Fill, raw: dict[str, Any]) -> None:
        external_id = fill.trade_id or f'{fill.exchange_order_id}:{fill.client_order_id}:{fill.qty}:{fill.price}'
        if not self._mark_seen(fill.venue, 'futures_fill', external_id, raw):
            return
        self.journal.record_fill(fill)
        self.portfolio.apply_fill(fill)
        self.stats.fills_applied += 1

    def _apply_mark(self, venue: str, symbol: str, raw: dict[str, Any]) -> None:
        mark = float(raw.get('markPrice', raw.get('mark_price', 0)) or 0)
        index = float(raw.get('indexPrice', raw.get('index_price', 0)) or 0)
        liq = float(raw.get('liquidationPrice', raw.get('liqPx', 0)) or 0)
        oi = float(raw.get('openInterest', raw.get('oi', 0)) or 0)
        basis = float(raw.get('basisBps', raw.get('basis_bps', 0)) or 0)
        self.truth.apply_mark_price(venue, symbol, mark_price=mark, index_price=index, liquidation_price=liq, open_interest=oi, basis_bps=basis)

    async def _dispatch(self, venue: str, payload: dict[str, Any]) -> None:
        if payload.get('markPrice') or payload.get('mark_price'):
            self._apply_mark(venue, payload.get('symbol', ''), payload)
            return
        adapter = self._adapters[venue]
        if venue == 'binance':
            ou = adapter.parse_order_update(payload)
            if ou:
                self._apply_order_update(venue, ou, payload)
            fill = adapter.parse_execution(payload)
            if fill:
                self._apply_fill(fill, payload)
            for bal in adapter.parse_balance(payload):
                self._apply_balance(bal, payload)
            for pos in adapter.parse_position(payload):
                self._apply_position(pos, payload)
            funding = adapter.parse_funding(payload)
            if funding:
                self.truth.apply_funding(funding)
                self.stats.funding_updates += 1
            return
        if venue == 'bybit':
            for ou in adapter.parse_order(payload):
                self._apply_order_update(venue, ou, payload)
            for fill in adapter.parse_execution(payload):
                self._apply_fill(fill, payload)
            for bal in adapter.parse_wallet(payload):
                self._apply_balance(bal, payload)
            for pos in adapter.parse_position(payload):
                self._apply_position(pos, payload)
            funding = adapter.parse_funding(payload)
            if funding:
                self.truth.apply_funding(funding)
                self.stats.funding_updates += 1
            return
        if venue == 'mexc':
            ou = adapter.parse_order(payload)
            if ou:
                self._apply_order_update(venue, ou, payload)
            fill = adapter.parse_execution(payload)
            if fill:
                self._apply_fill(fill, payload)
            for pos in adapter.parse_position(payload):
                self._apply_position(pos, payload)
            funding = adapter.parse_funding(payload)
            if funding:
                self.truth.apply_funding(funding)
                self.stats.funding_updates += 1
            return
        if venue == 'bitget':
            for ou in adapter.parse_order(payload):
                self._apply_order_update(venue, ou, payload)
            for fill in adapter.parse_execution(payload):
                self._apply_fill(fill, payload)
            for bal in adapter.parse_account(payload):
                self._apply_balance(bal, payload)
            for pos in adapter.parse_position(payload):
                self._apply_position(pos, payload)
            funding = adapter.parse_funding(payload)
            if funding:
                self.truth.apply_funding(funding)
                self.stats.funding_updates += 1
            return
        if payload.get('markPrice') or payload.get('mark_price'):
            self._apply_mark(venue, payload.get('symbol', ''), payload)

    async def _run_session(self, venue: str, session: BasePrivateWsSession) -> None:
        checkpoint = self.journal.load_stream_checkpoint(venue, session.channel)
        _ = self._plans.build(venue, checkpoint, getattr(session, 'symbol', None))
        manager = StatefulSessionManager(venue, session, self.journal, self.metrics, self.reconnect_policy)
        async for message in manager.stream():
            self.lease.renew(f'futures-private-stream:{venue}')
            await self._dispatch(venue, message.payload)

    async def _guarded_session(self, venue: str, session: BasePrivateWsSession) -> None:
        lease_name = f'futures-private-stream:{venue}'
        if not self.lease.acquire(lease_name):
            return
        try:
            await self._run_session(venue, session)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self.dlq.push('futures_private_ws', venue, str(exc))
            raise
        finally:
            self.lease.release(lease_name)

    async def run(self) -> None:
        async with asyncio.TaskGroup() as tg:
            for venue, session in self.sessions.items():
                self.stats.sessions_started += 1
                tg.create_task(self._guarded_session(venue, session), name=f'futures-private-ws-{venue}')
