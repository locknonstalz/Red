from __future__ import annotations

from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

from ai.feature_engineering import OnlineFeatureStore
from ai.online_model import OnlineLogisticModel
from common.models import Fill, Signal, Side, Tick
from ops.metrics import MetricsRegistry


@dataclass(slots=True)
class AIScoreResult:
    accepted: bool
    probability: float
    adjusted_signal: Signal | None = None
    reason: str = 'ok'


@dataclass(slots=True)
class PendingLabel:
    features: dict[str, float]
    side: Side
    entry_mid: float
    due_tick: int


@dataclass(slots=True)
class StrategyRewardState:
    ewma_reward: float = 0.0
    trades: int = 0


class AIDecisionEngine:
    def __init__(
        self,
        metrics: MetricsRegistry,
        *,
        enabled: bool = True,
        entry_horizon_ticks: int = 8,
        min_training_move_bps: float = 2.0,
        min_accept_probability: float = 0.53,
        strong_probability: float = 0.63,
        size_boost: float = 1.5,
        size_cut: float = 0.5,
        model_path: str = 'ai_model.json',
    ) -> None:
        self.metrics = metrics
        self.enabled = enabled
        self.entry_horizon_ticks = entry_horizon_ticks
        self.min_training_move_bps = min_training_move_bps
        self.min_accept_probability = min_accept_probability
        self.strong_probability = strong_probability
        self.size_boost = size_boost
        self.size_cut = size_cut
        self.model_path = model_path
        self.feature_store = OnlineFeatureStore()
        self.model = self._load_model(model_path)
        self.pending: dict[tuple[str, str], list[PendingLabel]] = {}
        self.rewards: dict[str, StrategyRewardState] = {}
        self._fill_entry: dict[str, float] = {}

    def _load_model(self, path: str) -> OnlineLogisticModel:
        p = Path(path)
        if p.exists():
            try:
                return OnlineLogisticModel.load(p)
            except Exception:
                return OnlineLogisticModel()
        return OnlineLogisticModel()

    def observe_tick(self, tick: Tick) -> None:
        snapshot = self.feature_store.observe_tick(tick)
        key = (tick.venue, tick.symbol)
        matured = []
        for pending in self.pending.get(key, []):
            if snapshot.tick_index >= pending.due_tick:
                matured.append(pending)
        if not matured:
            return
        remaining = [p for p in self.pending.get(key, []) if snapshot.tick_index < p.due_tick]
        self.pending[key] = remaining
        for pending in matured:
            move_bps = ((tick.mid - pending.entry_mid) / pending.entry_mid) * 10000.0 if pending.entry_mid else 0.0
            directional_move = move_bps if pending.side == Side.BUY else -move_bps
            label = 1 if directional_move >= self.min_training_move_bps else 0
            self.model.update(pending.features, label)
            self.metrics.increment('ai_training_updates_total')
        if self.model.updates and self.model.updates % 50 == 0:
            self.persist()

    def persist(self) -> None:
        try:
            self.model.save(self.model_path)
        except Exception:
            pass

    def score_signal(self, signal: Signal, tick: Tick) -> AIScoreResult:
        if not self.enabled:
            return AIScoreResult(True, probability=0.5, adjusted_signal=signal, reason='disabled')
        features = self.feature_store.features_for_signal(tick, signal.side, signal.strength)
        probability = self.model.predict_proba(features)
        reward = self.rewards.get(signal.strategy, StrategyRewardState())
        reward_adjustment = max(min(reward.ewma_reward / 25.0, 0.05), -0.05)
        adjusted_probability = max(0.0, min(1.0, probability + reward_adjustment))
        if adjusted_probability < self.min_accept_probability:
            self.metrics.increment('ai_signals_rejected_total')
            return AIScoreResult(False, adjusted_probability, None, reason='probability_below_threshold')
        qty = signal.qty or 0.0
        if adjusted_probability >= self.strong_probability:
            qty *= self.size_boost
        else:
            qty *= self.size_cut + (adjusted_probability - self.min_accept_probability) / max(self.strong_probability - self.min_accept_probability, 1e-9) * (1.0 - self.size_cut)
        qty = max(qty, 1e-9)
        tags = dict(signal.tags)
        tags.update({
            'ai_probability': round(adjusted_probability, 5),
            'ai_raw_probability': round(probability, 5),
            'ai_model_updates': self.model.updates,
        })
        adjusted = replace(signal, qty=qty, strength=max(signal.strength, adjusted_probability), tags=tags)
        key = (tick.venue, tick.symbol)
        due_tick = self.feature_store.current_tick_index(tick.venue, tick.symbol) + self.entry_horizon_ticks
        self.pending.setdefault(key, []).append(PendingLabel(features=features, side=signal.side, entry_mid=tick.mid, due_tick=due_tick))
        self.metrics.increment('ai_signals_accepted_total')
        return AIScoreResult(True, adjusted_probability, adjusted, reason='accepted')

    def observe_fill(self, fill: Fill, strategy_name: str | None = None) -> None:
        if fill.client_order_id not in self._fill_entry:
            self._fill_entry[fill.client_order_id] = fill.price
            return
        entry = self._fill_entry[fill.client_order_id]
        pnl_bps = ((fill.price - entry) / entry) * 10000.0 if entry else 0.0
        if fill.side == Side.BUY:
            pnl_bps *= -1.0
        if strategy_name:
            state = self.rewards.setdefault(strategy_name, StrategyRewardState())
            state.trades += 1
            alpha = 0.15
            state.ewma_reward = (1 - alpha) * state.ewma_reward + alpha * pnl_bps
        self.metrics.increment('ai_fill_feedback_total')
