@echo off
cd /d %~dp0
call .venv\Scripts\activate.bat
python -m pip install pyinstaller
pyinstaller --noconfirm --onefile --windowed --name UltraTraderControlCenter gui_launcher.py
