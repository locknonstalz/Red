import asyncio

from common.bus import EventBus
from common.models import Order, OrderStatus, Side
from execution.live.ws_sessions import ReplayPrivateWsSession
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from services.live_orchestration import LiveOrchestrationService
from storage.journal import SqliteJournal


def test_stateful_reconnect_and_checkpoint_resume(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'reconnect.db'))
    metrics = MetricsRegistry()
    portfolio = PortfolioService('USDT', journal, metrics)
    order = Order(strategy='s', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=0.01, client_order_id='c-recon')
    journal.record_order(order)
    journal.update_order_status(order.client_order_id, OrderStatus.ACCEPTED)

    session = ReplayPrivateWsSession(
        'binance',
        [
            {'e': 'executionReport', 'X': 'NEW', 'c': 'c-recon', 'i': 1, 's': 'BTCUSDT', 'S': 'BUY', 'z': '0', 'E': 1700000000000, 'seq': 1},
        ],
        reconnect_frames=[[
            {'e': 'executionReport', 'x': 'TRADE', 'X': 'FILLED', 'c': 'c-recon', 'i': 1, 's': 'BTCUSDT', 'S': 'BUY', 'l': '0.01', 'L': '100', 'z': '0.01', 'n': '0.01', 't': 10, 'E': 1700000000100, 'seq': 2},
        ]],
        fail_after_batches=1,
    )

    svc = LiveOrchestrationService(sessions={'binance': session}, journal=journal, portfolio=portfolio, metrics=metrics, bus=EventBus())
    asyncio.run(svc.run())
    assert metrics.snapshot()['private_stream_reconnects_total'] == 1
    ckpt = journal.load_stream_checkpoint('binance', 'private')
    assert ckpt is not None and ckpt.sequence == 2
    assert portfolio.get_position('BTCUSDT').qty == 0.01


def test_gap_recovery_replays_missing_sequences(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'gap.db'))
    metrics = MetricsRegistry()
    portfolio = PortfolioService('USDT', journal, metrics)
    order = Order(strategy='s', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=0.02, client_order_id='c-gap')
    journal.record_order(order)
    journal.update_order_status(order.client_order_id, OrderStatus.ACCEPTED)

    session = ReplayPrivateWsSession(
        'binance',
        [
            {'e': 'executionReport', 'X': 'NEW', 'c': 'c-gap', 'i': 1, 's': 'BTCUSDT', 'S': 'BUY', 'z': '0', 'E': 1700000000000, 'seq': 1},
            {'e': 'executionReport', 'x': 'TRADE', 'X': 'FILLED', 'c': 'c-gap', 'i': 1, 's': 'BTCUSDT', 'S': 'BUY', 'l': '0.01', 'L': '100', 'z': '0.02', 'n': '0.01', 't': 11, 'E': 1700000000200, 'seq': 3},
        ],
        gap_frames=[
            {'e': 'executionReport', 'x': 'TRADE', 'X': 'PARTIALLY_FILLED', 'c': 'c-gap', 'i': 1, 's': 'BTCUSDT', 'S': 'BUY', 'l': '0.01', 'L': '100', 'z': '0.01', 'n': '0.01', 't': 10, 'E': 1700000000100, 'seq': 2},
        ],
    )
    svc = LiveOrchestrationService(sessions={'binance': session}, journal=journal, portfolio=portfolio, metrics=metrics)
    asyncio.run(svc.run())
    assert metrics.snapshot()['private_stream_gap_detected_total'] == 1
    assert portfolio.get_position('BTCUSDT').qty == 0.02
