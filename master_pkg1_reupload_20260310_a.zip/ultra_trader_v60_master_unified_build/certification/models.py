from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone


@dataclass(slots=True)
class StepResult:
    name: str
    ok: bool
    detail: str = ''
    raw: dict | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class CertificationResult:
    venue: str
    environment: str
    symbol: str
    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    completed_at: str | None = None
    success: bool = True
    steps: list[StepResult] = field(default_factory=list)

    def add(self, step: StepResult) -> None:
        self.steps.append(step)
        if not step.ok:
            self.success = False

    def finalize(self) -> None:
        self.completed_at = datetime.now(timezone.utc).isoformat()
        self.success = all(step.ok for step in self.steps) if self.steps else False

    def to_dict(self) -> dict:
        return {
            'venue': self.venue,
            'environment': self.environment,
            'symbol': self.symbol,
            'started_at': self.started_at,
            'completed_at': self.completed_at,
            'success': self.success,
            'steps': [step.to_dict() for step in self.steps],
        }


@dataclass(slots=True)
class VenueCertificationConfig:
    venue: str
    environment: str
    symbol: str = 'BTCUSDT'
    enable_public_ws: bool = True
    enable_private_ws: bool = True
    enable_place_cancel: bool = True
    enable_balance_check: bool = True
    enable_order_status_check: bool = True
    require_passphrase: bool = False
    allow_live_micro_orders: bool = False
    notes: str = ''
