from __future__ import annotations

from ai.decision_engine import AIDecisionEngine
from capital.protection import CapitalProtectionService
from common.bus import EventBus
from common.models import Order, Tick
from execution.execution_service import ExecutionService
from common.logging import get_logger
from execution.sor import SmartOrderRouter
from ops.metrics import MetricsRegistry
from research.attribution import StrategyAttributionService
from research.allocator import StrategyAllocatorService
from research.scoring import SignalScoringLayer
from strategy.base import Strategy
from strategy.shadow import ShadowDeploymentService


class StrategyService:
    def __init__(
        self,
        bus: EventBus,
        execution: ExecutionService,
        strategies: list[Strategy],
        metrics: MetricsRegistry,
        ai_engine: AIDecisionEngine | None = None,
        capital_protection: CapitalProtectionService | None = None,
        signal_scorer: SignalScoringLayer | None = None,
        attribution: StrategyAttributionService | None = None,
        allocator: StrategyAllocatorService | None = None,
        router: SmartOrderRouter | None = None,
        shadow: ShadowDeploymentService | None = None,
        routed_strategies: set[str] | None = None,
    ) -> None:
        self.bus = bus
        self.execution = execution
        self.strategies = strategies
        self.metrics = metrics
        self.ai_engine = ai_engine
        self.capital_protection = capital_protection
        self.signal_scorer = signal_scorer
        self.attribution = attribution
        self.allocator = allocator
        self.router = router
        self.shadow = shadow
        self.routed_strategies = routed_strategies or set()
        self.tick_queue = bus.subscribe("ticks")
        self.fill_queue = bus.subscribe("fills")
        self.log = get_logger('strategy')
        self._strategy_tick_counts: dict[str, int] = {}
        self._strategy_last_blockers: dict[str, str] = {}

    async def _drain_fills(self) -> None:
        while not self.fill_queue.empty():
            fill = await self.fill_queue.get()
            if self.attribution is not None:
                self.attribution.observe_fill(fill)
            strategy_name = None
            for strategy in self.strategies:
                handler = getattr(strategy, 'on_fill', None)
                if handler is not None:
                    handler(fill.side, fill.qty)
                if getattr(strategy, 'name', '') == fill.client_order_id.split(':', 1)[0]:
                    strategy_name = strategy.name
            if self.ai_engine is not None:
                self.ai_engine.observe_fill(fill, strategy_name=strategy_name)

    async def run(self) -> None:
        while True:
            tick: Tick = await self.tick_queue.get()
            if self.ai_engine is not None:
                self.ai_engine.observe_tick(tick)
            if self.shadow is not None:
                self.shadow.observe_tick(tick)
            if self.capital_protection is not None:
                self.capital_protection.on_tick(tick)
                for protective_order in self.capital_protection.protective_orders(tick):
                    protective_tick = self.execution.last_tick_for(protective_order.venue, protective_order.symbol) or tick
                    await self.execution.submit_order(protective_order, market_tick=protective_tick)
            await self._drain_fills()
            for strategy in self.strategies:
                signals = strategy.on_tick(tick)
                name = getattr(strategy, 'name', strategy.__class__.__name__)
                self._strategy_tick_counts[name] = self._strategy_tick_counts.get(name, 0) + 1
                if not signals and self._strategy_tick_counts[name] % 10 == 0 and hasattr(strategy, 'debug_state'):
                    try:
                        self.log.info('strategy_waiting', extra={'strategy': name, 'tick_count': self._strategy_tick_counts[name], 'state': getattr(strategy, 'debug_state')()})
                    except Exception:
                        pass
                for signal in signals:
                    signal_tick = tick if tick.venue == signal.venue and tick.symbol == signal.symbol else self.execution.last_tick_for(signal.venue, signal.symbol)
                    if signal_tick is None:
                        self._strategy_last_blockers[name] = 'missing_market_tick'
                        self.log.info('strategy_signal_blocked', extra={'strategy': name, 'reason_code': 'missing_market_tick', 'reason_text': f'No market tick for {signal.venue} {signal.symbol}', 'signal_reason': signal.reason, 'symbol': signal.symbol, 'venue': signal.venue})
                        continue
                    if self.signal_scorer is not None:
                        research_score = self.signal_scorer.score(signal, signal_tick)
                        if not research_score.accepted or research_score.signal is None:
                            self._strategy_last_blockers[name] = 'score_below_threshold'
                            self.log.info('strategy_signal_blocked', extra={'strategy': name, 'reason_code': 'score_below_threshold', 'reason_text': getattr(research_score, 'reason', 'Research score rejected signal'), 'signal_reason': signal.reason, 'symbol': signal.symbol, 'venue': signal.venue})
                            continue
                        signal = research_score.signal
                    if self.allocator is not None:
                        alloc = self.allocator.evaluate(signal, signal_tick)
                        if not alloc.accepted or alloc.signal is None:
                            self._strategy_last_blockers[name] = 'strategy_allocator_blocked'
                            self.log.info('strategy_signal_blocked', extra={'strategy': name, 'reason_code': 'strategy_allocator_blocked', 'reason_text': getattr(alloc, 'reason', 'Allocator rejected signal'), 'signal_reason': signal.reason, 'symbol': signal.symbol, 'venue': signal.venue})
                            continue
                        signal = alloc.signal
                    if self.ai_engine is not None:
                        ai_score = self.ai_engine.score_signal(signal, signal_tick)
                        if not ai_score.accepted or ai_score.adjusted_signal is None:
                            self._strategy_last_blockers[name] = 'ai_blocked'
                            self.log.info('strategy_signal_blocked', extra={'strategy': name, 'reason_code': 'ai_blocked', 'reason_text': getattr(ai_score, 'reason', 'AI rejected signal'), 'signal_reason': signal.reason, 'symbol': signal.symbol, 'venue': signal.venue})
                            continue
                        signal = ai_score.adjusted_signal
                    self.metrics.increment("signals_total")
                    self.metrics.increment(f"signals_{signal.strategy}_total")
                    order_venue = signal.venue
                    if self.router is not None and signal.strategy in self.routed_strategies:
                        ticks = {venue: last for (venue, symbol), last in self.execution._last_ticks.items() if symbol == signal.symbol}
                        route = self.router.route(signal.symbol, signal.side, ticks)
                        if route is not None:
                            order_venue = route.selected_venue
                            signal_tick = self.execution.last_tick_for(order_venue, signal.symbol) or signal_tick
                    order = Order(
                        strategy=signal.strategy,
                        venue=order_venue,
                        symbol=signal.symbol,
                        side=signal.side,
                        qty=signal.qty or getattr(strategy, "order_size", 0.01),
                        order_type=signal.order_type,
                        limit_price=signal.limit_price,
                    )
                    if self.shadow is not None and self.shadow.enabled_for(order.strategy):
                        self.shadow.capture(order, mark_price=signal_tick.mid)
                        continue
                    self.log.info('signal_accepted_for_execution', extra={'strategy': name, 'symbol': order.symbol, 'venue': order.venue, 'side': order.side.value, 'qty': order.qty, 'signal_reason': signal.reason})
                    await self.execution.submit_order(order, market_tick=signal_tick)
