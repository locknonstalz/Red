from common.models import Balance, Order, Position, Side, VenueFilter
from execution.circuit_breakers import CircuitBreaker
from execution.filters import PrecisionFilterService
from services.reconciliation import ReconciliationService
from storage.journal import SqliteJournal
from ops.metrics import MetricsRegistry


class DummyBroker:
    async def list_open_orders(self):
        return []


def test_precision_filter_rounds_and_checks(tmp_path):
    service = PrecisionFilterService()
    order = Order(strategy='s', venue='binance', symbol='BTC/USDT', side=Side.BUY, qty=0.019)
    vf = VenueFilter('binance', 'BTC/USDT', tick_size=0.1, step_size=0.01, min_qty=0.01, min_notional=1)
    normalized = service.normalize(order, vf, reference_price=100)
    assert normalized.qty == 0.01


def test_reconciliation_idempotency(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'test.db'))
    metrics = MetricsRegistry()
    recon = ReconciliationService(DummyBroker(), journal, 1.0, metrics)
    recon._apply_balance(Balance('binance', 'USDT', 10, 0))
    recon._apply_balance(Balance('binance', 'USDT', 10, 0))
    assert journal.seen_reconciliation_event('binance', 'balance', 'USDT')


def test_circuit_breaker_opens():
    cb = CircuitBreaker(max_failures=2, cooldown_sec=10)
    assert cb.allow()
    cb.on_failure(); cb.on_failure()
    assert not cb.allow()
