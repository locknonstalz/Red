from fastapi.testclient import TestClient

from capital.protection import CapitalProtectionService
from common.models import Fill, Order, Side, Tick
from config.settings import CapitalProtectionSettings
from control_plane.api import create_control_plane_app
from control_plane.auth import AuthConfig, ControlPlanePrincipal, TokenAuthManager
from control_plane.service import ControlPlaneService
from execution.quality import ExecutionQualityAttributionService
from ops.alerts import AlertRouter
from ops.go_live import GoLiveScoringService
from ops.incidents import AlertInboxSink, IncidentWorkflowService, LivePromotionGateService
from ops.metrics import MetricsRegistry
from ops.rollout import RolloutGuardrailService
from portfolio.portfolio_service import PortfolioService
from research.asset_analysis import AssetAnalysisService
from research.capacity import CapacityScoringService
from storage.journal import SqliteJournal
from research.venue_health import VenueHealthScoringService


def test_execution_quality_tracks_slippage_and_fees() -> None:
    service = ExecutionQualityAttributionService()
    tick = Tick(venue='binance', symbol='BTCUSDT', price=100.0, bid=99.5, ask=100.5)
    order = Order(strategy='maker', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0)
    service.observe_submission(order, tick)
    fill = Fill(client_order_id=order.client_order_id, venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0, price=100.7, fee=0.05, strategy='maker')
    service.observe_fill(fill)

    snap = service.snapshot()
    maker = snap['strategy:maker']
    assert maker.fills == 1
    assert maker.avg_slippage_bps > 0
    assert maker.avg_fee_bps > 0
    assert maker.adverse_fill_rate == 1.0


def test_rollout_guardrails_block_excessive_stage_when_execution_quality_bad() -> None:
    alerts = AlertInboxSink()
    incidents = IncidentWorkflowService()
    promotions = LivePromotionGateService()
    promotions.request_promotion(strategy='alpha', target_stage='shadow', checks={'research_ok': True}, actor='ops', reason='start')
    promotions.approve('alpha', actor='admin')
    promotions.request_promotion(strategy='alpha', target_stage='paper', checks={'shadow_ok': True}, actor='ops', reason='ready')
    promotions.approve('alpha', actor='admin')
    promotions.request_promotion(strategy='alpha', target_stage='micro_live', checks={'paper_ok': True}, actor='ops', reason='promote')

    go_live = GoLiveScoringService(promotions=promotions, incidents=incidents, alerts=alerts)
    quality = ExecutionQualityAttributionService()
    tick = Tick(venue='binance', symbol='BTCUSDT', price=100.0, bid=99.8, ask=100.2)
    order = Order(strategy='alpha', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0)
    quality.observe_submission(order, tick)
    quality.observe_fill(Fill(client_order_id=order.client_order_id, venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0, price=101.0, fee=0.25, strategy='alpha'))

    guardrails = RolloutGuardrailService(go_live=go_live, promotions=promotions, incidents=incidents, alerts=alerts, execution_quality=quality)
    decision = guardrails.evaluate_promotion('alpha', 'micro_live')
    assert decision.allowed is False
    assert 'slippage_too_high' in decision.reasons


def test_execution_quality_endpoint_exposes_new_sections() -> None:
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    protection = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    quality = ExecutionQualityAttributionService()
    tick = Tick(venue='binance', symbol='BTCUSDT', price=100.0, bid=99.5, ask=100.5)
    order = Order(strategy='maker', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0)
    quality.observe_submission(order, tick)
    quality.observe_fill(Fill(client_order_id=order.client_order_id, venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0, price=100.55, fee=0.01, strategy='maker'))

    asset = AssetAnalysisService()
    asset.observe_tick(tick)
    health = VenueHealthScoringService()
    health.observe_tick(tick)
    capacity = CapacityScoringService(asset_analysis=asset, execution_quality=quality, venue_health=health)

    service = ControlPlaneService(
        capital_protection=protection,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        alert_router=AlertRouter([]),
        asset_analysis=asset,
        execution_quality=quality,
        capacity=capacity,
    )
    auth = TokenAuthManager(AuthConfig(enabled=True, static_tokens={
        'viewer-token': ControlPlanePrincipal(subject='viewer1', role='viewer'),
    }))
    client = TestClient(create_control_plane_app(service, auth))
    resp = client.get('/execution/quality', headers={'Authorization': 'Bearer viewer-token'})
    assert resp.status_code == 200
    data = resp.json()
    assert 'execution_quality' in data
    assert 'capacity_rankings' in data
    assert 'rollout_guardrails' in data
