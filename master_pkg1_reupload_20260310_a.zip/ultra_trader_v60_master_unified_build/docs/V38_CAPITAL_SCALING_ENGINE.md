# V38 Capital Scaling Engine

V38 adds portfolio optimizer, risk budgeting, strategy rotation, and capital deployment logic on top of governance, data quality, and live validation.

## What it does
- computes deployable notional after reserved capital buffer
- allocates per-strategy target notional using stage, health, readiness, expectancy, and capacity
- blocks deployment during global kill / only-close / strategy disable states
- exposes scaling decisions through runtime snapshot and control plane

## Main endpoint
- `GET /capital/scaling`
