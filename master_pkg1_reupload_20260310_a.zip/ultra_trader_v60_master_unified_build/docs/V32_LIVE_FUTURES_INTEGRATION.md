# V32 Live Futures Adapters & Execution Integration

В этой версии добавлены:
- futures private stream adapters для Binance / Bybit / MEXC / Bitget
- futures truth reconciliation для funding / mark / liquidation / position truth
- hedge lifecycle tracking для perp/spot basis legs
- futures live orchestration service
- futures certification scenarios

## Что покрыто
- order update parsing
- execution fill parsing
- account / wallet / position truth updates
- funding truth updates
- mark-price truth updates
- partial/full hedge lifecycle progression

## Что это даёт
- foundation для реального live futures truth loop
- venue-specific parsing boundary под futures private streams
- perp/spot hedge accounting hooks
- certification configs под futures environments
