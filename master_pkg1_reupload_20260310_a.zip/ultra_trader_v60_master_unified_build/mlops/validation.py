from __future__ import annotations

from dataclasses import dataclass

from mlops.trainer import OfflineTrainer, TrainingExample


@dataclass(slots=True)
class ValidationReport:
    folds: int
    accuracy: float
    precision: float


class WalkForwardValidator:
    def __init__(self, trainer: OfflineTrainer | None = None, folds: int = 3) -> None:
        self.trainer = trainer or OfflineTrainer()
        self.folds = max(folds, 2)

    def validate(self, examples: list[TrainingExample]) -> ValidationReport:
        if len(examples) < self.folds + 1:
            return ValidationReport(folds=0, accuracy=0.0, precision=0.0)
        fold_size = max(1, len(examples) // self.folds)
        correct = 0
        positive_pred = 0
        true_positive = 0
        total = 0
        completed = 0
        for idx in range(1, self.folds + 1):
            split = min(len(examples) - 1, idx * fold_size)
            train = examples[:split]
            test = examples[split: min(len(examples), split + fold_size)]
            if not test:
                continue
            weights = self.trainer.train(train)
            for ex in test:
                score = sum(weights.get(k, 0.0) * v for k, v in ex.features.items())
                pred = 1 if score >= 0 else 0
                total += 1
                correct += int(pred == ex.label)
                positive_pred += int(pred == 1)
                true_positive += int(pred == 1 and ex.label == 1)
            completed += 1
        accuracy = correct / total if total else 0.0
        precision = true_positive / positive_pred if positive_pred else 0.0
        return ValidationReport(folds=completed, accuracy=accuracy, precision=precision)
