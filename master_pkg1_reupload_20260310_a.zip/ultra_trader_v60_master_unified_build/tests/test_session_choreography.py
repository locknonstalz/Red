from common.models import StreamCheckpoint
from execution.live.session_choreography import VenueSessionChoreographer


def test_session_choreography_per_venue():
    choreo = VenueSessionChoreographer()
    checkpoint = StreamCheckpoint(venue='binance', channel='private', sequence=10, checkpoint='cp')
    plans = {venue: choreo.build(venue, checkpoint, 'BTC/USDT') for venue in ['binance', 'bybit', 'mexc', 'bitget']}
    assert plans['binance'].subscribe[0].name == 'userDataStream.subscribe'
    assert plans['mexc'].auth[0].name == 'create-listen-key'
    assert any(step.name == 'ping' for step in plans['bybit'].keepalive)
    assert any(step.name == 'subscribe' for step in plans['bitget'].subscribe)
