# V29 Execution Quality, Capacity, and Rollout Guardrails

This release adds four production-facing controls:

- execution quality attribution
- fee and slippage analytics
- capacity scoring
- rollout guardrails

## Execution quality attribution

`ExecutionQualityAttributionService` captures a market baseline on order submission and compares realized fills against that baseline.

Tracked metrics include:

- average fee bps
- average slippage bps
- average effective spread bps
- adverse fill rate
- notional and fill counts

The service aggregates by:

- strategy
- venue
- symbol
- global

## Capacity scoring

`CapacityScoringService` combines:

- asset quality from research analytics
- venue health
- realized slippage/adverse fills

It produces a capacity score and a recommended notional budget per venue/symbol.

## Rollout guardrails

`RolloutGuardrailService` sits on top of:

- go-live scoring
- incidents
- alerts
- execution quality

It prevents aggressive promotion when:

- go-live score is blocked
- incidents are active
- alerts are unacknowledged
- slippage is too high
- fees are too high
- adverse fill rate is too high

## Control plane

New dashboard/API sections expose:

- execution quality
- capacity rankings
- rollout guardrails

New endpoint:

- `GET /execution/quality`
