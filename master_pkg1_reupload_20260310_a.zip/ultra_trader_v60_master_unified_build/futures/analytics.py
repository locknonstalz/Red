from __future__ import annotations

from dataclasses import dataclass

from futures.models import FundingSnapshot


@dataclass(slots=True)
class FuturesRanking:
    venue: str
    symbol: str
    attractiveness: float


class FuturesAnalyticsService:
    def __init__(self) -> None:
        self._snapshots: dict[tuple[str, str], FundingSnapshot] = {}

    def observe_snapshot(self, snapshot: FundingSnapshot) -> None:
        self._snapshots[(snapshot.venue, snapshot.symbol)] = snapshot

    def rank(self) -> list[FuturesRanking]:
        out = []
        for (venue, symbol), snap in self._snapshots.items():
            score = abs(snap.basis_bps) * 0.5 + abs(snap.funding_rate) * 10000.0 * 0.3 + snap.open_interest * 0.000001
            out.append(FuturesRanking(venue=venue, symbol=symbol, attractiveness=score))
        return sorted(out, key=lambda x: x.attractiveness, reverse=True)
