from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from ai.decision_engine import AIDecisionEngine
from capital.protection import CapitalProtectionService
from control_plane.audit import AuditSigner
from control_plane.confirmations import ConfirmationManager
from futures.analytics import FuturesAnalyticsService
from ops.alerts import AlertRouter
from ops.go_live import CertificationEvidenceService, GoLiveScoringService, OperatorDrillService
from ops.rollout import RolloutGuardrailService
from ops.incidents import AlertInboxSink, IncidentWorkflowService, LivePromotionGateService
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from research.asset_analysis import AssetAnalysisService
from research.capacity import CapacityScoringService
from research.allocator import StrategyAllocatorService
from research.universe import UniverseSelectionEngine
from research.venue_health import VenueHealthScoringService
from research.alpha_lab import AlphaLabService
from research.alpha_governance import AlphaGovernanceService
from data.production_data import ProductionDataLayer
from live_validation.validation import LiveValidationService
from strategy.shadow import ShadowDeploymentService
from execution.quality import ExecutionQualityAttributionService
from storage.base import Journal
from capital.scaling import CapitalScalingEngine


@dataclass(slots=True)
class ControlPlaneSnapshot:
    portfolio: dict[str, Any]
    protection: dict[str, Any]
    ai: dict[str, Any]
    metrics: dict[str, float]
    recent_protection_events: list[dict[str, Any]]
    screener: list[dict[str, Any]]
    allocator: dict[str, Any]
    futures_rankings: list[dict[str, Any]]
    venue_health: list[dict[str, Any]]
    shadow: dict[str, Any]
    pending_confirmations: list[dict[str, Any]]
    alerts: list[dict[str, Any]]
    incidents: list[dict[str, Any]]
    promotions: list[dict[str, Any]]
    drills: list[dict[str, Any]]
    certification_evidence: list[dict[str, Any]]
    go_live_scores: list[dict[str, Any]]
    venue_certification: list[dict[str, Any]]
    execution_quality: list[dict[str, Any]]
    capacity_rankings: list[dict[str, Any]]
    rollout_guardrails: list[dict[str, Any]]
    alpha_lab: dict[str, Any]
    alpha_governance: dict[str, Any]
    production_data: dict[str, Any]
    live_validation: dict[str, Any]
    capital_scaling: dict[str, Any]


class ControlPlaneService:
    def __init__(
        self,
        *,
        capital_protection: CapitalProtectionService,
        portfolio: PortfolioService,
        metrics: MetricsRegistry,
        journal: Journal,
        ai_engine: AIDecisionEngine | None = None,
        alert_router: AlertRouter | None = None,
        audit_signer: AuditSigner | None = None,
        asset_analysis: AssetAnalysisService | None = None,
        universe: UniverseSelectionEngine | None = None,
        allocator: StrategyAllocatorService | None = None,
        futures_analytics: FuturesAnalyticsService | None = None,
        venue_health: VenueHealthScoringService | None = None,
        shadow: ShadowDeploymentService | None = None,
        confirmations: ConfirmationManager | None = None,
        alert_inbox: AlertInboxSink | None = None,
        incidents: IncidentWorkflowService | None = None,
        promotions: LivePromotionGateService | None = None,
        drills: OperatorDrillService | None = None,
        certification: CertificationEvidenceService | None = None,
        go_live: GoLiveScoringService | None = None,
        execution_quality: ExecutionQualityAttributionService | None = None,
        capacity: CapacityScoringService | None = None,
        rollout_guardrails: RolloutGuardrailService | None = None,
        alpha_lab: AlphaLabService | None = None,
        alpha_governance: AlphaGovernanceService | None = None,
        production_data: ProductionDataLayer | None = None,
        live_validation: LiveValidationService | None = None,
        capital_scaling: CapitalScalingEngine | None = None,
    ) -> None:
        self.capital_protection = capital_protection
        self.portfolio = portfolio
        self.metrics = metrics
        self.journal = journal
        self.ai_engine = ai_engine
        self.alert_router = alert_router or AlertRouter.noop()
        self.audit_signer = audit_signer or AuditSigner('audit-secret')
        self.asset_analysis = asset_analysis
        self.universe = universe
        self.allocator = allocator
        self.futures_analytics = futures_analytics
        self.venue_health = venue_health
        self.shadow = shadow
        self.confirmations = confirmations or ConfirmationManager()
        self.alert_inbox = alert_inbox or AlertInboxSink()
        self.incidents = incidents or IncidentWorkflowService()
        self.promotions = promotions or LivePromotionGateService()
        self.drills = drills or OperatorDrillService()
        self.certification = certification or CertificationEvidenceService()
        self.go_live = go_live or GoLiveScoringService(promotions=self.promotions, incidents=self.incidents, alerts=self.alert_inbox, shadow=self.shadow, drills=self.drills, evidence=self.certification)
        self.execution_quality = execution_quality
        self.capacity = capacity
        self.rollout_guardrails = rollout_guardrails or RolloutGuardrailService(go_live=self.go_live, promotions=self.promotions, incidents=self.incidents, alerts=self.alert_inbox, execution_quality=self.execution_quality, capacity=self.capacity)
        self.alpha_lab = alpha_lab
        self.alpha_governance = alpha_governance
        self.production_data = production_data
        self.live_validation = live_validation
        self.capital_scaling = capital_scaling
        self.alert_router.add_sink(self.alert_inbox)

    def snapshot(self) -> ControlPlaneSnapshot:
        protection_state = self.capital_protection.state_snapshot()
        ai_state = {
            'enabled': bool(getattr(self.ai_engine, 'enabled', False)),
            'model_updates': int(getattr(getattr(self.ai_engine, 'model', None), 'updates', 0) or 0),
            'pending_labels': sum(len(v) for v in getattr(self.ai_engine, 'pending', {}).values()) if self.ai_engine else 0,
        }
        screener = []
        if self.universe is not None:
            ranked = self.universe.select(list(getattr(self.asset_analysis, '_prices', {}).keys())).selected if self.asset_analysis is not None else []
            screener = [asdict(item) for item in ranked[:15]]
        futures_rankings = [asdict(item) for item in self.futures_analytics.rank()[:15]] if self.futures_analytics is not None else []
        allocator_state = asdict(self.allocator.snapshot()) if self.allocator is not None else {}
        venue_health = [asdict(item) for item in (self.venue_health.rank(sorted({row['venue'] for row in screener})) if self.venue_health is not None and screener else [])]
        shadow = self.shadow.snapshot() if self.shadow is not None else {}
        strategy_names = sorted({row['strategy'] for row in self.promotions.list_promotions()} | set(shadow.get('shadow_strategies', [])))
        go_live_scores = [self.go_live.strategy_score(name) for name in strategy_names]
        execution_quality = [] if self.execution_quality is None else [asdict(v) for k, v in sorted(self.execution_quality.snapshot().items()) if k.startswith('strategy:') or k == 'global']
        capacity_pairs = sorted({(row['venue'], row['symbol']) for row in screener})
        capacity_rankings = [] if self.capacity is None else [asdict(row) for row in self.capacity.rank(capacity_pairs)[:15]]
        rollout_guardrails = self.rollout_guardrails.snapshot()
        alpha_lab = {}
        alpha_governance = {}
        production_data = self.production_data.snapshot() if self.production_data is not None else {}
        live_validation = self.live_validation.snapshot() if self.live_validation is not None else {}
        capital_scaling = {}
        if self.alpha_lab is not None:
            strategies = strategy_names or ['momentum']
            venue = screener[0]['venue'] if screener else 'binance'
            symbol = screener[0]['symbol'] if screener else 'BTCUSDT'
            snap_alpha = self.alpha_lab.snapshot(strategies or ['momentum'], venue, symbol)
            alpha_lab = {
                'hypotheses': [asdict(x) for x in snap_alpha.hypotheses],
                'experiments': [asdict(x) for x in snap_alpha.experiments[-20:]],
                'factor_importance': [asdict(x) for x in snap_alpha.factor_importance[:15]],
                'regime_performance': [asdict(x) for x in snap_alpha.regime_performance[:20]],
                'decay_reports': [asdict(x) for x in snap_alpha.decay_reports],
                'sleeve_allocations': [asdict(x) for x in snap_alpha.sleeve_allocations],
            }
            if self.alpha_governance is not None:
                alpha_governance = self.alpha_governance.snapshot(strategies, venue, symbol)
                if self.capital_scaling is not None:
                    capital_scaling = self.capital_scaling.snapshot(strategies, venue, symbol).as_dict()
        if self.capital_scaling is not None and not capital_scaling:
            strategies = strategy_names or ['momentum']
            venue = screener[0]['venue'] if screener else 'binance'
            symbol = screener[0]['symbol'] if screener else 'BTCUSDT'
            capital_scaling = self.capital_scaling.snapshot(strategies, venue, symbol).as_dict()
        return ControlPlaneSnapshot(
            portfolio=asdict(self.portfolio.snapshot()),
            protection=protection_state,
            ai=ai_state,
            metrics=self.metrics.snapshot(),
            recent_protection_events=self.journal.recent_protection_events(limit=50),
            screener=screener,
            allocator=allocator_state,
            futures_rankings=futures_rankings,
            venue_health=venue_health,
            shadow=shadow,
            pending_confirmations=self.confirmations.snapshot(),
            alerts=self.alert_inbox.list_alerts(limit=50),
            incidents=self.incidents.list_incidents(limit=50),
            promotions=self.promotions.list_promotions(),
            drills=self.drills.list_drills(limit=50),
            certification_evidence=self.certification.latest(limit=50),
            go_live_scores=go_live_scores,
            venue_certification=self.go_live.venue_scores(),
            execution_quality=execution_quality,
            capacity_rankings=capacity_rankings,
            rollout_guardrails=rollout_guardrails,
            alpha_lab=alpha_lab,
            alpha_governance=alpha_governance,
            production_data=production_data,
            live_validation=live_validation,
            capital_scaling=capital_scaling,
        )

    def _audit(self, actor: str, action: str, payload: dict[str, Any]) -> None:
        record = self.audit_signer.sign(actor=actor, action=action, payload=payload)
        self.journal.record_protection_event('audit_signed', action, actor, {
            'payload': payload,
            'signature': record.signature,
            'created_at': record.created_at,
        })

    def _record_request(self, actor: str, action: str, reason: str, payload: dict[str, Any]) -> dict[str, Any]:
        confirmation = self.confirmations.request(actor=actor, action=action, reason=reason, payload=payload)
        req_payload = {'confirmation_id': confirmation.confirmation_id, 'action': action, 'payload': payload, 'actor': actor}
        self.journal.record_protection_event('manual_confirmation_requested', action, reason, req_payload)
        self.alert_router.send_alert(event='manual_confirmation_requested', severity='warning', summary=reason, payload=req_payload)
        return {
            'confirmation_required': True,
            'confirmation_id': confirmation.confirmation_id,
            'action': action,
            'expires_at': confirmation.expires_at.isoformat(),
            'payload': payload,
        }

    def request_only_close(self, enabled: bool, reason: str, actor: str = 'system') -> dict[str, Any]:
        return self._record_request(actor, 'only_close', reason, {'enabled': enabled})

    def request_global_kill(self, enabled: bool, reason: str, actor: str = 'system') -> dict[str, Any]:
        return self._record_request(actor, 'global_kill', reason, {'enabled': enabled})

    def request_strategy(self, strategy: str, enabled: bool, reason: str, actor: str = 'system') -> dict[str, Any]:
        return self._record_request(actor, 'strategy', reason, {'strategy': strategy, 'enabled': enabled})

    def request_ai(self, enabled: bool, reason: str, actor: str = 'system') -> dict[str, Any]:
        return self._record_request(actor, 'ai', reason, {'enabled': enabled})

    def execute_confirmation(self, confirmation_id: str, actor: str = 'system') -> dict[str, Any]:
        confirmation = self.confirmations.consume(confirmation_id)
        if confirmation is None:
            return {'ok': False, 'reason': 'confirmation_not_found'}
        if confirmation.actor != actor:
            return {'ok': False, 'reason': 'actor_mismatch'}
        action = confirmation.action
        payload = confirmation.payload
        reason = confirmation.reason
        if action == 'only_close':
            state = self.set_only_close(bool(payload.get('enabled')), reason, actor=actor)
        elif action == 'global_kill':
            state = self.set_global_kill(bool(payload.get('enabled')), reason, actor=actor)
        elif action == 'strategy':
            state = self.set_strategy(str(payload.get('strategy')), bool(payload.get('enabled')), reason, actor=actor)
        elif action == 'ai':
            state = self.set_ai(bool(payload.get('enabled')), reason, actor=actor)
        else:
            return {'ok': False, 'reason': 'unknown_action'}
        self.journal.record_protection_event('manual_confirmation_executed', action, reason, {'confirmation_id': confirmation_id, 'actor': actor})
        return {'ok': True, 'state': state, 'action': action}

    def set_only_close(self, enabled: bool, reason: str, actor: str = 'system') -> dict[str, Any]:
        if enabled:
            self.capital_protection.enable_only_close_mode(reason)
            severity = 'critical'
            event = 'only_close_enabled'
        else:
            self.capital_protection.disable_only_close_mode(reason)
            severity = 'warning'
            event = 'only_close_disabled'
        payload = {'enabled': enabled, 'actor': actor}
        self._audit(actor, event, payload)
        self.alert_router.send_alert(event=event, severity=severity, summary=reason, payload=payload)
        return self.capital_protection.state_snapshot()

    def set_global_kill(self, enabled: bool, reason: str, actor: str = 'system') -> dict[str, Any]:
        if enabled:
            self.capital_protection.trigger_global_kill(reason)
            event = 'global_kill_enabled'
            severity = 'critical'
        else:
            self.capital_protection.clear_global_kill(reason)
            event = 'global_kill_disabled'
            severity = 'warning'
        payload = {'enabled': enabled, 'actor': actor}
        self._audit(actor, event, payload)
        self.alert_router.send_alert(event=event, severity=severity, summary=reason, payload=payload)
        return self.capital_protection.state_snapshot()

    def set_strategy(self, strategy: str, enabled: bool, reason: str, actor: str = 'system') -> dict[str, Any]:
        if enabled:
            self.capital_protection.enable_strategy(strategy, reason)
            event = 'strategy_enabled'
            severity = 'warning'
            if self.shadow is not None and self.shadow.enabled_for(strategy):
                self.shadow.close_strategy(strategy)
        else:
            self.capital_protection.disable_strategy(strategy, reason)
            event = 'strategy_disabled'
            severity = 'critical'
        payload = {'strategy': strategy, 'enabled': enabled, 'actor': actor}
        self._audit(actor, event, payload)
        self.alert_router.send_alert(event=event, severity=severity, summary=reason, payload=payload)
        return self.capital_protection.state_snapshot()

    def set_ai(self, enabled: bool, reason: str, actor: str = 'system') -> dict[str, Any]:
        if self.ai_engine is None:
            return {'enabled': False, 'reason': 'ai_not_configured'}
        self.ai_engine.enabled = enabled
        payload = {'enabled': enabled, 'actor': actor}
        self.journal.record_protection_event('ai_toggle', 'ai', reason, payload)
        self._audit(actor, 'ai_toggle', payload)
        self.alert_router.send_alert(event='ai_toggle', severity='info', summary=reason, payload=payload)
        return {'enabled': self.ai_engine.enabled, 'reason': reason}

    def list_alerts(self, *, only_unacked: bool = False, limit: int = 100) -> list[dict[str, Any]]:
        return self.alert_inbox.list_alerts(only_unacked=only_unacked, limit=limit)

    def acknowledge_alert(self, alert_id: str, actor: str) -> dict[str, Any]:
        result = self.alert_inbox.acknowledge(alert_id, actor)
        if result.get('ok'):
            self.journal.record_protection_event('alert_acknowledged', alert_id, actor, result['alert'])
            self._audit(actor, 'alert_acknowledged', {'alert_id': alert_id})
        return result

    def open_incident_from_alert(self, alert_id: str, actor: str, note: str = '') -> dict[str, Any]:
        record = self.alert_inbox.get(alert_id)
        if record is None:
            return {'ok': False, 'reason': 'alert_not_found'}
        result = self.incidents.open_from_alert(record, actor=actor, note=note)
        if result.get('ok'):
            self.journal.record_protection_event('incident_opened', alert_id, actor, result['incident'])
            self._audit(actor, 'incident_opened', {'alert_id': alert_id, 'incident_id': result['incident']['incident_id']})
        return result

    def acknowledge_incident(self, incident_id: str, actor: str, note: str = '') -> dict[str, Any]:
        result = self.incidents.acknowledge(incident_id, actor=actor, note=note)
        if result.get('ok'):
            self.journal.record_protection_event('incident_acknowledged', incident_id, actor, result['incident'])
            self._audit(actor, 'incident_acknowledged', {'incident_id': incident_id})
        return result

    def resolve_incident(self, incident_id: str, actor: str, note: str = '') -> dict[str, Any]:
        result = self.incidents.resolve(incident_id, actor=actor, note=note)
        if result.get('ok'):
            self.journal.record_protection_event('incident_resolved', incident_id, actor, result['incident'])
            self._audit(actor, 'incident_resolved', {'incident_id': incident_id})
        return result

    def request_promotion(self, strategy: str, target_stage: str, checks: dict[str, bool], actor: str, reason: str) -> dict[str, Any]:
        result = self.promotions.request_promotion(strategy=strategy, target_stage=target_stage, checks=checks, actor=actor, reason=reason)
        if result.get('ok'):
            self.journal.record_protection_event('promotion_requested', strategy, reason, result['state'])
            self.alert_router.send_alert(event='promotion_requested', severity='info', summary=reason, payload={'strategy': strategy, 'target_stage': target_stage, 'checks': checks, 'actor': actor})
        return result

    def approve_promotion(self, strategy: str, actor: str) -> dict[str, Any]:
        result = self.promotions.approve(strategy, actor)
        if result.get('ok'):
            self.journal.record_protection_event('promotion_approved', strategy, actor, result['state'])
            self._audit(actor, 'promotion_approved', {'strategy': strategy, 'stage': result['state']['current_stage']})
        return result


    def run_operator_drill(self, drill_type: str, actor: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        result = self.drills.run(drill_type=drill_type, actor=actor, context=context)
        self.journal.record_protection_event('operator_drill', drill_type, actor, result['drill'])
        self._audit(actor, 'operator_drill', {'drill_type': drill_type, 'success': result.get('ok', False)})
        return result

    def ingest_certification_report(self, report: dict[str, Any], actor: str = 'system') -> dict[str, Any]:
        result = self.certification.ingest_exchange_report(report)
        self.journal.record_protection_event('certification_evidence', str(report.get('venue') or report.get('exchange') or 'unknown'), actor, result['evidence'])
        self._audit(actor, 'certification_evidence', {'subject_type': 'venue', 'subject_id': result['evidence']['subject_id'], 'status': result['evidence']['status']})
        return result

    def record_strategy_go_live_evidence(self, strategy: str, checks: dict[str, bool], actor: str = 'system', payload: dict[str, Any] | None = None) -> dict[str, Any]:
        result = self.certification.record_strategy_evidence(strategy, checks=checks, payload=payload)
        self.journal.record_protection_event('strategy_go_live_evidence', strategy, actor, result['evidence'])
        self._audit(actor, 'strategy_go_live_evidence', {'strategy': strategy, 'status': result['evidence']['status']})
        return result

    def go_live_readiness(self, strategy: str) -> dict[str, Any]:
        return self.go_live.strategy_score(strategy)
