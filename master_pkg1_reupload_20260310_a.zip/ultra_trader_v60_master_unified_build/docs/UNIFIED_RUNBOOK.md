# Unified Operator Runbook

## Daily checks
- `/health`
- `/state`
- `/risk/dashboard`
- `/execution/quality`
- `/alpha-lab`
- `/governance`
- `/capital/scaling`
- `/data/quality`

## Pre-live checks
- exchange certification passes on selected venues
- no reconciliation drift
- no stale private streams
- kill switch and only-close tested
- scoreboards emit net pnl, fees, slippage, funding drag and hedge cost

## First-wave micro-live order
Day 1-2:
- funding_carry only

Day 3-4:
- add cross_exchange_arbitrage

Day 5-7:
- add market_making_toxicity_aware

## Scale only if
- net pnl > 0 after costs
- truth drift clean
- cost drag acceptable
- stability gate passes
