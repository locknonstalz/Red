from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from ops.incidents import AlertInboxSink, IncidentWorkflowService, LivePromotionGateService
from strategy.shadow import ShadowDeploymentService


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class DrillRecord:
    drill_id: str
    drill_type: str
    actor: str
    status: str
    success: bool
    details: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=utc_now)

    def snapshot(self) -> dict[str, Any]:
        return {
            'drill_id': self.drill_id,
            'drill_type': self.drill_type,
            'actor': self.actor,
            'status': self.status,
            'success': self.success,
            'details': dict(self.details),
            'created_at': self.created_at.isoformat(),
        }


class OperatorDrillService:
    def __init__(self) -> None:
        self._records: list[DrillRecord] = []
        self._counter = 0

    def run(self, *, drill_type: str, actor: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        context = dict(context or {})
        self._counter += 1
        rules: dict[str, bool] = {
            'only_close': bool(context.get('only_close_after') is True),
            'global_kill': bool(context.get('global_kill_after') is True),
            'alert_ack': bool(context.get('alert_acknowledged') is True),
            'incident_flow': bool(context.get('incident_opened') and context.get('incident_resolved')),
            'promotion_gate': bool(context.get('promotion_ready') is True),
            'reconnect_recovery': bool(context.get('recovery_ok') is True),
        }
        success = rules.get(drill_type, False)
        record = DrillRecord(
            drill_id=f'drill-{self._counter:04d}',
            drill_type=drill_type,
            actor=actor,
            status='passed' if success else 'failed',
            success=success,
            details={'checks': rules, **context},
        )
        self._records.append(record)
        return {'ok': success, 'drill': record.snapshot()}

    def list_drills(self, limit: int = 100) -> list[dict[str, Any]]:
        return [r.snapshot() for r in self._records[-limit:]][::-1]

    def recent_success_ratio(self, limit: int = 20) -> float:
        rows = self._records[-limit:]
        if not rows:
            return 0.0
        return sum(1 for row in rows if row.success) / len(rows)


@dataclass(slots=True)
class CertificationEvidence:
    subject_type: str
    subject_id: str
    status: str
    checks: dict[str, bool] = field(default_factory=dict)
    score: float = 0.0
    payload: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=utc_now)

    def snapshot(self) -> dict[str, Any]:
        return {
            'subject_type': self.subject_type,
            'subject_id': self.subject_id,
            'status': self.status,
            'checks': dict(self.checks),
            'score': round(self.score, 4),
            'payload': dict(self.payload),
            'created_at': self.created_at.isoformat(),
        }


class CertificationEvidenceService:
    def __init__(self) -> None:
        self._evidence: list[CertificationEvidence] = []

    def ingest_exchange_report(self, report: dict[str, Any]) -> dict[str, Any]:
        venue = str(report.get('venue') or report.get('exchange') or 'unknown')
        checks = {
            'credentials': bool(report.get('credentials_ok', report.get('credentials', True))),
            'public_connectivity': bool(report.get('public_connectivity_ok', report.get('public_connectivity', True))),
            'private_connectivity': bool(report.get('private_connectivity_ok', report.get('private_connectivity', True))),
            'balances': bool(report.get('balances_ok', report.get('balances', True))),
            'place_order': bool(report.get('place_order_ok', report.get('place_order', False))),
            'cancel_order': bool(report.get('cancel_order_ok', report.get('cancel_order', False))),
            'final_status': bool(report.get('final_status_ok', report.get('final_status', False))),
        }
        score = sum(1.0 for ok in checks.values() if ok) / max(1, len(checks))
        status = 'passed' if score >= 0.85 else 'partial' if score >= 0.5 else 'failed'
        evidence = CertificationEvidence('venue', venue, status=status, checks=checks, score=score, payload=report)
        self._evidence.append(evidence)
        return {'ok': status != 'failed', 'evidence': evidence.snapshot()}

    def record_strategy_evidence(self, strategy: str, *, checks: dict[str, bool], payload: dict[str, Any] | None = None) -> dict[str, Any]:
        score = sum(1.0 for ok in checks.values() if ok) / max(1, len(checks))
        status = 'passed' if score >= 0.85 else 'partial' if score >= 0.5 else 'failed'
        evidence = CertificationEvidence('strategy', strategy, status=status, checks=checks, score=score, payload=dict(payload or {}))
        self._evidence.append(evidence)
        return {'ok': status != 'failed', 'evidence': evidence.snapshot()}

    def latest(self, *, subject_type: str | None = None, subject_id: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        rows = self._evidence
        if subject_type is not None:
            rows = [row for row in rows if row.subject_type == subject_type]
        if subject_id is not None:
            rows = [row for row in rows if row.subject_id == subject_id]
        return [row.snapshot() for row in rows[-limit:]][::-1]

    def latest_for(self, subject_type: str, subject_id: str) -> dict[str, Any] | None:
        for row in reversed(self._evidence):
            if row.subject_type == subject_type and row.subject_id == subject_id:
                return row.snapshot()
        return None


class GoLiveScoringService:
    def __init__(
        self,
        *,
        promotions: LivePromotionGateService,
        incidents: IncidentWorkflowService,
        alerts: AlertInboxSink,
        shadow: ShadowDeploymentService | None = None,
        drills: OperatorDrillService | None = None,
        evidence: CertificationEvidenceService | None = None,
    ) -> None:
        self.promotions = promotions
        self.incidents = incidents
        self.alerts = alerts
        self.shadow = shadow
        self.drills = drills or OperatorDrillService()
        self.evidence = evidence or CertificationEvidenceService()

    def _stage_score(self, stage: str) -> float:
        mapping = {
            'research': 0.2,
            'shadow': 0.45,
            'paper': 0.65,
            'micro_live': 0.85,
            'live': 1.0,
        }
        return mapping.get(stage, 0.0)

    def strategy_score(self, strategy: str) -> dict[str, Any]:
        record = next((row for row in self.promotions.list_promotions() if row['strategy'] == strategy), None)
        current_stage = record['current_stage'] if record else 'research'
        promotion_ready = bool(record and record.get('ready'))
        stage_component = self._stage_score(current_stage)

        active_incidents = len(self.incidents.list_incidents(active_only=True))
        unacked_alerts = len(self.alerts.list_alerts(only_unacked=True))
        alert_penalty = min(0.15, unacked_alerts * 0.03)
        incident_penalty = min(0.2, active_incidents * 0.05)

        shadow_score = 0.0
        if self.shadow is not None:
            snap = self.shadow.snapshot()
            realized = float(snap.get('realized_proxy_pnl_by_strategy', {}).get(strategy, 0.0))
            unreal = float(snap.get('unrealized_pnl_by_strategy', {}).get(strategy, 0.0))
            shadow_score = 0.15 if realized + unreal > 0 else 0.05 if (realized + unreal) == 0 else 0.0

        drill_score = 0.1 * self.drills.recent_success_ratio(limit=20)
        evidence_row = self.evidence.latest_for('strategy', strategy)
        evidence_score = 0.0 if evidence_row is None else 0.25 * float(evidence_row.get('score', 0.0))

        total = max(0.0, min(1.0, stage_component + shadow_score + drill_score + evidence_score - alert_penalty - incident_penalty))
        verdict = 'go' if total >= 0.8 and active_incidents == 0 and unacked_alerts == 0 else 'hold' if total >= 0.55 else 'block'
        return {
            'strategy': strategy,
            'score': round(total, 4),
            'verdict': verdict,
            'components': {
                'stage': round(stage_component, 4),
                'shadow': round(shadow_score, 4),
                'drills': round(drill_score, 4),
                'evidence': round(evidence_score, 4),
                'alert_penalty': round(alert_penalty, 4),
                'incident_penalty': round(incident_penalty, 4),
                'promotion_ready': promotion_ready,
                'current_stage': current_stage,
            },
        }

    def venue_scores(self) -> list[dict[str, Any]]:
        rows = self.evidence.latest(subject_type='venue', limit=100)
        out = []
        for row in rows:
            score = float(row['score'])
            verdict = 'ready' if score >= 0.85 else 'watch' if score >= 0.5 else 'blocked'
            out.append({'venue': row['subject_id'], 'score': round(score, 4), 'verdict': verdict, 'status': row['status'], 'checks': row['checks']})
        return out
