from __future__ import annotations

from dataclasses import dataclass

from execution.quality import ExecutionQualityAttributionService
from futures.liquidations import LiquidationAnalyticsService
from research.attribution import StrategyAttributionService
from research.onchain import OnChainAnalyticsService
from research.venue_health import VenueHealthScoringService


@dataclass(slots=True)
class ProfitabilityAssessment:
    strategy: str
    profitability_score: float
    edge_quality: float
    cost_drag: float
    market_stability: float
    recommendation: str


class ProfitabilityAdvisorService:
    def __init__(self, attribution: StrategyAttributionService, execution_quality: ExecutionQualityAttributionService, venue_health: VenueHealthScoringService, onchain: OnChainAnalyticsService, liquidations: LiquidationAnalyticsService) -> None:
        self.attribution = attribution
        self.execution_quality = execution_quality
        self.venue_health = venue_health
        self.onchain = onchain
        self.liquidations = liquidations

    def assess(self, strategy: str, venue: str, symbol: str) -> ProfitabilityAssessment:
        attr = self.attribution.snapshot().get(strategy)
        eq = self.execution_quality.snapshot().get(f'strategy:{strategy}') or self.execution_quality.snapshot().get('global')
        health_rank = self.venue_health.rank([venue])
        health = health_rank[0].score if health_rank else 50.0
        onchain_bias = self.onchain.alpha_bias(symbol)
        liq = self.liquidations.snapshot(venue, symbol)
        pnl = 0.0 if attr is None else attr.realized_pnl
        wins = 0 if attr is None else attr.win_trades
        losses = 0 if attr is None else attr.loss_trades
        edge_quality = max(0.0, min(100.0, 50.0 + pnl * 0.1 + (wins - losses) * 5.0 + onchain_bias * 10.0))
        cost_drag = 0.0 if eq is None else (eq.avg_fee_bps + eq.avg_slippage_bps + eq.avg_effective_spread_bps * 0.25)
        market_stability = max(0.0, min(100.0, health - liq.cascade_risk * 25.0 - abs(liq.skew) * 10.0))
        profitability_score = max(0.0, min(100.0, edge_quality * 0.55 + market_stability * 0.30 - cost_drag * 1.5 + 20.0))
        if profitability_score >= 70.0:
            recommendation = 'scale_gradually'
        elif profitability_score >= 50.0:
            recommendation = 'trade_selectively'
        else:
            recommendation = 'keep_in_shadow_or_reduce'
        return ProfitabilityAssessment(strategy=strategy, profitability_score=profitability_score, edge_quality=edge_quality, cost_drag=cost_drag, market_stability=market_stability, recommendation=recommendation)
