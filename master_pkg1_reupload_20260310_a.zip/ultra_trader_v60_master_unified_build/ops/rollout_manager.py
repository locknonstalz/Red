
from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

Stage = Literal['research','shadow','micro_live','live']

@dataclass
class RolloutDecision:
    current_stage: Stage
    target_stage: Stage
    action: str
    reason: str

@dataclass
class RolloutManager:
    def decide(self, current_stage: Stage, scorecard_recommendation: str, guard_action: str) -> RolloutDecision:
        if guard_action == 'only_close':
            return RolloutDecision(current_stage, current_stage, 'only_close', 'truth_drift_or_stream_safety')
        if scorecard_recommendation == 'do_not_scale':
            target = 'paper' if current_stage == 'micro_live' else current_stage
            return RolloutDecision(current_stage, target, 'demote_or_hold', 'negative_net_alpha')
        if current_stage == 'research':
            return RolloutDecision(current_stage, 'shadow', 'promote', 'research_passed')
        if current_stage == 'shadow' and scorecard_recommendation in {'hold','scale_gradually'}:
            return RolloutDecision(current_stage, 'micro_live', 'promote', 'shadow_passed')
        if current_stage == 'micro_live' and scorecard_recommendation == 'scale_gradually':
            return RolloutDecision(current_stage, 'live', 'promote', 'micro_live_passed')
        return RolloutDecision(current_stage, current_stage, 'hold', 'insufficient_evidence')
