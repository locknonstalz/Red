from datetime import timedelta, timezone, datetime

from common.models import Order, Side, Tick
from config.settings import RiskSettings
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from risk.risk_service import RiskService
from storage.journal import SqliteJournal


def make_services(tmp_path):
    journal = SqliteJournal(str(tmp_path / "test.db"))
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency="USDT", journal=journal, metrics=metrics)
    risk = RiskService(RiskSettings(max_order_notional=1000, max_position_abs=1.0, max_symbol_notional=2000), portfolio, metrics)
    return risk, portfolio


def test_risk_rejects_stale_market_data(tmp_path):
    risk, _ = make_services(tmp_path)
    tick = Tick("demo", "BTC/USDT", 100, 99, 101, ts=datetime.now(timezone.utc) - timedelta(seconds=10))
    order = Order(strategy="s", venue="demo", symbol="BTC/USDT", side=Side.BUY, qty=0.1)
    decision = risk.check_order(order, tick)
    assert not decision.allowed
    assert decision.reason == "stale_market_data"


def test_risk_rejects_large_position(tmp_path):
    risk, portfolio = make_services(tmp_path)
    portfolio.get_position("BTC/USDT").qty = 0.95
    tick = Tick("demo", "BTC/USDT", 100, 99, 101)
    order = Order(strategy="s", venue="demo", symbol="BTC/USDT", side=Side.BUY, qty=0.1)
    decision = risk.check_order(order, tick)
    assert not decision.allowed
    assert decision.reason == "max_position_abs_exceeded"
