import asyncio

from common.bus import EventBus
from common.models import Order, Side, Tick
from config.settings import RiskSettings
from execution.broker import PaperBroker
from execution.execution_service import ExecutionService
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from risk.risk_service import RiskService
from storage.journal import SqliteJournal


def test_execution_happy_path(tmp_path):
    journal = SqliteJournal(str(tmp_path / "exec.db"))
    metrics = MetricsRegistry()
    portfolio = PortfolioService("USDT", journal, metrics)
    risk = RiskService(RiskSettings(max_order_notional=100000, max_position_abs=10, max_symbol_notional=100000), portfolio, metrics)
    broker = PaperBroker(metrics)
    execution = ExecutionService(EventBus(), broker, journal, portfolio, risk, metrics)
    order = Order(strategy="s", venue="demo", symbol="BTC/USDT", side=Side.BUY, qty=1.0)
    tick = Tick("demo", "BTC/USDT", 100.0, 99.0, 101.0)
    ok = asyncio.run(execution.submit_order(order, tick))
    assert ok is True
    assert portfolio.get_position("BTC/USDT").qty == 1.0
    assert "fills_total" in metrics.snapshot()
