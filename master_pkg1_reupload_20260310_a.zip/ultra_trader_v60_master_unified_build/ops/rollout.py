from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from execution.quality import ExecutionQualityAttributionService
from ops.go_live import GoLiveScoringService
from ops.incidents import AlertInboxSink, IncidentWorkflowService, LivePromotionGateService
from research.capacity import CapacityScoringService


@dataclass(slots=True)
class RolloutGuardrailDecision:
    strategy: str
    allowed_stage: str
    requested_stage: str
    allowed: bool
    reasons: list[str]
    score: float

    def snapshot(self) -> dict[str, Any]:
        return {
            'strategy': self.strategy,
            'allowed_stage': self.allowed_stage,
            'requested_stage': self.requested_stage,
            'allowed': self.allowed,
            'reasons': list(self.reasons),
            'score': round(self.score, 4),
        }


class RolloutGuardrailService:
    def __init__(
        self,
        *,
        go_live: GoLiveScoringService,
        promotions: LivePromotionGateService,
        incidents: IncidentWorkflowService,
        alerts: AlertInboxSink,
        execution_quality: ExecutionQualityAttributionService | None = None,
        capacity: CapacityScoringService | None = None,
    ) -> None:
        self.go_live = go_live
        self.promotions = promotions
        self.incidents = incidents
        self.alerts = alerts
        self.execution_quality = execution_quality
        self.capacity = capacity

    def evaluate_promotion(self, strategy: str, requested_stage: str) -> RolloutGuardrailDecision:
        score_row = self.go_live.strategy_score(strategy)
        reasons: list[str] = []
        score = float(score_row['score'])
        verdict = str(score_row['verdict'])
        active_incidents = len(self.incidents.list_incidents(active_only=True))
        unacked_alerts = len(self.alerts.list_alerts(only_unacked=True))
        allowed_stage = 'paper'
        if verdict == 'go' and score >= 0.85 and active_incidents == 0 and unacked_alerts == 0:
            allowed_stage = 'live'
        elif verdict in {'go', 'hold'} and score >= 0.7:
            allowed_stage = 'micro_live'
        elif score >= 0.55:
            allowed_stage = 'paper'
        else:
            allowed_stage = 'shadow'

        if verdict == 'block':
            reasons.append('go_live_score_blocked')
        if active_incidents:
            reasons.append('active_incidents_present')
        if unacked_alerts:
            reasons.append('unacked_alerts_present')

        if self.execution_quality is not None:
            snap = self.execution_quality.snapshot().get(f'strategy:{strategy}')
            if snap is not None:
                if snap.avg_slippage_bps > 8.0:
                    reasons.append('slippage_too_high')
                if snap.avg_fee_bps > 15.0:
                    reasons.append('fees_too_high')
                if snap.adverse_fill_rate > 0.65:
                    reasons.append('adverse_fill_rate_too_high')

        if self.capacity is not None:
            # evaluate worst observed capacity among current watched pairs if any can be inferred later; keep lightweight.
            pass

        stage_order = ['research', 'shadow', 'paper', 'micro_live', 'live']
        allowed_index = stage_order.index(allowed_stage)
        requested_index = stage_order.index(requested_stage)
        if requested_index > allowed_index:
            reasons.append('requested_stage_above_guardrail_limit')
        return RolloutGuardrailDecision(
            strategy=strategy,
            allowed_stage=allowed_stage,
            requested_stage=requested_stage,
            allowed=requested_index <= allowed_index and not (verdict == 'block' and requested_stage in {'micro_live', 'live'}),
            reasons=reasons,
            score=score,
        )

    def snapshot(self) -> list[dict[str, Any]]:
        rows = []
        for row in self.promotions.list_promotions():
            requested_stage = str(row.get('pending_stage') or row.get('current_stage') or 'research')
            rows.append(self.evaluate_promotion(row['strategy'], requested_stage).snapshot())
        return rows
