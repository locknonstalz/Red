from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class OnChainSnapshot:
    symbol: str
    exchange_inflow: float = 0.0
    exchange_outflow: float = 0.0
    stablecoin_flow: float = 0.0
    whale_score: float = 0.0
    netflow_score: float = 0.0


class OnChainAnalyticsService:
    def __init__(self) -> None:
        self._data: dict[str, OnChainSnapshot] = {}

    def ingest(self, symbol: str, *, exchange_inflow: float = 0.0, exchange_outflow: float = 0.0, stablecoin_flow: float = 0.0, whale_score: float = 0.0) -> None:
        net = stablecoin_flow + exchange_outflow - exchange_inflow
        netflow_score = max(-100.0, min(100.0, net / max(abs(exchange_inflow) + abs(exchange_outflow) + abs(stablecoin_flow), 1.0) * 100.0))
        self._data[symbol] = OnChainSnapshot(symbol=symbol, exchange_inflow=exchange_inflow, exchange_outflow=exchange_outflow, stablecoin_flow=stablecoin_flow, whale_score=whale_score, netflow_score=netflow_score)

    def snapshot(self, symbol: str) -> OnChainSnapshot | None:
        return self._data.get(symbol)

    def alpha_bias(self, symbol: str) -> float:
        snap = self.snapshot(symbol)
        if snap is None:
            return 0.0
        return max(-1.0, min(1.0, snap.netflow_score / 100.0 * 0.7 + snap.whale_score / 100.0 * 0.3))
