# v35-v37 Governance, Production Data, and Live Validation

## v35 Alpha Governance

Added:
- hypothesis approval workflow
- strategy health scoring
- automatic demotion on decay / low readiness
- sleeve rotation adjusted by health

## v36 Production Data Layer

Added:
- production data ingest boundary
- feed-quality scoring
- freshness/completeness checks for market, funding, news, and on-chain feeds

## v37 Live Validation

Added:
- micro-live planning gate
- stress-scenario runner
- capacity discovery summary
- control-plane endpoints for data quality and live validation

## New control plane endpoints

- `GET /alpha-lab`
- `GET /data/quality`
- `GET /live-validation`

## Why this matters

These layers move the project closer to real launch readiness:
- governance reduces uncontrolled strategy drift
- production data quality avoids trading on stale/bad feeds
- live validation creates a safer bridge from paper/testnet into micro-live
