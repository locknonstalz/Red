from __future__ import annotations

import asyncio
import hashlib
import json
from dataclasses import dataclass
from typing import AsyncIterator

from common.models import SessionState, StreamCheckpoint, utc_now
from execution.live.ws_sessions import SessionMessage, SupportsRecovery
from ops.metrics import MetricsRegistry
from storage.base import Journal


class SequenceGapError(RuntimeError):
    def __init__(self, venue: str, expected: int, actual: int) -> None:
        super().__init__(f'{venue} sequence gap: expected {expected}, got {actual}')
        self.venue = venue
        self.expected = expected
        self.actual = actual


@dataclass(slots=True)
class ReconnectPolicy:
    max_attempts: int = 5
    backoff_sec: float = 0.25


class StatefulSessionManager:
    def __init__(self, venue: str, session: SupportsRecovery, journal: Journal, metrics: MetricsRegistry, reconnect_policy: ReconnectPolicy | None = None) -> None:
        self.venue = venue
        self.session = session
        self.journal = journal
        self.metrics = metrics
        self.reconnect_policy = reconnect_policy or ReconnectPolicy()
        self._stop = False

    def _payload_hash(self, payload: dict) -> str:
        return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()

    def _last_checkpoint(self) -> StreamCheckpoint | None:
        return self.journal.load_stream_checkpoint(self.venue, self.session.channel)

    def _save_state(self, *, state: str, auth_ok: bool, subscriptions_ok: bool, last_error: str = '') -> None:
        self.journal.save_session_state(SessionState(venue=self.venue, state=state, auth_ok=auth_ok, subscriptions_ok=subscriptions_ok, last_error=last_error, updated_at=utc_now()))

    def _persist_checkpoint(self, msg: SessionMessage) -> None:
        self.journal.save_stream_checkpoint(StreamCheckpoint(venue=self.venue, channel=msg.channel, sequence=msg.sequence, checkpoint=msg.checkpoint, payload_hash=self._payload_hash(msg.payload), updated_at=utc_now()))

    async def stop(self) -> None:
        self._stop = True
        await self.session.stop()

    async def stream(self) -> AsyncIterator[SessionMessage]:
        attempts = 0
        expected_seq = None
        while not self._stop:
            resume_from = self._last_checkpoint()
            self._save_state(state='connecting', auth_ok=False, subscriptions_ok=False)
            try:
                self._save_state(state='authenticating', auth_ok=False, subscriptions_ok=False)
                self._save_state(state='subscribing', auth_ok=True, subscriptions_ok=False)
                self._save_state(state='live', auth_ok=True, subscriptions_ok=True)
                async for msg in self.session.lifecycle(resume_from=resume_from):
                    attempts = 0
                    if msg.sequence is not None:
                        if expected_seq is None and resume_from and resume_from.sequence is not None:
                            expected_seq = resume_from.sequence + 1
                        if expected_seq is not None and msg.sequence > expected_seq:
                            self.metrics.increment('private_stream_gap_detected_total')
                            recovered = await self.session.recover_gap(resume_from, msg.sequence)
                            recovered_seqs = {item.sequence for item in recovered if item.sequence is not None}
                            need = set(range(expected_seq, msg.sequence))
                            if need and not need.issubset(recovered_seqs):
                                raise SequenceGapError(self.venue, expected_seq, msg.sequence)
                            for recovered_msg in sorted(recovered, key=lambda x: (x.sequence is None, x.sequence)):
                                self._persist_checkpoint(recovered_msg)
                                yield recovered_msg
                            expected_seq = msg.sequence
                        if expected_seq is None:
                            expected_seq = msg.sequence
                        elif msg.sequence < expected_seq:
                            self.metrics.increment('private_stream_duplicate_or_old_total')
                            continue
                    self._persist_checkpoint(msg)
                    yield msg
                    if msg.sequence is not None:
                        expected_seq = msg.sequence + 1
                self._save_state(state='closed', auth_ok=True, subscriptions_ok=True)
                return
            except asyncio.CancelledError:
                self._save_state(state='cancelled', auth_ok=False, subscriptions_ok=False)
                raise
            except Exception as exc:
                attempts += 1
                self.metrics.increment('private_stream_reconnects_total')
                self._save_state(state='reconnecting', auth_ok=False, subscriptions_ok=False, last_error=str(exc))
                if attempts > self.reconnect_policy.max_attempts:
                    self._save_state(state='failed', auth_ok=False, subscriptions_ok=False, last_error=str(exc))
                    raise
                await asyncio.sleep(self.reconnect_policy.backoff_sec * attempts)
