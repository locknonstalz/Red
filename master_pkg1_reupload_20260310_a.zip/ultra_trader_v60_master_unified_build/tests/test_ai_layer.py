import asyncio

from ai.decision_engine import AIDecisionEngine
from common.bus import EventBus
from common.models import OrderType, Side, Signal, Tick
from config.settings import RiskSettings
from execution.broker import PaperBroker
from execution.execution_service import ExecutionService
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from risk.risk_service import RiskService
from storage.journal import SqliteJournal
from strategy.base import Strategy
from strategy.strategy_service import StrategyService


class SingleSignalStrategy(Strategy):
    name = 'single_signal'

    def on_tick(self, tick: Tick):
        if tick.venue != 'binance':
            return []
        return [Signal(self.name, tick.venue, tick.symbol, Side.BUY, 0.55, 'test_entry', qty=1.0, order_type=OrderType.MARKET)]


def test_ai_online_model_learns_from_future_ticks(tmp_path):
    metrics = MetricsRegistry()
    ai = AIDecisionEngine(metrics, entry_horizon_ticks=2, min_training_move_bps=1.0, min_accept_probability=0.0, model_path=str(tmp_path / 'ai_model.json'))
    ticks = [
        Tick('binance', 'BTC/USDT', 100.0, 99.9, 100.1),
        Tick('binance', 'BTC/USDT', 100.1, 100.0, 100.2),
        Tick('binance', 'BTC/USDT', 100.3, 100.2, 100.4),
        Tick('binance', 'BTC/USDT', 100.5, 100.4, 100.6),
    ]
    for tick in ticks[:2]:
        ai.observe_tick(tick)
    result = ai.score_signal(Signal('s', 'binance', 'BTC/USDT', Side.BUY, 0.5, 'learn', qty=1.0), ticks[1])
    assert result.accepted is True
    ai.observe_tick(ticks[2])
    ai.observe_tick(ticks[3])
    assert ai.model.updates >= 1
    assert metrics.snapshot()['ai_training_updates_total'] >= 1


def test_strategy_service_uses_ai_to_filter_and_resize_orders(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'ai_exec.db'))
    metrics = MetricsRegistry()
    bus = EventBus()
    portfolio = PortfolioService('USDT', journal, metrics)
    risk = RiskService(RiskSettings(max_order_notional=100000, max_position_abs=10, max_symbol_notional=100000), portfolio, metrics)
    broker = PaperBroker(metrics)
    execution = ExecutionService(bus, broker, journal, portfolio, risk, metrics)
    ai = AIDecisionEngine(metrics, entry_horizon_ticks=2, min_training_move_bps=1.0, min_accept_probability=0.0, strong_probability=0.1, size_boost=2.0, model_path=str(tmp_path / 'model.json'))
    ai.model.weights = {'base_strength': 4.0, 'signed_momentum_1': 2.0}
    strategy_service = StrategyService(bus=bus, execution=execution, strategies=[SingleSignalStrategy()], metrics=metrics, ai_engine=ai)

    async def scenario():
        runner = asyncio.create_task(strategy_service.run())
        try:
            tick1 = Tick('binance', 'BTC/USDT', 100.0, 99.9, 100.1)
            execution.update_market_tick(tick1)
            await bus.publish('ticks', tick1)
            await asyncio.sleep(0.05)
            tick2 = Tick('binance', 'BTC/USDT', 100.4, 100.3, 100.5)
            execution.update_market_tick(tick2)
            await bus.publish('ticks', tick2)
            await asyncio.sleep(0.05)
        finally:
            runner.cancel()
            await asyncio.gather(runner, return_exceptions=True)

    asyncio.run(scenario())
    pos = portfolio.get_position('BTC/USDT')
    assert pos.qty >= 2.0
    snap = metrics.snapshot()
    assert snap['ai_signals_accepted_total'] >= 1
    assert snap['orders_submitted_total'] >= 1
