from common.bus import EventBus
from common.models import Side
from execution.live.adapters import build_live_broker
from market.live.adapters import BinanceSpotMarketAdapter, BitgetSpotMarketAdapter, BybitV5MarketAdapter, MexcSpotMarketAdapter, build_market_adapter
from market.live.base import ExchangeCredentials
from ops.metrics import MetricsRegistry


def test_market_adapter_parsers():
    bus = EventBus()
    metrics = MetricsRegistry()
    adapters = [
        (BinanceSpotMarketAdapter(bus, metrics, 'BTC/USDT'), {"e": "bookTicker", "b": "100", "a": "101", "E": 1700000000000}),
        (BybitV5MarketAdapter(bus, metrics, 'BTC/USDT'), {"topic": "tickers.BTCUSDT", "ts": 1700000000000, "data": {"bid1Price": "100", "ask1Price": "101", "lastPrice": "100.5"}}),
        (MexcSpotMarketAdapter(bus, metrics, 'BTC/USDT'), {"c": "spot@public.bookTicker.v3.api@BTCUSDT", "d": {"b": "100", "a": "101", "t": 1700000000000}}),
        (BitgetSpotMarketAdapter(bus, metrics, 'BTC/USDT'), {"arg": {"channel": "ticker"}, "data": [{"bidPr": "100", "askPr": "101", "lastPr": "100.5", "ts": "1700000000000"}]})
    ]
    for adapter, payload in adapters:
        tick = adapter.parse_message(payload)
        assert tick is not None
        assert tick.bid == 100.0
        assert tick.ask == 101.0


def test_builders_construct_supported_live_components():
    bus = EventBus()
    metrics = MetricsRegistry()
    assert build_market_adapter('binance', bus, metrics, 'BTC/USDT').venue == 'binance'
    broker = build_live_broker('bitget', ExchangeCredentials('k', 's', 'p'), metrics)
    assert broker.venue == 'bitget'
