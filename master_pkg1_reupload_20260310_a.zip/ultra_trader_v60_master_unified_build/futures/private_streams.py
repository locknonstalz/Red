from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from common.models import Balance, Fill, OrderUpdate, Position, Side
from futures.models import FundingSnapshot


def _utc_ms(ms: int | str | None) -> datetime:
    value = int(ms or 0)
    if value <= 0:
        return datetime.now(timezone.utc)
    return datetime.fromtimestamp(value / 1000, tz=timezone.utc)


class BinanceFuturesPrivateAdapter:
    venue = 'binance'

    def parse_execution(self, payload: dict[str, Any]) -> Fill | None:
        event = payload.get('o', payload)
        if payload.get('e') != 'ORDER_TRADE_UPDATE' or event.get('x') not in {'TRADE', 'CALCULATED'}:
            return None
        return Fill(
            client_order_id=event.get('c', ''),
            exchange_order_id=str(event.get('i', '')),
            venue=self.venue,
            symbol=event.get('s', ''),
            side=Side(event.get('S', 'BUY')),
            qty=float(event.get('l', 0) or 0),
            price=float(event.get('L', 0) or event.get('ap', 0) or 0),
            fee=float(event.get('n', 0) or 0),
            trade_id=str(event.get('t', '')),
            ts=_utc_ms(payload.get('E')),
        )

    def parse_order_update(self, payload: dict[str, Any]) -> OrderUpdate | None:
        event = payload.get('o', payload)
        if payload.get('e') != 'ORDER_TRADE_UPDATE':
            return None
        if event.get('x') in {'TRADE', 'CALCULATED'}:
            return None
        return OrderUpdate(
            venue=self.venue,
            client_order_id=event.get('c', ''),
            exchange_order_id=str(event.get('i', '')),
            symbol=event.get('s', ''),
            status=str(event.get('X', event.get('x', 'NEW'))),
            filled_qty=float(event.get('z', 0) or 0),
            avg_price=float(event.get('ap', 0) or 0),
            raw=payload,
            ts=_utc_ms(payload.get('E')),
        )

    def parse_position(self, payload: dict[str, Any]) -> list[Position]:
        if payload.get('e') != 'ACCOUNT_UPDATE':
            return []
        rows = []
        for item in payload.get('a', {}).get('P', []):
            rows.append(Position(
                symbol=item.get('s', ''),
                qty=float(item.get('pa', 0) or 0),
                avg_price=float(item.get('ep', 0) or 0),
                realized_pnl=float(item.get('cr', 0) or 0),
                mark_price=float(item.get('mp', item.get('ep', 0)) or 0),
                venue=self.venue,
            ))
        return rows

    def parse_balance(self, payload: dict[str, Any]) -> list[Balance]:
        if payload.get('e') != 'ACCOUNT_UPDATE':
            return []
        return [
            Balance(self.venue, item.get('a', ''), float(item.get('wb', 0) or 0), 0.0, _utc_ms(payload.get('E')))
            for item in payload.get('a', {}).get('B', [])
        ]

    def parse_funding(self, payload: dict[str, Any]) -> FundingSnapshot | None:
        if payload.get('e') != 'ACCOUNT_CONFIG_UPDATE':
            return None
        data = payload.get('ac', {})
        symbol = data.get('s', '')
        if not symbol:
            return None
        return FundingSnapshot(venue=self.venue, symbol=symbol, funding_rate=float(data.get('f', 0) or 0), ts=_utc_ms(payload.get('E')))


class BybitFuturesPrivateAdapter:
    venue = 'bybit'

    def parse_execution(self, payload: dict[str, Any]) -> list[Fill]:
        if not str(payload.get('topic', '')).startswith('execution'):
            return []
        return [
            Fill(
                client_order_id=row.get('orderLinkId', ''),
                exchange_order_id=row.get('orderId', ''),
                venue=self.venue,
                symbol=row.get('symbol', ''),
                side=Side(row.get('side', 'Buy').upper()),
                qty=float(row.get('execQty', 0) or 0),
                price=float(row.get('execPrice', 0) or 0),
                fee=float(row.get('execFee', 0) or 0),
                trade_id=row.get('execId', ''),
                ts=_utc_ms(payload.get('creationTime')),
            )
            for row in payload.get('data', [])
        ]

    def parse_order(self, payload: dict[str, Any]) -> list[OrderUpdate]:
        if payload.get('topic') != 'order':
            return []
        return [
            OrderUpdate(
                venue=self.venue,
                client_order_id=row.get('orderLinkId', ''),
                exchange_order_id=row.get('orderId', ''),
                symbol=row.get('symbol', ''),
                status=row.get('orderStatus', 'New'),
                filled_qty=float(row.get('cumExecQty', 0) or 0),
                avg_price=float(row.get('avgPrice', 0) or 0),
                raw=row,
                ts=_utc_ms(payload.get('creationTime')),
            )
            for row in payload.get('data', [])
        ]

    def parse_position(self, payload: dict[str, Any]) -> list[Position]:
        if payload.get('topic') != 'position':
            return []
        return [
            Position(
                symbol=row.get('symbol', ''),
                qty=float(row.get('size', 0) or 0),
                avg_price=float(row.get('avgPrice', 0) or 0),
                realized_pnl=float(row.get('cumRealisedPnl', 0) or 0),
                mark_price=float(row.get('markPrice', row.get('avgPrice', 0)) or 0),
                venue=self.venue,
            )
            for row in payload.get('data', [])
        ]

    def parse_wallet(self, payload: dict[str, Any]) -> list[Balance]:
        if payload.get('topic') != 'wallet':
            return []
        out: list[Balance] = []
        for acct in payload.get('data', []):
            for coin in acct.get('coin', []):
                out.append(Balance(self.venue, coin.get('coin', ''), float(coin.get('walletBalance', 0) or 0), 0.0, _utc_ms(payload.get('creationTime'))))
        return out

    def parse_funding(self, payload: dict[str, Any]) -> FundingSnapshot | None:
        if payload.get('topic') != 'greeks':
            return None
        data = payload.get('data', [])
        if not data:
            return None
        row = data[0]
        return FundingSnapshot(venue=self.venue, symbol=row.get('baseCoin', ''), funding_rate=float(row.get('basisRateYear', 0) or 0) / 365.0, ts=_utc_ms(payload.get('creationTime')))


class MexcFuturesPrivateAdapter:
    venue = 'mexc'

    def parse_order(self, payload: dict[str, Any]) -> OrderUpdate | None:
        if payload.get('channel') != 'push.personal.order':
            return None
        row = payload.get('data', {})
        return OrderUpdate(
            venue=self.venue,
            client_order_id=str(row.get('externalOid', '')),
            exchange_order_id=str(row.get('orderId', '')),
            symbol=row.get('symbol', ''),
            status=str(row.get('state', 'NEW')),
            filled_qty=float(row.get('dealVol', 0) or 0),
            avg_price=float(row.get('dealAvgPrice', 0) or 0),
            raw=row,
            ts=_utc_ms(payload.get('ts')),
        )

    def parse_execution(self, payload: dict[str, Any]) -> Fill | None:
        if payload.get('channel') != 'push.personal.order':
            return None
        row = payload.get('data', {})
        if float(row.get('dealVol', 0) or 0) <= 0:
            return None
        return Fill(
            client_order_id=str(row.get('externalOid', '')),
            exchange_order_id=str(row.get('orderId', '')),
            venue=self.venue,
            symbol=row.get('symbol', ''),
            side=Side('BUY' if int(row.get('side', 1)) == 1 else 'SELL'),
            qty=float(row.get('dealVol', 0) or 0),
            price=float(row.get('dealAvgPrice', 0) or row.get('price', 0) or 0),
            fee=float(row.get('fee', 0) or 0),
            trade_id=str(row.get('id', '')),
            ts=_utc_ms(payload.get('ts')),
        )

    def parse_position(self, payload: dict[str, Any]) -> list[Position]:
        if payload.get('channel') != 'push.personal.position':
            return []
        row = payload.get('data', {})
        return [Position(symbol=row.get('symbol', ''), qty=float(row.get('holdVol', 0) or 0), avg_price=float(row.get('openAvgPrice', 0) or 0), realized_pnl=float(row.get('realised', 0) or 0), mark_price=float(row.get('fairPrice', row.get('openAvgPrice', 0)) or 0), venue=self.venue)]

    def parse_funding(self, payload: dict[str, Any]) -> FundingSnapshot | None:
        if payload.get('channel') != 'push.personal.position':
            return None
        row = payload.get('data', {})
        return FundingSnapshot(venue=self.venue, symbol=row.get('symbol', ''), funding_rate=float(row.get('fundingRate', 0) or 0), ts=_utc_ms(payload.get('ts')))


class BitgetFuturesPrivateAdapter:
    venue = 'bitget'

    def parse_order(self, payload: dict[str, Any]) -> list[OrderUpdate]:
        if payload.get('arg', {}).get('channel') != 'orders':
            return []
        return [
            OrderUpdate(
                venue=self.venue,
                client_order_id=row.get('clientOid', ''),
                exchange_order_id=row.get('ordId', row.get('orderId', '')),
                symbol=row.get('instId', ''),
                status=row.get('status', 'new'),
                filled_qty=float(row.get('accFillSz', 0) or row.get('accBaseVolume', 0) or 0),
                avg_price=float(row.get('fillPx', 0) or row.get('priceAvg', 0) or 0),
                raw=row,
                ts=_utc_ms(row.get('uTime')),
            )
            for row in payload.get('data', [])
        ]

    def parse_execution(self, payload: dict[str, Any]) -> list[Fill]:
        if payload.get('arg', {}).get('channel') != 'orders':
            return []
        out = []
        for row in payload.get('data', []):
            qty = float(row.get('fillSz', 0) or 0)
            if qty <= 0:
                continue
            out.append(Fill(
                client_order_id=row.get('clientOid', ''),
                exchange_order_id=row.get('ordId', row.get('orderId', '')),
                venue=self.venue,
                symbol=row.get('instId', ''),
                side=Side(str(row.get('side', 'buy')).upper()),
                qty=qty,
                price=float(row.get('fillPx', 0) or 0),
                fee=float(row.get('fee', 0) or 0),
                trade_id=row.get('tradeId', ''),
                ts=_utc_ms(row.get('uTime')),
            ))
        return out

    def parse_position(self, payload: dict[str, Any]) -> list[Position]:
        if payload.get('arg', {}).get('channel') != 'positions':
            return []
        return [
            Position(symbol=row.get('instId', ''), qty=float(row.get('total', 0) or 0), avg_price=float(row.get('averageOpenPrice', 0) or 0), realized_pnl=float(row.get('achievedProfits', 0) or 0), mark_price=float(row.get('markPrice', row.get('averageOpenPrice', 0)) or 0), venue=self.venue)
            for row in payload.get('data', [])
        ]

    def parse_account(self, payload: dict[str, Any]) -> list[Balance]:
        if payload.get('arg', {}).get('channel') != 'account':
            return []
        return [Balance(self.venue, row.get('marginCoin', row.get('coin', '')), float(row.get('available', 0) or 0), float(row.get('locked', 0) or 0), _utc_ms(row.get('uTime'))) for row in payload.get('data', [])]

    def parse_funding(self, payload: dict[str, Any]) -> FundingSnapshot | None:
        if payload.get('arg', {}).get('channel') != 'positions':
            return None
        data = payload.get('data', [])
        if not data:
            return None
        row = data[0]
        return FundingSnapshot(venue=self.venue, symbol=row.get('instId', ''), funding_rate=float(row.get('fundingRate', 0) or 0), ts=_utc_ms(row.get('uTime')))
