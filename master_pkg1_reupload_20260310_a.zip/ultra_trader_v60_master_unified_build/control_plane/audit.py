from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any


@dataclass(frozen=True, slots=True)
class SignedAuditRecord:
    created_at: str
    actor: str
    action: str
    payload: dict[str, Any]
    signature: str


class AuditSigner:
    def __init__(self, secret: str) -> None:
        self.secret = secret

    def sign(self, *, actor: str, action: str, payload: dict[str, Any] | None = None) -> SignedAuditRecord:
        body = {
            'created_at': datetime.now(timezone.utc).isoformat(),
            'actor': actor,
            'action': action,
            'payload': payload or {},
        }
        canonical = json.dumps(body, sort_keys=True, separators=(',', ':')).encode()
        signature = hmac.new(self.secret.encode(), canonical, hashlib.sha256).hexdigest()
        return SignedAuditRecord(signature=signature, **body)

    def verify(self, record: SignedAuditRecord) -> bool:
        canonical = json.dumps(
            {
                'created_at': record.created_at,
                'actor': record.actor,
                'action': record.action,
                'payload': record.payload,
            },
            sort_keys=True,
            separators=(',', ':'),
        ).encode()
        expected = hmac.new(self.secret.encode(), canonical, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, record.signature)
