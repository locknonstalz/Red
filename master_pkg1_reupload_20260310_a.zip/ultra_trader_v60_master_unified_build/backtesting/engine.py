from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from common.models import Fill, OrderType, Signal, Side, Tick


@dataclass(slots=True)
class BacktestConfig:
    fee_bps: float = 5.0
    slippage_bps: float = 2.0
    initial_cash: float = 100_000.0
    max_position: float = 1.0


@dataclass(slots=True)
class BacktestReport:
    trades: int
    final_cash: float
    final_position: float
    realized_pnl: float
    max_drawdown: float
    turnover: float
    win_rate: float


class SignalStrategy(Protocol):
    def on_tick(self, tick: Tick) -> Signal | list[Signal] | None: ...


class BacktestEngine:
    def __init__(self, config: BacktestConfig | None = None) -> None:
        self.config = config or BacktestConfig()

    def _fill_price(self, tick: Tick, side: Side, order_type: OrderType) -> float:
        base = tick.ask if side == Side.BUY else tick.bid
        slippage = base * self.config.slippage_bps / 10000.0
        if order_type == OrderType.LIMIT:
            return base
        return base + slippage if side == Side.BUY else base - slippage

    def run(self, ticks: list[Tick], strategy: SignalStrategy) -> BacktestReport:
        cash = self.config.initial_cash
        position = 0.0
        avg_entry = 0.0
        realized = 0.0
        equity_peak = cash
        max_drawdown = 0.0
        turnover = 0.0
        trades = 0
        wins = 0
        losses = 0
        for tick in ticks:
            signals = strategy.on_tick(tick)
            if signals is None:
                equity = cash + position * tick.mid
                equity_peak = max(equity_peak, equity)
                max_drawdown = max(max_drawdown, equity_peak - equity)
                continue
            if not isinstance(signals, list):
                signals = [signals]
            for signal in signals:
                qty = min(abs(signal.qty or 0.0), self.config.max_position)
                if qty <= 0:
                    continue
                px = self._fill_price(tick, signal.side, signal.order_type)
                fee = qty * px * self.config.fee_bps / 10000.0
                signed = qty if signal.side == Side.BUY else -qty
                if position == 0 or position * signed > 0:
                    new_pos = position + signed
                    avg_entry = ((abs(position) * avg_entry) + (qty * px)) / max(abs(new_pos), 1e-12)
                    position = new_pos
                    cash -= signed * px + fee
                else:
                    closing = min(abs(position), qty)
                    pnl = ((px - avg_entry) * closing if position > 0 else (avg_entry - px) * closing) - fee
                    realized += pnl
                    cash += (closing * px if position > 0 else -closing * px) + pnl
                    position += signed
                    if position == 0:
                        avg_entry = 0.0
                    trades += 1
                    turnover += closing * px
                    if pnl >= 0:
                        wins += 1
                    else:
                        losses += 1
            equity = cash + position * tick.mid
            equity_peak = max(equity_peak, equity)
            max_drawdown = max(max_drawdown, equity_peak - equity)
        return BacktestReport(trades=trades, final_cash=cash, final_position=position, realized_pnl=realized, max_drawdown=max_drawdown, turnover=turnover, win_rate=(wins / max(trades, 1)))
