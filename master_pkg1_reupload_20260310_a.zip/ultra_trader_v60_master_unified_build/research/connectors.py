from __future__ import annotations

from dataclasses import dataclass

from research.external_research import ExternalResearchIngestionLayer, ResearchSignal


@dataclass(slots=True)
class ConnectorPayload:
    symbol: str
    score: float
    confidence: float
    source: str
    tags: dict[str, str]


class BaseResearchConnector:
    name = 'base'

    def translate(self, payload: dict) -> ConnectorPayload:
        raise NotImplementedError

    def ingest(self, layer: ExternalResearchIngestionLayer, payload: dict) -> ResearchSignal:
        translated = self.translate(payload)
        signal = ResearchSignal(
            source=translated.source,
            symbol=translated.symbol,
            score=translated.score,
            confidence=translated.confidence,
            tags=translated.tags,
        )
        layer.ingest(signal)
        return signal


class NewsSentimentConnector(BaseResearchConnector):
    name = 'news_sentiment'

    def translate(self, payload: dict) -> ConnectorPayload:
        sentiment = float(payload.get('sentiment', 0.0))
        urgency = float(payload.get('urgency', 0.5))
        return ConnectorPayload(
            symbol=str(payload['symbol']),
            score=max(-1.0, min(1.0, sentiment)) * urgency,
            confidence=max(0.0, min(1.0, float(payload.get('confidence', 0.7)))),
            source=self.name,
            tags={'headline': str(payload.get('headline', ''))[:128]},
        )


class OnChainFlowConnector(BaseResearchConnector):
    name = 'onchain_flow'

    def translate(self, payload: dict) -> ConnectorPayload:
        inflow = float(payload.get('exchange_inflow_usd', 0.0))
        outflow = float(payload.get('exchange_outflow_usd', 0.0))
        net = outflow - inflow
        scale = max(abs(inflow) + abs(outflow), 1.0)
        score = max(-1.0, min(1.0, net / scale))
        return ConnectorPayload(
            symbol=str(payload['symbol']),
            score=score,
            confidence=max(0.0, min(1.0, float(payload.get('confidence', 0.65)))),
            source=self.name,
            tags={'flow_regime': 'outflow' if net > 0 else 'inflow'},
        )


class DerivativesMetricsConnector(BaseResearchConnector):
    name = 'derivatives_metrics'

    def translate(self, payload: dict) -> ConnectorPayload:
        funding = float(payload.get('funding_rate', 0.0))
        oi_change = float(payload.get('oi_change', 0.0))
        score = max(-1.0, min(1.0, oi_change * 0.25 - funding * 40.0))
        return ConnectorPayload(
            symbol=str(payload['symbol']),
            score=score,
            confidence=max(0.0, min(1.0, float(payload.get('confidence', 0.75)))),
            source=self.name,
            tags={'regime': 'crowded_long' if funding > 0 else 'crowded_short'},
        )


class ExternalAnalyticsHub:
    def __init__(self, layer: ExternalResearchIngestionLayer) -> None:
        self.layer = layer
        self.connectors = {
            'news': NewsSentimentConnector(),
            'onchain': OnChainFlowConnector(),
            'derivatives': DerivativesMetricsConnector(),
        }

    def ingest(self, kind: str, payload: dict) -> ResearchSignal:
        try:
            connector = self.connectors[kind]
        except KeyError as exc:
            raise ValueError(f'unsupported external analytics kind: {kind}') from exc
        return connector.ingest(self.layer, payload)
