from storage.journal import SqliteJournal, build_journal


def test_build_journal_defaults_to_sqlite(tmp_path):
    journal = build_journal(sqlite_path=str(tmp_path / 'a.db'), prefer_postgres=False)
    assert isinstance(journal, SqliteJournal)
    journal.close()
