from common.bus import EventBus
from common.models import ExecutionPolicy, Order, Side, Tick
from config.settings import CapitalProtectionSettings, ExecutionTacticsSettings, RiskSettings
from execution.broker import PaperBroker
from execution.execution_service import ExecutionService
from execution.tactics import ExecutionTacticsService, QueueFillProbabilityModel
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from research.venue_health import VenueHealthScoringService
from risk.risk_service import RiskService
from storage.journal import SqliteJournal
from capital.protection import CapitalProtectionService


def test_execution_tactics_builds_twap_plan_for_large_order() -> None:
    tactics = ExecutionTacticsService(ExecutionTacticsSettings(enabled=True, strategies=['liquidity_taking'], min_slice_notional=100.0, default_slices=4))
    tick = Tick(venue='binance', symbol='BTCUSDT', price=100.0, bid=99.0, ask=101.0)
    order = Order(strategy='liquidity_taking', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=5.0)
    plan = tactics.build_plan(order, tick, venue_health_score=0.4)
    assert plan.policy == ExecutionPolicy.TWAP
    assert plan.slice_count == 4
    assert all(s.execution_policy == ExecutionPolicy.TWAP for s in plan.slices)


def test_queue_fill_probability_prefers_aggressive_orders() -> None:
    model = QueueFillProbabilityModel()
    tick = Tick(venue='binance', symbol='BTCUSDT', price=100.0, bid=99.9, ask=100.1)
    passive = Order(strategy='market_making', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0, execution_policy=ExecutionPolicy.PASSIVE)
    aggressive = Order(strategy='liquidity_taking', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.0, execution_policy=ExecutionPolicy.AGGRESSIVE)
    assert model.estimate(tick, aggressive, venue_health_score=0.9) > model.estimate(tick, passive, venue_health_score=0.9)


async def _submit_with_tactics() -> tuple[SqliteJournal, PortfolioService]:
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    risk = RiskService(settings=RiskSettings(max_order_notional=100000.0, max_position_abs=1000.0, max_symbol_notional=100000.0), portfolio=portfolio, metrics=metrics)
    protection = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    tactics = ExecutionTacticsService(ExecutionTacticsSettings(enabled=True, strategies=['liquidity_taking'], min_slice_notional=10.0, default_slices=3))
    health = VenueHealthScoringService()
    svc = ExecutionService(EventBus(), PaperBroker(metrics), journal, portfolio, risk, metrics, capital_protection=protection, venue_health=health, tactics=tactics)
    tick = Tick(venue='binance', symbol='BTCUSDT', price=100.0, bid=99.0, ask=101.0)
    svc.update_market_tick(tick)
    order = Order(strategy='liquidity_taking', venue='binance', symbol='BTCUSDT', side=Side.BUY, qty=1.5)
    ok = await svc.submit_order(order, tick)
    assert ok is True
    return journal, portfolio


def test_execution_service_aggregates_child_order_slices() -> None:
    import asyncio

    journal, portfolio = asyncio.run(_submit_with_tactics())
    pos = portfolio.get_position('BTCUSDT', venue='binance')
    assert pos.qty > 0
    assert pos.mark_price > 0
