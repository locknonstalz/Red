from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from secrets import token_urlsafe
from typing import Any

from ops.alerts import AlertMessage, AlertSink


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(slots=True)
class AlertRecord:
    alert_id: str
    event: str
    severity: str
    summary: str
    payload: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=utc_now)
    acknowledged_by: str | None = None
    acknowledged_at: datetime | None = None

    @property
    def acknowledged(self) -> bool:
        return self.acknowledged_by is not None

    def snapshot(self) -> dict[str, Any]:
        data = asdict(self)
        data['created_at'] = self.created_at.isoformat()
        data['acknowledged_at'] = self.acknowledged_at.isoformat() if self.acknowledged_at else None
        data['acknowledged'] = self.acknowledged
        return data


class AlertInboxSink(AlertSink):
    def __init__(self) -> None:
        self._records: list[AlertRecord] = []

    def emit(self, message: AlertMessage) -> None:
        self._records.append(
            AlertRecord(
                alert_id=token_urlsafe(8),
                event=message.event,
                severity=message.severity,
                summary=message.summary,
                payload=dict(message.payload),
            )
        )

    def list_alerts(self, *, only_unacked: bool = False, limit: int = 100) -> list[dict[str, Any]]:
        records = [r for r in self._records if not only_unacked or not r.acknowledged]
        return [r.snapshot() for r in records[-limit:]][::-1]

    def get(self, alert_id: str) -> AlertRecord | None:
        for record in self._records:
            if record.alert_id == alert_id:
                return record
        return None

    def acknowledge(self, alert_id: str, actor: str) -> dict[str, Any]:
        record = self.get(alert_id)
        if record is None:
            return {'ok': False, 'reason': 'alert_not_found'}
        if not record.acknowledged:
            record.acknowledged_by = actor
            record.acknowledged_at = utc_now()
        return {'ok': True, 'alert': record.snapshot()}


@dataclass(slots=True)
class IncidentRecord:
    incident_id: str
    title: str
    severity: str
    status: str = 'open'
    source_alert_id: str | None = None
    created_at: datetime = field(default_factory=utc_now)
    acknowledged_by: str | None = None
    acknowledged_at: datetime | None = None
    resolved_by: str | None = None
    resolved_at: datetime | None = None
    notes: list[dict[str, Any]] = field(default_factory=list)

    def snapshot(self) -> dict[str, Any]:
        return {
            'incident_id': self.incident_id,
            'title': self.title,
            'severity': self.severity,
            'status': self.status,
            'source_alert_id': self.source_alert_id,
            'created_at': self.created_at.isoformat(),
            'acknowledged_by': self.acknowledged_by,
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            'resolved_by': self.resolved_by,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'notes': list(self.notes),
        }


class IncidentWorkflowService:
    def __init__(self) -> None:
        self._incidents: dict[str, IncidentRecord] = {}

    def open_from_alert(self, alert: AlertRecord, actor: str, note: str = '') -> dict[str, Any]:
        incident = IncidentRecord(
            incident_id=token_urlsafe(10),
            title=f'{alert.event}: {alert.summary}',
            severity=alert.severity,
            source_alert_id=alert.alert_id,
        )
        if note:
            incident.notes.append({'ts': utc_now().isoformat(), 'actor': actor, 'message': note})
        self._incidents[incident.incident_id] = incident
        return {'ok': True, 'incident': incident.snapshot()}

    def acknowledge(self, incident_id: str, actor: str, note: str = '') -> dict[str, Any]:
        incident = self._incidents.get(incident_id)
        if incident is None:
            return {'ok': False, 'reason': 'incident_not_found'}
        incident.status = 'acknowledged'
        incident.acknowledged_by = actor
        incident.acknowledged_at = utc_now()
        if note:
            incident.notes.append({'ts': utc_now().isoformat(), 'actor': actor, 'message': note})
        return {'ok': True, 'incident': incident.snapshot()}

    def resolve(self, incident_id: str, actor: str, note: str = '') -> dict[str, Any]:
        incident = self._incidents.get(incident_id)
        if incident is None:
            return {'ok': False, 'reason': 'incident_not_found'}
        incident.status = 'resolved'
        incident.resolved_by = actor
        incident.resolved_at = utc_now()
        if note:
            incident.notes.append({'ts': utc_now().isoformat(), 'actor': actor, 'message': note})
        return {'ok': True, 'incident': incident.snapshot()}

    def list_incidents(self, *, active_only: bool = False, limit: int = 100) -> list[dict[str, Any]]:
        incidents = list(self._incidents.values())
        if active_only:
            incidents = [i for i in incidents if i.status != 'resolved']
        incidents = sorted(incidents, key=lambda item: item.created_at, reverse=True)
        return [i.snapshot() for i in incidents[:limit]]


@dataclass(slots=True)
class PromotionRecord:
    strategy: str
    current_stage: str = 'research'
    pending_stage: str | None = None
    checks: dict[str, bool] = field(default_factory=dict)
    requested_by: str | None = None
    approved_by: str | None = None
    reason: str = ''
    history: list[dict[str, Any]] = field(default_factory=list)

    def snapshot(self) -> dict[str, Any]:
        return {
            'strategy': self.strategy,
            'current_stage': self.current_stage,
            'pending_stage': self.pending_stage,
            'checks': dict(self.checks),
            'ready': bool(self.checks) and all(self.checks.values()),
            'requested_by': self.requested_by,
            'approved_by': self.approved_by,
            'reason': self.reason,
            'history': list(self.history),
        }


class LivePromotionGateService:
    stages = ('research', 'shadow', 'paper', 'micro_live', 'live')

    def __init__(self) -> None:
        self._records: dict[str, PromotionRecord] = {}

    def _record(self, strategy: str) -> PromotionRecord:
        return self._records.setdefault(strategy, PromotionRecord(strategy=strategy))

    def request_promotion(self, *, strategy: str, target_stage: str, checks: dict[str, bool], actor: str, reason: str) -> dict[str, Any]:
        if target_stage not in self.stages:
            return {'ok': False, 'reason': 'invalid_target_stage'}
        record = self._record(strategy)
        current_idx = self.stages.index(record.current_stage)
        target_idx = self.stages.index(target_stage)
        if target_idx != current_idx + 1:
            return {'ok': False, 'reason': 'must_promote_one_stage_at_a_time', 'state': record.snapshot()}
        record.pending_stage = target_stage
        record.checks = dict(checks)
        record.requested_by = actor
        record.reason = reason
        record.history.append({'ts': utc_now().isoformat(), 'actor': actor, 'event': 'promotion_requested', 'target_stage': target_stage, 'checks': dict(checks), 'reason': reason})
        return {'ok': True, 'state': record.snapshot()}

    def approve(self, strategy: str, actor: str) -> dict[str, Any]:
        record = self._record(strategy)
        if not record.pending_stage:
            return {'ok': False, 'reason': 'no_pending_promotion', 'state': record.snapshot()}
        if not record.checks or not all(record.checks.values()):
            return {'ok': False, 'reason': 'gates_not_satisfied', 'state': record.snapshot()}
        record.current_stage = record.pending_stage
        record.pending_stage = None
        record.approved_by = actor
        record.history.append({'ts': utc_now().isoformat(), 'actor': actor, 'event': 'promotion_approved', 'stage': record.current_stage})
        return {'ok': True, 'state': record.snapshot()}

    def list_promotions(self) -> list[dict[str, Any]]:
        return [self._records[name].snapshot() for name in sorted(self._records)]
