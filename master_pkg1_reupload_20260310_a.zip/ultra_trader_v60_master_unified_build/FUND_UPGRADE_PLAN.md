# Fund Upgrade Plan v11

Completed:
- venue-specific recovery request builders
- stateful reconnect with checkpoint replay path
- DB-backed failover lease coordination
- private session choreography plans per venue
- production monitoring compose bundle

Remaining:
- run live certification against all venues with funded sandbox accounts
- deploy multi-region active/passive failover
- add treasury, compliance, and kill-switch runbooks
