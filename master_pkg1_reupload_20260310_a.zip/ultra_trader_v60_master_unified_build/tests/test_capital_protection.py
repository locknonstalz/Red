from common.models import Order, Side, Tick, Fill
from config.settings import CapitalProtectionSettings, DailyLossGuardSettings, DrawdownGovernorSettings, StrategyKillSwitchSettings, PositionProtectionSettings
from capital.protection import CapitalProtectionService
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.journal import SqliteJournal


def make_service(tmp_path, **overrides):
    journal = SqliteJournal(str(tmp_path / 'test.db'))
    settings = CapitalProtectionSettings(**overrides)
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    return CapitalProtectionService(settings, portfolio, journal, metrics), portfolio, journal


def test_only_close_blocks_new_risk(tmp_path):
    svc, portfolio, _ = make_service(tmp_path, only_close_mode=True)
    tick = Tick(venue='binance', symbol='BTC/USDT', price=100, bid=99.5, ask=100.5)
    order = Order(strategy='momentum', venue='binance', symbol='BTC/USDT', side=Side.BUY, qty=1)
    decision = svc.evaluate_order(order, tick)
    assert not decision.allowed
    assert decision.reason == 'only_close_mode'


def test_drawdown_governor_reduces_size(tmp_path):
    svc, portfolio, _ = make_service(tmp_path, drawdown=DrawdownGovernorSettings(reduce_at=10, pause_at=30, kill_at=200, reduced_size_factor=0.5))
    svc._equity_peak = 5
    # force equity = 80 by negative unrealized
    pos = portfolio.get_position('BTC/USDT', venue='binance')
    pos.qty = 1
    pos.avg_price = 100
    pos.mark_price = 80
    tick = Tick(venue='binance', symbol='BTC/USDT', price=80, bid=79.5, ask=80.5)
    order = Order(strategy='momentum', venue='binance', symbol='BTC/USDT', side=Side.SELL, qty=2)
    decision = svc.evaluate_order(order, tick)
    assert decision.allowed
    assert decision.adjusted_qty == 1.0


def test_strategy_kill_switch_after_consecutive_losses(tmp_path):
    svc, _, _ = make_service(tmp_path, strategy_kill=StrategyKillSwitchSettings(max_strategy_daily_loss=9999, max_consecutive_losses=2))
    for _ in range(2):
        svc.on_fill(Fill(client_order_id='a', venue='binance', symbol='BTC/USDT', side=Side.BUY, qty=1, price=100, fee=1, strategy='momentum'))
    order = Order(strategy='momentum', venue='binance', symbol='BTC/USDT', side=Side.BUY, qty=1)
    tick = Tick(venue='binance', symbol='BTC/USDT', price=100, bid=99.5, ask=100.5)
    decision = svc.evaluate_order(order, tick)
    assert not decision.allowed
    assert decision.reason == 'strategy_kill_switch'


def test_position_protection_generates_exit(tmp_path):
    svc, portfolio, journal = make_service(tmp_path, position_protection=PositionProtectionSettings(stop_loss_bps=40, trailing_stop_bps=25, take_profit_bps=80, max_holding_ticks=100))
    pos = portfolio.get_position('BTC/USDT', venue='binance')
    pos.qty = 1
    pos.avg_price = 100
    pos.mark_price = 100
    svc.on_tick(Tick(venue='binance', symbol='BTC/USDT', price=101, bid=100.99, ask=101.01))
    exits = svc.protective_orders(Tick(venue='binance', symbol='BTC/USDT', price=99, bid=98.99, ask=99.01))
    assert len(exits) == 1
    assert exits[0].side == Side.SELL
    row = journal._conn.execute("select count(*) from protection_events where event_type='position_protection'").fetchone()
    assert row[0] == 1
