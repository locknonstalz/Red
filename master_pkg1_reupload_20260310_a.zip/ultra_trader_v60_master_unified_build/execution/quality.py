from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from common.models import Fill, Order, Side, Tick


@dataclass(slots=True)
class ExecutionBaseline:
    strategy: str
    venue: str
    symbol: str
    side: Side
    expected_price: float
    mid_price: float
    spread_bps: float


@dataclass(slots=True)
class ExecutionQualityRow:
    group: str
    fills: int
    notional: float
    avg_fee_bps: float
    avg_slippage_bps: float
    avg_effective_spread_bps: float
    adverse_fill_rate: float


class ExecutionQualityAttributionService:
    def __init__(self) -> None:
        self._pending: dict[str, ExecutionBaseline] = {}
        self._fills = defaultdict(int)
        self._notional = defaultdict(float)
        self._fees = defaultdict(float)
        self._slippage_bps = defaultdict(float)
        self._effective_spread_bps = defaultdict(float)
        self._adverse = defaultdict(int)

    def observe_submission(self, order: Order, market_tick: Tick | None) -> None:
        if market_tick is None:
            return
        expected = market_tick.ask if order.side == Side.BUY else market_tick.bid
        mid = market_tick.mid
        spread_bps = (market_tick.spread / mid * 10000.0) if mid else 0.0
        self._pending[order.client_order_id] = ExecutionBaseline(
            strategy=order.strategy,
            venue=order.venue,
            symbol=order.symbol,
            side=order.side,
            expected_price=float(expected),
            mid_price=float(mid),
            spread_bps=float(spread_bps),
        )

    def observe_fill(self, fill: Fill) -> None:
        baseline = self._pending.pop(fill.client_order_id, None)
        strategy = fill.strategy or (baseline.strategy if baseline is not None else 'unknown')
        venue = fill.venue
        groups = [f'strategy:{strategy}', f'venue:{venue}', f'symbol:{fill.symbol}', 'global']
        notional = abs(fill.qty * fill.price)
        fee_bps = (fill.fee / notional * 10000.0) if notional else 0.0
        slippage_bps = 0.0
        effective_spread_bps = 0.0
        adverse = 0
        if baseline is not None and baseline.expected_price > 0 and baseline.mid_price > 0:
            if fill.side == Side.BUY:
                slippage_bps = (fill.price - baseline.expected_price) / baseline.expected_price * 10000.0
                effective_spread_bps = (fill.price - baseline.mid_price) / baseline.mid_price * 10000.0
            else:
                slippage_bps = (baseline.expected_price - fill.price) / baseline.expected_price * 10000.0
                effective_spread_bps = (baseline.mid_price - fill.price) / baseline.mid_price * 10000.0
            adverse = 1 if slippage_bps > 0 else 0
        for group in groups:
            self._fills[group] += 1
            self._notional[group] += notional
            self._fees[group] += fee_bps
            self._slippage_bps[group] += slippage_bps
            self._effective_spread_bps[group] += effective_spread_bps
            self._adverse[group] += adverse

    def snapshot(self) -> dict[str, ExecutionQualityRow]:
        groups = set(self._fills)
        out: dict[str, ExecutionQualityRow] = {}
        for group in groups:
            fills = self._fills[group]
            out[group] = ExecutionQualityRow(
                group=group,
                fills=fills,
                notional=round(self._notional[group], 6),
                avg_fee_bps=round(self._fees[group] / fills, 6) if fills else 0.0,
                avg_slippage_bps=round(self._slippage_bps[group] / fills, 6) if fills else 0.0,
                avg_effective_spread_bps=round(self._effective_spread_bps[group] / fills, 6) if fills else 0.0,
                adverse_fill_rate=round(self._adverse[group] / fills, 6) if fills else 0.0,
            )
        return out
