from fastapi.testclient import TestClient

from ai.decision_engine import AIDecisionEngine
from capital.protection import CapitalProtectionService
from config.settings import CapitalProtectionSettings
from control_plane.api import create_control_plane_app
from control_plane.auth import AuthConfig, ControlPlanePrincipal, TokenAuthManager
from control_plane.service import ControlPlaneService
from ops.alerts import AlertRouter
from ops.metrics import MetricsRegistry
from portfolio.portfolio_service import PortfolioService
from storage.journal import SqliteJournal


def _build_client() -> TestClient:
    journal = SqliteJournal(':memory:')
    metrics = MetricsRegistry()
    portfolio = PortfolioService(base_currency='USDT', journal=journal, metrics=metrics)
    capital = CapitalProtectionService(CapitalProtectionSettings(), portfolio=portfolio, journal=journal, metrics=metrics)
    ai = AIDecisionEngine(metrics=metrics, enabled=True, model_path='/tmp/nonexistent-v27.json')
    service = ControlPlaneService(
        capital_protection=capital,
        portfolio=portfolio,
        metrics=metrics,
        journal=journal,
        ai_engine=ai,
        alert_router=AlertRouter([]),
    )
    auth = TokenAuthManager(AuthConfig(enabled=True, static_tokens={
        'viewer-token': ControlPlanePrincipal(subject='viewer1', role='viewer'),
        'operator-token': ControlPlanePrincipal(subject='ops1', role='operator'),
        'admin-token': ControlPlanePrincipal(subject='admin1', role='admin'),
    }))
    return TestClient(create_control_plane_app(service, auth))


def test_dashboard_has_hardening_headers() -> None:
    client = _build_client()
    res = client.get('/dashboard', headers={'Authorization': 'Bearer viewer-token'})
    assert res.status_code == 200
    assert res.headers['X-Frame-Options'] == 'DENY'
    assert res.headers['X-Content-Type-Options'] == 'nosniff'
    assert 'Content-Security-Policy' in res.headers
    assert 'Ultra Trader v27 Control Dashboard' in res.text


def test_alert_ack_and_incident_workflow() -> None:
    client = _build_client()
    enable = client.post('/controls/only-close', json={'enabled': True, 'reason': 'drill'}, headers={'Authorization': 'Bearer operator-token'})
    assert enable.status_code == 200

    alerts = client.get('/alerts', headers={'Authorization': 'Bearer viewer-token'}).json()['alerts']
    assert alerts
    alert_id = alerts[0]['alert_id']

    ack = client.post('/alerts/ack', json={'alert_id': alert_id}, headers={'Authorization': 'Bearer operator-token'})
    assert ack.status_code == 200
    assert ack.json()['ok'] is True
    assert ack.json()['alert']['acknowledged'] is True

    inc = client.post('/incidents/open', json={'alert_id': alert_id, 'note': 'investigating'}, headers={'Authorization': 'Bearer operator-token'})
    assert inc.status_code == 200
    incident_id = inc.json()['incident']['incident_id']

    ack_inc = client.post('/incidents/ack', json={'incident_id': incident_id, 'note': 'owner assigned'}, headers={'Authorization': 'Bearer operator-token'})
    assert ack_inc.status_code == 200
    assert ack_inc.json()['incident']['status'] == 'acknowledged'

    res_inc = client.post('/incidents/resolve', json={'incident_id': incident_id, 'note': 'resolved'}, headers={'Authorization': 'Bearer operator-token'})
    assert res_inc.status_code == 200
    assert res_inc.json()['incident']['status'] == 'resolved'


def test_promotion_gates_require_next_stage_and_checks() -> None:
    client = _build_client()
    bad = client.post(
        '/promotions/request',
        json={'strategy': 'alpha', 'target_stage': 'micro_live', 'reason': 'skip', 'checks': {'shadow_pnl_ok': True}},
        headers={'Authorization': 'Bearer operator-token'},
    )
    assert bad.status_code == 200
    assert bad.json()['ok'] is False

    req = client.post(
        '/promotions/request',
        json={'strategy': 'alpha', 'target_stage': 'shadow', 'reason': 'ready', 'checks': {'checklist_ok': True, 'shadow_pnl_ok': True}},
        headers={'Authorization': 'Bearer operator-token'},
    )
    assert req.status_code == 200
    assert req.json()['ok'] is True
    assert req.json()['state']['ready'] is True

    approve = client.post('/promotions/approve', json={'strategy': 'alpha'}, headers={'Authorization': 'Bearer admin-token'})
    assert approve.status_code == 200
    assert approve.json()['ok'] is True
    assert approve.json()['state']['current_stage'] == 'shadow'
