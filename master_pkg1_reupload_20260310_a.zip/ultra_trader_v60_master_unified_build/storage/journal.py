from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from contextlib import suppress
from datetime import datetime, timedelta, timezone

from common.models import Balance, Fill, Order, OrderStatus, Position, SessionState, StreamCheckpoint
from storage.base import Journal


def _hash_payload(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


ORDER_SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
    client_order_id TEXT PRIMARY KEY,
    strategy TEXT,
    venue TEXT,
    symbol TEXT,
    side TEXT,
    qty REAL,
    order_type TEXT,
    limit_price REAL,
    status TEXT,
    filled_qty REAL DEFAULT 0,
    avg_fill_price REAL DEFAULT 0,
    exchange_order_id TEXT,
    exchange_status TEXT,
    ts TEXT,
    note TEXT DEFAULT '',
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
)
"""

FILL_SCHEMA = """
CREATE TABLE IF NOT EXISTS fills (
    trade_id TEXT PRIMARY KEY,
    client_order_id TEXT,
    venue TEXT,
    symbol TEXT,
    side TEXT,
    qty REAL,
    price REAL,
    fee REAL,
    exchange_order_id TEXT,
    strategy TEXT DEFAULT '',
    ts TEXT
)
"""

BALANCE_SCHEMA = """
CREATE TABLE IF NOT EXISTS balances (
    venue TEXT,
    asset TEXT,
    free REAL,
    locked REAL,
    ts TEXT,
    PRIMARY KEY (venue, asset)
)
"""

POSITION_SCHEMA = """
CREATE TABLE IF NOT EXISTS positions (
    venue TEXT,
    symbol TEXT,
    qty REAL,
    avg_price REAL,
    realized_pnl REAL,
    mark_price REAL,
    updated_at TEXT,
    PRIMARY KEY (venue, symbol)
)
"""

RECON_SCHEMA = """
CREATE TABLE IF NOT EXISTS reconciliation_events (
    venue TEXT,
    event_type TEXT,
    external_id TEXT,
    payload_hash TEXT,
    recorded_at TEXT DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (venue, event_type, external_id)
)
"""

DLQ_SCHEMA = """
CREATE TABLE IF NOT EXISTS dead_letter_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic TEXT,
    payload TEXT,
    reason TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
)
"""

PROTECTION_SCHEMA = """
CREATE TABLE IF NOT EXISTS protection_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT,
    subject TEXT,
    reason TEXT,
    payload TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
)
"""

CHECKPOINT_SCHEMA = """
CREATE TABLE IF NOT EXISTS stream_checkpoints (
    venue TEXT,
    channel TEXT,
    sequence INTEGER,
    checkpoint TEXT,
    payload_hash TEXT,
    updated_at TEXT,
    PRIMARY KEY (venue, channel)
)
"""

SESSION_STATE_SCHEMA = """
CREATE TABLE IF NOT EXISTS session_state (
    venue TEXT PRIMARY KEY,
    state TEXT,
    auth_ok INTEGER,
    subscriptions_ok INTEGER,
    last_error TEXT,
    updated_at TEXT
)
"""

LEASE_SCHEMA = """
CREATE TABLE IF NOT EXISTS failover_leases (
    lease_name TEXT PRIMARY KEY,
    owner TEXT,
    fencing_token INTEGER DEFAULT 0,
    expires_at TEXT,
    updated_at TEXT
)
"""


class SqliteJournal(Journal):
    def __init__(self, path: str) -> None:
        self.path = path
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._create_schema()

    def _create_schema(self) -> None:
        cur = self._conn.cursor()
        for ddl in (ORDER_SCHEMA, FILL_SCHEMA, BALANCE_SCHEMA, POSITION_SCHEMA, RECON_SCHEMA, DLQ_SCHEMA, PROTECTION_SCHEMA, CHECKPOINT_SCHEMA, SESSION_STATE_SCHEMA, LEASE_SCHEMA):
            cur.execute(ddl)
        self._conn.commit()

    def record_order(self, order: Order, note: str = "") -> None:
        self._conn.execute(
            """
            INSERT OR REPLACE INTO orders (
                client_order_id, strategy, venue, symbol, side, qty, order_type, limit_price,
                status, filled_qty, avg_fill_price, exchange_order_id, exchange_status, ts, note
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                order.client_order_id, order.strategy, order.venue, order.symbol, order.side.value,
                order.qty, order.order_type.value, order.limit_price, order.status.value,
                order.filled_qty, order.avg_fill_price, getattr(order, 'exchange_order_id', None),
                getattr(order, 'exchange_status', None), order.ts.isoformat(), note,
            ),
        )
        self._conn.commit()

    def update_order_status(self, client_order_id: str, status: OrderStatus, note: str = "") -> None:
        self._conn.execute(
            "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP, note = CASE WHEN ? = '' THEN note ELSE ? END WHERE client_order_id = ?",
            (status.value, note, note, client_order_id),
        )
        self._conn.commit()

    def record_fill(self, fill: Fill) -> None:
        trade_id = fill.trade_id or _hash_payload(f'{fill.client_order_id}:{fill.exchange_order_id}:{fill.ts.isoformat()}:{fill.qty}:{fill.price}')
        self._conn.execute(
            "INSERT OR IGNORE INTO fills (trade_id, client_order_id, venue, symbol, side, qty, price, fee, exchange_order_id, ts, strategy) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (trade_id, fill.client_order_id, fill.venue, fill.symbol, fill.side.value, fill.qty, fill.price, fill.fee, fill.exchange_order_id, fill.ts.isoformat(), getattr(fill, 'strategy', '')),
        )
        self._conn.commit()

    def open_order_ids(self) -> list[str]:
        rows = self._conn.execute("SELECT client_order_id FROM orders WHERE status IN ('NEW', 'ACCEPTED', 'PARTIALLY_FILLED')").fetchall()
        return [r[0] for r in rows]

    def save_balance_snapshot(self, balance: Balance) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO balances (venue, asset, free, locked, ts) VALUES (?, ?, ?, ?, ?)",
            (balance.venue, balance.asset, balance.free, balance.locked, balance.ts.isoformat()),
        )
        self._conn.commit()

    def save_position_snapshot(self, position: Position) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO positions (venue, symbol, qty, avg_price, realized_pnl, mark_price, updated_at) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)",
            (position.venue, position.symbol, position.qty, position.avg_price, position.realized_pnl, position.mark_price),
        )
        self._conn.commit()

    def seen_reconciliation_event(self, venue: str, event_type: str, external_id: str) -> bool:
        row = self._conn.execute(
            "SELECT 1 FROM reconciliation_events WHERE venue = ? AND event_type = ? AND external_id = ?",
            (venue, event_type, external_id),
        ).fetchone()
        return bool(row)

    def record_reconciliation_event(self, venue: str, event_type: str, external_id: str, payload_hash: str) -> None:
        self._conn.execute(
            "INSERT OR IGNORE INTO reconciliation_events (venue, event_type, external_id, payload_hash) VALUES (?, ?, ?, ?)",
            (venue, event_type, external_id, payload_hash),
        )
        self._conn.commit()

    def enqueue_dead_letter(self, topic: str, payload: str, reason: str) -> None:
        self._conn.execute(
            "INSERT INTO dead_letter_queue (topic, payload, reason) VALUES (?, ?, ?)",
            (topic, payload, reason),
        )
        self._conn.commit()

    def record_protection_event(self, event_type: str, subject: str, reason: str, payload: dict) -> None:
        self._conn.execute(
            "INSERT INTO protection_events (event_type, subject, reason, payload) VALUES (?, ?, ?, ?)",
            (event_type, subject, reason, json.dumps(payload, sort_keys=True)),
        )
        self._conn.commit()

    def recent_protection_events(self, limit: int = 100) -> list[dict]:
        rows = self._conn.execute(
            "SELECT event_type, subject, reason, payload, created_at FROM protection_events ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {
                'event_type': row[0],
                'subject': row[1],
                'reason': row[2],
                'payload': json.loads(row[3] or '{}'),
                'created_at': row[4],
            }
            for row in rows
        ]

    def save_stream_checkpoint(self, checkpoint: StreamCheckpoint) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO stream_checkpoints (venue, channel, sequence, checkpoint, payload_hash, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
            (checkpoint.venue, checkpoint.channel, checkpoint.sequence, checkpoint.checkpoint, checkpoint.payload_hash, checkpoint.updated_at.isoformat()),
        )
        self._conn.commit()

    def load_stream_checkpoint(self, venue: str, channel: str) -> StreamCheckpoint | None:
        row = self._conn.execute(
            "SELECT venue, channel, sequence, checkpoint, payload_hash, updated_at FROM stream_checkpoints WHERE venue = ? AND channel = ?",
            (venue, channel),
        ).fetchone()
        if not row:
            return None
        return StreamCheckpoint(venue=row[0], channel=row[1], sequence=row[2], checkpoint=row[3] or '', payload_hash=row[4] or '')

    def save_session_state(self, state: SessionState) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO session_state (venue, state, auth_ok, subscriptions_ok, last_error, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
            (state.venue, state.state, int(state.auth_ok), int(state.subscriptions_ok), state.last_error, state.updated_at.isoformat()),
        )
        self._conn.commit()

    def load_session_state(self, venue: str) -> SessionState | None:
        row = self._conn.execute(
            "SELECT venue, state, auth_ok, subscriptions_ok, last_error, updated_at FROM session_state WHERE venue = ?",
            (venue,),
        ).fetchone()
        if not row:
            return None
        return SessionState(venue=row[0], state=row[1], auth_ok=bool(row[2]), subscriptions_ok=bool(row[3]), last_error=row[4] or '')

    def acquire_failover_lease(self, lease_name: str, owner: str, ttl_sec: int) -> bool:
        now = _utc_now()
        expires_at = (now + timedelta(seconds=ttl_sec)).isoformat()
        row = self._conn.execute("SELECT owner, expires_at, fencing_token FROM failover_leases WHERE lease_name = ?", (lease_name,)).fetchone()
        if not row:
            self._conn.execute(
                "INSERT INTO failover_leases (lease_name, owner, fencing_token, expires_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (lease_name, owner, 1, expires_at, now.isoformat()),
            )
            self._conn.commit()
            return True
        current_owner, current_expiry, fencing = row
        expired = not current_expiry or datetime.fromisoformat(current_expiry) <= now
        if expired or current_owner == owner:
            self._conn.execute(
                "UPDATE failover_leases SET owner = ?, fencing_token = ?, expires_at = ?, updated_at = ? WHERE lease_name = ?",
                (owner, int(fencing or 0) + 1, expires_at, now.isoformat(), lease_name),
            )
            self._conn.commit()
            return True
        return False

    def renew_failover_lease(self, lease_name: str, owner: str, ttl_sec: int) -> bool:
        now = _utc_now()
        expires_at = (now + timedelta(seconds=ttl_sec)).isoformat()
        row = self._conn.execute("SELECT owner, expires_at FROM failover_leases WHERE lease_name = ?", (lease_name,)).fetchone()
        if not row:
            return False
        current_owner, current_expiry = row
        expired = not current_expiry or datetime.fromisoformat(current_expiry) <= now
        if current_owner != owner and not expired:
            return False
        self._conn.execute("UPDATE failover_leases SET owner = ?, expires_at = ?, updated_at = ? WHERE lease_name = ?", (owner, expires_at, now.isoformat(), lease_name))
        self._conn.commit()
        return True

    def release_failover_lease(self, lease_name: str, owner: str) -> None:
        self._conn.execute("DELETE FROM failover_leases WHERE lease_name = ? AND owner = ?", (lease_name, owner))
        self._conn.commit()

    def close(self) -> None:
        with suppress(Exception):
            self._conn.close()


class PostgresJournal(SqliteJournal):
    def __init__(self, dsn: str) -> None:
        try:
            import psycopg
        except ImportError as exc:
            raise RuntimeError('psycopg is required for PostgresJournal. Install psycopg[binary]>=3.2') from exc
        self._psycopg = psycopg
        self.dsn = dsn
        self._conn = psycopg.connect(dsn, autocommit=True)
        self._create_schema()

    def _create_schema(self) -> None:
        with self._conn.cursor() as cur:
            ddls = [ORDER_SCHEMA, FILL_SCHEMA, BALANCE_SCHEMA, POSITION_SCHEMA, RECON_SCHEMA, DLQ_SCHEMA, PROTECTION_SCHEMA, CHECKPOINT_SCHEMA, SESSION_STATE_SCHEMA, LEASE_SCHEMA]
            for ddl in ddls:
                cur.execute(ddl.replace('INTEGER PRIMARY KEY AUTOINCREMENT', 'BIGSERIAL PRIMARY KEY').replace('INSERT OR REPLACE', 'INSERT').replace('INSERT OR IGNORE', 'INSERT'))

    def record_order(self, order: Order, note: str = "") -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO orders (
                    client_order_id, strategy, venue, symbol, side, qty, order_type, limit_price,
                    status, filled_qty, avg_fill_price, exchange_order_id, exchange_status, ts, note
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (client_order_id) DO UPDATE SET
                    status = EXCLUDED.status,
                    filled_qty = EXCLUDED.filled_qty,
                    avg_fill_price = EXCLUDED.avg_fill_price,
                    exchange_order_id = EXCLUDED.exchange_order_id,
                    exchange_status = EXCLUDED.exchange_status,
                    updated_at = CURRENT_TIMESTAMP,
                    note = EXCLUDED.note
                """,
                (order.client_order_id, order.strategy, order.venue, order.symbol, order.side.value, order.qty, order.order_type.value, order.limit_price, order.status.value, order.filled_qty, order.avg_fill_price, getattr(order, 'exchange_order_id', None), getattr(order, 'exchange_status', None), order.ts.isoformat(), note),
            )

    def update_order_status(self, client_order_id: str, status: OrderStatus, note: str = "") -> None:
        with self._conn.cursor() as cur:
            cur.execute("UPDATE orders SET status = %s, updated_at = CURRENT_TIMESTAMP, note = CASE WHEN %s = '' THEN note ELSE %s END WHERE client_order_id = %s", (status.value, note, note, client_order_id))

    def record_fill(self, fill: Fill) -> None:
        trade_id = fill.trade_id or _hash_payload(f'{fill.client_order_id}:{fill.exchange_order_id}:{fill.ts.isoformat()}:{fill.qty}:{fill.price}')
        with self._conn.cursor() as cur:
            cur.execute(
                "INSERT INTO fills (trade_id, client_order_id, venue, symbol, side, qty, price, fee, exchange_order_id, ts, strategy) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING",
                (trade_id, fill.client_order_id, fill.venue, fill.symbol, fill.side.value, fill.qty, fill.price, fill.fee, fill.exchange_order_id, fill.ts.isoformat(), getattr(fill, 'strategy', '')),
            )

    def open_order_ids(self) -> list[str]:
        with self._conn.cursor() as cur:
            cur.execute("SELECT client_order_id FROM orders WHERE status IN ('NEW', 'ACCEPTED', 'PARTIALLY_FILLED')")
            return [r[0] for r in cur.fetchall()]

    def save_balance_snapshot(self, balance: Balance) -> None:
        with self._conn.cursor() as cur:
            cur.execute("INSERT INTO balances (venue, asset, free, locked, ts) VALUES (%s,%s,%s,%s,%s) ON CONFLICT (venue, asset) DO UPDATE SET free=EXCLUDED.free, locked=EXCLUDED.locked, ts=EXCLUDED.ts", (balance.venue, balance.asset, balance.free, balance.locked, balance.ts.isoformat()))

    def save_position_snapshot(self, position: Position) -> None:
        with self._conn.cursor() as cur:
            cur.execute("INSERT INTO positions (venue, symbol, qty, avg_price, realized_pnl, mark_price, updated_at) VALUES (%s,%s,%s,%s,%s,%s,CURRENT_TIMESTAMP) ON CONFLICT (venue, symbol) DO UPDATE SET qty=EXCLUDED.qty, avg_price=EXCLUDED.avg_price, realized_pnl=EXCLUDED.realized_pnl, mark_price=EXCLUDED.mark_price, updated_at=CURRENT_TIMESTAMP", (position.venue, position.symbol, position.qty, position.avg_price, position.realized_pnl, position.mark_price))

    def seen_reconciliation_event(self, venue: str, event_type: str, external_id: str) -> bool:
        with self._conn.cursor() as cur:
            cur.execute("SELECT 1 FROM reconciliation_events WHERE venue=%s AND event_type=%s AND external_id=%s", (venue, event_type, external_id))
            return bool(cur.fetchone())

    def record_reconciliation_event(self, venue: str, event_type: str, external_id: str, payload_hash: str) -> None:
        with self._conn.cursor() as cur:
            cur.execute("INSERT INTO reconciliation_events (venue, event_type, external_id, payload_hash) VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING", (venue, event_type, external_id, payload_hash))

    def enqueue_dead_letter(self, topic: str, payload: str, reason: str) -> None:
        with self._conn.cursor() as cur:
            cur.execute("INSERT INTO dead_letter_queue (topic, payload, reason) VALUES (%s,%s,%s)", (topic, payload, reason))

    def record_protection_event(self, event_type: str, subject: str, reason: str, payload: dict) -> None:
        with self._conn.cursor() as cur:
            cur.execute(
                "INSERT INTO protection_events (event_type, subject, reason, payload) VALUES (%s, %s, %s, %s)",
                (event_type, subject, reason, json.dumps(payload, sort_keys=True)),
            )


    def recent_protection_events(self, limit: int = 100) -> list[dict]:
        with self._conn.cursor() as cur:
            cur.execute(
                "SELECT event_type, subject, reason, payload, created_at FROM protection_events ORDER BY id DESC LIMIT %s",
                (limit,),
            )
            rows = cur.fetchall()
            return [
                {
                    'event_type': row[0],
                    'subject': row[1],
                    'reason': row[2],
                    'payload': json.loads(row[3] or '{}'),
                    'created_at': str(row[4]),
                }
                for row in rows
            ]

    def save_stream_checkpoint(self, checkpoint: StreamCheckpoint) -> None:
        with self._conn.cursor() as cur:
            cur.execute("INSERT INTO stream_checkpoints (venue, channel, sequence, checkpoint, payload_hash, updated_at) VALUES (%s,%s,%s,%s,%s,%s) ON CONFLICT (venue, channel) DO UPDATE SET sequence=EXCLUDED.sequence, checkpoint=EXCLUDED.checkpoint, payload_hash=EXCLUDED.payload_hash, updated_at=EXCLUDED.updated_at", (checkpoint.venue, checkpoint.channel, checkpoint.sequence, checkpoint.checkpoint, checkpoint.payload_hash, checkpoint.updated_at.isoformat()))

    def load_stream_checkpoint(self, venue: str, channel: str) -> StreamCheckpoint | None:
        with self._conn.cursor() as cur:
            cur.execute("SELECT venue, channel, sequence, checkpoint, payload_hash, updated_at FROM stream_checkpoints WHERE venue=%s AND channel=%s", (venue, channel))
            row = cur.fetchone()
            if not row:
                return None
            return StreamCheckpoint(venue=row[0], channel=row[1], sequence=row[2], checkpoint=row[3] or '', payload_hash=row[4] or '')

    def save_session_state(self, state: SessionState) -> None:
        with self._conn.cursor() as cur:
            cur.execute("INSERT INTO session_state (venue, state, auth_ok, subscriptions_ok, last_error, updated_at) VALUES (%s,%s,%s,%s,%s,%s) ON CONFLICT (venue) DO UPDATE SET state=EXCLUDED.state, auth_ok=EXCLUDED.auth_ok, subscriptions_ok=EXCLUDED.subscriptions_ok, last_error=EXCLUDED.last_error, updated_at=EXCLUDED.updated_at", (state.venue, state.state, int(state.auth_ok), int(state.subscriptions_ok), state.last_error, state.updated_at.isoformat()))

    def load_session_state(self, venue: str) -> SessionState | None:
        with self._conn.cursor() as cur:
            cur.execute("SELECT venue, state, auth_ok, subscriptions_ok, last_error, updated_at FROM session_state WHERE venue=%s", (venue,))
            row = cur.fetchone()
            if not row:
                return None
            return SessionState(venue=row[0], state=row[1], auth_ok=bool(row[2]), subscriptions_ok=bool(row[3]), last_error=row[4] or '')

    def acquire_failover_lease(self, lease_name: str, owner: str, ttl_sec: int) -> bool:
        now = _utc_now()
        expires_at = now + timedelta(seconds=ttl_sec)
        with self._conn.cursor() as cur:
            cur.execute("SELECT owner, expires_at, fencing_token FROM failover_leases WHERE lease_name=%s", (lease_name,))
            row = cur.fetchone()
            if not row:
                cur.execute("INSERT INTO failover_leases (lease_name, owner, fencing_token, expires_at, updated_at) VALUES (%s,%s,%s,%s,%s)", (lease_name, owner, 1, expires_at.isoformat(), now.isoformat()))
                return True
            current_owner, current_expiry, fencing = row
            expired = current_expiry is None or datetime.fromisoformat(str(current_expiry)) <= now
            if expired or current_owner == owner:
                cur.execute("UPDATE failover_leases SET owner=%s, fencing_token=%s, expires_at=%s, updated_at=%s WHERE lease_name=%s", (owner, int(fencing or 0) + 1, expires_at.isoformat(), now.isoformat(), lease_name))
                return True
            return False

    def renew_failover_lease(self, lease_name: str, owner: str, ttl_sec: int) -> bool:
        now = _utc_now()
        expires_at = now + timedelta(seconds=ttl_sec)
        with self._conn.cursor() as cur:
            cur.execute("SELECT owner, expires_at FROM failover_leases WHERE lease_name=%s", (lease_name,))
            row = cur.fetchone()
            if not row:
                return False
            current_owner, current_expiry = row
            expired = current_expiry is None or datetime.fromisoformat(str(current_expiry)) <= now
            if current_owner != owner and not expired:
                return False
            cur.execute("UPDATE failover_leases SET owner=%s, expires_at=%s, updated_at=%s WHERE lease_name=%s", (owner, expires_at.isoformat(), now.isoformat(), lease_name))
            return True

    def release_failover_lease(self, lease_name: str, owner: str) -> None:
        with self._conn.cursor() as cur:
            cur.execute("DELETE FROM failover_leases WHERE lease_name=%s AND owner=%s", (lease_name, owner))


def build_journal(*, sqlite_path: str | None = None, prefer_postgres: bool | None = None, postgres_dsn: str | None = None) -> Journal:
    prefer_postgres = (os.getenv('PREFER_POSTGRES', '0') == '1') if prefer_postgres is None else prefer_postgres
    dsn = postgres_dsn or os.getenv('DATABASE_URL')
    if prefer_postgres and dsn:
        return PostgresJournal(dsn)
    return SqliteJournal(sqlite_path or os.getenv('SQLITE_PATH', 'ultra_trader_v11.db'))
