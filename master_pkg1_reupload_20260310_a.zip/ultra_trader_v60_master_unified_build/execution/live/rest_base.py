from __future__ import annotations

import abc
import base64
import hashlib
import hmac
import json
import time
from dataclasses import dataclass

import httpx

from common.models import Balance, Fill, Order, OrderStatus, Position, VenueFilter
from execution.broker import Broker
from market.live.base import ExchangeCredentials
from ops.metrics import MetricsRegistry


@dataclass(slots=True)
class ExchangeOrderAck:
    exchange_order_id: str
    exchange_status: str
    raw: dict


class BaseRestBroker(Broker, abc.ABC):
    venue: str
    base_url: str

    def __init__(self, credentials: ExchangeCredentials, metrics: MetricsRegistry, timeout_sec: float = 10.0) -> None:
        self.credentials = credentials
        self.metrics = metrics
        self.client = httpx.AsyncClient(base_url=self.base_url, timeout=timeout_sec)

    @abc.abstractmethod
    async def submit_live(self, order: Order) -> ExchangeOrderAck:
        raise NotImplementedError

    @abc.abstractmethod
    async def list_open_orders(self) -> list[str]:
        raise NotImplementedError

    @abc.abstractmethod
    async def fetch_balances(self) -> list[Balance]:
        raise NotImplementedError

    @abc.abstractmethod
    async def fetch_positions(self) -> list[Position]:
        raise NotImplementedError

    @abc.abstractmethod
    async def fetch_symbol_filter(self, symbol: str) -> VenueFilter:
        raise NotImplementedError

    async def submit(self, order: Order, market_price: float) -> Fill:
        ack = await self.submit_live(order)
        setattr(order, 'exchange_order_id', ack.exchange_order_id)
        setattr(order, 'exchange_status', ack.exchange_status)
        order.status = OrderStatus.ACCEPTED
        self.metrics.increment(f'live_orders_{self.venue}_accepted_total')
        return Fill(client_order_id=order.client_order_id, venue=order.venue, symbol=order.symbol, side=order.side, qty=0.0, price=market_price, fee=0.0)

    async def aclose(self) -> None:
        await self.client.aclose()

    @staticmethod
    def sign_hmac_sha256(secret: str, payload: str) -> str:
        return hmac.new(secret.encode(), payload.encode(), hashlib.sha256).hexdigest()

    @staticmethod
    def sign_base64_hmac_sha256(secret: str, payload: str) -> str:
        digest = hmac.new(secret.encode(), payload.encode(), hashlib.sha256).digest()
        return base64.b64encode(digest).decode()

    @staticmethod
    def ts_ms() -> str:
        return str(int(time.time() * 1000))
