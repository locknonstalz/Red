from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Sequence

from common.models import Signal, Tick


class Strategy(ABC):
    name: str

    @abstractmethod
    def on_tick(self, tick: Tick) -> Sequence[Signal]:
        raise NotImplementedError
