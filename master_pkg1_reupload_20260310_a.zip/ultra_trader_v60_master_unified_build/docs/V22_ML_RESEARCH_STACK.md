v22 ML Research Stack

Adds a feature store, offline trainer, model registry, walk-forward validator, and a training script for champion/challenger style experimentation.
