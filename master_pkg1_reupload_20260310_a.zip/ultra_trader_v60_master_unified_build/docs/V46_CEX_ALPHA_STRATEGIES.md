# V46 CEX Alpha Strategies

This release wires five CEX-oriented strategies into the engine:

1. **FundingCarryStrategy** — spot/perp carry using funding + basis thresholds.
2. **CrossExchangeArbitrageStrategy** — paired venue spread capture.
3. **MarketMakingStrategy** — passive quoting with toxicity + microprice filters.
4. **LiquidationCascadeStrategy** — liquidation-pressure breakout entries.
5. **StatisticalArbitrageStrategy** — pair spread mean reversion.

## Why these fit the engine

- Existing execution, SOR, and hedging layers handle multi-venue orchestration.
- Alpha lab and live alpha scoreboard can rank the strategies by net alpha after costs.
- Capital scaling and autonomous portfolio allocation can allocate between sleeves.

## Operational focus

- Run **funding_carry** and **cross_exchange_arbitrage** first in micro-live.
- Use **market_making** only on venues with good venue-health and low toxicity.
- Gate **liquidation_cascade** with tight capital and kill-switches.
- Keep **statistical_arbitrage** in paper or micro-live until correlation persistence is proven.
