# v18 Launch Readiness

v18 closes the main gaps found in the v17 audit.

## What changed

- unified runtime bootstrap via `runtime/bootstrap.py`
- one runtime now wires strategy, execution, reconciliation, orchestration, control plane, and metrics
- live mode can run **multiple venues at the same time** using `LIVE_VENUES`
- control plane can run in-process with the trading runtime
- Prometheus exporter can run from the same process
- preflight now validates mode, venue list, credentials, control-plane secrets, and required deployment docs
- `.env.example` added for reproducible startup

## Recommended boot order

1. Fill `.env.example` values into a local `.env`
2. Run `python scripts/preflight.py`
3. Start paper mode: `python app.py`
4. Start testnet mode with one venue
5. Expand to `LIVE_VENUES=binance,bybit`
6. Run exchange certification steps from `docs/LIVE_CERTIFICATION_MATRIX.md`

## Remaining work before real money

- funded sandbox/testnet accounts for all four venues
- full place/cancel/amend/fill end-to-end certification on each venue
- Postgres HA rollout with real backups
- live alert routing secrets and on-call policy
- go-live runbooks signed off by operator team


## Added in v20-v22
- Research analytics layer
- Futures risk and derivatives analytics
- Offline ML research stack
