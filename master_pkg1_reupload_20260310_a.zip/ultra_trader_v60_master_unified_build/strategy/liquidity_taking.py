from __future__ import annotations

from collections import deque
from typing import Sequence

from common.models import Side, Signal, Tick
from strategy.base import Strategy


class LiquidityTakingStrategy(Strategy):
    def __init__(self, name: str, venue: str, symbol: str, trade_size: float, lookback: int = 12, breakout_bps: float = 6.0, min_spread_bps: float = 1.5) -> None:
        self.name = name
        self.venue = venue
        self.symbol = symbol
        self.trade_size = trade_size
        self.lookback = deque(maxlen=lookback)
        self.breakout_bps = breakout_bps
        self.min_spread_bps = min_spread_bps
        self._last_side: Side | None = None

    def on_tick(self, tick: Tick) -> Sequence[Signal]:
        if tick.venue != self.venue or tick.symbol != self.symbol:
            return []
        self.lookback.append(tick.mid)
        if len(self.lookback) < self.lookback.maxlen:
            return []
        recent = list(self.lookback)
        prev_high = max(recent[:-1])
        prev_low = min(recent[:-1])
        spread_bps = (tick.spread / tick.mid) * 10000 if tick.mid else 0.0
        threshold = tick.mid * (self.breakout_bps / 10000)
        if spread_bps < self.min_spread_bps and tick.mid > prev_high + threshold and self._last_side != Side.BUY:
            self._last_side = Side.BUY
            return [Signal(self.name, self.venue, self.symbol, Side.BUY, 0.9, "micro_breakout_buy", qty=self.trade_size)]
        if spread_bps < self.min_spread_bps and tick.mid < prev_low - threshold and self._last_side != Side.SELL:
            self._last_side = Side.SELL
            return [Signal(self.name, self.venue, self.symbol, Side.SELL, 0.9, "micro_breakout_sell", qty=self.trade_size)]
        return []
