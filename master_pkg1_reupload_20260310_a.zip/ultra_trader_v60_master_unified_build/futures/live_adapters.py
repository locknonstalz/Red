from __future__ import annotations

from dataclasses import dataclass

from common.models import VenueFilter
from market.live.base import ExchangeCredentials
from ops.metrics import MetricsRegistry


@dataclass(slots=True)
class FuturesVenueSpec:
    venue: str
    market_ws: str
    private_ws: str
    rest_base: str
    product_type: str = 'perpetual'


FUTURES_SPECS = {
    'binance': FuturesVenueSpec('binance', 'wss://fstream.binance.com/ws', 'wss://ws-fapi.binance.com/ws-fapi/v1', 'https://fapi.binance.com'),
    'bybit': FuturesVenueSpec('bybit', 'wss://stream.bybit.com/v5/public/linear', 'wss://stream.bybit.com/v5/private', 'https://api.bybit.com'),
    'mexc': FuturesVenueSpec('mexc', 'wss://contract.mexc.com/edge', 'wss://contract.mexc.com/edge', 'https://contract.mexc.com'),
    'bitget': FuturesVenueSpec('bitget', 'wss://ws.bitget.com/v2/ws/public', 'wss://ws.bitget.com/v2/ws/private', 'https://api.bitget.com'),
}


def build_futures_spec(venue: str) -> FuturesVenueSpec:
    try:
        return FUTURES_SPECS[venue.lower()]
    except KeyError as exc:
        raise ValueError(f'unsupported futures venue: {venue}') from exc


class FuturesFilterCatalog:
    def __init__(self) -> None:
        self._filters: dict[tuple[str, str], VenueFilter] = {}

    def upsert(self, venue_filter: VenueFilter) -> None:
        self._filters[(venue_filter.venue, venue_filter.symbol)] = venue_filter

    def get(self, venue: str, symbol: str) -> VenueFilter | None:
        return self._filters.get((venue, symbol))


class FuturesBrokerFactory:
    def __init__(self, metrics: MetricsRegistry) -> None:
        self.metrics = metrics

    def build(self, venue: str, credentials: ExchangeCredentials) -> dict[str, str]:
        spec = build_futures_spec(venue)
        self.metrics.increment(f'futures_broker_factory_{venue}_total')
        return {
            'venue': spec.venue,
            'rest_base': spec.rest_base,
            'market_ws': spec.market_ws,
            'private_ws': spec.private_ws,
            'api_key_set': str(bool(credentials.api_key)).lower(),
        }
