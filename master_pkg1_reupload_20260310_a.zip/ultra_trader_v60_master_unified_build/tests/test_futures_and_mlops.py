from pathlib import Path

from futures.analytics import FuturesAnalyticsService
from futures.models import DerivativeInstrument, FundingSnapshot, FuturesOrderIntent
from futures.portfolio import FuturesPortfolioService, FuturesPosition
from futures.risk import FuturesRiskService
from mlops.feature_store import FeatureRecord, FeatureStore
from mlops.model_registry import ModelRegistry
from mlops.trainer import OfflineTrainer, TrainingExample
from mlops.validation import WalkForwardValidator
from common.models import Side


def test_futures_risk_and_analytics():
    portfolio = FuturesPortfolioService()
    portfolio.register_instrument(DerivativeInstrument(venue='binance', symbol='BTCUSDT-PERP'))
    portfolio.upsert_position(FuturesPosition(symbol='BTCUSDT-PERP', venue='binance', qty=1.0, entry_price=100.0, mark_price=101.0, leverage=2.0))
    risk = FuturesRiskService(portfolio, max_leverage=3.0, min_liquidation_distance_bps=100.0)
    assert risk.check_intent(FuturesOrderIntent(strategy='f', venue='binance', symbol='BTCUSDT-PERP', side=Side.BUY, qty=0.1, leverage=2.0)).allowed
    assert not risk.check_intent(FuturesOrderIntent(strategy='f', venue='binance', symbol='BTCUSDT-PERP', side=Side.BUY, qty=0.1, leverage=10.0)).allowed
    analytics = FuturesAnalyticsService()
    analytics.observe_snapshot(FundingSnapshot(venue='binance', symbol='BTCUSDT-PERP', funding_rate=0.0001, open_interest=1_000_000, basis_bps=12.0))
    assert analytics.rank()[0].symbol == 'BTCUSDT-PERP'


def test_mlops_feature_store_training_registry(tmp_path: Path):
    store = FeatureStore(str(tmp_path / 'fs.jsonl'))
    for idx in range(6):
        store.append(FeatureRecord(symbol='BTC/USDT', features={'mom': float(idx), 'vol': float(5 - idx)}, label=1 if idx >= 3 else 0))
    records = store.read_all()
    assert len(records) == 6
    examples = [TrainingExample(features=r.features, label=int(r.label or 0)) for r in records]
    trainer = OfflineTrainer()
    model = trainer.train(examples)
    assert model
    report = WalkForwardValidator(trainer=trainer, folds=3).validate(examples)
    assert report.folds >= 1
    artifact = tmp_path / 'model.json'
    trainer.persist(model, str(artifact))
    registry = ModelRegistry(str(tmp_path / 'registry.json'))
    registry.register('entry_quality', 'v1', {'accuracy': report.accuracy}, str(artifact))
    assert registry.latest('entry_quality')['artifact_path'] == str(artifact)
