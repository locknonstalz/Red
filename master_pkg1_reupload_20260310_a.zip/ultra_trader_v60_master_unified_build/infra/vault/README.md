# Vault Integration Blueprint

This directory contains starter policies and an example AppRole workflow.
Replace all placeholders before production use.
