
# V51 Integrated Alpha Pipeline

This release integrates:
- V46 CEX alpha sleeves
- V47 deployment profiles and alpha scorecards
- V48 micro-live hardening guards
- V49 first-wave operator workflow
- V50 alpha factory and regime-aware specialist ensemble

Unified loop:
`discover -> test -> shadow -> micro_live -> score -> rotate capital`

Core modules:
- `integrated_alpha/pipeline.py`
- `ops/micro_live_controller.py`
- `ops/operator_review.py`
- `ops/rollout_manager.py`
- `alpha_factory/factory.py`
- `research/regime_ensemble.py`
- `scoreboard/alpha_scoreboard.py`
- `ops/micro_live_hardening.py`
