from storage.journal import SqliteJournal


def test_failover_lease_exclusive(tmp_path):
    journal = SqliteJournal(str(tmp_path / 'lease.db'))
    assert journal.acquire_failover_lease('private-stream:binance', 'node-a', 30)
    assert not journal.acquire_failover_lease('private-stream:binance', 'node-b', 30)
    assert journal.renew_failover_lease('private-stream:binance', 'node-a', 30)
    journal.release_failover_lease('private-stream:binance', 'node-a')
    assert journal.acquire_failover_lease('private-stream:binance', 'node-b', 30)
