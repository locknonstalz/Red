from pathlib import Path

from scripts import preflight


def test_preflight_ok(tmp_path, monkeypatch):
    repo = Path(__file__).resolve().parents[1]
    monkeypatch.chdir(repo)
    monkeypatch.setenv('TRADING_MODE', 'paper')
    monkeypatch.setenv('DEFAULT_VENUE', 'binance')
    monkeypatch.setenv('SQLITE_PATH', str(tmp_path / 'ok.db'))
    monkeypatch.setenv('CONTROL_PLANE_AUTH_SECRET', 'not-default')
    monkeypatch.setenv('CONTROL_PLANE_AUDIT_SECRET', 'not-default-audit')
    assert preflight.main() == 0


def test_preflight_live_missing_creds(tmp_path, monkeypatch):
    repo = Path(__file__).resolve().parents[1]
    monkeypatch.chdir(repo)
    monkeypatch.setenv('TRADING_MODE', 'live')
    monkeypatch.setenv('LIVE_VENUES', 'binance,bybit')
    monkeypatch.setenv('DEFAULT_VENUE', 'binance')
    monkeypatch.setenv('SQLITE_PATH', str(tmp_path / 'live.db'))
    monkeypatch.delenv('BINANCE_API_KEY', raising=False)
    monkeypatch.delenv('BINANCE_API_SECRET', raising=False)
    monkeypatch.delenv('BYBIT_API_KEY', raising=False)
    monkeypatch.delenv('BYBIT_API_SECRET', raising=False)
    assert preflight.main() == 1
