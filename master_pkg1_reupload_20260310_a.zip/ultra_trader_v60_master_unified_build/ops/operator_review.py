
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List

@dataclass
class DailyOperatorReview:
    strategy: str
    metrics: Dict[str, float | str]
    guard_snapshot: Dict[str, object]
    recommendation: str

    def to_lines(self) -> List[str]:
        return [
            f"strategy: {self.strategy}",
            f"net_pnl: {self.metrics.get('net_pnl', 0.0)}",
            f"fees: {self.metrics.get('fees', 0.0)}",
            f"slippage_cost: {self.metrics.get('slippage_cost', 0.0)}",
            f"funding_drag: {self.metrics.get('funding_drag', 0.0)}",
            f"hedge_cost: {self.metrics.get('hedge_cost', 0.0)}",
            f"recommendation: {self.recommendation}",
        ]
