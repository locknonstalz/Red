from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext, simpledialog, ttk
from typing import Any

APP_DIR = Path(__file__).resolve().parent
APP_PY = APP_DIR / 'app.py'
PREFLIGHT_PY = APP_DIR / 'scripts' / 'preflight.py'
ENV_FILE = APP_DIR / '.env'
LOG_DIR = APP_DIR / 'logs'
RUNTIME_LOG = LOG_DIR / 'gui_runtime.log'

ORDER_MESSAGES = {
    'order_submitted', 'order_submit', 'submit_order', 'order_created', 'order_placed',
    'filled', 'fill', 'order_filled', 'order_partially_filled', 'order_cancelled', 'order_closed'
}
POSITION_MESSAGES = {
    'position_opened', 'position_closed', 'position_update', 'position_changed',
    'hedge_opened', 'hedge_closed'
}
STRATEGY_KEYS = [
    ('ENABLE_FUNDING_CARRY', 'Funding Carry'),
    ('ENABLE_CROSS_EXCHANGE_ARBITRAGE', 'Cross Exchange Arbitrage'),
    ('ENABLE_MARKET_MAKING', 'Market Making'),
    ('ENABLE_STATISTICAL_ARBITRAGE', 'Statistical Arbitrage'),
    ('ENABLE_LIQUIDITY_TAKING', 'Liquidity Taking'),
    ('ENABLE_LIQUIDATION_CASCADE', 'Liquidation Cascade'),
    ('ENABLE_MOMENTUM', 'Momentum'),
]
IMPORTANT_ENV = [
    'TRADING_MODE', 'DEFAULT_VENUE', 'LIVE_VENUES', 'DEFAULT_SYMBOL', 'MAX_TOTAL_NOTIONAL',
    'MAX_ORDER_NOTIONAL', 'MICRO_LIVE_MIN_TARGET_NOTIONAL', 'ENABLE_FUNDING_CARRY',
    'FUNDING_CARRY_TRADE_SIZE', 'FUNDING_CARRY_MIN_FUNDING_RATE', 'FUNDING_CARRY_MIN_BASIS_BPS',
    'FUNDING_CARRY_MAX_BASIS_BPS', 'ONLY_CLOSE_MODE', 'GLOBAL_KILL_SWITCH'
]


class ProcessReader(threading.Thread):
    def __init__(self, stream, out_queue: queue.Queue[tuple[str, str]], kind: str) -> None:
        super().__init__(daemon=True)
        self.stream = stream
        self.out_queue = out_queue
        self.kind = kind

    def run(self) -> None:
        try:
            for line in iter(self.stream.readline, ''):
                if not line:
                    break
                self.out_queue.put((self.kind, line.rstrip('\n')))
        finally:
            try:
                self.stream.close()
            except Exception:
                pass


class FirstRunWizard(tk.Toplevel):
    def __init__(self, master: 'UltraTraderGUI') -> None:
        super().__init__(master)
        self.master_gui = master
        self.title('Мастер первого запуска')
        self.geometry('620x560')
        self.transient(master)
        self.grab_set()
        self.resizable(False, False)
        self.vars: dict[str, tk.StringVar] = {}
        self._build()
        self._prefill()

    def _build(self) -> None:
        frm = ttk.Frame(self, padding=16)
        frm.pack(fill='both', expand=True)
        ttk.Label(frm, text='Мастер первого запуска Ultra Trader', font=('Segoe UI', 16, 'bold')).pack(anchor='w')
        ttk.Label(frm, text='Заполните основные безопасные параметры. Мастер сохранит их в .env.', wraplength=580).pack(anchor='w', pady=(6, 14))
        fields = [
            ('TRADING_MODE', 'Режим', ['paper', 'micro_live', 'live']),
            ('DEFAULT_SYMBOL', 'Символ', None),
            ('DEFAULT_VENUE', 'Основная биржа', ['binance', 'bybit', 'mexc', 'bitget']),
            ('LIVE_VENUES', 'Live venues (через запятую)', None),
            ('MAX_TOTAL_NOTIONAL', 'Общий лимит notional', None),
            ('MAX_ORDER_NOTIONAL', 'Лимит на ордер', None),
            ('MICRO_LIVE_MIN_TARGET_NOTIONAL', 'Минимальный micro-live budget', None),
            ('FUNDING_CARRY_TRADE_SIZE', 'Размер funding carry', None),
        ]
        self.body = ttk.Frame(frm)
        self.body.pack(fill='x')
        for idx, (key, title, choices) in enumerate(fields):
            row = ttk.Frame(self.body)
            row.pack(fill='x', pady=5)
            ttk.Label(row, text=title, width=28).pack(side='left')
            var = tk.StringVar(value='')
            self.vars[key] = var
            if choices:
                box = ttk.Combobox(row, textvariable=var, values=choices, state='readonly', width=36)
                box.pack(side='left', fill='x', expand=True)
            else:
                ent = ttk.Entry(row, textvariable=var, width=40)
                ent.pack(side='left', fill='x', expand=True)
        strat_box = ttk.LabelFrame(frm, text='Стратегии', padding=10)
        strat_box.pack(fill='x', pady=(14, 10))
        self.strategy_vars: dict[str, tk.BooleanVar] = {}
        for idx, (key, title) in enumerate(STRATEGY_KEYS):
            v = tk.BooleanVar(value=(key == 'ENABLE_FUNDING_CARRY'))
            self.strategy_vars[key] = v
            ttk.Checkbutton(strat_box, text=title, variable=v).grid(row=idx//2, column=idx%2, sticky='w', padx=8, pady=4)
        notes = 'Совет: для первого запуска держите включённой только Funding Carry и режим micro_live.'
        ttk.Label(frm, text=notes, foreground='#555').pack(anchor='w', pady=(2, 12))
        btns = ttk.Frame(frm)
        btns.pack(fill='x', pady=(10,0))
        ttk.Button(btns, text='Сохранить и закрыть', command=self._save).pack(side='right')
        ttk.Button(btns, text='Отмена', command=self.destroy).pack(side='right', padx=8)

    def _prefill(self) -> None:
        env = self.master_gui.env_dict()
        defaults = {
            'TRADING_MODE': env.get('TRADING_MODE', 'micro_live'),
            'DEFAULT_SYMBOL': env.get('DEFAULT_SYMBOL', env.get('SYMBOL', 'BTC/USDT')),
            'DEFAULT_VENUE': env.get('DEFAULT_VENUE', 'binance'),
            'LIVE_VENUES': env.get('LIVE_VENUES', 'binance,bybit'),
            'MAX_TOTAL_NOTIONAL': env.get('MAX_TOTAL_NOTIONAL', '100'),
            'MAX_ORDER_NOTIONAL': env.get('MAX_ORDER_NOTIONAL', '15'),
            'MICRO_LIVE_MIN_TARGET_NOTIONAL': env.get('MICRO_LIVE_MIN_TARGET_NOTIONAL', '10'),
            'FUNDING_CARRY_TRADE_SIZE': env.get('FUNDING_CARRY_TRADE_SIZE', '0.0001'),
        }
        for k, v in defaults.items():
            self.vars[k].set(v)
        for k, _ in STRATEGY_KEYS:
            self.strategy_vars[k].set(env.get(k, '0') == '1' or k == 'ENABLE_FUNDING_CARRY')

    def _save(self) -> None:
        for key, var in self.vars.items():
            self.master_gui.set_env_value(key, var.get(), autosave=False)
        for key, var in self.strategy_vars.items():
            self.master_gui.set_env_value(key, '1' if var.get() else '0', autosave=False)
        self.master_gui.save_env_table(show_message=False)
        self.master_gui.refresh_env_table()
        self.master_gui.refresh_strategy_panel()
        messagebox.showinfo('Мастер', 'Базовые параметры сохранены в .env. Теперь можно запустить Preflight или Start.', parent=self)
        self.destroy()


class UltraTraderGUI(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title('Ultra Trader Control Center v3')
        self.geometry('1460x960')
        self.minsize(1280, 860)
        self._setup_style()

        self.process: subprocess.Popen[str] | None = None
        self.queue: queue.Queue[tuple[str, str]] = queue.Queue()
        self.readers: list[ProcessReader] = []
        self.last_runtime_snapshot: dict[str, Any] = {}
        self.last_waiting_reason: str = '—'
        self.last_block_reason: str = '—'
        self.last_event: str = 'Ожидание запуска'
        self.start_time: float | None = None
        self.order_rows: list[dict[str, Any]] = []
        self.position_rows: list[dict[str, Any]] = []
        self.metrics_history: list[dict[str, float]] = []
        self.env_rows: list[tuple[str, str]] = []
        self.env_index: dict[str, int] = {}

        LOG_DIR.mkdir(exist_ok=True)

        self.status_vars = {
            'engine': tk.StringVar(value='Остановлен'),
            'mode': tk.StringVar(value='—'),
            'venues': tk.StringVar(value='—'),
            'stage': tk.StringVar(value='—'),
            'target_notional': tk.StringVar(value='—'),
            'budget_reason': tk.StringVar(value='—'),
            'equity': tk.StringVar(value='—'),
            'portfolio': tk.StringVar(value='—'),
            'signal_reason': tk.StringVar(value='—'),
            'last_event': tk.StringVar(value=self.last_event),
            'uptime': tk.StringVar(value='—'),
            'log_file': tk.StringVar(value=str(RUNTIME_LOG)),
            'risk_flags': tk.StringVar(value='kill=False | only_close=False'),
            'daily_loss': tk.StringVar(value='—'),
            'drawdown': tk.StringVar(value='—'),
            'orders_count': tk.StringVar(value='0'),
            'positions_count': tk.StringVar(value='0'),
        }

        self._build_ui()
        self.refresh_env_table()
        self.refresh_strategy_panel()
        self.after(200, self._pump_queue)
        self.after(1000, self._tick_uptime)
        self.protocol('WM_DELETE_WINDOW', self._on_close)

    def _setup_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use('clam')
        except Exception:
            pass
        style.configure('Header.TLabel', font=('Segoe UI', 18, 'bold'))
        style.configure('SubHeader.TLabel', foreground='#555')
        style.configure('Accent.TButton', font=('Segoe UI', 10, 'bold'))

    def _build_ui(self) -> None:
        header = ttk.Frame(self, padding=12)
        header.pack(fill='x')
        ttk.Label(header, text='Ultra Trader Control Center v3', style='Header.TLabel').pack(side='left')
        ttk.Label(header, text='Панель оператора: запуск, стратегии, риск, графики, конфиг и диагностика', style='SubHeader.TLabel').pack(side='left', padx=16)

        controls = ttk.Frame(self, padding=(12, 0, 12, 8))
        controls.pack(fill='x')
        buttons = [
            ('Мастер первого запуска', self.open_wizard),
            ('Preflight', self.run_preflight),
            ('Start', self.start_engine),
            ('Stop', self.stop_engine),
            ('Restart', self.restart_engine),
            ('Открыть .env', self.open_env),
            ('Открыть папку проекта', self.open_project_dir),
            ('Сохранить лог как…', self.save_log_as),
            ('Обновить .env в GUI', self.refresh_env_table),
            ('Очистить лог в окне', self.clear_log),
        ]
        for idx, (text, cmd) in enumerate(buttons):
            style = 'Accent.TButton' if text in {'Start', 'Restart', 'Мастер первого запуска'} else 'TButton'
            ttk.Button(controls, text=text, command=cmd, style=style).pack(side='left', padx=(0, 8))

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill='both', expand=True, padx=12, pady=8)

        self.dashboard_tab = ttk.Frame(self.notebook, padding=12)
        self.logs_tab = ttk.Frame(self.notebook, padding=12)
        self.strategies_tab = ttk.Frame(self.notebook, padding=12)
        self.trading_tab = ttk.Frame(self.notebook, padding=12)
        self.risk_tab = ttk.Frame(self.notebook, padding=12)
        self.chart_tab = ttk.Frame(self.notebook, padding=12)
        self.config_tab = ttk.Frame(self.notebook, padding=12)
        self.diagnostics_tab = ttk.Frame(self.notebook, padding=12)

        self.notebook.add(self.dashboard_tab, text='Панель')
        self.notebook.add(self.logs_tab, text='Логи')
        self.notebook.add(self.strategies_tab, text='Стратегии')
        self.notebook.add(self.trading_tab, text='Ордера и позиции')
        self.notebook.add(self.risk_tab, text='Риск и режим')
        self.notebook.add(self.chart_tab, text='Графики')
        self.notebook.add(self.config_tab, text='Конфигурация')
        self.notebook.add(self.diagnostics_tab, text='Диагностика')

        self._build_dashboard()
        self._build_logs()
        self._build_strategies_tab()
        self._build_trading_tab()
        self._build_risk_tab()
        self._build_chart_tab()
        self._build_config_tab()
        self._build_diagnostics()

    def open_wizard(self) -> None:
        FirstRunWizard(self)

    def _kv(self, parent: ttk.Frame, title: str, var: tk.StringVar, row: int, col: int) -> None:
        box = ttk.LabelFrame(parent, text=title, padding=10)
        box.grid(row=row, column=col, sticky='nsew', padx=6, pady=6)
        ttk.Label(box, textvariable=var, font=('Segoe UI', 11, 'bold'), wraplength=320, justify='left').pack(anchor='w')

    def _build_dashboard(self) -> None:
        grid = ttk.Frame(self.dashboard_tab)
        grid.pack(fill='x')
        for i in range(4):
            grid.columnconfigure(i, weight=1)
        items = [
            ('Состояние движка', 'engine'), ('Режим', 'mode'), ('Биржи', 'venues'), ('Stage стратегии', 'stage'),
            ('Target notional', 'target_notional'), ('Причина бюджета', 'budget_reason'), ('Equity', 'equity'), ('Портфель', 'portfolio'),
            ('Риск-флаги', 'risk_flags'), ('Daily loss', 'daily_loss'), ('Drawdown', 'drawdown'), ('Причина no-trade', 'signal_reason'),
            ('Ордера', 'orders_count'), ('Позиции', 'positions_count'), ('Последнее событие', 'last_event'), ('Uptime', 'uptime'),
        ]
        for idx, (title, key) in enumerate(items):
            self._kv(grid, title, self.status_vars[key], idx // 4, idx % 4)
        runtime_frame = ttk.LabelFrame(self.dashboard_tab, text='Снимок runtime_started / runtime state', padding=10)
        runtime_frame.pack(fill='both', expand=True, pady=(12, 0))
        self.snapshot_text = scrolledtext.ScrolledText(runtime_frame, height=18, wrap='word', font=('Consolas', 10))
        self.snapshot_text.pack(fill='both', expand=True)
        self.snapshot_text.insert('1.0', 'После запуска здесь появится структурированный снимок runtime_started.
')
        self.snapshot_text.configure(state='disabled')

    def _build_logs(self) -> None:
        top = ttk.Frame(self.logs_tab)
        top.pack(fill='x')
        ttk.Label(top, text='Живой лог движка', font=('Segoe UI', 11, 'bold')).pack(side='left')
        ttk.Button(top, text='Показать только торговые события', command=self.filter_trade_logs).pack(side='left', padx=10)
        ttk.Button(top, text='Показать только диагностику no-trade', command=self.filter_diagnostics).pack(side='left')
        self.log_text = scrolledtext.ScrolledText(self.logs_tab, height=35, wrap='none', font=('Consolas', 10))
        self.log_text.pack(fill='both', expand=True, pady=(8, 0))

    def _build_strategies_tab(self) -> None:
        top = ttk.Frame(self.strategies_tab)
        top.pack(fill='x')
        ttk.Button(top, text='Включить только Funding Carry', command=self.enable_only_funding_carry).pack(side='left', padx=(0, 8))
        ttk.Button(top, text='Включить все стратегии', command=self.enable_all_strategies).pack(side='left', padx=(0, 8))
        ttk.Button(top, text='Обновить статусы', command=self.refresh_strategy_panel).pack(side='left')
        self.strategy_tree = ttk.Treeview(self.strategies_tab, columns=('name', 'enabled', 'stage', 'health', 'last_reason'), show='headings', height=10)
        for col, width in [('name', 240), ('enabled', 110), ('stage', 110), ('health', 110), ('last_reason', 520)]:
            self.strategy_tree.heading(col, text=col)
            self.strategy_tree.column(col, width=width, stretch=True)
        self.strategy_tree.pack(fill='x', pady=(12, 10))
        summary = ttk.LabelFrame(self.strategies_tab, text='Подсказки по стратегиям', padding=10)
        summary.pack(fill='both', expand=True)
        self.strategy_notes = scrolledtext.ScrolledText(summary, height=16, wrap='word', font=('Segoe UI', 10))
        self.strategy_notes.pack(fill='both', expand=True)
        self.strategy_notes.insert('1.0', 'Здесь появляются подсказки по включённым стратегиям и их текущим блокерам.
')

    def _build_trading_tab(self) -> None:
        split = ttk.Panedwindow(self.trading_tab, orient='vertical')
        split.pack(fill='both', expand=True)
        orders_frame = ttk.LabelFrame(split, text='Ордера / события исполнения', padding=8)
        positions_frame = ttk.LabelFrame(split, text='Позиции / состояния', padding=8)
        split.add(orders_frame, weight=1)
        split.add(positions_frame, weight=1)
        self.orders_tree = ttk.Treeview(orders_frame, columns=('ts', 'message', 'symbol', 'side', 'qty', 'price', 'venue', 'status'), show='headings', height=10)
        for col, width in [('ts', 170), ('message', 170), ('symbol', 110), ('side', 80), ('qty', 90), ('price', 100), ('venue', 90), ('status', 100)]:
            self.orders_tree.heading(col, text=col)
            self.orders_tree.column(col, width=width, stretch=True)
        self.orders_tree.pack(fill='both', expand=True)
        self.positions_tree = ttk.Treeview(positions_frame, columns=('ts', 'message', 'symbol', 'side', 'size', 'entry', 'venue', 'state'), show='headings', height=10)
        for col, width in [('ts', 170), ('message', 170), ('symbol', 110), ('side', 80), ('size', 90), ('entry', 100), ('venue', 90), ('state', 100)]:
            self.positions_tree.heading(col, text=col)
            self.positions_tree.column(col, width=width, stretch=True)
        self.positions_tree.pack(fill='both', expand=True)

    def _build_risk_tab(self) -> None:
        top = ttk.Frame(self.risk_tab)
        top.pack(fill='x')
        ttk.Button(top, text='Включить only-close в .env', command=lambda: self.set_env_value('ONLY_CLOSE_MODE', '1')).pack(side='left', padx=(0, 8))
        ttk.Button(top, text='Включить kill switch в .env', command=lambda: self.set_env_value('GLOBAL_KILL_SWITCH', '1')).pack(side='left', padx=(0, 8))
        ttk.Button(top, text='Снять stop-флаги в .env', command=self.reset_safety_flags).pack(side='left', padx=(0, 8))
        ttk.Label(top, text='Изменения применятся после Restart.').pack(side='left', padx=12)
        grid = ttk.Frame(self.risk_tab)
        grid.pack(fill='x', pady=(12, 0))
        for i in range(3): grid.columnconfigure(i, weight=1)
        for idx, (title, key) in enumerate([
            ('Risk flags', 'risk_flags'), ('Daily loss', 'daily_loss'), ('Drawdown', 'drawdown'),
            ('Target notional', 'target_notional'), ('Budget reason', 'budget_reason'), ('Причина no-trade', 'signal_reason'),
        ]):
            self._kv(grid, title, self.status_vars[key], idx // 3, idx % 3)
        self.risk_text = scrolledtext.ScrolledText(self.risk_tab, height=18, wrap='word', font=('Consolas', 10))
        self.risk_text.pack(fill='both', expand=True, pady=(12, 0))
        self.risk_text.insert('1.0', 'Сюда попадают важные защитные и блокирующие события.
')

    def _build_chart_tab(self) -> None:
        top = ttk.Frame(self.chart_tab)
        top.pack(fill='x')
        ttk.Label(top, text='Equity / Gross Notional / Target Notional', font=('Segoe UI', 11, 'bold')).pack(side='left')
        ttk.Button(top, text='Очистить историю', command=self.clear_chart_history).pack(side='left', padx=10)
        self.chart_canvas = tk.Canvas(self.chart_tab, bg='#111827', height=420, highlightthickness=0)
        self.chart_canvas.pack(fill='both', expand=True, pady=(12, 0))
        self.chart_canvas.bind('<Configure>', lambda _e: self.redraw_chart())

    def _build_config_tab(self) -> None:
        controls = ttk.Frame(self.config_tab)
        controls.pack(fill='x')
        ttk.Button(controls, text='Обновить из .env', command=self.refresh_env_table).pack(side='left', padx=(0, 8))
        ttk.Button(controls, text='Сохранить в .env', command=self.save_env_table).pack(side='left', padx=(0, 8))
        ttk.Button(controls, text='Показать важные параметры', command=self.filter_config_important).pack(side='left', padx=(0, 8))
        ttk.Label(controls, text='Двойной клик по значению для изменения.').pack(side='left', padx=12)
        self.env_tree = ttk.Treeview(self.config_tab, columns=('key', 'value'), show='headings')
        self.env_tree.heading('key', text='Ключ')
        self.env_tree.heading('value', text='Значение')
        self.env_tree.column('key', width=320, stretch=False)
        self.env_tree.column('value', width=760, stretch=True)
        self.env_tree.pack(fill='both', expand=True, pady=(10, 0))
        self.env_tree.bind('<Double-1>', self.edit_env_cell)

    def _build_diagnostics(self) -> None:
        top = ttk.Frame(self.diagnostics_tab)
        top.pack(fill='x')
        ttk.Button(top, text='Показать только no-trade события', command=self.filter_diagnostics).pack(side='left', padx=(0, 8))
        ttk.Button(top, text='Сводка ENV', command=self.refresh_env_summary).pack(side='left', padx=(0, 8))
        ttk.Button(top, text='Показать trade lifecycle', command=self.filter_trade_logs).pack(side='left')
        self.diag_text = scrolledtext.ScrolledText(self.diagnostics_tab, height=30, wrap='word', font=('Consolas', 10))
        self.diag_text.pack(fill='both', expand=True, pady=(8, 0))
        self.diag_text.insert('1.0', 'Сюда попадут strategy_waiting, strategy_signal_blocked, preflight и важные диагностические события.
')

    def append_log(self, line: str, target: scrolledtext.ScrolledText | None = None) -> None:
        widget = target or self.log_text
        widget.insert('end', line + '
')
        widget.see('end')

    def clear_log(self) -> None:
        for widget in (self.log_text, self.diag_text, self.risk_text):
            widget.delete('1.0', 'end')

    def save_log_as(self) -> None:
        path = filedialog.asksaveasfilename(defaultextension='.log', filetypes=[('Log files', '*.log'), ('Text files', '*.txt'), ('All files', '*.*')])
        if not path:
            return
        Path(path).write_text(self.log_text.get('1.0', 'end'), encoding='utf-8')
        messagebox.showinfo('Сохранено', f'Лог сохранён в
{path}')

    def open_env(self) -> None:
        try:
            os.startfile(str(ENV_FILE))
        except Exception:
            messagebox.showinfo('Открыть .env', f'Откройте файл вручную:
{ENV_FILE}')

    def open_project_dir(self) -> None:
        try:
            os.startfile(str(APP_DIR))
        except Exception:
            messagebox.showinfo('Открыть папку', f'Откройте папку вручную:
{APP_DIR}')

    def env_dict(self) -> dict[str, str]:
        return {k: v for k, v in self.env_rows}

    def _read_env_lines(self) -> list[str]:
        if not ENV_FILE.exists():
            return []
        return ENV_FILE.read_text(encoding='utf-8', errors='ignore').splitlines()

    def refresh_env_table(self) -> None:
        self.env_tree.delete(*self.env_tree.get_children())
        self.env_rows.clear(); self.env_index.clear()
        for line in self._read_env_lines():
            stripped = line.strip()
            if not stripped or stripped.startswith('#') or '=' not in line:
                continue
            key, value = line.split('=', 1)
            idx = len(self.env_rows)
            self.env_rows.append((key, value)); self.env_index[key] = idx
            self.env_tree.insert('', 'end', iid=str(idx), values=(key, value))

    def save_env_table(self, show_message: bool=True) -> None:
        lines = self._read_env_lines()
        by_key = {k: v for k, v in self.env_rows}
        existing_keys = []
        output: list[str] = []
        seen: set[str] = set()
        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith('#') or '=' not in line:
                output.append(line)
                continue
            key, _old = line.split('=', 1)
            existing_keys.append(key)
            if key in by_key:
                output.append(f'{key}={by_key[key]}'); seen.add(key)
            else:
                output.append(line)
        for key, value in self.env_rows:
            if key not in seen and key not in existing_keys:
                output.append(f'{key}={value}')
        ENV_FILE.write_text('
'.join(output) + '
', encoding='utf-8')
        if show_message:
            messagebox.showinfo('Сохранено', 'Изменения в .env сохранены. Для применения сделайте Restart.')

    def set_env_value(self, key: str, value: str, autosave: bool=True) -> None:
        if key in self.env_index:
            idx = self.env_index[key]
            self.env_rows[idx] = (key, value)
            self.env_tree.item(str(idx), values=(key, value))
        else:
            idx = len(self.env_rows)
            self.env_rows.append((key, value)); self.env_index[key] = idx
            self.env_tree.insert('', 'end', iid=str(idx), values=(key, value))
        if autosave:
            self.save_env_table()
            self.refresh_strategy_panel()

    def reset_safety_flags(self) -> None:
        self.set_env_value('ONLY_CLOSE_MODE', '0', autosave=False)
        self.set_env_value('GLOBAL_KILL_SWITCH', '0', autosave=False)
        self.save_env_table(); self.refresh_env_table(); self.refresh_strategy_panel()

    def enable_only_funding_carry(self) -> None:
        for key, _ in STRATEGY_KEYS:
            self.set_env_value(key, '1' if key == 'ENABLE_FUNDING_CARRY' else '0', autosave=False)
        self.save_env_table(); self.refresh_env_table(); self.refresh_strategy_panel()

    def enable_all_strategies(self) -> None:
        for key, _ in STRATEGY_KEYS:
            self.set_env_value(key, '1', autosave=False)
        self.save_env_table(); self.refresh_env_table(); self.refresh_strategy_panel()

    def refresh_strategy_panel(self) -> None:
        if not hasattr(self, 'strategy_tree'):
            return
        self.strategy_tree.delete(*self.strategy_tree.get_children())
        env = self.env_dict()
        health = {}
        if self.last_runtime_snapshot:
            for row in self.last_runtime_snapshot.get('alpha_governance', {}).get('health', []):
                health[row.get('strategy', '')] = row
        self.strategy_notes.delete('1.0', 'end')
        for key, title in STRATEGY_KEYS:
            strategy_key = title.lower().replace(' ', '_')
            row = health.get(strategy_key) or health.get('funding_carry' if 'FUNDING' in key else strategy_key, {})
            enabled = 'Да' if env.get(key, '0') == '1' else 'Нет'
            stage = str(row.get('stage', self.status_vars['stage'].get() if key == 'ENABLE_FUNDING_CARRY' else '—'))
            healthy = 'Да' if row.get('healthy', False) else ('—' if not row else 'Нет')
            reason = self.last_waiting_reason if key == 'ENABLE_FUNDING_CARRY' else '—'
            self.strategy_tree.insert('', 'end', values=(title, enabled, stage, healthy, reason))
            note = f'• {title}: включена={enabled}, stage={stage}, healthy={healthy}'
            if reason != '—':
                note += f', blocker={reason}'
            self.strategy_notes.insert('end', note + '
')
        self.strategy_notes.insert('end', '
Совет: для первого live-rollout держите включённой только Funding Carry, пока не увидите первый корректный fill.
')

    def filter_config_important(self) -> None:
        self.env_tree.selection_remove(*self.env_tree.selection())
        first = None
        for iid in self.env_tree.get_children():
            key = self.env_tree.item(iid, 'values')[0]
            if key in IMPORTANT_ENV or any(tok in key for tok in ['FUNDING_CARRY_', 'MICRO_LIVE_', 'KILL', 'ONLY_CLOSE']):
                self.env_tree.selection_add(iid)
                if first is None:
                    first = iid
        if first:
            self.env_tree.see(first)

    def edit_env_cell(self, event: tk.Event) -> None:
        item = self.env_tree.identify_row(event.y)
        col = self.env_tree.identify_column(event.x)
        if not item or col != '#2':
            return
        x, y, width, height = self.env_tree.bbox(item, col)
        old_value = self.env_tree.item(item, 'values')[1]
        entry = ttk.Entry(self.env_tree)
        entry.place(x=x, y=y, width=width, height=height)
        entry.insert(0, old_value)
        entry.focus_set()
        def save_edit(_event=None) -> None:
            new_value = entry.get()
            key = self.env_tree.item(item, 'values')[0]
            idx = int(item)
            self.env_rows[idx] = (key, new_value)
            self.env_tree.item(item, values=(key, new_value))
            entry.destroy()
        entry.bind('<Return>', save_edit)
        entry.bind('<FocusOut>', save_edit)

    def refresh_env_summary(self) -> None:
        self.append_log('--- ENV SUMMARY ---', self.diag_text)
        for key, value in self.env_rows:
            if key in IMPORTANT_ENV or any(token in key for token in ['FUNDING_CARRY_', 'MICRO_LIVE_']):
                self.append_log(f'{key}={value}', self.diag_text)

    def run_preflight(self) -> None:
        threading.Thread(target=self._run_preflight_worker, daemon=True).start()

    def _run_preflight_worker(self) -> None:
        cmd = [sys.executable, str(PREFLIGHT_PY)]
        self.queue.put(('diag', f"$ {' '.join(cmd)}"))
        try:
            proc = subprocess.run(cmd, cwd=APP_DIR, capture_output=True, text=True, check=False)
            output = (proc.stdout or '') + (proc.stderr or '')
            for line in output.splitlines():
                self.queue.put(('diag', line))
            self.queue.put(('event', f'Preflight завершён с кодом {proc.returncode}'))
        except Exception as exc:
            self.queue.put(('diag', f'Ошибка preflight: {exc}'))

    def start_engine(self) -> None:
        if self.process and self.process.poll() is None:
            messagebox.showinfo('Движок уже запущен', 'Сначала остановите текущий процесс или нажмите Restart.')
            return
        self.start_time = time.time(); self.last_event = 'Запуск процесса app.py'
        self.status_vars['last_event'].set(self.last_event); self.status_vars['engine'].set('Запускается…')
        cmd = [sys.executable, str(APP_PY)]
        self.append_log(f"$ {' '.join(cmd)}")
        with RUNTIME_LOG.open('a', encoding='utf-8') as fh:
            fh.write(f"
=== START {time.strftime('%Y-%m-%d %H:%M:%S')} ===
")
        self.process = subprocess.Popen(cmd, cwd=APP_DIR, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, text=True, bufsize=1)
        self.readers = [ProcessReader(self.process.stdout, self.queue, 'stdout'), ProcessReader(self.process.stderr, self.queue, 'stderr')]
        for reader in self.readers: reader.start()

    def stop_engine(self) -> None:
        if not self.process or self.process.poll() is not None:
            self.status_vars['engine'].set('Остановлен'); self.status_vars['last_event'].set('Процесс уже остановлен'); return
        self.last_event = 'Остановка процесса'; self.status_vars['last_event'].set(self.last_event)
        self.process.terminate(); self.after(3000, self._force_kill_if_needed)

    def _force_kill_if_needed(self) -> None:
        if self.process and self.process.poll() is None: self.process.kill()

    def restart_engine(self) -> None:
        self.stop_engine(); self.after(1500, self.start_engine)

    def _append_metric_point(self, payload: dict[str, Any]) -> None:
        protection = payload.get('protection', {}); portfolio = payload.get('portfolio', {}); budgets = payload.get('capital_scaling', {}).get('budgets', [])
        target = float(budgets[0].get('target_notional', 0.0)) if budgets else 0.0
        point = {'equity': float(protection.get('equity', 0.0) or 0.0), 'gross': float(portfolio.get('gross_notional', 0.0) or 0.0), 'target': target}
        self.metrics_history.append(point); self.metrics_history = self.metrics_history[-200:]; self.redraw_chart()

    def _update_from_runtime(self, payload: dict[str, Any]) -> None:
        self.last_runtime_snapshot = payload; self.status_vars['engine'].set('Работает')
        self.status_vars['mode'].set(str(payload.get('mode', '—'))); self.status_vars['venues'].set(', '.join(payload.get('venues', [])) or '—')
        health = payload.get('alpha_governance', {}).get('health', [])
        if health: self.status_vars['stage'].set(str(health[0].get('stage', '—')))
        budgets = payload.get('capital_scaling', {}).get('budgets', [])
        if budgets:
            budget = budgets[0]
            self.status_vars['target_notional'].set(str(budget.get('target_notional', '—')))
            self.status_vars['budget_reason'].set(str(budget.get('reason', '—')))
        protection = payload.get('protection', {})
        self.status_vars['equity'].set(str(protection.get('equity', '—')))
        self.status_vars['daily_loss'].set(str(protection.get('daily_loss', '—')))
        self.status_vars['drawdown'].set(str(protection.get('drawdown', '—')))
        self.status_vars['risk_flags'].set(f"kill={protection.get('global_kill_switch', False)} | only_close={protection.get('only_close_mode', False)}")
        portfolio = payload.get('portfolio', {})
        self.status_vars['portfolio'].set(f"realized={portfolio.get('realized_pnl', '—')}, unrealized={portfolio.get('unrealized_pnl', '—')}, gross={portfolio.get('gross_notional', '—')}")
        self.status_vars['signal_reason'].set(self.last_waiting_reason if self.last_waiting_reason != '—' else self.last_block_reason)
        pretty = json.dumps(payload, ensure_ascii=False, indent=2)
        self.snapshot_text.configure(state='normal'); self.snapshot_text.delete('1.0', 'end'); self.snapshot_text.insert('1.0', pretty); self.snapshot_text.configure(state='disabled')
        self._append_metric_point(payload); self.refresh_strategy_panel()

    def _extract_field(self, payload: dict[str, Any], *keys: str) -> Any:
        for key in keys:
            if key in payload: return payload[key]
        return ''

    def _insert_order_event(self, payload: dict[str, Any]) -> None:
        row = {'ts': payload.get('ts', ''), 'message': payload.get('message', ''), 'symbol': self._extract_field(payload, 'symbol', 'instrument'), 'side': self._extract_field(payload, 'side', 'direction'), 'qty': self._extract_field(payload, 'qty', 'size', 'quantity'), 'price': self._extract_field(payload, 'price', 'avg_price', 'entry_price'), 'venue': self._extract_field(payload, 'venue', 'exchange'), 'status': self._extract_field(payload, 'status', 'state', 'result')}
        self.order_rows.append(row); self.order_rows = self.order_rows[-200:]; self.orders_tree.insert('', 0, values=tuple(row.values()))
        if len(self.orders_tree.get_children()) > 200: self.orders_tree.delete(self.orders_tree.get_children()[-1])
        self.status_vars['orders_count'].set(str(len(self.order_rows)))

    def _insert_position_event(self, payload: dict[str, Any]) -> None:
        row = {'ts': payload.get('ts', ''), 'message': payload.get('message', ''), 'symbol': self._extract_field(payload, 'symbol', 'instrument'), 'side': self._extract_field(payload, 'side', 'direction'), 'size': self._extract_field(payload, 'size', 'qty', 'quantity'), 'entry': self._extract_field(payload, 'entry_price', 'price', 'avg_price'), 'venue': self._extract_field(payload, 'venue', 'exchange'), 'state': self._extract_field(payload, 'state', 'status', 'result')}
        self.position_rows.append(row); self.position_rows = self.position_rows[-200:]; self.positions_tree.insert('', 0, values=tuple(row.values()))
        if len(self.positions_tree.get_children()) > 200: self.positions_tree.delete(self.positions_tree.get_children()[-1])
        self.status_vars['positions_count'].set(str(len(self.position_rows)))

    def _handle_json_log(self, line: str) -> None:
        try: payload = json.loads(line)
        except Exception: return
        message = payload.get('message')
        if message == 'runtime_started':
            self._update_from_runtime(payload); self.last_event = 'runtime_started'; self.status_vars['last_event'].set(self.last_event)
        elif message == 'runtime_stopped':
            self.status_vars['engine'].set('Остановлен'); self.last_event = 'runtime_stopped'; self.status_vars['last_event'].set(self.last_event)
        elif message == 'strategy_waiting':
            reason = str(payload.get('reason', payload.get('blocker', 'unknown'))); self.last_waiting_reason = reason; self.status_vars['signal_reason'].set(reason)
            self.append_log(json.dumps(payload, ensure_ascii=False), self.diag_text); self.append_log(json.dumps(payload, ensure_ascii=False), self.risk_text); self.refresh_strategy_panel()
        elif message == 'strategy_signal_blocked':
            reason = str(payload.get('reason', 'unknown')); self.last_block_reason = reason; self.status_vars['signal_reason'].set(reason)
            self.append_log(json.dumps(payload, ensure_ascii=False), self.diag_text); self.append_log(json.dumps(payload, ensure_ascii=False), self.risk_text); self.refresh_strategy_panel()
        elif message in ORDER_MESSAGES:
            self.last_event = message; self.status_vars['last_event'].set(message); self._insert_order_event(payload); self.append_log(json.dumps(payload, ensure_ascii=False), self.diag_text)
        elif message in POSITION_MESSAGES:
            self.last_event = message; self.status_vars['last_event'].set(message); self._insert_position_event(payload); self.append_log(json.dumps(payload, ensure_ascii=False), self.diag_text)

    def _pump_queue(self) -> None:
        while True:
            try: kind, line = self.queue.get_nowait()
            except queue.Empty: break
            if kind in {'stdout', 'stderr'}:
                prefix = '' if kind == 'stdout' else '[stderr] '
                self.append_log(prefix + line)
                with RUNTIME_LOG.open('a', encoding='utf-8') as fh: fh.write(prefix + line + '
')
                if any(x in line for x in ['strategy_waiting', 'strategy_signal_blocked', 'order_submit_started', 'order_submit_validated', 'order_submit_succeeded', 'order_submit_failed', 'signal_accepted_for_execution', 'Preflight', 'submit', 'filled', 'position']): self.append_log(prefix + line, self.diag_text)
                self._handle_json_log(line)
            elif kind == 'diag': self.append_log(line, self.diag_text)
            elif kind == 'event': self.last_event = line; self.status_vars['last_event'].set(line)
        if self.process and self.process.poll() is not None:
            code = self.process.returncode
            if self.status_vars['engine'].get() != 'Остановлен':
                self.status_vars['engine'].set(f'Остановлен (код {code})'); self.status_vars['last_event'].set(f'Процесс завершён с кодом {code}')
            self.process = None
        self.after(200, self._pump_queue)

    def filter_diagnostics(self) -> None:
        source = self.log_text.get('1.0', 'end').splitlines()
        lines = [line for line in source if any(x in line for x in ['strategy_waiting', 'strategy_signal_blocked', 'order_submit_started', 'order_submit_validated', 'order_submit_succeeded', 'order_submit_failed', 'missing_market_tick', 'allocator', 'score_below_threshold', 'no-trade'])]
        self.diag_text.delete('1.0', 'end')
        self.diag_text.insert('1.0', ('
'.join(lines) + '
') if lines else 'Диагностические события no-trade пока не найдены в текущем логе.
')

    def filter_trade_logs(self) -> None:
        source = self.log_text.get('1.0', 'end').splitlines()
        lines = [line for line in source if any(x in line for x in ['submit', 'order', 'filled', 'position'])]
        self.diag_text.delete('1.0', 'end')
        self.diag_text.insert('1.0', ('
'.join(lines) + '
') if lines else 'Торговые события пока не найдены в текущем логе.
')

    def clear_chart_history(self) -> None:
        self.metrics_history.clear(); self.redraw_chart()

    def redraw_chart(self) -> None:
        canvas = self.chart_canvas; canvas.delete('all'); width = max(canvas.winfo_width(), 600); height = max(canvas.winfo_height(), 300); margin = 40
        canvas.create_rectangle(0, 0, width, height, fill='#111827', outline='')
        canvas.create_text(16, 16, text='Equity', fill='#93c5fd', anchor='w', font=('Segoe UI', 10, 'bold'))
        canvas.create_text(86, 16, text='Gross', fill='#34d399', anchor='w', font=('Segoe UI', 10, 'bold'))
        canvas.create_text(146, 16, text='Target', fill='#fbbf24', anchor='w', font=('Segoe UI', 10, 'bold'))
        canvas.create_line(margin, height - margin, width - margin, height - margin, fill='#374151')
        canvas.create_line(margin, margin, margin, height - margin, fill='#374151')
        if len(self.metrics_history) < 2:
            canvas.create_text(width / 2, height / 2, text='После нескольких снимков runtime здесь появятся графики.', fill='#9ca3af', font=('Segoe UI', 12)); return
        series_names = ['equity', 'gross', 'target']; colors = {'equity': '#93c5fd', 'gross': '#34d399', 'target': '#fbbf24'}
        max_val = max(max(point[name] for point in self.metrics_history) for name in series_names); min_val = min(min(point[name] for point in self.metrics_history) for name in series_names)
        if max_val == min_val: max_val += 1.0; min_val -= 1.0
        for name in series_names:
            points = []
            for i, point in enumerate(self.metrics_history):
                x = margin + (width - 2 * margin) * (i / (len(self.metrics_history) - 1)); y = height - margin - (height - 2 * margin) * ((point[name] - min_val) / (max_val - min_val)); points.extend((x, y))
            canvas.create_line(*points, fill=colors[name], width=2, smooth=True)
        canvas.create_text(width - margin, margin - 10, text=f'min={min_val:.2f} | max={max_val:.2f}', fill='#9ca3af', anchor='e', font=('Segoe UI', 9))

    def _tick_uptime(self) -> None:
        if self.start_time and self.process and self.process.poll() is None:
            elapsed = int(time.time() - self.start_time); h, rem = divmod(elapsed, 3600); m, s = divmod(rem, 60); self.status_vars['uptime'].set(f'{h:02d}:{m:02d}:{s:02d}')
        self.after(1000, self._tick_uptime)

    def _on_close(self) -> None:
        if self.process and self.process.poll() is None:
            if not messagebox.askyesno('Закрыть GUI', 'Движок сейчас работает. Остановить процесс и закрыть интерфейс?'): return
            self.stop_engine(); self.after(1200, self.destroy)
        else: self.destroy()


if __name__ == '__main__':
    app = UltraTraderGUI()
    app.mainloop()
