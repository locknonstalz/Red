from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from common.models import StreamCheckpoint
from execution.live.recovery_engines import RecoveryRequest, get_recovery_engine
from storage.base import Journal


@dataclass(slots=True)
class ChoreographyStep:
    name: str
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class SessionLifecyclePlan:
    venue: str
    auth: list[ChoreographyStep]
    subscribe: list[ChoreographyStep]
    keepalive: list[ChoreographyStep]
    reauth: list[ChoreographyStep]
    recovery: list[RecoveryRequest]


class VenueSessionChoreographer:
    def build(self, venue: str, checkpoint: StreamCheckpoint | None, symbol: str | None = None) -> SessionLifecyclePlan:
        engine = get_recovery_engine(venue)
        auth = [ChoreographyStep('authenticate', {'venue': venue})]
        subscribe = [ChoreographyStep('subscribe-private', {'venue': venue, 'symbol': symbol or 'ALL'})]
        keepalive = []
        reauth = [ChoreographyStep('re-authenticate', {'venue': venue})]
        if venue == 'binance':
            subscribe = [ChoreographyStep('userDataStream.subscribe', {'resume_from': checkpoint.sequence if checkpoint else None})]
            reauth = [ChoreographyStep('session.logon', {}), ChoreographyStep('userDataStream.subscribe', {})]
        elif venue == 'bybit':
            subscribe = [ChoreographyStep('subscribe', {'topics': ['order', 'execution', 'wallet']})]
            keepalive = [ChoreographyStep('ping', {'op': 'ping'})]
        elif venue == 'mexc':
            auth = [ChoreographyStep('create-listen-key', {}), ChoreographyStep('connect-listen-key', {})]
            keepalive = [ChoreographyStep('extend-listen-key', {})]
            reauth = [ChoreographyStep('rotate-listen-key', {})]
        elif venue == 'bitget':
            subscribe = [ChoreographyStep('subscribe', {'channels': ['orders', 'account']})]
            keepalive = [ChoreographyStep('ping', {'op': 'ping'})]
        return SessionLifecyclePlan(venue=venue, auth=auth, subscribe=subscribe, keepalive=keepalive, reauth=reauth, recovery=engine.build_requests(checkpoint, symbol))


class LeaseCoordinator:
    def __init__(self, journal: Journal, owner: str, ttl_sec: int = 30) -> None:
        self.journal = journal
        self.owner = owner
        self.ttl_sec = ttl_sec

    def acquire(self, lease_name: str) -> bool:
        return self.journal.acquire_failover_lease(lease_name, self.owner, self.ttl_sec)

    def renew(self, lease_name: str) -> bool:
        return self.journal.renew_failover_lease(lease_name, self.owner, self.ttl_sec)

    def release(self, lease_name: str) -> None:
        self.journal.release_failover_lease(lease_name, self.owner)
