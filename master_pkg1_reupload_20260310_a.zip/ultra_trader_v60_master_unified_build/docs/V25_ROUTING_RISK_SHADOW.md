# V25 Smart Routing, Venue Health, Advanced Risk, Shadow Deployment

Добавлено:
- `SmartOrderRouter` — выбор venue по цене и health-score.
- `VenueHealthScoringService` — score по spread/volatility/execution failures.
- `CorrelationConcentrationRiskGuard` — лимиты на concentration и correlated exposure.
- `ShadowDeploymentService` — shadow-режим для стратегий без реального исполнения.

## Новые env
- `SMART_ROUTING_ENABLED=1`
- `SMART_ROUTING_STRATEGIES=liquidity_taking,momentum`
- `SMART_ROUTING_HEALTH_WEIGHT=0.35`
- `ADVANCED_RISK_ENABLED=1`
- `MAX_VENUE_NOTIONAL=8000`
- `MAX_SYMBOL_CONCENTRATION_PCT=0.45`
- `MAX_CORRELATED_EXPOSURE_PCT=0.65`
- `CORRELATION_WINDOW=32`
- `CORRELATION_THRESHOLD=0.90`
- `SHADOW_ENABLED=0`
- `SHADOW_STRATEGIES=momentum`

## Что это даёт
- агрессивные стратегии можно маршрутизировать на более здоровую биржу;
- риск-контур режет перекосы по symbol/venue и correlated books;
- новые стратегии можно запускать в shadow перед боевым включением.
