from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class ResearchSignal:
    source: str
    symbol: str
    score: float
    confidence: float = 0.5
    tags: dict[str, str] = field(default_factory=dict)


class ExternalResearchIngestionLayer:
    def __init__(self) -> None:
        self._signals: dict[str, list[ResearchSignal]] = {}

    def ingest(self, signal: ResearchSignal) -> None:
        bucket = self._signals.setdefault(signal.symbol, [])
        bucket.append(signal)
        self._signals[signal.symbol] = bucket[-32:]

    def aggregate_score(self, symbol: str) -> float:
        bucket = self._signals.get(symbol, [])
        if not bucket:
            return 0.0
        weighted = sum(item.score * max(item.confidence, 0.0) for item in bucket)
        weights = sum(max(item.confidence, 0.0) for item in bucket)
        return weighted / weights if weights else 0.0
