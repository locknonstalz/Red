from common.models import Fill, Signal, Side, Tick
from research.asset_analysis import AssetAnalysisService
from research.attribution import StrategyAttributionService
from research.candle_patterns import CandlePatternEngine
from research.external_research import ExternalResearchIngestionLayer, ResearchSignal
from research.indicators import IndicatorEngine
from research.regime import MarketRegimeClassifier
from research.scoring import SignalScoringLayer
from research.universe import UniverseSelectionEngine


def test_research_stack_scores_and_selects_assets():
    asset = AssetAnalysisService(window=16)
    indicators = IndicatorEngine()
    regime = MarketRegimeClassifier(window=16)
    candles = CandlePatternEngine(bucket_size=3)
    ext = ExternalResearchIngestionLayer()
    scorer = SignalScoringLayer(asset, indicators, regime, ext, min_score=0.2)
    for price in [100, 100.2, 100.4, 100.5, 100.6, 100.8, 101.0, 101.1, 101.2]:
        tick = Tick(venue='binance', symbol='BTC/USDT', price=price, bid=price - 0.05, ask=price + 0.05)
        asset.observe_tick(tick)
        indicators.observe_tick(tick)
        regime.observe_tick(tick)
        candles.observe_tick(tick)
    ext.ingest(ResearchSignal(source='news', symbol='BTC/USDT', score=0.8, confidence=0.9))
    decision = scorer.score(Signal(strategy='momentum_xover', venue='binance', symbol='BTC/USDT', side=Side.BUY, strength=0.7, reason='test', qty=0.01), Tick(venue='binance', symbol='BTC/USDT', price=101.2, bid=101.15, ask=101.25))
    assert decision.accepted
    selector = UniverseSelectionEngine(asset, min_quality_score=0.0)
    selection = selector.select([('binance', 'BTC/USDT')])
    assert selection.selected
    assert candles.latest_patterns('binance', 'BTC/USDT')


def test_strategy_attribution_tracks_realized_pnl():
    svc = StrategyAttributionService()
    svc.observe_fill(Fill(client_order_id='1', venue='binance', symbol='BTC/USDT', side=Side.BUY, qty=1, price=100, strategy='alpha'))
    svc.observe_fill(Fill(client_order_id='2', venue='binance', symbol='BTC/USDT', side=Side.SELL, qty=1, price=102, strategy='alpha'))
    snap = svc.snapshot()['alpha']
    assert snap.realized_pnl > 0
    assert snap.fills == 2
