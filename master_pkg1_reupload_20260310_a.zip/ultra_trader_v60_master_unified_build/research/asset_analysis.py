from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from math import sqrt

from common.models import Tick


@dataclass(slots=True)
class AssetSnapshot:
    venue: str
    symbol: str
    last_price: float
    spread_bps: float
    realized_vol_bps: float
    liquidity_score: float
    noise_score: float
    quality_score: float


class AssetAnalysisService:
    def __init__(self, window: int = 64) -> None:
        self.window = max(window, 8)
        self._prices: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=self.window))
        self._spreads: dict[tuple[str, str], deque[float]] = defaultdict(lambda: deque(maxlen=self.window))

    def observe_tick(self, tick: Tick) -> None:
        key = (tick.venue, tick.symbol)
        self._prices[key].append(float(tick.mid))
        self._spreads[key].append(float(tick.spread))

    def snapshot(self, venue: str, symbol: str) -> AssetSnapshot | None:
        key = (venue, symbol)
        prices = self._prices.get(key)
        spreads = self._spreads.get(key)
        if not prices:
            return None
        last = prices[-1]
        spread_bps = ((sum(spreads) / len(spreads)) / last * 10000.0) if spreads and last else 0.0
        returns = []
        for a, b in zip(prices, list(prices)[1:]):
            if a:
                returns.append((b - a) / a)
        realized_vol_bps = sqrt(sum(r * r for r in returns) / len(returns)) * 10000.0 if returns else 0.0
        liquidity_score = max(0.0, 100.0 - spread_bps - realized_vol_bps * 0.2)
        noise_score = min(100.0, realized_vol_bps + spread_bps * 0.5)
        quality_score = max(0.0, min(100.0, liquidity_score - noise_score * 0.25 + 25.0))
        return AssetSnapshot(venue=venue, symbol=symbol, last_price=last, spread_bps=spread_bps, realized_vol_bps=realized_vol_bps, liquidity_score=liquidity_score, noise_score=noise_score, quality_score=quality_score)

    def rank(self, symbols: list[tuple[str, str]]) -> list[AssetSnapshot]:
        snapshots = [snap for venue, symbol in symbols if (snap := self.snapshot(venue, symbol)) is not None]
        return sorted(snapshots, key=lambda s: (s.quality_score, s.liquidity_score, -s.noise_score), reverse=True)
