from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class DriftSnapshot:
    missing_fills: int = 0
    duplicate_events: int = 0
    position_drift_abs: float = 0.0
    balance_drift_abs: float = 0.0
    stale_private_stream_sec: float = 0.0


@dataclass
class TruthDriftSentinel:
    max_missing_fills: int = 0
    max_duplicate_events: int = 0
    max_position_drift_abs: float = 0.0
    max_balance_drift_abs: float = 0.0
    max_stale_private_stream_sec: float = 15.0

    def evaluate(self, snap: DriftSnapshot) -> Dict[str, object]:
        breaches: List[str] = []
        if snap.missing_fills > self.max_missing_fills:
            breaches.append("missing_fills")
        if snap.duplicate_events > self.max_duplicate_events:
            breaches.append("duplicate_events")
        if snap.position_drift_abs > self.max_position_drift_abs:
            breaches.append("position_drift")
        if snap.balance_drift_abs > self.max_balance_drift_abs:
            breaches.append("balance_drift")
        if snap.stale_private_stream_sec > self.max_stale_private_stream_sec:
            breaches.append("stale_private_stream")
        status = "block" if breaches else "ok"
        only_close = bool(breaches)
        return {"status": status, "only_close": only_close, "breaches": breaches}


@dataclass
class CostMetrics:
    gross_pnl: float = 0.0
    net_pnl: float = 0.0
    fees: float = 0.0
    slippage_cost: float = 0.0
    funding_drag: float = 0.0
    hedge_cost: float = 0.0


@dataclass
class CostDragGuard:
    max_fee_share_of_gross: float = 0.40
    max_slippage_bps: float = 6.0
    max_hedge_share_of_gross: float = 0.20
    require_positive_net_pnl: bool = True
    notional_traded: float = 1.0

    def evaluate(self, metrics: CostMetrics) -> Dict[str, object]:
        breaches: List[str] = []
        gross = max(abs(metrics.gross_pnl), 1e-9)
        fee_share = abs(metrics.fees) / gross
        hedge_share = abs(metrics.hedge_cost) / gross
        slippage_bps = (abs(metrics.slippage_cost) / max(self.notional_traded, 1e-9)) * 10000
        if fee_share > self.max_fee_share_of_gross:
            breaches.append("fee_share")
        if slippage_bps > self.max_slippage_bps:
            breaches.append("slippage_bps")
        if hedge_share > self.max_hedge_share_of_gross:
            breaches.append("hedge_share")
        if self.require_positive_net_pnl and metrics.net_pnl <= 0:
            breaches.append("net_pnl")
        verdict = "do_not_scale" if breaches else "scale_candidate"
        return {
            "verdict": verdict,
            "breaches": breaches,
            "fee_share": fee_share,
            "hedge_share": hedge_share,
            "slippage_bps": slippage_bps,
        }


@dataclass
class StrategyRunStats:
    strategy: str
    stage: str = "micro_live"
    days_live: int = 0
    net_pnl_days_positive: int = 0
    incidents_open: int = 0
    truth_breaches_last_7d: int = 0
    cost_guard_breaches_last_7d: int = 0
    operator_overrides_last_7d: int = 0


@dataclass
class MicroLiveStabilityGate:
    min_days_live: int = 7
    min_positive_days: int = 5
    max_incidents_open: int = 0
    max_truth_breaches_last_7d: int = 0
    max_cost_guard_breaches_last_7d: int = 1
    max_operator_overrides_last_7d: int = 0

    def evaluate(self, stats: StrategyRunStats) -> Dict[str, object]:
        reasons: List[str] = []
        if stats.days_live < self.min_days_live:
            reasons.append("insufficient_live_days")
        if stats.net_pnl_days_positive < self.min_positive_days:
            reasons.append("insufficient_positive_days")
        if stats.incidents_open > self.max_incidents_open:
            reasons.append("incidents_open")
        if stats.truth_breaches_last_7d > self.max_truth_breaches_last_7d:
            reasons.append("truth_breaches")
        if stats.cost_guard_breaches_last_7d > self.max_cost_guard_breaches_last_7d:
            reasons.append("cost_guard_breaches")
        if stats.operator_overrides_last_7d > self.max_operator_overrides_last_7d:
            reasons.append("operator_overrides")
        promote = not reasons
        return {"promote": promote, "reasons": reasons, "recommended_action": "scale_gradually" if promote else "hold"}


@dataclass
class MicroLiveHardeningService:
    truth: TruthDriftSentinel = field(default_factory=TruthDriftSentinel)
    cost: CostDragGuard = field(default_factory=CostDragGuard)
    stability: MicroLiveStabilityGate = field(default_factory=MicroLiveStabilityGate)

    def snapshot(self, drift: DriftSnapshot, cost: CostMetrics, stats: StrategyRunStats) -> Dict[str, object]:
        truth_eval = self.truth.evaluate(drift)
        cost_eval = self.cost.evaluate(cost)
        stability_eval = self.stability.evaluate(stats)
        final_action = "only_close" if truth_eval["only_close"] else stability_eval["recommended_action"]
        if not truth_eval["only_close"] and cost_eval["verdict"] == "do_not_scale":
            final_action = "hold"
        return {
            "truth": truth_eval,
            "cost": cost_eval,
            "stability": stability_eval,
            "final_action": final_action,
        }
